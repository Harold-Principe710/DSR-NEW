# DesireAI - Gerar Imagem com Seedream 4.5

Site extraído do template `_template-gerar-imagem-seedream`, baseado no Big-AI.  
**Funcionalidade:** Geração de imagens em 4K usando apenas o modelo **Seedream 4.5**.

## Configuração

1. **Variáveis de ambiente**
   - Copie `.env.example` para `.env`
   - Configure `DATABASE_URL` (PostgreSQL)
   - Configure `KIE_API_KEY` (chave da KIE.AI para Seedream)
   - Configure `SESSION_SECRET` para autenticação

2. **Banco de dados**
   ```bash
   npm run db:push
   ```

3. **Rodar o projeto**
   ```bash
   npm run dev
   ```

4. Acesse `http://localhost:5000` e faça login para usar a página **Gerar Imagem**.

## Estrutura

- `client/` – Frontend React (Vite)
- `server/` – Backend Express
- `shared/` – Schema compartilhado (apenas Seedream 4.5 em `IMAGE_MODELS`)
