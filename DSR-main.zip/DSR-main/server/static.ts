import express, { type Express } from "express";
import fs from "fs";
import path from "path";

const DIST_PATH = path.resolve(__dirname, "public");
const PERSISTENT_UPLOAD_DIR = path.resolve(process.cwd(), "uploads");
const IMMUTABLE_ASSET_CACHE = "public, max-age=31536000, immutable";
const SHORT_PUBLIC_CACHE = "public, max-age=3600";
const HTML_CACHE = "no-cache";

function assertDistExists() {
  if (fs.existsSync(DIST_PATH)) return;
  throw new Error(
    `Could not find the build directory: ${DIST_PATH}, make sure to build the client first`,
  );
}

function setDistStaticHeaders(res: express.Response, filePath: string) {
  const normalizedPath = filePath.split(path.sep).join("/");
  if (normalizedPath.includes("/assets/")) {
    res.setHeader("Cache-Control", IMMUTABLE_ASSET_CACHE);
    return;
  }

  if (normalizedPath.endsWith("/index.html")) {
    res.setHeader("Cache-Control", HTML_CACHE);
    return;
  }

  res.setHeader("Cache-Control", SHORT_PUBLIC_CACHE);
}

function setImmutableAssetHeaders(res: express.Response) {
  res.setHeader("Cache-Control", IMMUTABLE_ASSET_CACHE);
}

export function serveStaticAssetFastPaths(app: Express) {
  assertDistExists();

  const assetsPath = path.join(DIST_PATH, "assets");
  if (fs.existsSync(assetsPath)) {
    app.use("/assets", express.static(assetsPath, {
      fallthrough: true,
      setHeaders: setImmutableAssetHeaders,
    }));
  }

  const videoPostersPath = path.join(DIST_PATH, "video-posters");
  if (fs.existsSync(videoPostersPath)) {
    app.use("/video-posters", express.static(videoPostersPath, {
      fallthrough: true,
      maxAge: "1h",
    }));
  }

  if (fs.existsSync(PERSISTENT_UPLOAD_DIR)) {
    app.use("/uploads", express.static(PERSISTENT_UPLOAD_DIR, {
      fallthrough: true,
      maxAge: "1h",
    }));
  }
}

export function serveStatic(app: Express) {
  assertDistExists();

  app.use(express.static(DIST_PATH, {
    index: false,
    fallthrough: true,
    setHeaders: setDistStaticHeaders,
  }));

  // fall through to index.html if the file doesn't exist
  app.use("*", (_req, res) => {
    res.setHeader("Cache-Control", HTML_CACHE);
    res.sendFile(path.resolve(DIST_PATH, "index.html"));
  });
}
