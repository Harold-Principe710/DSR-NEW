/**
 * A/B testing middleware + cache.
 * - Caches active tests in memory (30s TTL) to avoid hitting Postgres on every request.
 * - Assigns a sticky variant per (session, test) and stores it on req.session.abAssignment.
 * - Increments variant visits atomically via SQL `visits = visits + 1`.
 */
import type { Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { isBotRequest } from "./botDetection";
import type { AbTest, AbVariant } from "@shared/schema";
import crypto from "crypto";

type ActiveTest = AbTest & { variants: AbVariant[] };

const CACHE_TTL_MS = 30 * 1000;
export const AB_PREVIEW_TOKEN_TTL_MS = 60 * 60 * 1000;

let cachedTests: ActiveTest[] = [];
let cachedAt = 0;
let inflight: Promise<ActiveTest[]> | null = null;

function refreshActiveTests(): Promise<ActiveTest[]> {
  if (inflight) return inflight;
  inflight = storage
    .getActiveAbTests()
    .then((tests) => {
      cachedTests = tests;
      cachedAt = Date.now();
      return tests;
    })
    .catch((err) => {
      console.error("[ab-testing] Failed to load active tests:", err);
      cachedAt = Date.now();
      return cachedTests;
    })
    .finally(() => {
      inflight = null;
    });
  return inflight;
}

async function getActiveTests(): Promise<ActiveTest[]> {
  const now = Date.now();
  if (now - cachedAt < CACHE_TTL_MS) return cachedTests;
  return refreshActiveTests();
}

function getCachedActiveTests(): ActiveTest[] {
  const now = Date.now();
  if (now - cachedAt >= CACHE_TTL_MS) {
    void refreshActiveTests();
  }
  return cachedTests;
}

/** Forces the next request to refetch active tests (call after CRUD changes). */
export function invalidateAbTestsCache() {
  cachedAt = 0;
  cachedTests = [];
}

/** Warms the A/B cache without blocking app readiness or request TTFB. */
export function warmAbTestsCache() {
  void refreshActiveTests();
}

/** Find the active test whose publicPath matches the request path. */
export async function findActiveTestByPath(path: string): Promise<ActiveTest | null> {
  const tests = await getActiveTests();
  return tests.find((t) => t.publicPath === path) ?? null;
}

function findCachedActiveTestByPath(path: string): ActiveTest | null {
  const tests = getCachedActiveTests();
  return tests.find((t) => t.publicPath === path) ?? null;
}

/** Find the active test by slug. */
export async function findActiveTestBySlug(slug: string): Promise<ActiveTest | null> {
  const tests = await getActiveTests();
  return tests.find((t) => t.slug === slug) ?? null;
}

/** Weighted random selection. Falls back to last variant if rounding drifts. */
export function selectVariant(variants: AbVariant[]): AbVariant {
  const total = variants.reduce((sum, v) => sum + v.weight, 0);
  if (total <= 0) return variants[variants.length - 1];
  let rand = Math.random() * total;
  for (const variant of variants) {
    rand -= variant.weight;
    if (rand <= 0) return variant;
  }
  return variants[variants.length - 1];
}

function readAssignmentMap(req: Request): Record<string, string> {
  const session = req.session as any;
  if (!session) return {};
  if (!session.abAssignment || typeof session.abAssignment !== "object") {
    session.abAssignment = {};
  }
  return session.abAssignment as Record<string, string>;
}

function readPreviewAssignmentMap(req: Request): Record<string, string> {
  const session = req.session as any;
  if (!session) return {};
  if (!session.abPreviewAssignment || typeof session.abPreviewAssignment !== "object") {
    session.abPreviewAssignment = {};
  }
  return session.abPreviewAssignment as Record<string, string>;
}

function getPreviewSecret() {
  const configured = (process.env.AB_PREVIEW_SECRET || process.env.SESSION_SECRET || "").trim();
  if (configured) return configured;
  return process.env.NODE_ENV === "production" ? "" : "dev_secret_change_me";
}

function signPreviewPayload(testSlug: string, componentKey: string, expiresAtMs: number) {
  const secret = getPreviewSecret();
  if (!secret) return "";
  return crypto
    .createHmac("sha256", secret)
    .update(`${testSlug}.${componentKey}.${expiresAtMs}`)
    .digest("hex");
}

export function signAbPreviewToken(testSlug: string, componentKey: string, expiresAtMs = Date.now() + AB_PREVIEW_TOKEN_TTL_MS) {
  const signature = signPreviewPayload(testSlug, componentKey, expiresAtMs);
  return signature ? `${expiresAtMs}.${signature}` : "";
}

function verifyAbPreviewToken(testSlug: string, componentKey: string, token: unknown) {
  const raw = typeof token === "string" ? token.trim() : "";
  const [expiresAtRaw, signature = ""] = raw.split(".");
  const expiresAtMs = Number(expiresAtRaw);
  if (!Number.isFinite(expiresAtMs) || expiresAtMs < Date.now() || !signature) return false;

  const expected = signPreviewPayload(testSlug, componentKey, expiresAtMs);
  if (!expected || expected.length !== signature.length) return false;

  try {
    return crypto.timingSafeEqual(Buffer.from(signature, "hex"), Buffer.from(expected, "hex"));
  } catch {
    return false;
  }
}

/**
 * Returns the stored variantId for this session+test, or assigns a new one.
 * Increments visits asynchronously when a fresh assignment is made.
 * Returns null when the test has no variants.
 */
export function ensureAssignment(req: Request, test: ActiveTest): string | null {
  if (test.variants.length === 0) return null;
  const map = readAssignmentMap(req);
  const existing = map[test.slug];
  if (existing && test.variants.some((v) => v.id === existing)) {
    return existing;
  }
  const picked = selectVariant(test.variants);
  map[test.slug] = picked.id;
  delete readPreviewAssignmentMap(req)[test.slug];
  // Persist the session synchronously enough that subsequent requests see the
  // assignment. Express-session writes on response end, but we still want a
  // visit increment regardless of whether the session save succeeds.
  storage
    .incrementAbVariantVisits(picked.id)
    .catch((err) => console.error("[ab-testing] Failed to increment visits:", err));
  return picked.id;
}

/**
 * Forces a specific variant for this session without incrementing visits.
 * Triggered by a signed `?ab_preview=<componentKey>&ab_preview_token=...`
 * query on the public path so QA can open previews in a fresh/incognito tab
 * without letting arbitrary visitors self-select variants.
 */
function applyPreviewOverride(req: Request, test: ActiveTest): boolean {
  const previewKey = req.query?.ab_preview;
  if (typeof previewKey !== "string" || !previewKey) return false;
  const variant = test.variants.find((v) => v.componentKey === previewKey);
  if (!variant) return false;
  if (!verifyAbPreviewToken(test.slug, variant.componentKey, req.query?.ab_preview_token)) {
    console.warn("[ab-testing] Preview override rejected: invalid token", {
      testSlug: test.slug,
      componentKey: variant.componentKey,
    });
    return false;
  }
  const session = req.session as any;
  if (!session) return false;
  if (!session.abAssignment || typeof session.abAssignment !== "object") {
    session.abAssignment = {};
  }
  session.abAssignment[test.slug] = variant.id;
  readPreviewAssignmentMap(req)[test.slug] = variant.id;
  return true;
}

/**
 * Express middleware: when the request path matches an active test's publicPath,
 * ensures an A/B assignment exists in req.session for that test. Always calls
 * next() — never alters the response. Errors are logged and swallowed so the
 * SPA still loads if the cache or DB is misbehaving.
 *
 * Signed preview query params force a specific variant (writes session,
 * skips visit increment) so QA links from the admin panel work even in
 * fresh/incognito sessions.
 */
export function abTestingMiddleware(req: Request, _res: Response, next: NextFunction) {
  if (req.method !== "GET") return next();
  // Skip API and static asset requests early.
  if (
    req.path.startsWith("/api/") ||
    req.path.startsWith("/uploads/") ||
    req.path.startsWith("/assets/") ||
    req.path.startsWith("/@")
  ) {
    return next();
  }
  // Bots and automation must not touch visit counts or assignment.
  if (isBotRequest(req)) return next();
  if (typeof req.query?.ab_preview === "string") {
    findActiveTestByPath(req.path)
      .then((test) => {
        if (test) {
          if (!applyPreviewOverride(req, test)) {
            ensureAssignment(req, test);
          }
        }
        next();
      })
      .catch((err) => {
        console.error("[ab-testing] middleware error:", err);
        next();
      });
    return;
  }

  const test = findCachedActiveTestByPath(req.path);
  if (test) {
    ensureAssignment(req, test);
  }
  next();
}

/** Resolve the variantId currently assigned to this session for a test slug. */
export async function resolveAssignmentBySlug(
  req: Request,
  testSlug: string,
): Promise<{ test: ActiveTest; variantId: string } | null> {
  const test = await findActiveTestBySlug(testSlug);
  if (!test) return null;
  const variantId = ensureAssignment(req, test);
  if (!variantId) return null;
  return { test, variantId };
}
