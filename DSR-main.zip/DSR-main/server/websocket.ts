import { WebSocketServer, WebSocket } from "ws";
import { Server, IncomingMessage } from "http";
import { log } from "./index";
import { getSession } from "./sessionAuth";

const connections: Map<string, Set<WebSocket>> = new Map();

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: "/ws" });
  const sessionMiddleware = getSession();

  wss.on("connection", (ws, req: IncomingMessage) => {
    log("WebSocket client attempting connection...", "ws");

    let authenticatedUserId: string | null = null;

    const mockRes = {
      setHeader: () => { },
      getHeader: () => null,
      end: () => { },
    };

    sessionMiddleware(req as any, mockRes as any, () => {
      const session = (req as any).session;
      const sessionUserId = typeof session?.userId === "string" ? session.userId : null;

      if (sessionUserId) {
        const userId: string = sessionUserId;
        authenticatedUserId = userId;

        if (!connections.has(userId)) {
          connections.set(userId, new Set());
        }
        connections.get(userId)!.add(ws);

        log(`User ${userId} authenticated via WebSocket (session)`, "ws");
        ws.send(JSON.stringify({ type: "auth_success" }));
      } else {
        log("WebSocket: No valid session found, closing connection", "ws");
        ws.send(JSON.stringify({ type: "auth_failed", message: "No valid session" }));
        ws.close(4001, "Unauthorized");
        return;
      }
    });

    ws.on("close", () => {
      if (authenticatedUserId) {
        const userConnections = connections.get(authenticatedUserId);
        if (userConnections) {
          userConnections.delete(ws);
          if (userConnections.size === 0) {
            connections.delete(authenticatedUserId);
          }
          log(`User ${authenticatedUserId} disconnected from WebSocket`, "ws");
        }
      }
    });

    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
    });
  });

  log("WebSocket server initialized on /ws", "ws");
  return wss;
}

export function notifyUser(userId: string, event: string, data: any) {
  const userConnections = connections.get(userId);

  if (userConnections && userConnections.size > 0) {
    const message = JSON.stringify({ type: event, data });

    userConnections.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });

    log(`Notified user ${userId}: ${event}`, "ws");
    return true;
  }

  return false;
}

export function notifyVideoCompleted(userId: string, video: any) {
  return notifyUser(userId, "video_completed", video);
}

export function notifyVideoFailed(userId: string, video: any) {
  return notifyUser(userId, "video_failed", video);
}

export function notifyImageCompleted(userId: string, image: any) {
  return notifyUser(userId, "image_completed", image);
}

export function notifyImageFailed(userId: string, image: any) {
  return notifyUser(userId, "image_failed", image);
}

export function notifyAudioCompleted(userId: string, audio: any) {
  return notifyUser(userId, "audio_completed", audio);
}

export function notifyAudioFailed(userId: string, audio: any) {
  return notifyUser(userId, "audio_failed", audio);
}

export function notifyPixPaid(userId: string, payment: any) {
  return notifyUser(userId, "pix_paid", payment);
}
