import {
  users, sessions, userCredits, creditTransactions, adminAuditLog,
  affiliates, affiliateReferrals, affiliateEarnings, affiliatePayouts, generatedImages, webhookLogs,
  type UserCredits, type CreditTransaction, type InsertCreditTransaction,
  type AdminAuditLog, type InsertAdminAuditLog,
  type Affiliate, type InsertAffiliate, type AffiliateReferral, type AffiliateEarning, type AffiliatePayout,
  type GeneratedImage, type InsertGeneratedImage,
  type WebhookLog, type InsertWebhookLog,
  pixPayments, type PixPayment, type InsertPixPayment,
  userFingerprints, type UserFingerprint,
  videoPovRequests,
  type VideoPovPreviewAnalysisStatus,
  type VideoPovPreviewBodyType,
  type VideoPovPreviewProvider,
  type VideoPovPreviewSkinTone,
  type VideoPovRequest,
  funnelSessions, funnelEvents, paymentWebhookLogs,
  type FunnelSession, type FunnelStep, type FunnelEvent,
  type InsertPaymentWebhookLog, type PaymentWebhookLog,
  abTests, abVariants, abConversions,
  type AbTest, type InsertAbTest, type AbVariant, type InsertAbVariant, type InsertAbConversion
} from "@shared/schema";
import {
  type AdminPixProductKey,
  type AdminCustomerResponseKind,
  type AdminCustomerSortBy,
  type AdminCustomerSortDir,
  type AdminCustomerUnifiedRow,
} from "@shared/admin-types";
import { type User, type UpsertUser } from "@shared/models/auth";
import { db } from "./db";
import { addAppDays, endOfAppDay, parseAppDateInput, startOfAppDay } from "./timezone";
import { eq, desc, asc, and, or, sql, SQL, lte, gt, gte, ne, count, isNotNull, isNull, ilike, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface GalleryImage {
  id: string;
  imageUrl: string;
  prompt: string | null;
  type: "created" | "edited";
  createdAt: Date;
  isFavorite: boolean;
}

export type AdminResponsePaymentStatus = "paid" | "unpaid";
export type AdminCustomerLeadStage = "all" | "photo_generated" | "generation_error" | "first_screen";

export type VideoPovRequestUpdate = Partial<Pick<
  VideoPovRequest,
  "status" | "previewAnalysisImageUrl" | "previewAnalysisError" | "previewVideoKey" | "previewResolvedAt"
>> & {
  previewAnalysisStatus?: VideoPovPreviewAnalysisStatus;
  previewAnalysisProvider?: VideoPovPreviewProvider | null;
  previewVisualTone?: VideoPovPreviewSkinTone | null;
  previewBodyType?: VideoPovPreviewBodyType | null;
};

export type AdminRealPreviewLogRow = {
  requestId: string;
  sessionId: string | null;
  userId: string;
  username: string | null;
  customerName: string | null;
  customerEmail: string | null;
  paymentStatus: AdminResponsePaymentStatus;
  position: string;
  previewAnalysisStatus: string;
  previewAnalysisProvider: string | null;
  previewAnalysisError: string | null;
  previewVisualTone: string | null;
  previewBodyType: string | null;
  previewVideoKey: string | null;
  previewResolvedAt: Date | null;
  createdAt: Date | null;
  updatedAt: Date | null;
};

export type AdminRealPreviewLogsResult = {
  summary: {
    total: number;
    success: number;
    errors: number;
    previewFallbacks: number;
    aiFallbacks: number;
    pending: number;
    processing: number;
    openAiSuccess: number;
    geminiFallbackSuccess: number;
    avgResolveMs: number | null;
  };
  rows: AdminRealPreviewLogRow[];
  total: number;
};

export type PixPaymentMetrics = {
  created: number;
  converted: number;
  paid: number;
  activePaid: number;
  refunded: number;
  chargedback: number;
  grossRevenueCents: number;
  refundedCents: number;
  netRevenueCents: number;
};

export type AdminPackResponseRow = {
  id: string;
  sessionId: string;
  userId: string | null;
  username: string | null;
  email: string | null;
  customerName: string | null;
  customerEmail: string | null;
  paymentStatus: AdminResponsePaymentStatus;
  eventName: string;
  metadata: Record<string, unknown>;
  occurredAt: Date | null;
  kind: "pack";
};

export type AdminVideoPovResponseRow = {
  id: string;
  sessionId: string;
  userId: string | null;
  username: string | null;
  email: string | null;
  customerName: string | null;
  customerEmail: string | null;
  paymentStatus: AdminResponsePaymentStatus;
  eventName: string;
  metadata: Record<string, unknown>;
  occurredAt: Date | null;
  kind: "video_pov";
  requestId: string | null;
  position: string | null;
  hole: string | null;
  sexType: string | null;
  speechType: string | null;
  requestStatus: string | null;
  requestAmountCents: number | null;
  requestCreatedAt: Date | null;
};

const ADMIN_PACK_EVENT_NAME = "landing.pack_photos_submit";
const ADMIN_VIDEO_POV_EVENT_NAME = "offer.video_pov_submitted";
const FUNNEL_STEP_ORDER: FunnelStep[] = [
  "visitor_entered",
  "photo_uploaded",
  "generated_photo_viewed",
  "offer_viewed",
  "offer_responded",
  "video_loading_screen",
  "video_loaded",
  "pix_generated",
  "pix_paid",
];
const FUNNEL_STEP_RANK = new Map(FUNNEL_STEP_ORDER.map((step, index) => [step, index] as const));

const ADMIN_CUSTOMER_SORTABLE_COLUMNS = {
  createdAt: funnelSessions.createdAt,
  visitorLastSeenAt: funnelSessions.visitorLastSeenAt,
  maxStepReached: funnelSessions.maxStepReached,
  saleAmountCents: funnelSessions.saleAmountCents,
  paidAt: funnelSessions.paidAt,
};

function getMaxFunnelStep(left: FunnelStep, right: FunnelStep): FunnelStep {
  return (FUNNEL_STEP_RANK.get(left) ?? 0) >= (FUNNEL_STEP_RANK.get(right) ?? 0) ? left : right;
}

function toAdminMetadataRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
}

function sanitizeAdminOfferMetadata(
  metadata: Record<string, unknown>,
  allowedKeys: string[],
): Record<string, string | number | boolean> {
  const sanitized: Record<string, string | number | boolean> = {};

  for (const key of allowedKeys) {
    const value = metadata[key];
    if (
      typeof value === "string"
      || typeof value === "number"
      || typeof value === "boolean"
    ) {
      sanitized[key] = value;
    }
  }

  return sanitized;
}

function normalizeAbAssignments(value: unknown): Record<string, string> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const assignments: Record<string, string> = {};
  for (const [testSlug, variantId] of Object.entries(value as Record<string, unknown>)) {
    const cleanTestSlug = String(testSlug || "").trim();
    const cleanVariantId = typeof variantId === "string" ? variantId.trim() : "";
    if (cleanTestSlug && cleanVariantId) {
      assignments[cleanTestSlug] = cleanVariantId;
    }
  }
  return assignments;
}

function filterPreviewAbAssignments(assignments: Record<string, string>, previewAssignments: Record<string, string>) {
  return Object.fromEntries(
    Object.entries(assignments).filter(([testSlug, variantId]) => previewAssignments[testSlug] !== variantId),
  );
}

function buildAdminOfferResponseExistsCondition(eventName: typeof ADMIN_PACK_EVENT_NAME | typeof ADMIN_VIDEO_POV_EVENT_NAME): SQL {
  return sql`
    exists (
      select 1
      from ${funnelEvents}
      where ${funnelEvents.sessionId} = ${funnelSessions.sessionId}
        and ${funnelEvents.eventName} = ${eventName}
    )
  `;
}

function buildAdminResponseKindCondition(responseKind: AdminCustomerResponseKind): SQL {
  const hasPackResponse = buildAdminOfferResponseExistsCondition(ADMIN_PACK_EVENT_NAME);
  const hasVideoPovResponse = buildAdminOfferResponseExistsCondition(ADMIN_VIDEO_POV_EVENT_NAME);

  switch (responseKind) {
    case "pack":
      return and(hasPackResponse, sql`not (${hasVideoPovResponse})`)!;
    case "video_pov":
      return and(sql`not (${hasPackResponse})`, hasVideoPovResponse)!;
    case "both":
      return and(hasPackResponse, hasVideoPovResponse)!;
    case "none":
      return and(sql`not (${hasPackResponse})`, sql`not (${hasVideoPovResponse})`)!;
  }
}

function buildAdminPixProductCondition(pixProduct: AdminPixProductKey): SQL {
  const planIdSql = sql`(${funnelEvents.metadata} ->> 'planId')`;
  const journeyNodeSql = sql`lower(coalesce(${funnelEvents.metadata} ->> 'journeyNode', ''))`;

  const planMatch = (planIds: string[], extraCondition?: SQL) => {
    const planConditions = planIds.map((planId) => sql`${planIdSql} = ${planId}`);
    const anyPlanCondition = planConditions.length === 1
      ? planConditions[0]
      : or(...planConditions)!;

    return sql`
      exists (
        select 1
        from ${funnelEvents}
        where ${funnelEvents.sessionId} = ${funnelSessions.sessionId}
          and ${funnelEvents.step} = 'pix_generated'
          and ${anyPlanCondition}
          ${extraCondition ? sql`and ${extraCondition}` : sql``}
      )
    `;
  };

  switch (pixProduct) {
    case "single_photo":
      return planMatch(["1-foto", "1-foto-1990"]);
    case "pack_photos":
      return planMatch(["pack-fotos-1990", "pack-fotos-2990"]);
    case "video_pov":
      return planMatch(["video-pov-1990", "video-pov-990", "video-pov-promo-1990", "video-pov-2990"]);
    case "pack_photos_video_pov":
      return planMatch(["video-pov-pack-2990", "video-pov-pack-3990"], sql`${journeyNodeSql} like ${"%pack%"}`);
    case "video_pov_pack_photos":
      return planMatch(["video-pov-pack-2990", "video-pov-pack-3990"], sql`${journeyNodeSql} not like ${"%pack%"}`);
    case "unlimited_daily":
      return planMatch(["ilimitado"]);
    case "upsell_instapro_weekly":
      return planMatch(["upsell-instapro-semanal"]);
  }

  return sql`false`;
}

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUsersByIds(ids: string[]): Promise<User[]>;
  getUserCredits(userId: string): Promise<UserCredits | undefined>;
  getUserCreditsByStripeCustomerId(stripeCustomerId: string): Promise<UserCredits | undefined>;
  createUserCredits(userId: string, options?: { initialBalance?: number }): Promise<UserCredits>;
  claimDailyCredits(userId: string): Promise<{ credited: number; message: string }>;
  applyDailyCreditsIfNeeded(userId: string): Promise<{ credited: number; newBalance: number }>;
  consumeCreditsWithDailyFirst(userId: string, amount: number): Promise<UserCredits>;
  markUserAsPurchased(userId: string): Promise<void>;
  updateCredits(userId: string, amount: number, isSpending?: boolean): Promise<UserCredits>;
  updateUserStripeInfo(userId: string, info: { stripeCustomerId?: string; stripeSubscriptionId?: string }): Promise<UserCredits | undefined>;
  updateUserPlan(userId: string, planTier: string, subscriptionId: string | null, periodEnd?: Date): Promise<UserCredits | undefined>;
  grantMonthlyCredits(userId: string, credits: number, planName: string): Promise<void>;
  getActiveGenerationsCount(userId: string, type: 'video' | 'image' | 'audio'): Promise<number>;
  getCreditTransactions(userId: string): Promise<CreditTransaction[]>;
  createCreditTransaction(data: InsertCreditTransaction & { userId: string }): Promise<CreditTransaction>;
  claimWhatsAppBonus(userId: string, bonusAmount: number): Promise<{ success: boolean; message?: string; credited?: number }>;
  initiateWhatsAppShare(userId: string): Promise<{ success: boolean; waitSeconds: number; alreadyInitiated?: boolean; message?: string }>;
  getAllUsers(): Promise<User[]>;
  getStats(): Promise<{
    totalUsers: number;
    totalVideos: number;
    totalCreditsUsed: number;
    totalRevenue: number;
  }>;


  // Background removal methods
  // Extended Image methods
  // Affiliate program methods
  getAffiliateByUserId(userId: string): Promise<Affiliate | undefined>;
  getAffiliateByCode(code: string): Promise<Affiliate | undefined>;
  createAffiliate(data: InsertAffiliate): Promise<Affiliate>;
  updateAffiliate(id: string, data: Partial<Affiliate>): Promise<Affiliate | undefined>;
  getAffiliateReferrals(affiliateId: string): Promise<AffiliateReferral[]>;
  createAffiliateReferral(data: Partial<AffiliateReferral>): Promise<AffiliateReferral>;
  updateAffiliateReferral(id: string, data: Partial<AffiliateReferral>): Promise<AffiliateReferral | undefined>;
  getAffiliate(id: string): Promise<Affiliate | undefined>;
  getAffiliateEarnings(affiliateId: string): Promise<AffiliateEarning[]>;
  createAffiliateEarning(data: Partial<AffiliateEarning>): Promise<AffiliateEarning>;
  updateAffiliateEarning(id: string, data: Partial<AffiliateEarning>): Promise<AffiliateEarning | undefined>;
  getAffiliatePayouts(affiliateId: string): Promise<AffiliatePayout[]>;
  getAffiliatePayout(id: string): Promise<AffiliatePayout | undefined>;
  createAffiliatePayout(data: Partial<AffiliatePayout>): Promise<AffiliatePayout>;
  updateAffiliatePayout(id: string, data: Partial<AffiliatePayout>): Promise<AffiliatePayout | undefined>;
  updateAffiliateBalance(affiliateId: string, amount: number, type: 'add' | 'subtract'): Promise<void>;
  getAllAffiliates(): Promise<Affiliate[]>;
  getAllPendingPayouts(): Promise<AffiliatePayout[]>;
  getReferralByUserId(userId: string): Promise<AffiliateReferral | undefined>;
  getCalculatedBalances(affiliateId: string): Promise<{ available: number; pending: number }>;
  releaseAffiliateBalance(affiliateId: string): Promise<void>;

  // Audio methods
  // Lipsync methods
  // Sound effects methods
  // Generated images methods
  getGeneratedImages(userId: string, limit?: number, offset?: number): Promise<GeneratedImage[]>;
  getGeneratedImage(id: string): Promise<GeneratedImage | undefined>;
  getGeneratedImageByTaskId(taskId: string): Promise<GeneratedImage | undefined>;
  /** Returns image counts per userId, optionally filtered by createdAt range */
  getGeneratedImageCountsByUserInRange(dateFrom?: Date, dateTo?: Date): Promise<{ userId: string; count: number }[]>;
  /** Returns count and total credits per userId for analytics (optionally filtered by date) */
  getUsageByUserInRange(
    source: "lipsyncs" | "motionControls" | "filmProjects" | "generatedImages" | "imageEdits" | "backgroundRemovals" | "extendedImages" | "audios" | "soundEffects" | "transcriptions" | "chat",
    dateFrom?: Date,
    dateTo?: Date
  ): Promise<{ userId: string; count: number; totalCredits: number }[]>;
  createGeneratedImage(userId: string, data: InsertGeneratedImage & { creditCost: number }): Promise<GeneratedImage>;
  updateGeneratedImage(id: string, data: Partial<GeneratedImage>): Promise<GeneratedImage | undefined>;
  completeGeneratedImageIfActive(id: string, imageUrl: string, completedAt: Date): Promise<{ image?: GeneratedImage; transitioned: boolean }>;
  failGeneratedImageAndRefundIfActive(id: string, errorMessage: string, refundDescription: string): Promise<{
    image?: GeneratedImage;
    transitioned: boolean;
    refunded: boolean;
    freeSessionId: string | null;
  }>;
  deleteGeneratedImage(id: string): Promise<void>;
  userHasCompletedGeneratedImage(userId: string): Promise<boolean>;

  // Image Edit methods
  getGalleryImages(userId: string, filter: string, limit: number, offset: number): Promise<{ items: GalleryImage[]; total: number }>;

  // Monthly usage limits methods
  resetMonthlyUsage(userId: string): Promise<void>;
  incrementMonthlyImageCount(userId: string): Promise<void>;
  // Chat methods
  // Webhook log methods
  createWebhookLog(data: InsertWebhookLog): Promise<WebhookLog>;
  getWebhookLogs(limit: number, offset: number): Promise<WebhookLog[]>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  deleteUserByEmail(email: string): Promise<boolean>;
  expireStaleImages(): Promise<number>;
  clearUserHistory(userId: string, mediaTypes: string[], cutoffDate: Date | null): Promise<{ deleted: Record<string, number> }>;

  // PIX / taxId methods
  updateUserTaxId(userId: string, taxId: string): Promise<void>;
  createPixPayment(data: Omit<InsertPixPayment, "id" | "externalId" | "createdAt">): Promise<PixPayment>;
  getPixPayment(id: string): Promise<PixPayment | undefined>;
  getPixPaymentByAbacateId(abacatePayId: string): Promise<PixPayment | undefined>;
  updatePixPaymentStatus(id: string, status: string, paidAt?: Date): Promise<void>;
  getPaidPixPaymentsInRange(from: Date, to: Date): Promise<{ payment: PixPayment; email: string | null }[]>;
  createVideoPovRequest(
    userId: string,
    data: {
      position: string;
      hole: string;
      sexType: string;
      speechType: string;
      amountCents?: number;
      sessionId?: string | null;
      previewAnalysisImageUrl?: string | null;
      previewAnalysisStatus?: VideoPovPreviewAnalysisStatus;
    }
  ): Promise<VideoPovRequest>;
  getRecentVideoPovRequestByFingerprint(
    userId: string,
    sessionId: string | null,
    data: {
      position: string;
      hole: string;
      sexType: string;
      speechType: string;
      previewAnalysisImageUrl?: string | null;
      since: Date;
    }
  ): Promise<VideoPovRequest | undefined>;
  getVideoPovRequest(id: string): Promise<VideoPovRequest | undefined>;
  updateVideoPovRequest(id: string, data: VideoPovRequestUpdate): Promise<VideoPovRequest | undefined>;

  // Funnel tracking / admin analytics
  upsertFunnelSession(data: {
    sessionId: string;
    userId?: string | null;
    step?: FunnelStep;
    uploadedPhotoUrl?: string | null;
    generatedPhotoUrl?: string | null;
    customerName?: string | null;
    customerEmail?: string | null;
    utmSource?: string | null;
    utmMedium?: string | null;
    utmCampaign?: string | null;
    utmContent?: string | null;
    utmTerm?: string | null;
    isPaid?: boolean;
    paidAt?: Date | null;
    saleAmountCents?: number | null;
    saleTransactionId?: string | null;
    saleProvider?: string | null;
    saleEvent?: string | null;
  }): Promise<FunnelSession>;
  createFunnelEvent(data: {
    sessionId: string;
    userId?: string | null;
    step: FunnelStep;
    eventName: string;
    idempotencyKey?: string | null;
    metadata?: Record<string, unknown>;
    occurredAt?: Date;
  }): Promise<FunnelEvent | null>;
  getFunnelStepCounts(dateFrom: Date, dateTo: Date): Promise<Record<FunnelStep, number>>;
  getGeneratedMediaCountInRange(dateFrom: Date, dateTo: Date): Promise<number>;
  getPixPaymentMetricsInRange(dateFrom: Date, dateTo: Date): Promise<PixPaymentMetrics>;
  createPaymentWebhookLog(data: InsertPaymentWebhookLog): Promise<PaymentWebhookLog>;
  getPaymentWebhookLogByIdempotencyKey(idempotencyKey: string): Promise<PaymentWebhookLog | undefined>;
  updatePaymentWebhookLog(
    idempotencyKey: string,
    data: { status: string; errorMessage?: string | null; processedAt?: Date | null }
  ): Promise<void>;

  getAdminCustomers(params: {
    dateFrom: Date;
    dateTo: Date;
    search?: string;
    paymentStatus?: "paid" | "unpaid" | "all";
    leadStage?: AdminCustomerLeadStage;
    responseKind?: AdminCustomerResponseKind;
    pixProduct?: AdminPixProductKey;
    sortBy?: AdminCustomerSortBy;
    sortDir?: AdminCustomerSortDir;
    limit: number;
    offset: number;
  }): Promise<{ rows: AdminCustomerUnifiedRow[]; total: number }>;
  getAdminPackResponses(params: {
    dateFrom: Date;
    dateTo: Date;
    search?: string;
    paymentStatus?: "paid" | "unpaid" | "all";
    limit: number;
    offset: number;
  }): Promise<{ rows: AdminPackResponseRow[]; total: number }>;
  getAdminVideoPovResponses(params: {
    dateFrom: Date;
    dateTo: Date;
    search?: string;
    paymentStatus?: "paid" | "unpaid" | "all";
    limit: number;
    offset: number;
  }): Promise<{ rows: AdminVideoPovResponseRow[]; total: number }>;
  getAdminRealPreviewLogs(params: {
    dateFrom: Date;
    dateTo: Date;
    search?: string;
    limit: number;
    offset: number;
  }): Promise<AdminRealPreviewLogsResult>;
  getFunnelSessionDetails(sessionId: string): Promise<{ session?: FunnelSession; events: FunnelEvent[] }>;
  createPaymentWebhookLog(data: InsertPaymentWebhookLog): Promise<PaymentWebhookLog>;
  getPaymentWebhookLogByIdempotencyKey(idempotencyKey: string): Promise<PaymentWebhookLog | undefined>;
  updatePaymentWebhookLog(
    idempotencyKey: string,
    data: { status: string; errorMessage?: string | null; processedAt?: Date | null }
  ): Promise<void>;

  // Fingerprint / blocking
  upsertUserFingerprint(data: {
    userId: string;
    fingerprintId: string;
    ip?: string;
    isVpn?: boolean;
    isProxy?: boolean;
    isTor?: boolean;
    vpnConfidenceScore?: "low" | "medium" | "high";
    vpnSuspected?: boolean;
    affiliateLink?: string | null;
  }): Promise<UserFingerprint>;
  getUserFingerprintByUserId(userId: string): Promise<UserFingerprint | undefined>;
  findUsersByFingerprint(fingerprintId: string): Promise<UserFingerprint[]>;
  blockUser(userId: string, reason: string): Promise<void>;
  unblockUser(userId: string): Promise<void>;

  // Flow Sessions (Estilo Livre)
  isUserBlocked(userId: string): Promise<{ blocked: boolean; blockReason: string | null }>;

  // A/B Testing
  getActiveAbTests(): Promise<Array<AbTest & { variants: AbVariant[] }>>;
  getAllAbTestsWithVariants(): Promise<Array<AbTest & { variants: AbVariant[] }>>;
  getActiveAbTestByPublicPath(publicPath: string, excludeId?: string): Promise<AbTest | undefined>;
  getAbTestWithVariants(id: string): Promise<(AbTest & { variants: AbVariant[] }) | undefined>;
  getDistinctFunnelSessionsSince(date: Date): Promise<number>;
  getFunnelVisitorEnteredSince(date: Date): Promise<number>;
  createAbTestWithVariants(
    test: Pick<InsertAbTest, "name" | "slug" | "publicPath"> & { status?: "active" | "paused" | "ended" },
    variants: Array<Pick<InsertAbVariant, "name" | "slug" | "componentKey" | "weight">>,
  ): Promise<AbTest & { variants: AbVariant[] }>;
  updateAbTest(
    id: string,
    data: { status?: "active" | "paused" | "ended"; name?: string },
    variantWeights?: Array<{ id: string; weight: number }>,
  ): Promise<(AbTest & { variants: AbVariant[] }) | undefined>;
  endAbTest(id: string): Promise<void>;
  incrementAbVariantVisits(variantId: string): Promise<void>;
  recordAbConversion(data: InsertAbConversion): Promise<boolean>;
  getAbAssignmentsForSession(sessionId: string): Promise<Record<string, string>>;
  recordAbConversionsForAssignments(data: {
    assignments?: Record<string, string> | null;
    sessionId?: string | null;
    transactionId: string;
    amountCents: number;
    externalReference?: string | null;
  }): Promise<{
    attempted: number;
    inserted: number;
    variantIds: string[];
    source: "payment" | "session" | "none";
  }>;
  getAbTestStats(testId: string): Promise<{
    variants: Array<{
      id: string;
      name: string;
      slug: string;
      componentKey: string;
      weight: number;
      visits: number;
      conversions: number;
      conversionRate: number;
      revenueCents: number;
      rpvCents: number;
    }>;
  }>;
}

export class DatabaseStorage implements IStorage {

  // ═══ FLOW SESSION METHODS (Estilo Livre) ═══

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUsersByIds(ids: string[]): Promise<User[]> {
    if (ids.length === 0) return [];
    return db.select().from(users).where(inArray(users.id, ids));
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async updateUser(userId: string, data: Partial<User>): Promise<User | undefined> {
    const [user] = await db.update(users).set(data).where(eq(users.id, userId)).returning();
    return user || undefined;
  }

  async getUserCredits(userId: string): Promise<UserCredits | undefined> {
    const [credits] = await db.select().from(userCredits).where(eq(userCredits.userId, userId));

    if (credits) {
      const now = new Date();
      const lastCheck = credits.lastExpirationCheck ? new Date(credits.lastExpirationCheck) : null;
      // Check expiration at most once every 24 hours to avoid heavy queries on every request
      const shouldCheckExpiration = !lastCheck || (now.getTime() - lastCheck.getTime() > 24 * 60 * 60 * 1000);

      if (shouldCheckExpiration) {
        // Calculate cutoff date: 4 months ago
        const cutoffDate = new Date();
        cutoffDate.setMonth(cutoffDate.getMonth() - 4);

        // Get sum of all POSITIVE transactions (grants) in the last 4 months
        const result = await db.execute(sql`
          SELECT COALESCE(SUM(amount), 0) as valid_sum
          FROM credit_transactions
          WHERE user_id = ${userId}
            AND amount > 0
            AND created_at >= ${cutoffDate}
        `);

        // @ts-ignore
        const validSum = Number(result.rows[0].valid_sum);
        const currentBalance = credits.balance;

        // If current balance exceeds valid sum, expire the difference
        if (currentBalance > validSum) {
          const expiredAmount = currentBalance - validSum;

          if (expiredAmount > 0) {
            console.log(`[storage] Expiring ${expiredAmount} credits for user ${userId}`);

            await db.transaction(async (tx) => {
              // Deduct from balance
              await tx.update(userCredits)
                .set({
                  balance: validSum,
                  totalExpired: sql`${userCredits.totalExpired} + ${expiredAmount}`,
                  lastExpirationCheck: now,
                  updatedAt: now
                })
                .where(eq(userCredits.userId, userId));

              // Record expiration transaction
              await tx.insert(creditTransactions).values({
                userId,
                amount: -expiredAmount,
                type: "expiration",
                description: `Expiração de créditos não utilizados (+4 meses)`,
                createdAt: now
              });
            });

            // Return updated credits object
            return {
              ...credits,
              balance: validSum,
              lastExpirationCheck: now,
              totalExpired: (credits.totalExpired || 0) + expiredAmount
            };
          }
        } else {
          // Just update the check timestamp
          await db.update(userCredits)
            .set({ lastExpirationCheck: now })
            .where(eq(userCredits.userId, userId));

          credits.lastExpirationCheck = now;
        }
      }
    }

    return credits || undefined;
  }

  async createUserCredits(userId: string, options?: { initialBalance?: number }): Promise<UserCredits> {
    const now = new Date();

    // Anonymous/session users get high balance (no auth)
    let initialBalance = options?.initialBalance ?? 60;
    let bonusDescription = options?.initialBalance !== undefined
      ? `Créditos iniciais (modo sem login) - ${initialBalance}`
      : "Bônus de boas-vindas - 60 créditos grátis";
    let affiliatePlanId: string | null = null;
    let affiliatePlanDays: number = 7;
    let shouldMarkClaimed = false;

    let referral: { affiliateId: string } | undefined;
    try {
      if (options?.initialBalance === undefined) {
        const [r] = await db
          .select()
          .from(affiliateReferrals)
          .where(eq(affiliateReferrals.referredUserId, userId))
          .limit(1);
        referral = r;
      }

      if (referral) {
        const [affiliate] = await db
          .select()
          .from(affiliates)
          .where(eq(affiliates.id, referral.affiliateId))
          .limit(1);

        if (affiliate) {
          let isAffiliateOffer = false;

          // Apply custom credit amount (no card validation needed)
          if ((affiliate.freeCreditsAmount || 0) > 0) {
            initialBalance = affiliate.freeCreditsAmount || 0;
            const affiliateName = affiliate.displayName || "Afiliado";
            bonusDescription = `Oferta exclusiva ${affiliateName} - ${initialBalance} créditos grátis`;
            console.log(`[storage] Applying affiliate offer for user ${userId}: ${initialBalance} credits (Affiliate: ${affiliate.id})`);
            isAffiliateOffer = true;
          }

          // Store affiliate plan info for post-insert activation
          if (affiliate.freePlanId) {
            affiliatePlanId = affiliate.freePlanId;
            affiliatePlanDays = affiliate.freePlanDays || 7;
            isAffiliateOffer = true;
          }

          shouldMarkClaimed = isAffiliateOffer;
        }
      }
    } catch (err) {
      console.error("[storage] Error checking affiliate offer during user creation:", err);
      // Fallback to default 60 is automatic via initialBalance initialization
    }

    const creditCreation = await db.transaction(async (tx) => {
      const inserted = await tx
        .insert(userCredits)
        .values({
          userId,
          balance: initialBalance,
          totalPurchased: 0,
          totalSpent: 0,
          hasPurchased: false,
          dailyCreditsAccumulated: 0,
          lastDailyCredits: now, // Set to today so daily credits only start tomorrow
        })
        .onConflictDoNothing({ target: userCredits.userId })
        .returning();

      if (inserted[0]) {
        await tx.insert(creditTransactions).values({
          userId,
          amount: initialBalance,
          type: "bonus",
          description: bonusDescription,
        });
        return { credits: inserted[0], created: true };
      }

      const [existing] = await tx
        .select()
        .from(userCredits)
        .where(eq(userCredits.userId, userId))
        .limit(1);
      if (!existing) {
        throw new Error("Falha ao criar carteira de créditos");
      }
      return { credits: existing, created: false };
    });

    // Auto-activate affiliate trial plan (no card validation needed)
    if (creditCreation.created && affiliatePlanId) {
      try {
        const periodEnd = new Date(now.getTime() + affiliatePlanDays * 24 * 60 * 60 * 1000);
        await this.updateUserPlan(userId, affiliatePlanId, null, periodEnd);
        console.log(`[storage] Auto-activated ${affiliatePlanDays}-day trial of ${affiliatePlanId} for user ${userId} (expires: ${periodEnd.toISOString()})`);
      } catch (err) {
        console.error("[storage] Error auto-activating affiliate plan:", err);
      }
    }

    // Mark as claimed so the card validation modal won't try to re-grant
    if (creditCreation.created && shouldMarkClaimed) {
      try {
        await this.updateUser(userId, { freeCreditsClaimed: true } as any);
      } catch (err) {
        console.error("[storage] Error marking freeCreditsClaimed:", err);
      }
    }

    return creditCreation.credits;
  }

  async claimDailyCredits(userId: string): Promise<{ credited: number; message: string }> {
    await this.createUserCredits(userId);

    return await db.transaction(async (tx) => {
      const [credits] = await tx
        .select()
        .from(userCredits)
        .where(eq(userCredits.userId, userId))
        .for("update")
        .limit(1);

      if (!credits) {
        throw new Error("Carteira de créditos não encontrada");
      }

      if (credits.hasPurchased || credits.planTier !== "free") {
        return { credited: 0, message: "Créditos diários são apenas para contas gratuitas" };
      }

      const now = new Date();
      const lastClaim = credits.lastDailyCredits;

      if (lastClaim) {
        const lastClaimDate = new Date(lastClaim);
        const isSameDay = lastClaimDate.toDateString() === now.toDateString();
        if (isSameDay) {
          return { credited: 0, message: "Você já resgatou seus créditos diários hoje" };
        }
      }

      const maxBalance = 60;
      const dailyAmount = 20;

      if (credits.balance >= maxBalance) {
        return { credited: 0, message: "Você já tem 60+ créditos. Use seus créditos para receber mais diariamente!" };
      }

      const remainingSlots = maxBalance - credits.balance;
      const creditsToGive = Math.min(dailyAmount, remainingSlots);
      const currentAccumulated = credits.dailyCreditsAccumulated || 0;

      await tx
        .update(userCredits)
        .set({
          balance: credits.balance + creditsToGive,
          lastDailyCredits: now,
          dailyCreditsAccumulated: currentAccumulated + creditsToGive,
          updatedAt: now,
        })
        .where(eq(userCredits.id, credits.id));

      await tx.insert(creditTransactions).values({
        userId,
        amount: creditsToGive,
        type: "daily_bonus",
        description: `Créditos diários gratuitos (+${creditsToGive})`,
      });

      return {
        credited: creditsToGive,
        message: `Você recebeu ${creditsToGive} créditos diários!`
      };
    });
  }

  async applyDailyCreditsIfNeeded(userId: string): Promise<{ credited: number; newBalance: number }> {
    await this.createUserCredits(userId);

    return await db.transaction(async (tx) => {
      const [credits] = await tx
        .select()
        .from(userCredits)
        .where(eq(userCredits.userId, userId))
        .for("update")
        .limit(1);

      if (!credits) {
        throw new Error("Carteira de créditos não encontrada");
      }

      if (credits.planTier !== "free") {
        return { credited: 0, newBalance: credits.balance };
      }

      const now = new Date();
      const lastClaim = credits.lastDailyCredits;
      let daysElapsed = 1;

      if (lastClaim) {
        const lastClaimDate = new Date(lastClaim);
        const isSameDay = lastClaimDate.toDateString() === now.toDateString();
        if (isSameDay) {
          return { credited: 0, newBalance: credits.balance };
        }

        const msPerDay = 24 * 60 * 60 * 1000;
        const lastClaimMidnight = new Date(lastClaimDate.getFullYear(), lastClaimDate.getMonth(), lastClaimDate.getDate());
        const nowMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        daysElapsed = Math.floor((nowMidnight.getTime() - lastClaimMidnight.getTime()) / msPerDay);
        daysElapsed = Math.max(1, daysElapsed);
      }

      const maxBalance = 60;
      const dailyAmount = 20;

      if (credits.balance >= maxBalance) {
        return { credited: 0, newBalance: credits.balance };
      }

      const remainingSlots = maxBalance - credits.balance;
      const potentialCredits = dailyAmount * daysElapsed;
      const creditsToGive = Math.min(potentialCredits, remainingSlots);

      if (creditsToGive <= 0) {
        return { credited: 0, newBalance: credits.balance };
      }

      const currentAccumulated = credits.dailyCreditsAccumulated || 0;
      const [updated] = await tx
        .update(userCredits)
        .set({
          balance: credits.balance + creditsToGive,
          lastDailyCredits: now,
          dailyCreditsAccumulated: currentAccumulated + creditsToGive,
          updatedAt: now,
        })
        .where(eq(userCredits.id, credits.id))
        .returning();

      await tx.insert(creditTransactions).values({
        userId,
        amount: creditsToGive,
        type: "daily_bonus",
        description: `Créditos diários gratuitos (+${creditsToGive}${daysElapsed > 1 ? ` - ${daysElapsed} dias` : ''})`,
      });

      return {
        credited: creditsToGive,
        newBalance: updated.balance
      };
    });
  }

  async consumeCreditsWithDailyFirst(userId: string, amount: number): Promise<UserCredits> {
    return await db.transaction(async (tx) => {
      const [credits] = await tx
        .select()
        .from(userCredits)
        .where(eq(userCredits.userId, userId))
        .for("update")
        .limit(1);

      if (!credits || credits.balance < amount) {
        throw new Error(`Créditos insuficientes. Você precisa de ${amount} mas tem ${credits?.balance ?? 0}`);
      }

      const dailyAccumulated = credits.dailyCreditsAccumulated || 0;
      const dailyToConsume = Math.min(dailyAccumulated, amount);

      const [updated] = await tx
        .update(userCredits)
        .set({
          balance: credits.balance - amount,
          totalSpent: credits.totalSpent + amount,
          dailyCreditsAccumulated: dailyAccumulated - dailyToConsume,
          updatedAt: new Date(),
        })
        .where(eq(userCredits.id, credits.id))
        .returning();

      return updated;
    });
  }

  async markUserAsPurchased(userId: string): Promise<void> {
    await db
      .update(userCredits)
      .set({ hasPurchased: true, updatedAt: new Date() })
      .where(eq(userCredits.userId, userId));
  }

  async getUserCreditsByStripeCustomerId(stripeCustomerId: string): Promise<UserCredits | undefined> {
    const [credits] = await db.select().from(userCredits).where(eq(userCredits.stripeCustomerId, stripeCustomerId));
    return credits || undefined;
  }

  async updateUserStripeInfo(userId: string, info: { stripeCustomerId?: string; stripeSubscriptionId?: string }): Promise<UserCredits | undefined> {
    const [updated] = await db
      .update(userCredits)
      .set({ ...info, updatedAt: new Date() })
      .where(eq(userCredits.userId, userId))
      .returning();
    return updated;
  }

  async updateUserPlan(userId: string, planTier: string, subscriptionId: string | null, periodEnd?: Date): Promise<UserCredits | undefined> {
    let credits = await this.getUserCredits(userId);
    if (!credits) {
      credits = await this.createUserCredits(userId);
    }

    const updates: any = {
      planTier: planTier as any,
      stripeSubscriptionId: subscriptionId,
      hasPurchased: true,
      updatedAt: new Date(),
    };

    if (periodEnd) {
      updates.planEndDate = periodEnd;
    }

    if (planTier !== 'free' && !credits.planStartDate) {
      updates.planStartDate = new Date();
    }

    const [updated] = await db
      .update(userCredits)
      .set(updates)
      .where(eq(userCredits.userId, userId))
      .returning();
    return updated;
  }

  async grantMonthlyCredits(userId: string, creditAmount: number, planName: string): Promise<void> {
    let credits = await this.getUserCredits(userId);
    if (!credits) {
      credits = await this.createUserCredits(userId);
    }

    const now = new Date();
    const lastGrant = credits.lastPlanCreditGrant;

    if (lastGrant) {
      const daysSinceLastGrant = (now.getTime() - new Date(lastGrant).getTime()) / (1000 * 60 * 60 * 24);
      if (daysSinceLastGrant < 25) {
        console.log(`[storage] Skipping credit grant for ${userId} - already granted ${daysSinceLastGrant.toFixed(1)} days ago`);
        return;
      }
    }

    await db
      .update(userCredits)
      .set({
        balance: credits.balance + creditAmount,
        totalPurchased: credits.totalPurchased + creditAmount,
        lastPlanCreditGrant: now,
        updatedAt: now,
      })
      .where(eq(userCredits.userId, userId));

    await this.createCreditTransaction({
      userId,
      amount: creditAmount,
      type: "subscription",
      description: `Créditos mensais do plano ${planName} (+${creditAmount})`,
    });

    console.log(`[storage] Granted ${creditAmount} monthly credits to ${userId} for plan ${planName}`);
  }

  async updateCredits(userId: string, amount: number, isSpending: boolean = false): Promise<UserCredits> {
    return await db.transaction(async (tx) => {
      let [credits] = await tx
        .select()
        .from(userCredits)
        .where(eq(userCredits.userId, userId))
        .for("update")
        .limit(1);

      if (!credits) {
        await tx
          .insert(userCredits)
          .values({ userId, balance: 0 })
          .onConflictDoNothing({ target: userCredits.userId });

        [credits] = await tx
          .select()
          .from(userCredits)
          .where(eq(userCredits.userId, userId))
          .for("update")
          .limit(1);

        if (!credits) {
          throw new Error("Falha ao criar carteira de créditos");
        }
      }

      const newBalance = credits.balance + amount;
      const updates: Partial<UserCredits> = {
        balance: newBalance,
        updatedAt: new Date(),
      };

      if (isSpending && amount < 0) {
        if (credits.balance < Math.abs(amount)) {
          throw new Error(`Créditos insuficientes. Você precisa de ${Math.abs(amount)} mas tem ${credits.balance}`);
        }
        updates.totalSpent = credits.totalSpent + Math.abs(amount);
      } else if (amount > 0) {
        updates.totalPurchased = credits.totalPurchased + amount;
      }

      const [updated] = await tx
        .update(userCredits)
        .set(updates)
        .where(eq(userCredits.id, credits.id))
        .returning();

      return updated;
    });
  }

  // ═══ VIDEO SESSION METHODS ═══
  // ═══ VIDEO EXPIRATION & SESSION CLEANUP (14 days) ═══

  async getActiveGenerationsCount(userId: string, type: 'video' | 'image' | 'audio'): Promise<number> {

          if (type === 'image') {
            const result = await db
              .select({ count: count() })
              .from(generatedImages)
              .where(
                and(
                  eq(generatedImages.userId, userId),
                  or(
                    eq(generatedImages.status, "pending"),
                    eq(generatedImages.status, "processing")
                  )
                )
              );
            return result[0]?.count || 0;
          }
          return 0;
              
  }

  async getCreditTransactions(userId: string): Promise<CreditTransaction[]> {
    return db
      .select()
      .from(creditTransactions)
      .where(eq(creditTransactions.userId, userId))
      .orderBy(desc(creditTransactions.createdAt));
  }

  async createCreditTransaction(data: InsertCreditTransaction & { userId: string }): Promise<CreditTransaction> {
    const [transaction] = await db
      .insert(creditTransactions)
      .values(data)
      .returning();
    return transaction;
  }

  async claimWhatsAppBonus(userId: string, bonusAmount: number): Promise<{ success: boolean; message?: string; credited?: number }> {
    const REQUIRED_WAIT_MS = 10 * 60 * 1000; // 10 minutes

    // Use a database transaction with advisory lock for full atomicity
    return await db.transaction(async (tx) => {
      // Acquire advisory lock based on userId hash to serialize concurrent requests
      const lockKey = Math.abs(userId.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0));
      await tx.execute(sql`SELECT pg_advisory_xact_lock(${lockKey})`);

      // Check existing whatsapp-related transactions
      const existingRecords = await tx.execute(sql`
        SELECT id, type, created_at FROM credit_transactions 
        WHERE user_id = ${userId} AND type IN ('whatsapp_bonus', 'whatsapp_share_initiated')
      `);

      const records = existingRecords.rows as Array<{ id: string; type: string; created_at: Date }>;

      // Check if already claimed
      const existingBonus = records.find(r => r.type === "whatsapp_bonus");
      if (existingBonus) {
        return { success: false, message: "Você já resgatou este bônus." };
      }

      // Check if share was initiated
      const initiation = records.find(r => r.type === "whatsapp_share_initiated");
      if (!initiation || !initiation.created_at) {
        return { success: false, message: "Você precisa compartilhar no WhatsApp primeiro." };
      }

      const elapsed = Date.now() - new Date(initiation.created_at).getTime();
      if (elapsed < REQUIRED_WAIT_MS) {
        const remainingSeconds = Math.ceil((REQUIRED_WAIT_MS - elapsed) / 1000);
        return {
          success: false,
          message: `Aguarde mais ${Math.floor(remainingSeconds / 60)}:${(remainingSeconds % 60).toString().padStart(2, '0')} minutos.`
        };
      }

      // Record the bonus transaction FIRST with unique constraint protection
      // This ensures we don't update credits if transaction already exists
      try {
        await tx.insert(creditTransactions).values({
          userId,
          amount: bonusAmount,
          type: "whatsapp_bonus",
          description: "Bônus de compartilhamento no WhatsApp",
        });
      } catch (error: any) {
        // If unique constraint violation, bonus was already claimed by concurrent request
        if (error?.code === '23505') {
          return { success: false, message: "Você já resgatou este bônus." };
        }
        throw error;
      }

      // Now update/create userCredits atomically (transaction insert succeeded)
      const existingCredits = await tx.execute(sql`
        SELECT user_id FROM user_credits WHERE user_id = ${userId} FOR UPDATE
      `);

      if (existingCredits.rows.length === 0) {
        // Create credits row if it doesn't exist
        await tx.insert(userCredits).values({
          userId,
          balance: bonusAmount,
          totalPurchased: bonusAmount,
          totalSpent: 0,
        });
      } else {
        // Update existing credits
        await tx
          .update(userCredits)
          .set({
            balance: sql`${userCredits.balance} + ${bonusAmount}`,
            totalPurchased: sql`${userCredits.totalPurchased} + ${bonusAmount}`
          })
          .where(eq(userCredits.userId, userId));
      }

      return { success: true, credited: bonusAmount };
    });
  }

  async initiateWhatsAppShare(userId: string): Promise<{ success: boolean; waitSeconds: number; alreadyInitiated?: boolean; message?: string }> {
    const REQUIRED_WAIT_MS = 10 * 60 * 1000; // 10 minutes

    // Use transaction with advisory lock for user-level serialization
    return await db.transaction(async (tx) => {
      // Acquire advisory lock based on userId hash to serialize concurrent requests
      const lockKey = Math.abs(userId.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0));
      await tx.execute(sql`SELECT pg_advisory_xact_lock(${lockKey})`);

      // Check existing whatsapp-related transactions
      const existingRecords = await tx.execute(sql`
        SELECT id, type, created_at FROM credit_transactions 
        WHERE user_id = ${userId} AND type IN ('whatsapp_bonus', 'whatsapp_share_initiated')
      `);

      const records = existingRecords.rows as Array<{ id: string; type: string; created_at: Date }>;

      // Check if already claimed
      const existingBonus = records.find(r => r.type === "whatsapp_bonus");
      if (existingBonus) {
        return { success: false, waitSeconds: 0, message: "Você já resgatou este bônus." };
      }

      // Check if already initiated
      const existingInitiation = records.find(r => r.type === "whatsapp_share_initiated");
      if (existingInitiation && existingInitiation.created_at) {
        const elapsed = Date.now() - new Date(existingInitiation.created_at).getTime();
        const remaining = Math.max(0, Math.ceil((REQUIRED_WAIT_MS - elapsed) / 1000));
        return { success: true, waitSeconds: remaining, alreadyInitiated: true };
      }

      // Create initiation record with ON CONFLICT handling for idempotency
      try {
        await tx.insert(creditTransactions).values({
          userId,
          amount: 0,
          type: "whatsapp_share_initiated",
          description: "Compartilhamento WhatsApp iniciado",
        });
      } catch (error: any) {
        // If unique constraint violation, re-check for existing initiation
        if (error?.code === '23505') { // PostgreSQL unique violation
          const recheck = await tx.execute(sql`
            SELECT created_at FROM credit_transactions 
            WHERE user_id = ${userId} AND type = 'whatsapp_share_initiated'
          `);
          if (recheck.rows.length > 0) {
            const created = (recheck.rows[0] as any).created_at;
            const elapsed = Date.now() - new Date(created).getTime();
            const remaining = Math.max(0, Math.ceil((REQUIRED_WAIT_MS - elapsed) / 1000));
            return { success: true, waitSeconds: remaining, alreadyInitiated: true };
          }
        }
        throw error;
      }

      return { success: true, waitSeconds: 600 };
    });
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async getStats(): Promise<{
    totalUsers: number;
    totalVideos: number;
    totalCreditsUsed: number;
    totalRevenue: number;
  }> {

          const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
          const [creditsSum] = await db.select({ sum: sql<number>`coalesce(sum(total_spent), 0)` }).from(userCredits);
          const [purchasesSum] = await db.select({ sum: sql<number>`coalesce(sum(total_purchased), 0)` }).from(userCredits);

          const creditsPurchased = Number(purchasesSum.sum) || 0;
          const estimatedRevenue = (creditsPurchased / 10) * 0.23;

          return {
            totalUsers: Number(userCount.count) || 0,
            totalVideos: 0,
            totalCreditsUsed: Number(creditsSum.sum) || 0,
            totalRevenue: estimatedRevenue,
          };
              
  }


  async completeOnboarding(userId: string): Promise<void> {
    await db
      .update(userCredits)
      .set({ hasCompletedOnboarding: true, updatedAt: new Date() })
      .where(eq(userCredits.userId, userId));
  }

  // Admin methods
  async getAllUsersWithCredits(
    search?: string,
    limit: number = 50,
    offset: number = 0,
    sortBy: string = 'createdAt',
    sortOrder: 'asc' | 'desc' = 'desc',
    filterPlan?: string
  ): Promise<{ users: (User & { credits?: UserCredits })[], total: number }> {

    // Build the query with JOIN
    let baseQuery = db.select({
      user: users,
      credits: userCredits
    })
      .from(users)
      .leftJoin(userCredits, eq(users.id, userCredits.userId));

    const timestampSortBy = sortBy as 'createdAt' | 'lastLogin';

    // Apply filters
    const conditions = [];
    if (search && search.trim()) {
      const searchTerm = `%${search.trim()}%`;
      conditions.push(
        or(
          ilike(users.email, searchTerm),
          ilike(users.firstName, searchTerm),
          ilike(users.lastName, searchTerm),
          ilike(users.username, searchTerm)
        )
      );
    }

    if (filterPlan && filterPlan !== 'all') {
      if (filterPlan === 'free') {
        // Free plan is default if no credits or planTier is free
        conditions.push(
          or(
            isNull(userCredits.planTier),
            eq(userCredits.planTier, 'free')
          )
        );
      } else {
        conditions.push(eq(userCredits.planTier, filterPlan as any));
      }
    }

    // Apply filtering
    let queryWithFilters = baseQuery.$dynamic();
    if (conditions.length > 0) {
      queryWithFilters = queryWithFilters.where(and(...conditions));
    }

    // Apply sorting
    let orderByClause;
    switch (sortBy) {
      case 'credits':
        orderByClause = sortOrder === 'desc' ? desc(userCredits.balance) : asc(userCredits.balance);
        break;
      case 'plan':
        orderByClause = sortOrder === 'desc' ? desc(userCredits.planTier) : asc(userCredits.planTier);
        break;
      case 'lastLogin':
        orderByClause = sortOrder === 'desc' ? desc(users.lastLogin) : asc(users.lastLogin);
        break;
      case 'createdAt':
      default:
        orderByClause = sortOrder === 'desc' ? desc(users.createdAt) : asc(users.createdAt);
        break;
    }

    // Get total count (using a separate query for accuracy with filters)
    // For simplicity in pagination with complex joins, we can count the results of the filtered query
    // But direct count(*) is more efficient.
    // Let's re-construct conditions for a count query on users table? 
    // No, if we filter by plan (joined table), we need the join in count too.

    const countQuery = db.select({ count: sql<number>`count(*)` })
      .from(users)
      .leftJoin(userCredits, eq(users.id, userCredits.userId));

    let countQueryWithFilters = countQuery.$dynamic();
    if (conditions.length > 0) {
      countQueryWithFilters = countQueryWithFilters.where(and(...conditions));
    }

    const [countResult] = await countQueryWithFilters;
    const total = Number(countResult?.count || 0);

    // Get paginated results
    const results = await queryWithFilters
      .orderBy(orderByClause)
      .limit(limit)
      .offset(offset);

    // Map results to expected format
    const mappedUsers = results.map(r => ({
      ...r.user,
      credits: r.credits || undefined
    }));

    return {
      users: mappedUsers,
      total
    };
  }

  async adminUpdateUserCredits(userId: string, amount: number, adminUserId: string, adminEmail: string, reason: string): Promise<UserCredits> {
    let credits = await this.getUserCredits(userId);
    if (!credits) {
      credits = await this.createUserCredits(userId);
    }

    const previousBalance = credits.balance;
    const newBalance = credits.balance + amount;

    const [updated] = await db
      .update(userCredits)
      .set({
        balance: newBalance,
        updatedAt: new Date(),
      })
      .where(eq(userCredits.userId, userId))
      .returning();

    // Create credit transaction
    await this.createCreditTransaction({
      userId,
      amount,
      type: amount > 0 ? "admin_credit" : "admin_debit",
      description: `Ajuste admin: ${reason}`,
    });

    // Create audit log
    await this.createAdminAuditLog({
      adminUserId,
      adminEmail,
      targetUserId: userId,
      action: "adjust_credits",
      details: reason,
      previousValue: String(previousBalance),
      newValue: String(newBalance),
    });

    return updated;
  }

  async adminUpdateUserPlan(
    userId: string,
    planTier: string,
    adminUserId: string,
    adminEmail: string,
    expirationDays?: number | null,
    permanent?: boolean
  ): Promise<UserCredits | undefined> {
    let credits = await this.getUserCredits(userId);
    if (!credits) {
      credits = await this.createUserCredits(userId);
    }

    const previousPlan = credits.planTier;
    const now = new Date();

    // Determine if this is a valid admin-assigned plan
    // A paid plan must be either permanent OR have an expiration date
    const isPaidPlan = planTier !== "free";
    const hasValidExpiration = expirationDays && expirationDays > 0;
    const isPermanent = permanent === true;

    // Reject invalid state: paid plan without permanent or expiration
    if (isPaidPlan && !isPermanent && !hasValidExpiration) {
      throw new Error("Planos pagos requerem acesso permanente ou data de expiração");
    }

    let planEndDate: Date | null = null;
    if (isPaidPlan && !isPermanent && hasValidExpiration) {
      planEndDate = new Date(now.getTime() + expirationDays * 24 * 60 * 60 * 1000);
    }

    // Only set adminAssignedPlan true if it's a valid admin-controlled paid plan
    const isAdminAssignedPlan = isPaidPlan && (isPermanent || hasValidExpiration);

    const updateData: any = {
      planTier: planTier as any,
      planEndDate: planEndDate,
      adminAssignedPlan: isAdminAssignedPlan,
      updatedAt: now,
    };

    if (isPaidPlan) {
      updateData.planStartDate = now;
    }

    const [updated] = await db
      .update(userCredits)
      .set(updateData)
      .where(eq(userCredits.userId, userId))
      .returning();

    const expirationInfo = planTier === "free"
      ? ""
      : permanent
        ? " (permanente)"
        : expirationDays
          ? ` (expira em ${expirationDays} dias)`
          : "";

    await this.createAdminAuditLog({
      adminUserId,
      adminEmail,
      targetUserId: userId,
      action: "change_plan",
      details: `Plano alterado de ${previousPlan} para ${planTier}${expirationInfo}`,
      previousValue: previousPlan,
      newValue: planTier,
    });

    return updated;
  }

  async updateUserFeatures(userId: string, enabledFeatures: Record<string, boolean>): Promise<UserCredits | undefined> {
    const [updated] = await db
      .update(userCredits)
      .set({ enabledFeatures, updatedAt: new Date() })
      .where(eq(userCredits.userId, userId))
      .returning();
    return updated;
  }

  async expireStaleImages(): Promise<number> {
    const FORTY_FIVE_MIN_MS = 45 * 60 * 1000;
    const cutoff = new Date(Date.now() - FORTY_FIVE_MIN_MS);

    // Find all images stuck in processing/pending for more than 45 minutes
    const staleImages = await db
      .select()
      .from(generatedImages)
      .where(
        and(
          or(
            eq(generatedImages.status, "processing"),
            eq(generatedImages.status, "pending")
          ),
          lte(generatedImages.createdAt, cutoff)
        )
      );

    if (staleImages.length === 0) return 0;

    let expiredCount = 0;
    for (const image of staleImages) {
      const result = await this.failGeneratedImageAndRefundIfActive(
        image.id,
        "Tempo limite excedido (45 minutos). Créditos reembolsados.",
        "Reembolso automático: timeout na geração de imagem após 45 min"
      );
      if (result.transitioned) expiredCount += 1;
    }

    return expiredCount;
  }

  async checkAndExpirePlans(): Promise<number> {
    const now = new Date();

    // First, find users with expired plans to get their current plan tier
    const usersToExpire = await db
      .select()
      .from(userCredits)
      .where(
        and(
          eq(userCredits.adminAssignedPlan, true),
          isNotNull(userCredits.planEndDate),
          lte(userCredits.planEndDate, now)
        )
      );

    if (usersToExpire.length === 0) {
      return 0;
    }

    // Save previous plan tiers before updating
    const previousPlans = usersToExpire.map(u => ({
      userId: u.userId,
      planTier: u.planTier,
      planEndDate: u.planEndDate
    }));

    // Update all expired users
    await db
      .update(userCredits)
      .set({
        planTier: "free",
        adminAssignedPlan: false,
        planEndDate: null,
        updatedAt: now,
      })
      .where(
        and(
          eq(userCredits.adminAssignedPlan, true),
          isNotNull(userCredits.planEndDate),
          lte(userCredits.planEndDate, now)
        )
      );

    // Create audit logs with correct previous values
    for (const prev of previousPlans) {
      await this.createAdminAuditLog({
        adminUserId: "system",
        adminEmail: "system@bigAI.com",
        targetUserId: prev.userId,
        action: "plan_expired",
        details: `Plano ${prev.planTier} expirado em ${prev.planEndDate?.toLocaleDateString('pt-BR')}, revertido para Free`,
        previousValue: prev.planTier,
        newValue: "free",
      });
    }

    return previousPlans.length;
  }

  async getAdminAuditLogs(limit: number = 100, offset: number = 0): Promise<AdminAuditLog[]> {
    return db
      .select()
      .from(adminAuditLog)
      .orderBy(desc(adminAuditLog.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async createAdminAuditLog(log: InsertAdminAuditLog): Promise<AdminAuditLog> {
    const [created] = await db
      .insert(adminAuditLog)
      .values(log)
      .returning();
    return created;
  }

  async getAdminMetrics(options?: { dateFrom?: string; dateTo?: string }): Promise<any> {
          const parsedDateFrom = parseAppDateInput(options?.dateFrom);
          const parsedDateTo = parseAppDateInput(options?.dateTo);
          const dateFrom = parsedDateFrom ? startOfAppDay(parsedDateFrom) : null;
          const dateTo = parsedDateTo ? endOfAppDay(parsedDateTo) : null;
          const hasDateFilter = dateFrom && dateTo;
          const selectedDayStart = dateTo ? startOfAppDay(dateTo) : startOfAppDay();
          const selectedDayEnd = dateTo ? endOfAppDay(dateTo) : endOfAppDay();

          const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);

          const planCounts = await db
            .select({
              planTier: userCredits.planTier,
              count: sql<number>`count(*)`,
            })
            .from(userCredits)
            .groupBy(userCredits.planTier);

          const usersByPlan: Record<string, number> = {};
          planCounts.forEach((row) => {
            usersByPlan[row.planTier || "free"] = Number(row.count);
          });

          const [creditsStats] = await db
            .select({
              totalBalance: sql<number>`coalesce(sum(balance), 0)`,
              totalSpent: sql<number>`coalesce(sum(total_spent), 0)`,
            })
            .from(userCredits);

          const [subsCount] = await db
            .select({ count: sql<number>`count(*)` })
            .from(userCredits)
            .where(isNotNull(userCredits.stripeSubscriptionId));

          let recentSignupsCount;
          if (hasDateFilter) {
            recentSignupsCount = await db
              .select({ count: sql<number>`count(*)` })
              .from(users)
              .where(and(gte(users.createdAt, dateFrom!), lte(users.createdAt, dateTo!)));
          } else {
            const sevenDaysAgo = addAppDays(new Date(), -7);
            recentSignupsCount = await db.select({ count: sql<number>`count(*)` }).from(users).where(gte(users.createdAt, sevenDaysAgo));
          }
          const recentSignups = Number(recentSignupsCount[0]?.count) || 0;

          let activeUsersToday;
          if (hasDateFilter) {
            const [loggedIn] = await db
              .select({ count: sql<number>`count(*)` })
              .from(users)
              .where(and(gte(users.lastLogin, selectedDayStart), lte(users.lastLogin, selectedDayEnd)));
            activeUsersToday = Number(loggedIn?.count) || 0;
          } else {
            const today = startOfAppDay();
            const [activeToday] = await db
              .select({ count: sql<number>`count(distinct user_id)` })
              .from(generatedImages)
              .where(gte(generatedImages.createdAt, today));
            activeUsersToday = Number(activeToday?.count) || 0;
          }

          let usersGeneratedMediaSelectedDay: number | undefined;
          if (hasDateFilter) {
            const imageUserIds = await db.select({ userId: generatedImages.userId }).from(generatedImages).where(and(gte(generatedImages.createdAt, selectedDayStart), lte(generatedImages.createdAt, selectedDayEnd)));
            const allIds = new Set<string>([
              ...imageUserIds.map(r => r.userId),
            ]);
            usersGeneratedMediaSelectedDay = allIds.size;
          }

          let creditsSpentInPeriod: number | undefined;
          if (hasDateFilter) {
            const [iCred] = await db.select({ s: sql<number>`coalesce(sum(credit_cost), 0)` }).from(generatedImages).where(and(gte(generatedImages.createdAt, dateFrom!), lte(generatedImages.createdAt, dateTo!)));
            creditsSpentInPeriod = Number(iCred?.s || 0);
          }

          let modelUsageImage: Record<string, { count: number; creditsCharged: number }> | undefined;
          let menuUsage: Record<string, number> | undefined;
          if (hasDateFilter) {
            const imageModelRows = await db
              .select({
                model: generatedImages.model,
                count: sql<number>`count(*)`,
                credits: sql<number>`coalesce(sum(credit_cost), 0)`,
              })
              .from(generatedImages)
              .where(and(gte(generatedImages.createdAt, dateFrom!), lte(generatedImages.createdAt, dateTo!)))
              .groupBy(generatedImages.model);
            modelUsageImage = {};
            imageModelRows.forEach((row) => {
              modelUsageImage![row.model] = { count: Number(row.count), creditsCharged: Number(row.credits) };
            });

            const [iMenu] = await db.select({ c: sql<number>`count(*)` }).from(generatedImages).where(and(gte(generatedImages.createdAt, dateFrom!), lte(generatedImages.createdAt, dateTo!)));
            menuUsage = {
              "Gerar Imagem": Number(iMenu?.c || 0),
            };
          }

          return {
            totalUsers: Number(userCount.count) || 0,
            usersByPlan,
            totalCreditsInCirculation: Number(creditsStats.totalBalance) || 0,
            totalCreditsSpent: Number(creditsStats.totalSpent) || 0,
            totalVideos: 0,
            videosByStatus: {},
            videosByModel: {},
            recentSignups,
            activeUsersToday,
            subscribersCount: Number(subsCount?.count) || 0,
            ...(hasDateFilter && {
              signupsInPeriod: recentSignups,
              creditsSpentInPeriod,
              usersLoggedInSelectedDay: activeUsersToday,
              usersGeneratedMediaSelectedDay,
              modelUsageVideo: {},
              modelUsageImage,
              menuUsage,
            }),
          };
              
  }

  async generateReferralCode(userId: string): Promise<string> {
    const credits = await this.getUserCredits(userId);
    if (!credits) {
      throw new Error("User credits not found");
    }

    if (credits.referralCode) {
      return credits.referralCode;
    }

    const code = `REF-${userId.substring(0, 6).toUpperCase()}${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    await db
      .update(userCredits)
      .set({ referralCode: code, updatedAt: new Date() })
      .where(eq(userCredits.userId, userId));

    return code;
  }

  async getUserByReferralCode(code: string): Promise<UserCredits | undefined> {
    const [credits] = await db
      .select()
      .from(userCredits)
      .where(eq(userCredits.referralCode, code));
    return credits || undefined;
  }

  async setReferredBy(userId: string, referrerUserId: string): Promise<void> {
    if (userId === referrerUserId) {
      return;
    }

    const credits = await this.getUserCredits(userId);
    if (credits?.referredBy) {
      return;
    }

    await db
      .update(userCredits)
      .set({ referredBy: referrerUserId, updatedAt: new Date() })
      .where(eq(userCredits.userId, userId));
  }

  async processReferralReward(referredUserId: string): Promise<{ rewarded: boolean; referrerId?: string }> {
    const REFERRAL_REWARD = 300;

    const referredCredits = await this.getUserCredits(referredUserId);
    if (!referredCredits?.referredBy || referredCredits.referralRewardPaid) {
      return { rewarded: false };
    }

    const referrerId = referredCredits.referredBy;
    const referrerCredits = await this.getUserCredits(referrerId);
    if (!referrerCredits) {
      return { rewarded: false };
    }

    await db
      .update(userCredits)
      .set({
        referralRewardPaid: true,
        updatedAt: new Date()
      })
      .where(eq(userCredits.userId, referredUserId));

    await db
      .update(userCredits)
      .set({
        balance: sql`${userCredits.balance} + ${REFERRAL_REWARD}`,
        referralCount: sql`${userCredits.referralCount} + 1`,
        referralCreditsEarned: sql`${userCredits.referralCreditsEarned} + ${REFERRAL_REWARD}`,
        updatedAt: new Date()
      })
      .where(eq(userCredits.userId, referrerId));

    await this.createCreditTransaction({
      userId: referrerId,
      amount: REFERRAL_REWARD,
      type: "referral",
      description: `Bônus de indicação: usuário indicado assinou um plano`,
    });

    console.log(`[referral] Rewarded ${REFERRAL_REWARD} credits to ${referrerId} for referring ${referredUserId}`);

    return { rewarded: true, referrerId };
  }

  async getReferralStats(userId: string): Promise<{ code: string; count: number; creditsEarned: number }> {
    const code = await this.generateReferralCode(userId);
    const credits = await this.getUserCredits(userId);

    return {
      code,
      count: credits?.referralCount || 0,
      creditsEarned: credits?.referralCreditsEarned || 0,
    };
  }


  // Affiliate program methods
  async getAffiliateByUserId(userId: string): Promise<Affiliate | undefined> {
    const [affiliate] = await db.select().from(affiliates).where(eq(affiliates.userId, userId));
    return affiliate || undefined;
  }

  async getAffiliateByCode(code: string): Promise<Affiliate | undefined> {
    const [affiliate] = await db.select().from(affiliates).where(eq(affiliates.referralCode, code));
    return affiliate || undefined;
  }

  async createAffiliate(data: InsertAffiliate): Promise<Affiliate> {
    const [affiliate] = await db.insert(affiliates).values(data).returning();
    return affiliate;
  }

  async updateAffiliate(id: string, data: Partial<Affiliate>): Promise<Affiliate | undefined> {
    const [updated] = await db
      .update(affiliates)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(affiliates.id, id))
      .returning();
    return updated;
  }

  async getAffiliateReferrals(affiliateId: string): Promise<AffiliateReferral[]> {
    return db.select().from(affiliateReferrals).where(eq(affiliateReferrals.affiliateId, affiliateId)).orderBy(desc(affiliateReferrals.createdAt));
  }

  async createAffiliateReferral(data: Partial<AffiliateReferral>): Promise<AffiliateReferral> {
    const [referral] = await db.insert(affiliateReferrals).values(data as any).returning();
    return referral;
  }

  async updateAffiliateReferral(id: string, data: Partial<AffiliateReferral>): Promise<AffiliateReferral | undefined> {
    const [updated] = await db.update(affiliateReferrals).set(data).where(eq(affiliateReferrals.id, id)).returning();
    return updated || undefined;
  }



  async getAffiliate(id: string): Promise<Affiliate | undefined> {
    const [affiliate] = await db
      .select()
      .from(affiliates)
      .where(eq(affiliates.id, id));
    return affiliate;
  }

  async getAffiliateBySlug(slug: string): Promise<Affiliate | undefined> {
    const [affiliate] = await db
      .select()
      .from(affiliates)
      .where(eq(affiliates.slug, slug));
    return affiliate;
  }

  async getAffiliateEarnings(affiliateId: string): Promise<AffiliateEarning[]> {
    return db.select().from(affiliateEarnings).where(eq(affiliateEarnings.affiliateId, affiliateId)).orderBy(desc(affiliateEarnings.createdAt));
  }

  async createAffiliateEarning(data: Partial<AffiliateEarning>): Promise<AffiliateEarning> {
    const [earning] = await db.insert(affiliateEarnings).values(data as any).returning();

    // Update affiliate totals
    await db
      .update(affiliates)
      .set({
        totalEarnings: sql`${affiliates.totalEarnings} + ${data.commissionAmount}`,
        availableBalance: sql`${affiliates.availableBalance} + ${data.commissionAmount}`,
        updatedAt: new Date(),
      })
      .where(eq(affiliates.id, data.affiliateId!));

    return earning;
  }

  async updateAffiliateEarning(id: string, data: Partial<AffiliateEarning>): Promise<AffiliateEarning | undefined> {
    const [updated] = await db.update(affiliateEarnings).set(data).where(eq(affiliateEarnings.id, id)).returning();
    return updated;
  }

  async getAffiliatePayouts(affiliateId: string): Promise<AffiliatePayout[]> {
    return db.select().from(affiliatePayouts).where(eq(affiliatePayouts.affiliateId, affiliateId)).orderBy(desc(affiliatePayouts.requestedAt));
  }

  async createAffiliatePayout(data: Partial<AffiliatePayout>): Promise<AffiliatePayout> {
    const [payout] = await db.insert(affiliatePayouts).values(data as any).returning();

    // Deduct from available balance
    if (data.affiliateId && data.amount) {
      await this.updateAffiliateBalance(data.affiliateId, data.amount, 'subtract');
    }

    return payout;
  }

  async updateAffiliatePayout(id: string, data: Partial<AffiliatePayout>): Promise<AffiliatePayout | undefined> {
    const [updated] = await db.update(affiliatePayouts).set(data).where(eq(affiliatePayouts.id, id)).returning();

    // If payout is marked as paid, update affiliate balances
    if (data.status === "paid") {
      const payout = await db.select().from(affiliatePayouts).where(eq(affiliatePayouts.id, id));
      if (payout[0]) {
        await db
          .update(affiliates)
          .set({
            availableBalance: sql`${affiliates.availableBalance} - ${payout[0].amount}`,
            paidTotal: sql`${affiliates.paidTotal} + ${payout[0].amount}`,
            updatedAt: new Date(),
          })
          .where(eq(affiliates.id, payout[0].affiliateId));
      }
    }

    return updated;
  }

  async getAllAffiliates(): Promise<Affiliate[]> {
    return db.select().from(affiliates).orderBy(desc(affiliates.createdAt));
  }

  async getCalculatedBalances(affiliateId: string): Promise<{ available: number; pending: number }> {
    // Get affiliate to check default payoutDays setting
    const affiliate = await this.getAffiliate(affiliateId);
    const defaultPayoutDays = affiliate?.payoutDays ?? 30; // Default to 30 if not found

    const now = new Date();

    // Fetch all earnings for the affiliate that are not reversed
    // We need to fetch individual records to check per-earning payoutDays
    const earnings = await db
      .select({
        amount: affiliateEarnings.commissionAmount,
        createdAt: affiliateEarnings.createdAt,
        payoutDays: affiliateEarnings.payoutDays
      })
      .from(affiliateEarnings)
      .where(
        and(
          eq(affiliateEarnings.affiliateId, affiliateId),
          ne(affiliateEarnings.status, "reversed")
        )
      );

    let maturedTotal = 0;
    let pendingTotal = 0;

    for (const earning of earnings) {
      const term = earning.payoutDays ?? defaultPayoutDays;
      const maturityDate = new Date(earning.createdAt!);
      maturityDate.setDate(maturityDate.getDate() + term);

      if (now >= maturityDate) {
        maturedTotal += earning.amount;
      } else {
        pendingTotal += earning.amount;
      }
    }

    // Get total paid payouts (approved/paid) + pending payouts (reserved funds)
    const payouts = await db
      .select({ total: sql<number>`sum(${affiliatePayouts.amount})` })
      .from(affiliatePayouts)
      .where(
        and(
          eq(affiliatePayouts.affiliateId, affiliateId),
          or(
            eq(affiliatePayouts.status, "approved"),
            eq(affiliatePayouts.status, "paid"),
            eq(affiliatePayouts.status, "pending")
          )
        )
      );

    const payoutsTotal = payouts[0]?.total || 0;

    // Available = Matured Earnings - All Payouts (Pending + Approved/Paid)
    // This logic treats Pending Payouts as effectively "reserved" from the Available Balance
    const available = Math.max(0, maturedTotal - payoutsTotal);

    return {
      available,
      pending: pendingTotal
    };
  }

  async releaseAffiliateBalance(affiliateId: string): Promise<void> {
    await db
      .update(affiliateEarnings)
      .set({ payoutDays: 0 })
      .where(
        and(
          eq(affiliateEarnings.affiliateId, affiliateId),
          ne(affiliateEarnings.status, "reversed")
        )
      );

    // Force recalculation and update cache to ensure frontend reflects changes immediately
    const { available } = await this.getCalculatedBalances(affiliateId);
    await this.updateAffiliate(affiliateId, { availableBalance: available });
  }

  async getAllPendingPayouts(): Promise<AffiliatePayout[]> {
    return db.select().from(affiliatePayouts).where(eq(affiliatePayouts.status, "pending")).orderBy(affiliatePayouts.requestedAt);
  }

  async getReferralByUserId(userId: string): Promise<AffiliateReferral | undefined> {
    const [referral] = await db.select().from(affiliateReferrals).where(eq(affiliateReferrals.referredUserId, userId));
    return referral || undefined;
  }

  async getGeneratedImages(userId: string, limit?: number, offset?: number): Promise<GeneratedImage[]> {
    let query: any = db.select().from(generatedImages).where(eq(generatedImages.userId, userId)).orderBy(desc(generatedImages.createdAt));
    if (limit) {
      query = query.limit(limit);
    }
    if (offset) {
      query = query.offset(offset);
    }
    return query;
  }

  async getGeneratedImageCountsByUserInRange(dateFrom?: Date, dateTo?: Date): Promise<{ userId: string; count: number }[]> {
    const conditions = [];
    if (dateFrom) conditions.push(gte(generatedImages.createdAt, dateFrom));
    if (dateTo) conditions.push(lte(generatedImages.createdAt, dateTo));
    let rows: { userId: string; count: number }[];
    if (conditions.length > 0) {
      rows = await db
        .select({
          userId: generatedImages.userId,
          count: sql<number>`count(*)::int`,
        })
        .from(generatedImages)
        .where(and(...conditions))
        .groupBy(generatedImages.userId);
    } else {
      rows = await db
        .select({
          userId: generatedImages.userId,
          count: sql<number>`count(*)::int`,
        })
        .from(generatedImages)
        .groupBy(generatedImages.userId);
    }
    return rows.map(r => ({ userId: r.userId, count: Number(r.count) }));
  }

  async getUsageByUserInRange(
    source: "lipsyncs" | "motionControls" | "filmProjects" | "generatedImages" | "imageEdits" | "backgroundRemovals" | "extendedImages" | "audios" | "soundEffects" | "transcriptions" | "chat",
    dateFrom?: Date,
    dateTo?: Date
  ): Promise<{ userId: string; count: number; totalCredits: number }[]> {

          const addConditions = (col: any) => {
            const c: any[] = [];
            if (dateFrom) c.push(gte(col, dateFrom));
            if (dateTo) c.push(lte(col, dateTo));
            return c.length > 0 ? and(...c) : undefined;
          };

          type Row = { userId: string; count: number; totalCredits: number };
          let rows: Row[] = [];

          if (source === "generatedImages") {
            const w = addConditions(generatedImages.createdAt);
            rows = await (w
              ? db.select({ userId: generatedImages.userId, count: sql<number>`count(*)::int`, totalCredits: sql<number>`coalesce(sum(${generatedImages.creditCost}), 0)::int` }).from(generatedImages).where(w).groupBy(generatedImages.userId)
              : db.select({ userId: generatedImages.userId, count: sql<number>`count(*)::int`, totalCredits: sql<number>`coalesce(sum(${generatedImages.creditCost}), 0)::int` }).from(generatedImages).groupBy(generatedImages.userId));
          }

          return rows.map(r => ({ userId: r.userId, count: Number(r.count), totalCredits: Number(r.totalCredits) }));
              
  }

  async getGeneratedImage(id: string): Promise<GeneratedImage | undefined> {
    const [image] = await db.select().from(generatedImages).where(eq(generatedImages.id, id));
    return image || undefined;
  }

  async getGeneratedImageByTaskId(taskId: string): Promise<GeneratedImage | undefined> {
    const [image] = await db.select().from(generatedImages).where(eq(generatedImages.taskId, taskId));
    return image || undefined;
  }

  async createGeneratedImage(userId: string, data: InsertGeneratedImage & { creditCost: number; sessionId?: string }): Promise<GeneratedImage> {
    const [image] = await db.insert(generatedImages).values({
      userId,
      sessionId: data.sessionId || null,
      prompt: data.prompt,
      negativePrompt: data.negativePrompt,
      model: data.model,
      aspectRatio: data.aspectRatio,
      creditCost: data.creditCost,
      status: "pending",
    }).returning();
    return image;
  }

  async updateGeneratedImage(id: string, data: Partial<GeneratedImage>): Promise<GeneratedImage | undefined> {
    const [image] = await db.update(generatedImages).set(data).where(eq(generatedImages.id, id)).returning();
    return image || undefined;
  }

  async completeGeneratedImageIfActive(
    id: string,
    imageUrl: string,
    completedAt: Date
  ): Promise<{ image?: GeneratedImage; transitioned: boolean }> {
    return await db.transaction(async (tx) => {
      const [image] = await tx
        .select()
        .from(generatedImages)
        .where(eq(generatedImages.id, id))
        .for("update")
        .limit(1);

      if (!image) return { transitioned: false };
      if (image.status === "completed" || image.status === "failed") {
        return { image, transitioned: false };
      }

      const [updated] = await tx
        .update(generatedImages)
        .set({ status: "completed", imageUrl, completedAt })
        .where(eq(generatedImages.id, id))
        .returning();

      return { image: updated, transitioned: true };
    });
  }

  async failGeneratedImageAndRefundIfActive(
    id: string,
    errorMessage: string,
    refundDescription: string
  ): Promise<{
    image?: GeneratedImage;
    transitioned: boolean;
    refunded: boolean;
    freeSessionId: string | null;
  }> {
    return await db.transaction(async (tx) => {
      const [image] = await tx
        .select()
        .from(generatedImages)
        .where(eq(generatedImages.id, id))
        .for("update")
        .limit(1);

      if (!image) {
        return { transitioned: false, refunded: false, freeSessionId: null };
      }

      if (image.status === "completed" || image.status === "failed") {
        return { image, transitioned: false, refunded: false, freeSessionId: null };
      }

      const [failedImage] = await tx
        .update(generatedImages)
        .set({ status: "failed", errorMessage })
        .where(eq(generatedImages.id, image.id))
        .returning();

      if (image.creditCost <= 0) {
        return {
          image: failedImage,
          transitioned: true,
          refunded: false,
          freeSessionId: image.sessionId ?? null,
        };
      }

      let [credits] = await tx
        .select()
        .from(userCredits)
        .where(eq(userCredits.userId, image.userId))
        .for("update")
        .limit(1);

      if (!credits) {
        await tx
          .insert(userCredits)
          .values({ userId: image.userId, balance: 0 })
          .onConflictDoNothing({ target: userCredits.userId });

        [credits] = await tx
          .select()
          .from(userCredits)
          .where(eq(userCredits.userId, image.userId))
          .for("update")
          .limit(1);
      }

      if (!credits) {
        throw new Error("Falha ao criar carteira de créditos para reembolso");
      }

      await tx
        .update(userCredits)
        .set({
          balance: credits.balance + image.creditCost,
          totalPurchased: credits.totalPurchased + image.creditCost,
          updatedAt: new Date(),
        })
        .where(eq(userCredits.id, credits.id));

      await tx.insert(creditTransactions).values({
        userId: image.userId,
        amount: image.creditCost,
        type: "refund",
        description: refundDescription,
      });

      return {
        image: failedImage,
        transitioned: true,
        refunded: true,
        freeSessionId: null,
      };
    });
  }

  async deleteGeneratedImage(id: string): Promise<void> {
    await db.delete(generatedImages).where(eq(generatedImages.id, id));
  }

  async userHasCompletedGeneratedImage(userId: string): Promise<boolean> {
    const [row] = await db
      .select({ id: generatedImages.id })
      .from(generatedImages)
      .where(
        and(
          eq(generatedImages.userId, userId),
          eq(generatedImages.status, "completed"),
          isNotNull(generatedImages.imageUrl),
        )
      )
      .limit(1);
    return !!row;
  }

  // ═══ IMAGE SESSIONS ═══
  // Image Edit methods

  async getGalleryImages(userId: string, filter: string, limit: number, offset: number): Promise<{ items: GalleryImage[]; total: number }> {
          const conditions = [eq(generatedImages.userId, userId), eq(generatedImages.status, "completed"), isNotNull(generatedImages.imageUrl)];
          if (filter === "favorites") {
              conditions.push(eq(generatedImages.isFavorite, true));
          }
          
          let q: any = db.select().from(generatedImages).where(and(...conditions)).orderBy(desc(generatedImages.createdAt));
          let countQ: any = db.select({ count: count() }).from(generatedImages).where(and(...conditions));

          const [itemsRows, [{ count: totalCount }]] = await Promise.all([
            q.limit(limit).offset(offset),
            countQ,
          ]);

          return {
            items: itemsRows.map((img: any) => ({
              id: img.id,
              url: img.imageUrl,
              prompt: img.prompt,
              type: 'image' as const,
              createdAt: img.createdAt,
            })),
            total: Number(totalCount),
          };
  }

  async resetMonthlyUsage(userId: string): Promise<void> {
    await db.update(userCredits)
      .set({
        monthlyImageCount: 0,
        monthlyVideoCount: 0,
        lastMonthlyReset: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(userCredits.userId, userId));
  }

  async incrementMonthlyImageCount(userId: string): Promise<void> {
    await db.update(userCredits)
      .set({
        monthlyImageCount: sql`${userCredits.monthlyImageCount} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(userCredits.userId, userId));
  }

  // Motion Control methods
  // Chat methods
  // Extended Image methods
  // Affiliate helper methods
  async getAffiliatePayout(id: string): Promise<AffiliatePayout | undefined> {
    const [payout] = await db.select().from(affiliatePayouts).where(eq(affiliatePayouts.id, id));
    return payout || undefined;
  }

  async updateAffiliateBalance(affiliateId: string, amount: number, type: 'add' | 'subtract'): Promise<void> {
    // Direct update:
    const [affiliateData] = await db.select().from(affiliates).where(eq(affiliates.id, affiliateId));
    if (!affiliateData) return;

    const currentBalance = affiliateData.availableBalance;
    const newBalance = type === 'add' ? currentBalance + amount : currentBalance - amount;

    await db.update(affiliates)
      .set({ availableBalance: newBalance })
      .where(eq(affiliates.id, affiliateId));
  }

  // Webhook log methods
  async createWebhookLog(data: InsertWebhookLog): Promise<WebhookLog> {
    const [log] = await db.insert(webhookLogs).values(data).returning();
    return log;
  }

  async getWebhookLogs(limit: number = 100, offset: number = 0): Promise<WebhookLog[]> {
    return db.select().from(webhookLogs)
      .orderBy(desc(webhookLogs.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return user || undefined;
  }

  async deleteUserByEmail(email: string): Promise<boolean> {
          const userToDel = await this.getUserByEmail(email);
          if (!userToDel) return false;
          const userId = userToDel.id;

          await db.transaction(async (tx) => {
            await tx.delete(generatedImages).where(eq(generatedImages.userId, userId));
            await tx.delete(userFingerprints).where(eq(userFingerprints.userId, userId));
            await tx.delete(webhookLogs).where(eq(webhookLogs.email, email));
            await tx.delete(adminAuditLog).where(eq(adminAuditLog.targetUserId, userId));
            await tx.delete(adminAuditLog).where(eq(adminAuditLog.adminUserId, userId));
            await tx.delete(pixPayments).where(eq(pixPayments.userId, userId));
            await tx.delete(videoPovRequests).where(eq(videoPovRequests.userId, userId));
            
            const affiliate = await tx.select().from(affiliates).where(eq(affiliates.userId, userId));
            if (affiliate.length > 0) {
              const aId = affiliate[0].id;
              await tx.delete(affiliateReferrals).where(or(eq(affiliateReferrals.affiliateId, aId), eq(affiliateReferrals.referredUserId, userId)));
              await tx.delete(affiliateEarnings).where(eq(affiliateEarnings.affiliateId, aId));
              await tx.delete(affiliatePayouts).where(eq(affiliatePayouts.affiliateId, aId));
              await tx.delete(affiliates).where(eq(affiliates.id, aId));
            } else {
              await tx.delete(affiliateReferrals).where(eq(affiliateReferrals.referredUserId, userId));
            }
            
            await tx.delete(creditTransactions).where(eq(creditTransactions.userId, userId));
            await tx.delete(userCredits).where(eq(userCredits.userId, userId));
            await tx.delete(users).where(eq(users.id, userId));
          });
          return true;
  }

  async clearUserHistory(userId: string, mediaTypes: string[], cutoffDate: Date | null): Promise<{ deleted: Record<string, number> }> {
          const buildConditions = (tableRef: any) => {
            const conditions = [eq(tableRef.userId, userId)];
            if (cutoffDate) {
              conditions.push(gte(tableRef.createdAt, cutoffDate));
            }
            return and(...conditions);
          };

          let deletedImages = 0;
          if (mediaTypes.includes('image')) {
            await db.transaction(async (tx) => {
              const result = await tx.delete(generatedImages).where(buildConditions(generatedImages)).returning({ id: generatedImages.id });
              deletedImages = result.length;
            });
          }
          
          return { deleted: { image: deletedImages } };
  }

  async updateUserTaxId(userId: string, taxId: string): Promise<void> {
    await db.update(users).set({ taxId }).where(eq(users.id, userId));
  }

  async createPixPayment(data: Omit<InsertPixPayment, "id" | "externalId" | "createdAt">): Promise<PixPayment> {
    const [payment] = await db.insert(pixPayments).values(data).returning();
    return payment;
  }

  async createVideoPovRequest(
    userId: string,
    data: {
      position: string;
      hole: string;
      sexType: string;
      speechType: string;
      amountCents?: number;
      sessionId?: string | null;
      previewAnalysisImageUrl?: string | null;
      previewAnalysisStatus?: VideoPovPreviewAnalysisStatus;
    }
  ): Promise<VideoPovRequest> {
    const [request] = await db
      .insert(videoPovRequests)
      .values({
        userId,
        sessionId: data.sessionId ?? null,
        position: data.position,
        hole: data.hole,
        sexType: data.sexType,
        speechType: data.speechType,
        amountCents: data.amountCents ?? 1990,
        status: "pending_payment",
        previewAnalysisImageUrl: data.previewAnalysisImageUrl ?? null,
        previewAnalysisStatus: data.previewAnalysisStatus ?? "pending",
        updatedAt: new Date(),
      })
      .returning();
    return request;
  }

  async getRecentVideoPovRequestByFingerprint(
    userId: string,
    sessionId: string | null,
    data: {
      position: string;
      hole: string;
      sexType: string;
      speechType: string;
      previewAnalysisImageUrl?: string | null;
      since: Date;
    }
  ): Promise<VideoPovRequest | undefined> {
    const sessionCondition = sessionId
      ? eq(videoPovRequests.sessionId, sessionId)
      : isNull(videoPovRequests.sessionId);
    const previewImageCondition = data.previewAnalysisImageUrl
      ? eq(videoPovRequests.previewAnalysisImageUrl, data.previewAnalysisImageUrl)
      : isNull(videoPovRequests.previewAnalysisImageUrl);
    const [request] = await db
      .select()
      .from(videoPovRequests)
      .where(and(
        eq(videoPovRequests.userId, userId),
        sessionCondition,
        previewImageCondition,
        eq(videoPovRequests.position, data.position),
        eq(videoPovRequests.hole, data.hole),
        eq(videoPovRequests.sexType, data.sexType),
        eq(videoPovRequests.speechType, data.speechType),
        gte(videoPovRequests.createdAt, data.since),
      ))
      .orderBy(desc(videoPovRequests.createdAt))
      .limit(1);
    return request || undefined;
  }

  async getVideoPovRequest(id: string): Promise<VideoPovRequest | undefined> {
    const [request] = await db
      .select()
      .from(videoPovRequests)
      .where(eq(videoPovRequests.id, id))
      .limit(1);
    return request || undefined;
  }

  async updateVideoPovRequest(id: string, data: VideoPovRequestUpdate): Promise<VideoPovRequest | undefined> {
    const [request] = await db
      .update(videoPovRequests)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(videoPovRequests.id, id))
      .returning();
    return request || undefined;
  }

  async getPixPayment(id: string): Promise<PixPayment | undefined> {
    const [payment] = await db.select().from(pixPayments).where(eq(pixPayments.id, id));
    return payment || undefined;
  }

  async getPixPaymentByAbacateId(abacatePayId: string): Promise<PixPayment | undefined> {
    const [payment] = await db.select().from(pixPayments).where(eq(pixPayments.abacatePayId, abacatePayId));
    return payment || undefined;
  }

  async updatePixPaymentStatus(id: string, status: string, paidAt?: Date): Promise<void> {
    const updateData: any = { status };
    if (paidAt) updateData.paidAt = paidAt;
    await db.update(pixPayments).set(updateData).where(eq(pixPayments.id, id));
  }

  async getPaidPixPaymentsInRange(
    from: Date,
    to: Date
  ): Promise<{ payment: PixPayment; email: string | null }[]> {
    const rows = await db
      .select({
        payment: pixPayments,
        email: users.email,
      })
      .from(pixPayments)
      .innerJoin(users, eq(pixPayments.userId, users.id))
      .where(
        and(
          eq(pixPayments.status, "paid"),
          isNotNull(pixPayments.paidAt),
          gte(pixPayments.paidAt, from),
          lte(pixPayments.paidAt, to)
        )
      )
      .orderBy(asc(pixPayments.paidAt));
    return rows.map((r) => ({ payment: r.payment, email: r.email ?? null }));
  }

  async upsertFunnelSession(data: {
    sessionId: string;
    userId?: string | null;
    step?: FunnelStep;
    uploadedPhotoUrl?: string | null;
    generatedPhotoUrl?: string | null;
    customerName?: string | null;
    customerEmail?: string | null;
    utmSource?: string | null;
    utmMedium?: string | null;
    utmCampaign?: string | null;
    utmContent?: string | null;
    utmTerm?: string | null;
    isPaid?: boolean;
    paidAt?: Date | null;
    saleAmountCents?: number | null;
    saleTransactionId?: string | null;
    saleProvider?: string | null;
    saleEvent?: string | null;
  }): Promise<FunnelSession> {
    // Wrap the read-modify-write in a transaction with SELECT ... FOR UPDATE
    // so concurrent events for the same sessionId can't regress
    // maxStepReached or stomp each other's partial updates.
    return await db.transaction(async (tx) => {
      const now = new Date();

      const [existing] = await tx
        .select()
        .from(funnelSessions)
        .where(eq(funnelSessions.sessionId, data.sessionId))
        .for("update")
        .limit(1);

      if (!existing) {
        const [created] = await tx.insert(funnelSessions).values({
          sessionId: data.sessionId,
          userId: data.userId ?? null,
          currentStep: data.step ?? "visitor_entered",
          maxStepReached: data.step ?? "visitor_entered",
          visitorFirstSeenAt: now,
          visitorLastSeenAt: now,
          uploadedPhotoUrl: data.uploadedPhotoUrl ?? null,
          generatedPhotoUrl: data.generatedPhotoUrl ?? null,
          customerName: data.customerName ?? null,
          customerEmail: data.customerEmail ?? null,
          utmSource: data.utmSource ?? null,
          utmMedium: data.utmMedium ?? null,
          utmCampaign: data.utmCampaign ?? null,
          utmContent: data.utmContent ?? null,
          utmTerm: data.utmTerm ?? null,
          isPaid: data.isPaid ?? false,
          paidAt: data.paidAt ?? null,
          saleAmountCents: data.saleAmountCents ?? null,
          saleTransactionId: data.saleTransactionId ?? null,
          saleProvider: data.saleProvider ?? null,
          saleEvent: data.saleEvent ?? null,
          updatedAt: now,
        }).returning();
        return created;
      }

      const updateData: Partial<FunnelSession> = {
        visitorLastSeenAt: now,
        updatedAt: now,
      };
      if (data.userId !== undefined) updateData.userId = data.userId;
      if (data.step !== undefined) {
        updateData.currentStep = data.step;
        updateData.maxStepReached = getMaxFunnelStep(existing.maxStepReached, data.step);
      }
      if (data.uploadedPhotoUrl !== undefined) updateData.uploadedPhotoUrl = data.uploadedPhotoUrl;
      if (data.generatedPhotoUrl !== undefined) updateData.generatedPhotoUrl = data.generatedPhotoUrl;
      if (data.customerName !== undefined) updateData.customerName = data.customerName;
      if (data.customerEmail !== undefined) updateData.customerEmail = data.customerEmail;
      if (data.utmSource !== undefined) updateData.utmSource = data.utmSource;
      if (data.utmMedium !== undefined) updateData.utmMedium = data.utmMedium;
      if (data.utmCampaign !== undefined) updateData.utmCampaign = data.utmCampaign;
      if (data.utmContent !== undefined) updateData.utmContent = data.utmContent;
      if (data.utmTerm !== undefined) updateData.utmTerm = data.utmTerm;
      if (data.isPaid !== undefined) updateData.isPaid = data.isPaid;
      if (data.paidAt !== undefined) updateData.paidAt = data.paidAt;
      if (data.saleAmountCents !== undefined) updateData.saleAmountCents = data.saleAmountCents;
      if (data.saleTransactionId !== undefined) updateData.saleTransactionId = data.saleTransactionId;
      if (data.saleProvider !== undefined) updateData.saleProvider = data.saleProvider;
      if (data.saleEvent !== undefined) updateData.saleEvent = data.saleEvent;

      const [updated] = await tx
        .update(funnelSessions)
        .set(updateData)
        .where(eq(funnelSessions.sessionId, data.sessionId))
        .returning();
      return updated;
    });
  }

  async createFunnelEvent(data: {
    sessionId: string;
    userId?: string | null;
    step: FunnelStep;
    eventName: string;
    idempotencyKey?: string | null;
    metadata?: Record<string, unknown>;
    occurredAt?: Date;
  }): Promise<FunnelEvent | null> {
    await this.upsertFunnelSession({
      sessionId: data.sessionId,
      userId: data.userId ?? null,
      step: data.step,
    });

    try {
      const [event] = await db
        .insert(funnelEvents)
        .values({
          sessionId: data.sessionId,
          userId: data.userId ?? null,
          step: data.step,
          eventName: data.eventName,
          idempotencyKey: data.idempotencyKey ?? null,
          metadata: data.metadata ?? {},
          occurredAt: data.occurredAt ?? new Date(),
        })
        .returning();
      return event;
    } catch (error: any) {
      if ((error?.code === "23505" || error?.cause?.code === "23505") && data.idempotencyKey) {
        return null;
      }
      throw error;
    }
  }

  async getFunnelStepCounts(dateFrom: Date, dateTo: Date): Promise<Record<FunnelStep, number>> {
    const steps: FunnelStep[] = [
      "visitor_entered",
      "photo_uploaded",
      "generated_photo_viewed",
      "offer_viewed",
      "offer_responded",
      "video_loading_screen",
      "video_loaded",
      "pix_generated",
      "pix_paid",
    ];

    const rows = await db
      .select({
        step: funnelEvents.step,
        count: sql<number>`count(distinct ${funnelEvents.sessionId})::int`,
      })
      .from(funnelEvents)
      .where(and(gte(funnelEvents.occurredAt, dateFrom), lte(funnelEvents.occurredAt, dateTo)))
      .groupBy(funnelEvents.step);

    const output = {} as Record<FunnelStep, number>;
    for (const step of steps) output[step] = 0;
    for (const row of rows) output[row.step] = Number(row.count || 0);
    return output;
  }

  async getGeneratedMediaCountInRange(dateFrom: Date, dateTo: Date): Promise<number> {
    const [row] = await db
      .select({
        count: sql<number>`count(*)::int`,
      })
      .from(generatedImages)
      .where(
        and(
          eq(generatedImages.status, "completed"),
          or(
            and(
              isNotNull(generatedImages.completedAt),
              gte(generatedImages.completedAt, dateFrom),
              lte(generatedImages.completedAt, dateTo),
            ),
            and(
              isNull(generatedImages.completedAt),
              gte(generatedImages.createdAt, dateFrom),
              lte(generatedImages.createdAt, dateTo),
            ),
          ),
        ),
      );

    return Number(row?.count || 0);
  }

  async getPixPaymentMetricsInRange(dateFrom: Date, dateTo: Date): Promise<PixPaymentMetrics> {
    const [row] = await db
      .select({
        created: sql<number>`count(*) filter (
          where ${pixPayments.brCode} is not null
            and ${pixPayments.createdAt} >= ${dateFrom}
            and ${pixPayments.createdAt} <= ${dateTo}
        )::int`,
        paid: sql<number>`count(*) filter (
          where ${pixPayments.paidAt} is not null
            and ${pixPayments.paidAt} >= ${dateFrom}
            and ${pixPayments.paidAt} <= ${dateTo}
            and ${pixPayments.status} in ('paid', 'refunded', 'chargedback')
        )::int`,
        converted: sql<number>`count(*) filter (
          where ${pixPayments.brCode} is not null
            and ${pixPayments.createdAt} >= ${dateFrom}
            and ${pixPayments.createdAt} <= ${dateTo}
            and ${pixPayments.status} in ('paid', 'refunded', 'chargedback')
        )::int`,
        activePaid: sql<number>`count(*) filter (
          where ${pixPayments.status} = 'paid'
            and ${pixPayments.paidAt} is not null
            and ${pixPayments.paidAt} >= ${dateFrom}
            and ${pixPayments.paidAt} <= ${dateTo}
        )::int`,
        refunded: sql<number>`count(*) filter (
          where ${pixPayments.status} = 'refunded'
            and ${pixPayments.refundedAt} is not null
            and ${pixPayments.refundedAt} >= ${dateFrom}
            and ${pixPayments.refundedAt} <= ${dateTo}
        )::int`,
        chargedback: sql<number>`count(*) filter (
          where ${pixPayments.status} = 'chargedback'
            and ${pixPayments.refundedAt} is not null
            and ${pixPayments.refundedAt} >= ${dateFrom}
            and ${pixPayments.refundedAt} <= ${dateTo}
        )::int`,
        grossRevenueCents: sql<number>`coalesce(sum(${pixPayments.amountCents}) filter (
          where ${pixPayments.paidAt} is not null
            and ${pixPayments.paidAt} >= ${dateFrom}
            and ${pixPayments.paidAt} <= ${dateTo}
            and ${pixPayments.status} in ('paid', 'refunded', 'chargedback')
        ), 0)::int`,
        refundedCents: sql<number>`coalesce(sum(${pixPayments.amountCents}) filter (
          where ${pixPayments.status} in ('refunded', 'chargedback')
            and ${pixPayments.refundedAt} is not null
            and ${pixPayments.refundedAt} >= ${dateFrom}
            and ${pixPayments.refundedAt} <= ${dateTo}
        ), 0)::int`,
      })
      .from(pixPayments);

    const grossRevenueCents = Number(row?.grossRevenueCents || 0);
    const refundedCents = Number(row?.refundedCents || 0);
      return {
        created: Number(row?.created || 0),
        converted: Number(row?.converted || 0),
        paid: Number(row?.paid || 0),
      activePaid: Number(row?.activePaid || 0),
      refunded: Number(row?.refunded || 0),
      chargedback: Number(row?.chargedback || 0),
      grossRevenueCents,
      refundedCents,
      netRevenueCents: grossRevenueCents - refundedCents,
    };
  }


  async getAdminCustomers(params: {
    dateFrom: Date;
    dateTo: Date;
    search?: string;
    paymentStatus?: "paid" | "unpaid" | "all";
    leadStage?: AdminCustomerLeadStage;
    responseKind?: AdminCustomerResponseKind;
    pixProduct?: AdminPixProductKey;
    sortBy?: AdminCustomerSortBy;
    sortDir?: AdminCustomerSortDir;
    limit: number;
    offset: number;
  }): Promise<{ rows: AdminCustomerUnifiedRow[]; total: number }> {
    const conditions: SQL[] = [
      gte(funnelSessions.visitorFirstSeenAt, params.dateFrom),
      lte(funnelSessions.visitorFirstSeenAt, params.dateTo),
    ];

    if (params.paymentStatus === "paid") {
      conditions.push(eq(funnelSessions.isPaid, true));
    } else if (params.paymentStatus === "unpaid") {
      conditions.push(eq(funnelSessions.isPaid, false));
    }

    if (params.leadStage === "photo_generated") {
      conditions.push(or(
        isNotNull(funnelSessions.generatedPhotoUrl),
        inArray(funnelSessions.maxStepReached, [
          "generated_photo_viewed",
          "offer_viewed",
          "offer_responded",
          "video_loading_screen",
          "video_loaded",
          "pix_generated",
          "pix_paid",
        ]),
      )!);
    } else if (params.leadStage === "generation_error") {
      conditions.push(isNotNull(funnelSessions.uploadedPhotoUrl));
      conditions.push(isNull(funnelSessions.generatedPhotoUrl));
      conditions.push(eq(funnelSessions.maxStepReached, "photo_uploaded"));
      conditions.push(sql`
        exists (
          select 1
          from ${generatedImages}
          where ${generatedImages.userId} = ${funnelSessions.userId}
            and ${generatedImages.createdAt} >= ${funnelSessions.visitorFirstSeenAt}
            and ${generatedImages.status} = 'failed'
        )
      `);
    } else if (params.leadStage === "first_screen") {
      conditions.push(eq(funnelSessions.maxStepReached, "visitor_entered"));
      conditions.push(isNull(funnelSessions.uploadedPhotoUrl));
    }

    const search = (params.search || "").trim();
    if (search) {
      const term = `%${search}%`;
      conditions.push(or(
        ilike(funnelSessions.sessionId, term),
        ilike(funnelSessions.customerName, term),
        ilike(funnelSessions.customerEmail, term),
        ilike(funnelSessions.utmSource, term),
        ilike(funnelSessions.utmCampaign, term),
      )!);
    }

    if (params.responseKind) conditions.push(buildAdminResponseKindCondition(params.responseKind));
    if (params.pixProduct) conditions.push(buildAdminPixProductCondition(params.pixProduct));

    const where = and(...conditions);
    const sortColumn = ADMIN_CUSTOMER_SORTABLE_COLUMNS[params.sortBy ?? "visitorLastSeenAt"]
      ?? ADMIN_CUSTOMER_SORTABLE_COLUMNS.visitorLastSeenAt;
    const sortOrder = params.sortDir === "asc" ? asc(sortColumn) : desc(sortColumn);
    const fallbackLastSeenOrder = params.sortDir === "asc"
      ? asc(funnelSessions.visitorLastSeenAt)
      : desc(funnelSessions.visitorLastSeenAt);
    const fallbackCreatedAtOrder = params.sortDir === "asc"
      ? asc(funnelSessions.createdAt)
      : desc(funnelSessions.createdAt);

    const [countRow] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(funnelSessions)
      .where(where);

    const sessionRows = await db
      .select()
      .from(funnelSessions)
      .where(where)
      .orderBy(sortOrder, fallbackLastSeenOrder, fallbackCreatedAtOrder)
      .limit(params.limit)
      .offset(params.offset);

    const sessionIds = sessionRows.map((row) => row.sessionId);
    const sessionUserIdBySessionId = new Map(sessionRows.map((row) => [row.sessionId, row.userId] as const));
    const pixEventsBySessionId = new Map<string, { planId: string | null; journeyNode: string | null }>();
    const offerEventsBySessionId = new Map<string, {
      packResponse: AdminCustomerUnifiedRow["packResponse"];
      videoPovResponse: AdminCustomerUnifiedRow["videoPovResponse"];
    }>();

    if (sessionIds.length > 0) {
      const [pixEvents, offerEvents] = await Promise.all([
        db
          .select({
            sessionId: funnelEvents.sessionId,
            metadata: funnelEvents.metadata,
            occurredAt: funnelEvents.occurredAt,
          })
          .from(funnelEvents)
          .where(and(
            inArray(funnelEvents.sessionId, sessionIds),
            eq(funnelEvents.step, "pix_generated"),
          ))
          .orderBy(desc(funnelEvents.occurredAt), desc(funnelEvents.createdAt)),
        db
          .select({
            id: funnelEvents.id,
            sessionId: funnelEvents.sessionId,
            eventName: funnelEvents.eventName,
            metadata: funnelEvents.metadata,
            occurredAt: funnelEvents.occurredAt,
          })
          .from(funnelEvents)
          .where(and(
            inArray(funnelEvents.sessionId, sessionIds),
            inArray(funnelEvents.eventName, [ADMIN_PACK_EVENT_NAME, ADMIN_VIDEO_POV_EVENT_NAME]),
          ))
          .orderBy(desc(funnelEvents.occurredAt), desc(funnelEvents.createdAt)),
      ]);

      for (const event of pixEvents) {
        if (pixEventsBySessionId.has(event.sessionId)) continue;

        const metadata = toAdminMetadataRecord(event.metadata);
        const planId = typeof metadata.planId === "string" ? metadata.planId : null;
        const journeyNode = typeof metadata.journeyNode === "string" ? metadata.journeyNode : null;

        pixEventsBySessionId.set(event.sessionId, {
          planId,
          journeyNode,
        });
      }

      const videoPovRequestIds = new Set<string>();

      for (const event of offerEvents) {
        const existing = offerEventsBySessionId.get(event.sessionId) ?? {
          packResponse: null,
          videoPovResponse: null,
        };

        const metadata = toAdminMetadataRecord(event.metadata);

        if (event.eventName === ADMIN_PACK_EVENT_NAME && !existing.packResponse) {
          existing.packResponse = {
            eventId: event.id,
            occurredAt: event.occurredAt,
            metadata: sanitizeAdminOfferMetadata(metadata, []),
          };
        }

        if (event.eventName === ADMIN_VIDEO_POV_EVENT_NAME && !existing.videoPovResponse) {
          const requestId = typeof metadata.requestId === "string" ? metadata.requestId : null;
          if (requestId) videoPovRequestIds.add(requestId);

          existing.videoPovResponse = {
            eventId: event.id,
            occurredAt: event.occurredAt,
            metadata: sanitizeAdminOfferMetadata(metadata, ["requestId", "position", "hole", "sexType", "speechType"]),
            requestId,
            position: typeof metadata.position === "string" ? metadata.position : null,
            hole: typeof metadata.hole === "string" ? metadata.hole : null,
            sexType: typeof metadata.sexType === "string" ? metadata.sexType : null,
            speechType: typeof metadata.speechType === "string" ? metadata.speechType : null,
            requestStatus: null,
            requestAmountCents: null,
            requestCreatedAt: null,
          };
        }

        offerEventsBySessionId.set(event.sessionId, existing);
      }

      if (videoPovRequestIds.size > 0) {
        const requestRows = await db
          .select()
          .from(videoPovRequests)
          .where(inArray(videoPovRequests.id, Array.from(videoPovRequestIds)));

        const requestMap = new Map(requestRows.map((request) => [request.id, request] as const));

        for (const [sessionId, eventGroup] of Array.from(offerEventsBySessionId.entries())) {
          const videoPovResponse = eventGroup.videoPovResponse;
          if (!videoPovResponse?.requestId) continue;

          const request = requestMap.get(videoPovResponse.requestId);
          if (!request) continue;

          const sessionUserId = sessionUserIdBySessionId.get(sessionId);
          if (!sessionUserId || request.userId !== sessionUserId) continue;

          eventGroup.videoPovResponse = {
            ...videoPovResponse,
            position: request.position ?? videoPovResponse.position,
            hole: request.hole ?? videoPovResponse.hole,
            sexType: request.sexType ?? videoPovResponse.sexType,
            speechType: request.speechType ?? videoPovResponse.speechType,
            requestStatus: request.status ?? null,
            requestAmountCents: request.amountCents ?? null,
            requestCreatedAt: request.createdAt ?? null,
          };
          offerEventsBySessionId.set(sessionId, eventGroup);
        }
      }
    }

    const rows = sessionRows.map((row) => {
      const pixEvent = pixEventsBySessionId.get(row.sessionId);
      const offerEvents = offerEventsBySessionId.get(row.sessionId);
      return {
        ...row,
        pixPlanId: pixEvent?.planId ?? null,
        pixJourneyNode: pixEvent?.journeyNode ?? null,
        packResponse: offerEvents?.packResponse ?? null,
        videoPovResponse: offerEvents?.videoPovResponse ?? null,
      };
    });

    return { rows, total: Number(countRow?.count || 0) };
  }

  async getAdminPackResponses(params: {
    dateFrom: Date;
    dateTo: Date;
    search?: string;
    paymentStatus?: "paid" | "unpaid" | "all";
    limit: number;
    offset: number;
  }): Promise<{ rows: AdminPackResponseRow[]; total: number }> {
    const conditions: SQL[] = [
      eq(funnelEvents.eventName, "landing.pack_photos_submit"),
      gte(funnelEvents.occurredAt, params.dateFrom),
      lte(funnelEvents.occurredAt, params.dateTo),
    ];

    if (params.paymentStatus === "paid") {
      conditions.push(eq(funnelSessions.isPaid, true));
    } else if (params.paymentStatus === "unpaid") {
      conditions.push(eq(funnelSessions.isPaid, false));
    }

    const search = (params.search || "").trim();
    if (search) {
      const term = `%${search}%`;
      conditions.push(or(
        ilike(funnelEvents.sessionId, term),
        ilike(funnelSessions.customerName, term),
        ilike(funnelSessions.customerEmail, term),
        ilike(users.username, term),
        ilike(users.email, term),
      )!);
    }

    const where = and(...conditions);

    const [countRow] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(funnelEvents)
      .innerJoin(funnelSessions, eq(funnelEvents.sessionId, funnelSessions.sessionId))
      .leftJoin(users, eq(funnelSessions.userId, users.id))
      .where(where);

    const rows = await db
      .select({
        id: funnelEvents.id,
        sessionId: funnelEvents.sessionId,
        userId: funnelSessions.userId,
        username: users.username,
        email: users.email,
        customerName: funnelSessions.customerName,
        customerEmail: funnelSessions.customerEmail,
        isPaid: funnelSessions.isPaid,
        eventName: funnelEvents.eventName,
        metadata: funnelEvents.metadata,
        occurredAt: funnelEvents.occurredAt,
      })
      .from(funnelEvents)
      .innerJoin(funnelSessions, eq(funnelEvents.sessionId, funnelSessions.sessionId))
      .leftJoin(users, eq(funnelSessions.userId, users.id))
      .where(where)
      .orderBy(desc(funnelEvents.occurredAt))
      .limit(params.limit)
      .offset(params.offset);

    return {
      rows: rows.map((row) => ({
        id: row.id,
        sessionId: row.sessionId,
        userId: row.userId,
        username: row.username,
        email: row.email,
        customerName: row.customerName,
        customerEmail: row.customerEmail,
        paymentStatus: row.isPaid ? "paid" : "unpaid",
        eventName: row.eventName,
        metadata: (row.metadata ?? {}) as Record<string, unknown>,
        occurredAt: row.occurredAt,
        kind: "pack",
      })),
      total: Number(countRow?.count || 0),
    };
  }

  async getAdminVideoPovResponses(params: {
    dateFrom: Date;
    dateTo: Date;
    search?: string;
    paymentStatus?: "paid" | "unpaid" | "all";
    limit: number;
    offset: number;
  }): Promise<{ rows: AdminVideoPovResponseRow[]; total: number }> {
    const conditions: SQL[] = [
      eq(funnelEvents.eventName, "offer.video_pov_submitted"),
      gte(funnelEvents.occurredAt, params.dateFrom),
      lte(funnelEvents.occurredAt, params.dateTo),
    ];

    if (params.paymentStatus === "paid") {
      conditions.push(eq(funnelSessions.isPaid, true));
    } else if (params.paymentStatus === "unpaid") {
      conditions.push(eq(funnelSessions.isPaid, false));
    }

    const search = (params.search || "").trim();
    if (search) {
      const term = `%${search}%`;
      conditions.push(or(
        ilike(funnelEvents.sessionId, term),
        ilike(funnelSessions.customerName, term),
        ilike(funnelSessions.customerEmail, term),
        ilike(users.username, term),
        ilike(users.email, term),
      )!);
    }

    const where = and(...conditions);

    const [countRow] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(funnelEvents)
      .innerJoin(funnelSessions, eq(funnelEvents.sessionId, funnelSessions.sessionId))
      .leftJoin(users, eq(funnelSessions.userId, users.id))
      .where(where);

    const rows = await db
      .select({
        id: funnelEvents.id,
        sessionId: funnelEvents.sessionId,
        userId: funnelSessions.userId,
        username: users.username,
        email: users.email,
        customerName: funnelSessions.customerName,
        customerEmail: funnelSessions.customerEmail,
        isPaid: funnelSessions.isPaid,
        eventName: funnelEvents.eventName,
        metadata: funnelEvents.metadata,
        occurredAt: funnelEvents.occurredAt,
      })
      .from(funnelEvents)
      .innerJoin(funnelSessions, eq(funnelEvents.sessionId, funnelSessions.sessionId))
      .leftJoin(users, eq(funnelSessions.userId, users.id))
      .where(where)
      .orderBy(desc(funnelEvents.occurredAt))
      .limit(params.limit)
      .offset(params.offset);

    const requestIds = Array.from(new Set(
      rows
        .map((row) => {
          const requestId = (row.metadata as Record<string, unknown> | null)?.requestId;
          return typeof requestId === "string" ? requestId : null;
        })
        .filter((requestId): requestId is string => Boolean(requestId)),
    ));

    const requestMap = new Map<string, VideoPovRequest>();
    if (requestIds.length > 0) {
      const povRequests = await db
        .select()
        .from(videoPovRequests)
        .where(inArray(videoPovRequests.id, requestIds));

      for (const povRequest of povRequests) {
        requestMap.set(povRequest.id, povRequest);
      }
    }

    return {
      rows: rows.map((row) => {
        const metadata = (row.metadata ?? {}) as Record<string, unknown>;
        const requestId = typeof metadata.requestId === "string" ? metadata.requestId : null;
        const request = requestId ? requestMap.get(requestId) : undefined;
        return {
          id: row.id,
          sessionId: row.sessionId,
          userId: row.userId,
          username: row.username,
          email: row.email,
          customerName: row.customerName,
          customerEmail: row.customerEmail,
          paymentStatus: row.isPaid ? "paid" : "unpaid",
          eventName: row.eventName,
          metadata,
          occurredAt: row.occurredAt,
          kind: "video_pov" as const,
          requestId,
          position: request?.position ?? (typeof metadata.position === "string" ? metadata.position : null),
          hole: request?.hole ?? (typeof metadata.hole === "string" ? metadata.hole : null),
          sexType: request?.sexType ?? (typeof metadata.sexType === "string" ? metadata.sexType : null),
          speechType: request?.speechType ?? (typeof metadata.speechType === "string" ? metadata.speechType : null),
          requestStatus: request?.status ?? null,
          requestAmountCents: request?.amountCents ?? null,
          requestCreatedAt: request?.createdAt ?? null,
        };
      }),
      total: Number(countRow?.count || 0),
    };
  }

  async getAdminRealPreviewLogs(params: {
    dateFrom: Date;
    dateTo: Date;
    search?: string;
    limit: number;
    offset: number;
  }): Promise<AdminRealPreviewLogsResult> {
    const conditions: SQL[] = [
      gte(videoPovRequests.createdAt, params.dateFrom),
      lte(videoPovRequests.createdAt, params.dateTo),
    ];

    const search = (params.search || "").trim();
    if (search) {
      const term = `%${search}%`;
      conditions.push(or(
        ilike(videoPovRequests.id, term),
        ilike(videoPovRequests.sessionId, term),
        ilike(videoPovRequests.userId, term),
        ilike(videoPovRequests.position, term),
        ilike(videoPovRequests.previewAnalysisStatus, term),
        ilike(videoPovRequests.previewAnalysisProvider, term),
        ilike(videoPovRequests.previewAnalysisError, term),
        ilike(videoPovRequests.previewVideoKey, term),
        ilike(funnelSessions.customerName, term),
        ilike(funnelSessions.customerEmail, term),
        ilike(users.username, term),
        ilike(users.email, term),
      )!);
    }

    const where = and(...conditions);
    const [summaryRow] = await db
      .select({
        total: sql<number>`count(*)::int`,
        success: sql<number>`count(*) filter (where ${videoPovRequests.previewAnalysisStatus} = 'completed' and ${videoPovRequests.previewVideoKey} is not null)::int`,
        errors: sql<number>`count(*) filter (where ${videoPovRequests.previewAnalysisStatus} = 'failed')::int`,
        previewFallbacks: sql<number>`count(*) filter (where ${videoPovRequests.previewAnalysisStatus} = 'failed')::int`,
        aiFallbacks: sql<number>`count(*) filter (where ${videoPovRequests.previewAnalysisStatus} = 'completed' and ${videoPovRequests.previewAnalysisProvider} is not null and ${videoPovRequests.previewAnalysisProvider} <> 'gpt-5.3-chat-latest')::int`,
        pending: sql<number>`count(*) filter (where ${videoPovRequests.previewAnalysisStatus} = 'pending')::int`,
        processing: sql<number>`count(*) filter (where ${videoPovRequests.previewAnalysisStatus} = 'processing')::int`,
        openAiSuccess: sql<number>`count(*) filter (where ${videoPovRequests.previewAnalysisProvider} = 'gpt-5.3-chat-latest')::int`,
        geminiFallbackSuccess: sql<number>`count(*) filter (where ${videoPovRequests.previewAnalysisProvider} = 'gemini-3-flash')::int`,
        avgResolveMs: sql<number | null>`round(avg(extract(epoch from (${videoPovRequests.previewResolvedAt} - ${videoPovRequests.createdAt})) * 1000) filter (where ${videoPovRequests.previewResolvedAt} is not null))::int`,
      })
      .from(videoPovRequests)
      .leftJoin(funnelSessions, eq(videoPovRequests.sessionId, funnelSessions.sessionId))
      .leftJoin(users, eq(videoPovRequests.userId, users.id))
      .where(where);

    const rows = await db
      .select({
        requestId: videoPovRequests.id,
        sessionId: videoPovRequests.sessionId,
        userId: videoPovRequests.userId,
        username: users.username,
        customerName: funnelSessions.customerName,
        customerEmail: funnelSessions.customerEmail,
        isPaid: funnelSessions.isPaid,
        position: videoPovRequests.position,
        previewAnalysisStatus: videoPovRequests.previewAnalysisStatus,
        previewAnalysisProvider: videoPovRequests.previewAnalysisProvider,
        previewAnalysisError: videoPovRequests.previewAnalysisError,
        previewVisualTone: videoPovRequests.previewVisualTone,
        previewBodyType: videoPovRequests.previewBodyType,
        previewVideoKey: videoPovRequests.previewVideoKey,
        previewResolvedAt: videoPovRequests.previewResolvedAt,
        createdAt: videoPovRequests.createdAt,
        updatedAt: videoPovRequests.updatedAt,
      })
      .from(videoPovRequests)
      .leftJoin(funnelSessions, eq(videoPovRequests.sessionId, funnelSessions.sessionId))
      .leftJoin(users, eq(videoPovRequests.userId, users.id))
      .where(where)
      .orderBy(desc(videoPovRequests.createdAt))
      .limit(params.limit)
      .offset(params.offset);

    const summary = {
      total: Number(summaryRow?.total || 0),
      success: Number(summaryRow?.success || 0),
      errors: Number(summaryRow?.errors || 0),
      previewFallbacks: Number(summaryRow?.previewFallbacks || 0),
      aiFallbacks: Number(summaryRow?.aiFallbacks || 0),
      pending: Number(summaryRow?.pending || 0),
      processing: Number(summaryRow?.processing || 0),
      openAiSuccess: Number(summaryRow?.openAiSuccess || 0),
      geminiFallbackSuccess: Number(summaryRow?.geminiFallbackSuccess || 0),
      avgResolveMs: summaryRow?.avgResolveMs == null ? null : Number(summaryRow.avgResolveMs),
    };

    return {
      summary,
      rows: rows.map((row) => ({
        requestId: row.requestId,
        sessionId: row.sessionId,
        userId: row.userId,
        username: row.username,
        customerName: row.customerName,
        customerEmail: row.customerEmail,
        paymentStatus: row.isPaid ? "paid" : "unpaid",
        position: row.position,
        previewAnalysisStatus: row.previewAnalysisStatus,
        previewAnalysisProvider: row.previewAnalysisProvider,
        previewAnalysisError: row.previewAnalysisError,
        previewVisualTone: row.previewVisualTone,
        previewBodyType: row.previewBodyType,
        previewVideoKey: row.previewVideoKey,
        previewResolvedAt: row.previewResolvedAt,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      })),
      total: summary.total,
    };
  }

  async getFunnelSessionDetails(sessionId: string): Promise<{ session?: FunnelSession; events: FunnelEvent[] }> {
    const [session] = await db
      .select()
      .from(funnelSessions)
      .where(eq(funnelSessions.sessionId, sessionId))
      .limit(1);

    const events = await db
      .select()
      .from(funnelEvents)
      .where(eq(funnelEvents.sessionId, sessionId))
      .orderBy(asc(funnelEvents.occurredAt));

    return {
      session: session || undefined,
      events,
    };
  }

  async createPaymentWebhookLog(data: InsertPaymentWebhookLog): Promise<PaymentWebhookLog> {
    const [row] = await db
      .insert(paymentWebhookLogs)
      .values(data)
      .returning();
    return row;
  }

  async getPaymentWebhookLogByIdempotencyKey(idempotencyKey: string): Promise<PaymentWebhookLog | undefined> {
    const [row] = await db
      .select()
      .from(paymentWebhookLogs)
      .where(eq(paymentWebhookLogs.idempotencyKey, idempotencyKey))
      .limit(1);
    return row || undefined;
  }

  async updatePaymentWebhookLog(
    idempotencyKey: string,
    data: { status: string; errorMessage?: string | null; processedAt?: Date | null }
  ): Promise<void> {
    await db
      .update(paymentWebhookLogs)
      .set({
        status: data.status,
        errorMessage: data.errorMessage ?? null,
        processedAt: data.processedAt ?? null,
      })
      .where(eq(paymentWebhookLogs.idempotencyKey, idempotencyKey));
  }

  // ─── Fingerprint / Blocking ─────────────────────────────────────

  async upsertUserFingerprint(data: {
    userId: string;
    fingerprintId: string;
    ip?: string;
    isVpn?: boolean;
    isProxy?: boolean;
    isTor?: boolean;
    vpnConfidenceScore?: "low" | "medium" | "high";
    vpnSuspected?: boolean;
    affiliateLink?: string | null;
  }): Promise<UserFingerprint> {
    const existing = await this.getUserFingerprintByUserId(data.userId);
    if (existing) {
      const [updated] = await db
        .update(userFingerprints)
        .set({
          fingerprintId: data.fingerprintId,
          ip: data.ip ?? existing.ip,
          isVpn: data.isVpn ?? existing.isVpn,
          isProxy: data.isProxy ?? existing.isProxy,
          isTor: data.isTor ?? existing.isTor,
          vpnConfidenceScore: data.vpnConfidenceScore ?? existing.vpnConfidenceScore,
          vpnSuspected: data.vpnSuspected ?? existing.vpnSuspected,
          affiliateLink: data.affiliateLink !== undefined ? data.affiliateLink : existing.affiliateLink,
          updatedAt: new Date(),
        })
        .where(eq(userFingerprints.userId, data.userId))
        .returning();
      return updated;
    }
    const [created] = await db
      .insert(userFingerprints)
      .values({
        userId: data.userId,
        fingerprintId: data.fingerprintId,
        ip: data.ip ?? null,
        isVpn: data.isVpn ?? false,
        isProxy: data.isProxy ?? false,
        isTor: data.isTor ?? false,
        vpnConfidenceScore: data.vpnConfidenceScore ?? "low",
        vpnSuspected: data.vpnSuspected ?? false,
        affiliateLink: data.affiliateLink ?? null,
      })
      .returning();
    return created;
  }

  async getUserFingerprintByUserId(userId: string): Promise<UserFingerprint | undefined> {
    const [fp] = await db.select().from(userFingerprints).where(eq(userFingerprints.userId, userId));
    return fp || undefined;
  }

  async findUsersByFingerprint(fingerprintId: string): Promise<UserFingerprint[]> {
    return db.select().from(userFingerprints).where(eq(userFingerprints.fingerprintId, fingerprintId));
  }

  async blockUser(userId: string, reason: string): Promise<void> {
    await db
      .update(userCredits)
      .set({ blocked: true, blockReason: reason, updatedAt: new Date() })
      .where(eq(userCredits.userId, userId));
  }

  async unblockUser(userId: string): Promise<void> {
    await db
      .update(userCredits)
      .set({ blocked: false, blockReason: null, updatedAt: new Date() })
      .where(eq(userCredits.userId, userId));
  }

  async isUserBlocked(userId: string): Promise<{ blocked: boolean; blockReason: string | null }> {
    const credits = await this.getUserCredits(userId);
    return {
      blocked: credits?.blocked ?? false,
      blockReason: credits?.blockReason ?? null,
    };
  }

  // ═══ A/B TESTING ═══

  async getActiveAbTests(): Promise<Array<AbTest & { variants: AbVariant[] }>> {
    const tests = await db
      .select()
      .from(abTests)
      .where(eq(abTests.status, "active"));
    if (tests.length === 0) return [];
    const variants = await db
      .select()
      .from(abVariants)
      .where(inArray(abVariants.testId, tests.map((t) => t.id)));
    return tests.map((t) => ({
      ...t,
      variants: variants.filter((v) => v.testId === t.id),
    }));
  }

  async getAllAbTestsWithVariants(): Promise<Array<AbTest & { variants: AbVariant[] }>> {
    const tests = await db
      .select()
      .from(abTests)
      .orderBy(desc(abTests.createdAt));
    if (tests.length === 0) return [];
    const variants = await db
      .select()
      .from(abVariants)
      .where(inArray(abVariants.testId, tests.map((t) => t.id)))
      .orderBy(asc(abVariants.createdAt));
    return tests.map((t) => ({
      ...t,
      variants: variants.filter((v) => v.testId === t.id),
    }));
  }

  async getActiveAbTestByPublicPath(publicPath: string, excludeId?: string): Promise<AbTest | undefined> {
    const conditions: SQL[] = [
      eq(abTests.status, "active"),
      eq(abTests.publicPath, publicPath),
    ];
    if (excludeId) conditions.push(ne(abTests.id, excludeId));

    const [test] = await db
      .select()
      .from(abTests)
      .where(and(...conditions))
      .limit(1);

    return test || undefined;
  }

  async getAbTestWithVariants(id: string): Promise<(AbTest & { variants: AbVariant[] }) | undefined> {
    const [test] = await db.select().from(abTests).where(eq(abTests.id, id));
    if (!test) return undefined;
    const variants = await db
      .select()
      .from(abVariants)
      .where(eq(abVariants.testId, id))
      .orderBy(asc(abVariants.createdAt));
    return { ...test, variants };
  }

  async createAbTestWithVariants(
    test: Pick<InsertAbTest, "name" | "slug" | "publicPath"> & { status?: "active" | "paused" | "ended" },
    variants: Array<Pick<InsertAbVariant, "name" | "slug" | "componentKey" | "weight">>,
  ): Promise<AbTest & { variants: AbVariant[] }> {
    return await db.transaction(async (tx) => {
      const [created] = await tx
        .insert(abTests)
        .values({
          name: test.name,
          slug: test.slug,
          publicPath: test.publicPath,
          status: test.status ?? "active",
        })
        .returning();
      if (variants.length === 0) {
        return { ...created, variants: [] };
      }
      const insertedVariants = await tx
        .insert(abVariants)
        .values(
          variants.map((v) => ({
            testId: created.id,
            name: v.name,
            slug: v.slug,
            componentKey: v.componentKey,
            weight: v.weight ?? 50,
          })),
        )
        .returning();
      return { ...created, variants: insertedVariants };
    });
  }

  async updateAbTest(
    id: string,
    data: { status?: "active" | "paused" | "ended"; name?: string },
    variantWeights?: Array<{ id: string; weight: number }>,
  ): Promise<(AbTest & { variants: AbVariant[] }) | undefined> {
    return await db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(abTests)
        .where(eq(abTests.id, id))
        .limit(1);
      if (!existing) return undefined;

      const updates: Partial<AbTest> = {};
      if (data.status !== undefined) updates.status = data.status;
      if (data.name !== undefined) updates.name = data.name;
      if (Object.keys(updates).length > 0) {
        await tx.update(abTests).set(updates).where(eq(abTests.id, id));
      }

      if (variantWeights && variantWeights.length > 0) {
        for (const vw of variantWeights) {
          await tx
            .update(abVariants)
            .set({ weight: vw.weight })
            .where(and(eq(abVariants.id, vw.id), eq(abVariants.testId, id)));
        }
      }

      const [updatedTest] = await tx
        .select()
        .from(abTests)
        .where(eq(abTests.id, id))
        .limit(1);
      const variants = await tx
        .select()
        .from(abVariants)
        .where(eq(abVariants.testId, id))
        .orderBy(asc(abVariants.createdAt));

      return updatedTest ? { ...updatedTest, variants } : undefined;
    });
  }

  async endAbTest(id: string): Promise<void> {
    await db.update(abTests).set({ status: "ended" }).where(eq(abTests.id, id));
  }

  async incrementAbVariantVisits(variantId: string): Promise<void> {
    await db
      .update(abVariants)
      .set({ visits: sql`${abVariants.visits} + 1` })
      .where(eq(abVariants.id, variantId));
  }

  async recordAbConversion(data: InsertAbConversion): Promise<boolean> {
    const inserted = await db
      .insert(abConversions)
      .values(data)
      .onConflictDoNothing({ target: [abConversions.variantId, abConversions.transactionId] })
      .returning({ id: abConversions.id });
    return inserted.length > 0;
  }

  async getAbAssignmentsForSession(sessionId: string): Promise<Record<string, string>> {
    const trimmedSessionId = String(sessionId || "").trim();
    if (!trimmedSessionId) return {};
    const [row] = await db
      .select({ sess: sessions.sess })
      .from(sessions)
      .where(eq(sessions.sid, trimmedSessionId))
      .limit(1);
    const sessionData = row?.sess as Record<string, unknown> | undefined;
    return filterPreviewAbAssignments(
      normalizeAbAssignments(sessionData?.abAssignment),
      normalizeAbAssignments(sessionData?.abPreviewAssignment),
    );
  }

  async recordAbConversionsForAssignments(data: {
    assignments?: Record<string, string> | null;
    sessionId?: string | null;
    transactionId: string;
    amountCents: number;
    externalReference?: string | null;
  }): Promise<{
    attempted: number;
    inserted: number;
    variantIds: string[];
    source: "payment" | "session" | "none";
  }> {
    const transactionId = String(data.transactionId || "").trim();
    if (!transactionId) {
      return { attempted: 0, inserted: 0, variantIds: [], source: "none" };
    }

    let source: "payment" | "session" | "none" = "none";
    let assignments = normalizeAbAssignments(data.assignments);
    if (Object.keys(assignments).length > 0) {
      source = "payment";
    } else if (data.sessionId) {
      assignments = await this.getAbAssignmentsForSession(data.sessionId);
      if (Object.keys(assignments).length > 0) {
        source = "session";
      }
    }

    const requestedVariantIds = Array.from(
      new Set(Object.values(assignments).map((variantId) => variantId.trim()).filter(Boolean)),
    );
    if (requestedVariantIds.length === 0) {
      return { attempted: 0, inserted: 0, variantIds: [], source };
    }

    const validVariants = await db
      .select({ id: abVariants.id })
      .from(abVariants)
      .where(inArray(abVariants.id, requestedVariantIds));
    const variantIds = validVariants.map((variant) => variant.id);
    if (variantIds.length === 0) {
      return { attempted: 0, inserted: 0, variantIds: [], source };
    }

    const amountCents = Math.max(0, Math.trunc(Number(data.amountCents) || 0));
    const inserted = await db
      .insert(abConversions)
      .values(
        variantIds.map((variantId) => ({
          variantId,
          transactionId,
          amountCents,
          externalReference: data.externalReference ?? null,
        })),
      )
      .onConflictDoNothing({ target: [abConversions.variantId, abConversions.transactionId] })
      .returning({ variantId: abConversions.variantId });

    return {
      attempted: variantIds.length,
      inserted: inserted.length,
      variantIds,
      source,
    };
  }

  async getDistinctFunnelSessionsSince(date: Date): Promise<number> {
    const [row] = await db
      .select({ count: sql<number>`COUNT(*)::int` })
      .from(funnelSessions)
      .where(gte(funnelSessions.createdAt, date));
    return Number(row?.count ?? 0);
  }

  async getFunnelVisitorEnteredSince(date: Date): Promise<number> {
    const [row] = await db
      .select({ count: sql<number>`COUNT(DISTINCT ${funnelEvents.sessionId})::int` })
      .from(funnelEvents)
      .where(
        and(
          eq(funnelEvents.step, "visitor_entered"),
          gte(funnelEvents.occurredAt, date),
        ),
      );
    return Number(row?.count ?? 0);
  }

  async getAbTestStats(testId: string): Promise<{
    variants: Array<{
      id: string;
      name: string;
      slug: string;
      componentKey: string;
      weight: number;
      visits: number;
      conversions: number;
      conversionRate: number;
      revenueCents: number;
      rpvCents: number;
    }>;
  }> {
    const variants = await db
      .select()
      .from(abVariants)
      .where(eq(abVariants.testId, testId))
      .orderBy(asc(abVariants.createdAt));
    if (variants.length === 0) return { variants: [] };

    const aggregates = await db
      .select({
        variantId: abConversions.variantId,
        conversions: sql<number>`COUNT(*)::int`,
        revenueCents: sql<number>`COALESCE(SUM(${abConversions.amountCents}), 0)::int`,
      })
      .from(abConversions)
      .where(inArray(abConversions.variantId, variants.map((v) => v.id)))
      .groupBy(abConversions.variantId);

    const aggregateMap = new Map(aggregates.map((a) => [a.variantId, a]));

    return {
      variants: variants.map((v) => {
        const agg = aggregateMap.get(v.id);
        const conversions = Number(agg?.conversions ?? 0);
        const revenueCents = Number(agg?.revenueCents ?? 0);
        const conversionRate = v.visits > 0 ? conversions / v.visits : 0;
        const rpvCents = v.visits > 0 ? revenueCents / v.visits : 0;
        return {
          id: v.id,
          name: v.name,
          slug: v.slug,
          componentKey: v.componentKey,
          weight: v.weight,
          visits: v.visits,
          conversions,
          conversionRate,
          revenueCents,
          rpvCents,
        };
      }),
    };
  }
}

export const storage = new DatabaseStorage();
