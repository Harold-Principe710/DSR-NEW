import crypto from "crypto";

export type PixCustomerData = {
  name: string;
  email: string;
  phone: string;
  document: string;
  documentType: "cpf";
  source: "customer_csv";
};

const DEFAULT_CUSTOMER_LIST_URL = "https://raw.githubusercontent.com/lucassavi/oaisdashd98ashd9/refs/heads/main/lista%20pix%20clientes.csv";
const DEFAULT_CACHE_TTL_MS = 6 * 60 * 60 * 1000;
const DEFAULT_FETCH_TIMEOUT_MS = 5_000;

let cachedCustomers: { url: string; expiresAt: number; rows: PixCustomerData[] } | null = null;
let inflightLoad: Promise<PixCustomerData[]> | null = null;

function normalizeHeader(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function normalizeText(value: unknown) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function onlyDigits(value: unknown) {
  return String(value ?? "").replace(/\D/g, "");
}

function normalizeEmail(value: unknown) {
  return String(value ?? "").trim().toLowerCase();
}

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isValidCpf(value: string) {
  const cpf = onlyDigits(value);
  if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;

  const calculateDigit = (length: number) => {
    let sum = 0;
    for (let index = 0; index < length; index += 1) {
      sum += Number(cpf[index]) * (length + 1 - index);
    }
    const remainder = (sum * 10) % 11;
    return remainder === 10 ? 0 : remainder;
  };

  return calculateDigit(9) === Number(cpf[9]) && calculateDigit(10) === Number(cpf[10]);
}

function parseCsvLine(line: string) {
  const cells: string[] = [];
  let current = "";
  let insideQuotes = false;

  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    const nextChar = line[index + 1];

    if (char === "\"" && insideQuotes && nextChar === "\"") {
      current += "\"";
      index += 1;
      continue;
    }

    if (char === "\"") {
      insideQuotes = !insideQuotes;
      continue;
    }

    if (char === "," && !insideQuotes) {
      cells.push(current.trim());
      current = "";
      continue;
    }

    current += char;
  }

  cells.push(current.trim());
  return cells;
}

function parseCustomerCsv(csv: string) {
  const lines = csv
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length < 2) return [];

  const headers = parseCsvLine(lines[0]).map(normalizeHeader);
  const findIndex = (...names: string[]) => headers.findIndex((header) => names.includes(header));
  const nameIndex = findIndex("nome", "name");
  const phoneIndex = findIndex("telefone", "phone", "celular");
  const emailIndex = findIndex("email", "email");
  const cpfIndex = findIndex("cpf", "documento", "document");

  if ([nameIndex, phoneIndex, emailIndex, cpfIndex].some((index) => index < 0)) {
    throw new Error("CSV de clientes PIX sem colunas obrigatórias: Nome, Telefone, E-mail, CPF");
  }

  const customers: PixCustomerData[] = [];
  for (const line of lines.slice(1)) {
    const cells = parseCsvLine(line);
    const name = normalizeText(cells[nameIndex]);
    const email = normalizeEmail(cells[emailIndex]);
    const phone = onlyDigits(cells[phoneIndex]);
    const document = onlyDigits(cells[cpfIndex]);

    if (name.length < 2 || !isValidEmail(email) || phone.length < 10 || phone.length > 13 || !isValidCpf(document)) {
      continue;
    }

    customers.push({
      name,
      email,
      phone,
      document,
      documentType: "cpf",
      source: "customer_csv",
    });
  }

  return customers;
}

async function fetchTextWithTimeout(url: string, timeoutMs: number) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      headers: { Accept: "text/csv,text/plain,*/*" },
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.text();
  } finally {
    clearTimeout(timeoutId);
  }
}

async function loadCustomerList() {
  const url = (process.env.PIX_CUSTOMER_LIST_URL || DEFAULT_CUSTOMER_LIST_URL).trim();
  const ttlMs = Number(process.env.PIX_CUSTOMER_CACHE_TTL_MS || DEFAULT_CACHE_TTL_MS);
  const timeoutMs = Number(process.env.PIX_CUSTOMER_LIST_TIMEOUT_MS || DEFAULT_FETCH_TIMEOUT_MS);
  const now = Date.now();

  if (cachedCustomers?.url === url && cachedCustomers.expiresAt > now && cachedCustomers.rows.length > 0) {
    return cachedCustomers.rows;
  }

  if (inflightLoad) return inflightLoad;

  inflightLoad = (async () => {
    try {
      const csv = await fetchTextWithTimeout(url, Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : DEFAULT_FETCH_TIMEOUT_MS);
      const rows = parseCustomerCsv(csv);
      if (rows.length === 0) throw new Error("CSV de clientes PIX não possui registros válidos");

      cachedCustomers = {
        url,
        rows,
        expiresAt: now + (Number.isFinite(ttlMs) && ttlMs > 0 ? ttlMs : DEFAULT_CACHE_TTL_MS),
      };
      return rows;
    } catch (error) {
      if (cachedCustomers?.rows.length) {
        console.warn("[pix-customer-data] Using stale customer cache after refresh failure");
        return cachedCustomers.rows;
      }
      throw error;
    } finally {
      inflightLoad = null;
    }
  })();

  return inflightLoad;
}

export async function getRandomPixCustomerData(): Promise<PixCustomerData> {
  const customers = await loadCustomerList();
  const index = crypto.randomInt(0, customers.length);
  return customers[index];
}

export function redactPixCustomerData(customer: PixCustomerData) {
  const initials = customer.name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");

  return {
    nameInitials: initials || null,
    emailDomain: customer.email.split("@")[1] || null,
    phoneLast4: customer.phone.slice(-4),
    documentLast4: customer.document.slice(-4),
    documentType: customer.documentType,
    source: customer.source,
  };
}
