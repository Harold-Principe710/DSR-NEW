import { APP_TIME_ZONE } from "@shared/timezone";

process.env.TZ = APP_TIME_ZONE;

const DATE_INPUT_RE = /^(\d{4})-(\d{2})-(\d{2})$/;

export function parseAppDateInput(value?: string | null): Date | null {
  if (!value) return null;

  const match = DATE_INPUT_RE.exec(value);
  if (!match) return null;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const parsed = new Date(year, month - 1, day, 0, 0, 0, 0);

  if (
    Number.isNaN(parsed.getTime()) ||
    parsed.getFullYear() !== year ||
    parsed.getMonth() !== month - 1 ||
    parsed.getDate() !== day
  ) {
    return null;
  }

  return parsed;
}

export function startOfAppDay(date = new Date()): Date {
  const value = new Date(date);
  value.setHours(0, 0, 0, 0);
  return value;
}

export function endOfAppDay(date = new Date()): Date {
  const value = new Date(date);
  value.setHours(23, 59, 59, 999);
  return value;
}

export function addAppDays(date: Date, days: number): Date {
  const value = new Date(date);
  value.setDate(value.getDate() + days);
  return value;
}

export function getAppDateRangeFromQuery(query: any) {
  const now = new Date();
  const preset = String(query?.preset || "7d");
  let dateFrom = startOfAppDay(addAppDays(now, -6));
  let dateTo = endOfAppDay(now);

  if (preset === "today") {
    dateFrom = startOfAppDay(now);
  } else if (preset === "yesterday") {
    const yesterday = addAppDays(now, -1);
    dateFrom = startOfAppDay(yesterday);
    dateTo = endOfAppDay(yesterday);
  } else if (preset === "30d") {
    dateFrom = startOfAppDay(addAppDays(now, -29));
  } else if (preset === "custom") {
    const parsedFrom = parseAppDateInput(String(query?.dateFrom || ""));
    const parsedTo = parseAppDateInput(String(query?.dateTo || ""));

    if (parsedFrom && parsedTo) {
      dateFrom = startOfAppDay(parsedFrom);
      dateTo = endOfAppDay(parsedTo);
    }
  }

  return { dateFrom, dateTo, preset, timeZone: APP_TIME_ZONE };
}
