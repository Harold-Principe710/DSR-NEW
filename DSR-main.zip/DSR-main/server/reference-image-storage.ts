import crypto from "crypto";

type CloudinaryReferenceImageConfig = {
  apiKey: string;
  apiSecret: string;
  cloudName: string;
  folder: string;
};

type CloudinaryUploadResponse = {
  secure_url?: string;
  public_id?: string;
  error?: {
    message?: string;
  };
};

let missingConfigWarningShown = false;

function getCloudinaryReferenceImageConfig(): CloudinaryReferenceImageConfig | null {
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME?.trim();
  const apiKey = process.env.CLOUDINARY_API_KEY?.trim();
  const apiSecret = process.env.CLOUDINARY_API_SECRET?.trim();
  const folder = process.env.CLOUDINARY_REFERENCE_UPLOAD_FOLDER?.trim() || "desireai/reference-uploads";

  if (!cloudName || !apiKey || !apiSecret) {
    if (!missingConfigWarningShown) {
      missingConfigWarningShown = true;
      console.warn("[Upload] Cloudinary não configurado. Usando storage temporário local para fotos de referência.");
    }

    return null;
  }

  return {
    apiKey,
    apiSecret,
    cloudName,
    folder,
  };
}

function buildCloudinarySignature(params: Record<string, string>, apiSecret: string) {
  const payload = Object.entries(params)
    .filter(([, value]) => value.length > 0)
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([key, value]) => `${key}=${value}`)
    .join("&");

  return crypto.createHash("sha1").update(`${payload}${apiSecret}`).digest("hex");
}

export async function uploadReferenceImageToCloudinary(params: {
  buffer: Buffer;
  fileId: string;
}): Promise<string | null> {
  const config = getCloudinaryReferenceImageConfig();
  if (!config) return null;

  const timestamp = Math.floor(Date.now() / 1000).toString();
  const signature = buildCloudinarySignature({
    folder: config.folder,
    public_id: params.fileId,
    timestamp,
  }, config.apiSecret);

  const formData = new FormData();
  formData.set("file", new Blob([params.buffer], { type: "image/jpeg" }), `${params.fileId}.jpg`);
  formData.set("api_key", config.apiKey);
  formData.set("folder", config.folder);
  formData.set("public_id", params.fileId);
  formData.set("signature", signature);
  formData.set("timestamp", timestamp);

  const response = await fetch(`https://api.cloudinary.com/v1_1/${config.cloudName}/image/upload`, {
    method: "POST",
    body: formData,
  });

  const data = await response.json() as CloudinaryUploadResponse;

  if (!response.ok || !data.secure_url) {
    const message = data.error?.message?.trim() || `Cloudinary respondeu com status ${response.status}`;
    throw new Error(message);
  }

  return data.secure_url;
}
