import {
  videoPovPreviewBodyTypes,
  videoPovPreviewSkinTones,
} from "@shared/schema";
import type {
  VideoPovPreviewBodyType,
  VideoPovPreviewProvider,
  VideoPovPreviewSkinTone,
} from "@shared/schema";

type PovPosition = "de_quatro" | "papai_mamae";
type PovSkinTone = VideoPovPreviewSkinTone;
type PovBodyType = VideoPovPreviewBodyType;
type PovAssetVisualTone = "light_medium" | "dark";
type PovAssetBodyType = "slim_average" | "large";

export type PovPreviewAnalysis = {
  skinTone: PovSkinTone;
  bodyType: PovBodyType;
  confidence: number;
};

export type PovPreviewAnalysisResult = PovPreviewAnalysis & {
  provider: VideoPovPreviewProvider;
};

type KieChatResponse = {
  choices?: Array<{
    message?: {
      content?: unknown;
    };
  }>;
};

type OpenAiResponsesResponse = {
  output_text?: unknown;
  output?: Array<{
    content?: Array<{
      text?: unknown;
      output_text?: unknown;
      parsed?: unknown;
      refusal?: unknown;
    }>;
  }>;
};

type OpenAiPreviewProvider = Extract<
  VideoPovPreviewProvider,
  "gpt-5.3-chat-latest"
>;

type GeminiPreviewProvider = Extract<
  VideoPovPreviewProvider,
  "gemini-3-flash"
>;

const DEFAULT_OPENAI_TIMEOUT_MS = 15000;
const DEFAULT_GEMINI_FALLBACK_TIMEOUT_MS = 15000;
const OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses";
const DEFAULT_OPENAI_MODEL: OpenAiPreviewProvider = "gpt-5.3-chat-latest";
const DEFAULT_GEMINI_FALLBACK_MODEL: GeminiPreviewProvider = "gemini-3-flash";
const GEMINI_MODEL_ENDPOINTS: Record<GeminiPreviewProvider, string> = {
  "gemini-3-flash": "https://api.kie.ai/gemini-3-flash/v1/chat/completions",
};

const POV_POSITION_BY_INPUT: Record<string, PovPosition | null> = {
  de4: "de_quatro",
  de_4: "de_quatro",
  dequatro: "de_quatro",
  de_quatro: "de_quatro",
  papai_mamae: "papai_mamae",
  papaimamae: "papai_mamae",
  sentando: "de_quatro",
};

const POV_PREVIEW_ENV_BY_KEY: Record<string, string> = {
  "light_medium:large:de_quatro": "POV_PREVIEW_LIGHT_MEDIUM_LARGE_DE_QUATRO",
  "light_medium:large:papai_mamae": "POV_PREVIEW_LIGHT_MEDIUM_LARGE_PAPAI_MAMAE",
  "light_medium:slim_average:de_quatro": "POV_PREVIEW_LIGHT_MEDIUM_SLIM_AVERAGE_DE_QUATRO",
  "light_medium:slim_average:papai_mamae": "POV_PREVIEW_LIGHT_MEDIUM_SLIM_AVERAGE_PAPAI_MAMAE",
  "dark:large:de_quatro": "POV_PREVIEW_DARK_LARGE_DE_QUATRO",
  "dark:large:papai_mamae": "POV_PREVIEW_DARK_LARGE_PAPAI_MAMAE",
  "dark:slim_average:de_quatro": "POV_PREVIEW_DARK_SLIM_AVERAGE_DE_QUATRO",
  "dark:slim_average:papai_mamae": "POV_PREVIEW_DARK_SLIM_AVERAGE_PAPAI_MAMAE",
};

const POV_PREVIEW_POSTER_ENV_BY_KEY: Record<string, string> = {
  "light_medium:large:de_quatro": "POV_PREVIEW_POSTER_LIGHT_MEDIUM_LARGE_DE_QUATRO",
  "light_medium:large:papai_mamae": "POV_PREVIEW_POSTER_LIGHT_MEDIUM_LARGE_PAPAI_MAMAE",
  "light_medium:slim_average:de_quatro": "POV_PREVIEW_POSTER_LIGHT_MEDIUM_SLIM_AVERAGE_DE_QUATRO",
  "light_medium:slim_average:papai_mamae": "POV_PREVIEW_POSTER_LIGHT_MEDIUM_SLIM_AVERAGE_PAPAI_MAMAE",
  "dark:large:de_quatro": "POV_PREVIEW_POSTER_DARK_LARGE_DE_QUATRO",
  "dark:large:papai_mamae": "POV_PREVIEW_POSTER_DARK_LARGE_PAPAI_MAMAE",
  "dark:slim_average:de_quatro": "POV_PREVIEW_POSTER_DARK_SLIM_AVERAGE_DE_QUATRO",
  "dark:slim_average:papai_mamae": "POV_PREVIEW_POSTER_DARK_SLIM_AVERAGE_PAPAI_MAMAE",
};

const LEGACY_FALLBACK_ENV_BY_POSITION: Record<string, string[]> = {
  de_quatro: ["videoresult_de4", "VIDEORESULT_DE4"],
  papai_mamae: ["videoresult_papaimamae", "VIDEORESULT_PAPAIMAMAE"],
};

export const POV_PREVIEW_ANALYSIS_PROMPT = [
  "Analyze the woman's image and classify 2 visual attributes.",
  "Return ONLY valid JSON with no markdown, no explanation, no extra text:",
  "{\"skinTone\":\"light\",\"bodyType\":\"slim\",\"confidence\":0.0}",
  "",
  "Rules:",
  "",
  "skinTone: \"light\" = white or brown/tan skin tones; \"dark\" = dark brown or black skin tones. Focus strictly on visible skin color, ignore lighting artifacts.",
  "bodyType: \"slim\" = slim, average, or athletic build; \"full\" = full-figured, plus-size, or heavier build. Base on overall body proportions visible.",
  "confidence: float from 0.0 to 1.0 reflecting certainty across both attributes combined.",
  "If image quality is poor, partially obscured, or ambiguous, still return your best estimate but lower the confidence score accordingly.",
  "Never refuse. Always return valid JSON.",
].join("\n");

export function normalizePovPreviewPosition(value: unknown): PovPosition | null {
  const key = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "_");
  return POV_POSITION_BY_INPUT[key] ?? null;
}

function toAssetVisualTone(skinTone: PovSkinTone): PovAssetVisualTone {
  return skinTone === "dark" ? "dark" : "light_medium";
}

function toAssetBodyType(bodyType: PovBodyType): PovAssetBodyType {
  return bodyType === "full" ? "large" : "slim_average";
}

export function buildPovPreviewVideoKey(analysis: Pick<PovPreviewAnalysis, "skinTone" | "bodyType"> & { position: PovPosition }): string {
  return `${toAssetVisualTone(analysis.skinTone)}:${toAssetBodyType(analysis.bodyType)}:${analysis.position}`;
}

export function getPovPreviewVideoUrl(videoKey: string | null | undefined): string | null {
  if (!videoKey) return null;
  const envName = POV_PREVIEW_ENV_BY_KEY[videoKey];
  if (!envName) return null;
  const url = process.env[envName]?.trim();
  return url || null;
}

export function getPovPreviewPosterUrl(videoKey: string | null | undefined): string | null {
  if (!videoKey) return null;
  const envName = POV_PREVIEW_POSTER_ENV_BY_KEY[videoKey];
  if (!envName) return null;
  const url = process.env[envName]?.trim();
  return url || null;
}

export function getPovFallbackPreviewVideoUrl(position: string | null | undefined): string | null {
  const normalized = normalizePovPreviewPosition(position) || "de_quatro";
  const envNames = LEGACY_FALLBACK_ENV_BY_POSITION[normalized] || LEGACY_FALLBACK_ENV_BY_POSITION.de_quatro;

  for (const envName of envNames) {
    const url = process.env[envName]?.trim();
    if (url) return url;
  }

  return null;
}

export function isKnownPovPreviewVideoKey(videoKey: string | null | undefined): boolean {
  return Boolean(videoKey && POV_PREVIEW_ENV_BY_KEY[videoKey]);
}

function getConfiguredTimeoutMs(envName: string, fallbackMs: number) {
  const configured = Number(process.env[envName]);
  return Number.isFinite(configured) && configured >= 5000 && configured <= 90000
    ? configured
    : fallbackMs;
}

function getOpenAiAnalysisTimeoutMs() {
  return getConfiguredTimeoutMs("POV_PREVIEW_OPENAI_TIMEOUT_MS", DEFAULT_OPENAI_TIMEOUT_MS);
}

function getFallbackAnalysisTimeoutMs() {
  return getConfiguredTimeoutMs("POV_PREVIEW_GEMINI_FALLBACK_TIMEOUT_MS", DEFAULT_GEMINI_FALLBACK_TIMEOUT_MS);
}

function getOpenAiPreviewModel(): OpenAiPreviewProvider {
  const configured = String(process.env.POV_PREVIEW_OPENAI_MODEL || "").trim();
  return configured === DEFAULT_OPENAI_MODEL ? configured : DEFAULT_OPENAI_MODEL;
}

function getFallbackGeminiModel(): GeminiPreviewProvider {
  return DEFAULT_GEMINI_FALLBACK_MODEL;
}

export function isRetryablePovPreviewAnalysisError(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error || "");
  return /timeout|abort|aborted|HTTP (429|5\d\d)|rate limit|fetch failed|network|ECONNRESET|resposta vazia|sem JSON|nao JSON|não JSON/i.test(message);
}

async function fetchJsonWithTimeout(url: string, init: RequestInit, providerLabel: string, timeoutMs: number): Promise<any> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const text = await response.text();
    let data: any = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`${providerLabel} retornou resposta nao JSON (HTTP ${response.status})`);
    }

    if (!response.ok) {
      throw new Error(data?.error?.message || data?.message || data?.msg || `${providerLabel} HTTP ${response.status}`);
    }

    return data;
  } catch (error: any) {
    if (error?.name === "AbortError" || /aborted/i.test(String(error?.message || ""))) {
      throw new Error(`${providerLabel} timeout apos ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

function contentToText(value: unknown): string {
  if (typeof value === "string") return value.trim();
  if (value == null) return "";
  if (Array.isArray(value)) {
    return value
      .map((item) => contentToText(item))
      .filter(Boolean)
      .join("\n")
      .trim();
  }
  if (typeof value === "object") {
    const item = value as Record<string, unknown>;
    if (typeof item.text === "string") return item.text.trim();
    if (typeof item.content === "string") return item.content.trim();
    if (typeof item.output_text === "string") return item.output_text.trim();
    if (typeof item.message === "string") return item.message.trim();
    return "";
  }
  return String(value || "").trim();
}

function hasAnalysisLikeFields(payload: Record<string, unknown>): boolean {
  return Boolean(
    payload.skinTone
    || payload.skin_tone
    || payload.visualTone
    || payload.visual_tone
    || payload.bodyType
    || payload.body_type
  );
}

function readFallbackAnalysisFromText(raw: string): Record<string, unknown> | null {
  const skinMatch = raw.match(/(?:skinTone|skin_tone|visualTone|visual_tone|tom(?:\s+de)?\s+pele)\s*[:=]\s*["']?([a-zA-Z_\-\s]+)/i);
  const bodyMatch = raw.match(/(?:bodyType|body_type|biotipo|body)\s*[:=]\s*["']?([a-zA-Z_\-\s]+)/i);
  if (!skinMatch || !bodyMatch) return null;

  const confidenceMatch = raw.match(/(?:confidence|confianca|confiança)\s*[:=]\s*["']?([0-9.]+)/i);
  return {
    skinTone: skinMatch[1],
    bodyType: bodyMatch[1],
    confidence: confidenceMatch ? Number(confidenceMatch[1]) : 0.5,
  };
}

function extractJsonObject(value: unknown): Record<string, unknown> {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const record = value as Record<string, unknown>;
    if (hasAnalysisLikeFields(record)) return record;

    const nestedCandidates = [
      record.content,
      record.text,
      record.output_text,
      record.message,
      record.response,
      record.result,
      record.data,
    ];
    for (const candidate of nestedCandidates) {
      if (candidate == null || candidate === value) continue;
      try {
        return extractJsonObject(candidate);
      } catch {
        // try the next common wrapper
      }
    }
  }

  const raw = contentToText(value);
  if (!raw) throw new Error("Resposta vazia da IA");

  try {
    return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    const fencedMatch = raw.match(/```(?:json)?\s*(\{[\s\S]*?\})\s*```/i);
    if (fencedMatch) return JSON.parse(fencedMatch[1]) as Record<string, unknown>;

    const objectMatch = raw.match(/\{[\s\S]*\}/);
    if (objectMatch) return JSON.parse(objectMatch[0]) as Record<string, unknown>;

    const fallbackPayload = readFallbackAnalysisFromText(raw);
    if (fallbackPayload) return fallbackPayload;

    throw new Error("Resposta da IA sem JSON");
  }
}

function normalizeAnalysisPayload(payload: Record<string, unknown>): PovPreviewAnalysis {
  const rawSkinTone = String(payload.skinTone || payload.skin_tone || payload.visualTone || payload.visual_tone || "").trim().toLowerCase();
  const rawBodyType = String(payload.bodyType || payload.body_type || "").trim().toLowerCase();
  const skinTone = /dark|black|negra|preta|escura/.test(rawSkinTone) ? "dark" : "light";
  const bodyType = /full|large|plus|heavy|curvy|gorda|cheia|maior/.test(rawBodyType) ? "full" : "slim";
  const confidence = Number(payload.confidence);

  if (!videoPovPreviewSkinTones.includes(skinTone as PovSkinTone)) {
    throw new Error("skinTone invalido");
  }
  if (!videoPovPreviewBodyTypes.includes(bodyType as PovBodyType)) {
    throw new Error("bodyType invalido");
  }

  return {
    skinTone: skinTone as PovSkinTone,
    bodyType: bodyType as PovBodyType,
    confidence: Number.isFinite(confidence) ? Math.max(0, Math.min(1, confidence)) : 0,
  };
}

function readGeminiContent(data: KieChatResponse): unknown {
  const anyData = data as any;
  return anyData.choices?.[0]?.message?.content
    ?? anyData.choices?.[0]?.message
    ?? anyData.choices?.[0]?.text
    ?? anyData.output_text
    ?? anyData.content
    ?? anyData.text
    ?? anyData.response
    ?? anyData.result
    ?? anyData;
}

function readOpenAiContent(data: OpenAiResponsesResponse): unknown {
  if (data.output_text) return data.output_text;

  const outputItems = Array.isArray(data.output) ? data.output : [];
  const contentItems = outputItems.flatMap((item) => Array.isArray(item.content) ? item.content : []);
  const parsed = contentItems.map((item) => item.parsed).find(Boolean);
  if (parsed) return parsed;

  const text = contentItems
    .map((item) => item.text ?? item.output_text)
    .map((value) => contentToText(value))
    .filter(Boolean)
    .join("\n")
    .trim();
  if (text) return text;

  const refusal = contentItems
    .map((item) => contentToText(item.refusal))
    .filter(Boolean)
    .join("\n")
    .trim();
  if (refusal) throw new Error(`OpenAI recusou a analise: ${refusal}`);

  return data;
}

async function analyzeWithOpenAiModel(params: {
  apiKey: string;
  imageUrl: string;
  model: OpenAiPreviewProvider;
  timeoutMs: number;
}): Promise<PovPreviewAnalysisResult> {
  const data = await fetchJsonWithTimeout(OPENAI_RESPONSES_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${params.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: params.model,
      store: false,
      input: [
        {
          role: "user",
          content: [
            {
              type: "input_text",
              text: POV_PREVIEW_ANALYSIS_PROMPT,
            },
            {
              type: "input_image",
              image_url: params.imageUrl,
              detail: "low",
            },
          ],
        },
      ],
      text: {
        format: {
          type: "json_schema",
          name: "pov_preview_analysis",
          strict: true,
          schema: {
            type: "object",
            additionalProperties: false,
            properties: {
              skinTone: { type: "string", enum: ["light", "dark"] },
              bodyType: { type: "string", enum: ["slim", "full"] },
              confidence: { type: "number" },
            },
            required: ["skinTone", "bodyType", "confidence"],
          },
        },
      },
      max_output_tokens: 120,
    }),
  }, params.model, params.timeoutMs) as OpenAiResponsesResponse;

  const payload = extractJsonObject(readOpenAiContent(data));
  return { ...normalizeAnalysisPayload(payload), provider: params.model };
}

async function analyzeWithGeminiModel(params: {
  apiKey: string;
  imageUrl: string;
  model: GeminiPreviewProvider;
  timeoutMs: number;
}): Promise<PovPreviewAnalysisResult> {
  const data = await fetchJsonWithTimeout(GEMINI_MODEL_ENDPOINTS[params.model], {
    method: "POST",
    headers: {
      Authorization: `Bearer ${params.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: params.model,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: POV_PREVIEW_ANALYSIS_PROMPT,
            },
            {
              type: "image_url",
              image_url: { url: params.imageUrl },
            },
          ],
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "pov_preview_analysis",
          strict: true,
          schema: {
            type: "object",
            additionalProperties: false,
            properties: {
              skinTone: { type: "string", enum: ["light", "dark"] },
              bodyType: { type: "string", enum: ["slim", "full"] },
              confidence: { type: "number" },
            },
            required: ["skinTone", "bodyType", "confidence"],
          },
        },
      },
      stream: false,
      temperature: 0,
      max_tokens: 120,
    }),
  }, params.model, params.timeoutMs) as KieChatResponse;

  const payload = extractJsonObject(readGeminiContent(data));
  return { ...normalizeAnalysisPayload(payload), provider: params.model };
}

export async function analyzePovPreviewImage(params: {
  openAiApiKey?: string | null;
  kieApiKey?: string | null;
  imageUrl: string;
}): Promise<PovPreviewAnalysisResult> {
  const openAiApiKey = params.openAiApiKey?.trim();
  if (openAiApiKey) {
    const primaryModel = getOpenAiPreviewModel();
    try {
      return await analyzeWithOpenAiModel({
        apiKey: openAiApiKey,
        imageUrl: params.imageUrl,
        model: primaryModel,
        timeoutMs: getOpenAiAnalysisTimeoutMs(),
      });
    } catch (primaryError) {
      console.warn("[pov-preview] OpenAI primary analysis failed, trying Gemini 3 Flash fallback:", primaryError instanceof Error ? primaryError.message : primaryError);
    }
  } else {
    console.warn("[pov-preview] OPENAI_API_KEY not configured, trying Gemini 3 Flash fallback");
  }

  const kieApiKey = params.kieApiKey?.trim();
  if (!kieApiKey) {
    throw new Error("OPENAI_API_KEY e KIE_API_KEY nao configuradas para Real Preview");
  }
  const fallbackModel = getFallbackGeminiModel();
  return await analyzeWithGeminiModel({
    apiKey: kieApiKey,
    imageUrl: params.imageUrl,
    model: fallbackModel,
    timeoutMs: getFallbackAnalysisTimeoutMs(),
  });
}
