/**
 * Bot detection for tracking endpoints. Used to skip writes that would
 * otherwise inflate visit/funnel counts with crawler and automation traffic.
 *
 * Conservative on purpose: false negatives are acceptable (a bot that slips
 * through adds 1 visit), false positives are not (a real visitor labelled
 * as bot disappears from the funnel).
 *
 * Patterns chosen to cover:
 *   - Search/social crawlers (Google, Bing, Yandex, Baidu, FB, Twitter, etc.)
 *   - Headless automation (HeadlessChrome, Puppeteer, Playwright, PhantomJS)
 *   - HTTP clients used by scripts (curl, wget, axios, python-requests, ...)
 *   - Generic "bot/crawler/spider" tokens
 *   - Empty / missing User-Agent (no real browser sends none)
 */
import type { Request } from "express";

const BOT_PATTERN =
  /bot\b|crawler|spider|crawling|slurp|baiduspider|yandex|sogou|exabot|facebookexternalhit|twitterbot|linkedinbot|embedly|whatsapp|telegrambot|discordbot|applebot|chrome-lighthouse|headlesschrome|phantomjs|puppeteer|playwright|http\.rb|axios\/|python-requests|curl\/|wget\/|node-fetch|go-http-client|okhttp|java\/|ahrefssiteaudit|semrushbot|mj12bot|petalbot|bytespider|gptbot|ccbot|claudebot|anthropic-ai/i;

export function isBotUserAgent(userAgent: string | undefined | null): boolean {
  const ua = String(userAgent ?? "").trim();
  // No UA at all → almost certainly automation. Real browsers always send one.
  if (!ua) return true;
  // Suspiciously short UA strings rarely come from real browsers.
  if (ua.length < 12) return true;
  return BOT_PATTERN.test(ua);
}

export function isBotRequest(req: Request): boolean {
  return isBotUserAgent(req.headers["user-agent"] as string | undefined);
}
