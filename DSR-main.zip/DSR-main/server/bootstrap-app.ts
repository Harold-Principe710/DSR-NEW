/**
 * Heavy app bootstrap. Loaded dynamically by `server/index.ts` AFTER the HTTP
 * port is already bound, so any slow module-level work here (drizzle pool,
 * connect-pg-simple, websocket server, posthog client, route definitions)
 * cannot keep DigitalOcean's readiness probe from hitting /health.
 */
import type { Express, Request, Response, NextFunction } from "express";
import type { Server } from "http";

export interface BootstrapHandles {
  setReady: () => void;
  setError: (message: string) => void;
  log: (message: string, source?: string) => void;
}

export async function bootstrapApp(
  app: Express,
  httpServer: Server,
  handles: BootstrapHandles,
): Promise<void> {
  const { setReady, setError, log } = handles;
  const isProduction = process.env.NODE_ENV === "production";

  log("phase=bootstrap_start", "startup");

  // 1. Websocket server (touches connect-pg session store internally).
  const { setupWebSocket } = await import("./websocket");
  setupWebSocket(httpServer);
  log("phase=websocket_ready", "startup");

  // 2. Static asset fast paths (production only). Routes registered later
  // can still mount more middleware on top of these.
  if (isProduction) {
    const { serveStaticAssetFastPaths } = await import("./static");
    serveStaticAssetFastPaths(app);
  }

  // 3. /api request logger — must be in front of registerRoutes so it sees
  // every API hit.
  app.use((req, res, next) => {
    const start = Date.now();
    const path = req.path;
    res.on("finish", () => {
      const duration = Date.now() - start;
      if (path.startsWith("/api")) {
        log(`${req.method} ${path} ${res.statusCode} in ${duration}ms`);
      }
    });
    next();
  });

  // 4. Application routes (sessions, funnel, payments, admin, etc).
  const { registerRoutes } = await import("./routes");
  await registerRoutes(httpServer, app);
  log("phase=routes_registered", "startup");

  // 5. Error handler + SPA static fallback.
  const { captureExceptionEvent } = await import("./posthog");
  app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    if (status >= 500) captureExceptionEvent(err, { req });
    console.error("[express-error]", message, err);
    if (res.headersSent) return;
    res.status(status).json({ message });
  });

  if (isProduction) {
    const { serveStatic } = await import("./static");
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  // 6. DB check + optional drizzle-kit push.
  const { testDatabaseConnection } = await import("./db");
  log("phase=db_check start", "startup");
  const dbConnected = await testDatabaseConnection();
  if (!dbConnected) {
    setError("Database connection failed");
    return;
  }
  log("phase=db_check ok", "startup");

  const runMigrationsEnv = process.env.RUN_MIGRATIONS_ON_BOOT;
  const runMigrationsByDefault = !isProduction;
  const runMigrations =
    runMigrationsEnv === "true" ? true :
    runMigrationsEnv === "false" ? false :
    runMigrationsByDefault;
  const skipMigrationsLegacy = process.env.SKIP_MIGRATIONS === "true";

  if (runMigrations && !skipMigrationsLegacy) {
    log("phase=migration start", "startup");
    const { runSchemaMigrations } = await import("./migrate");
    await runSchemaMigrations();
    log("phase=migration done", "startup");
  } else {
    log(
      `phase=migration skipped (RUN_MIGRATIONS_ON_BOOT=${runMigrationsEnv ?? "default"}, SKIP_MIGRATIONS=${process.env.SKIP_MIGRATIONS ?? "false"})`,
      "startup",
    );
  }

  // 7. Mark ready and start background jobs.
  setReady();

  const { warmAbTestsCache } = await import("./abTesting");
  warmAbTestsCache();

  startStaleImageJob(log);

  log("phase=ready app_initialized", "startup");
}

function startStaleImageJob(log: (message: string, source?: string) => void) {
  const checkInterval = 15 * 60 * 1000; // 15 minutes

  const runCheck = async () => {
    try {
      const { storage } = await import("./storage");
      const expiredImageCount = await storage.expireStaleImages();
      if (expiredImageCount > 0) {
        log(
          `Stale image check: ${expiredImageCount} image(s) expired after 45m and credits refunded`,
          "scheduler",
        );
      }
    } catch (error: any) {
      log(`Stale image check error: ${error.message}`, "scheduler");
    }
  };

  setTimeout(runCheck, 60000);
  setInterval(runCheck, checkInterval);
  log("Stale image expiration job started (runs every 15 min)", "scheduler");
}
