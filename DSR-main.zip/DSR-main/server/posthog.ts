/**
 * Server-side PostHog wrapper. All public functions no-op silently when
 * POSTHOG_API_KEY is unset, so the server starts fine without PostHog
 * configured. Bot traffic is filtered before any capture so it never
 * reaches PostHog and never inflates analytics.
 */
import { PostHog } from "posthog-node";
import type { Request } from "express";
import { isBotRequest } from "./botDetection";

const apiKey = (process.env.POSTHOG_API_KEY || "").trim();
const host = (process.env.POSTHOG_HOST || "https://us.i.posthog.com").trim();

let client: PostHog | null = null;

if (apiKey) {
  client = new PostHog(apiKey, {
    host,
    enableExceptionAutocapture: true,
  });
  console.log(`[posthog] enabled host=${host}`);
} else {
  console.warn("[posthog] POSTHOG_API_KEY ausente — eventos PostHog não serão enviados");
}

export function isPosthogEnabled(): boolean {
  return client !== null;
}

function resolveDistinctId(req: Request | null, explicit?: string | null): string {
  if (explicit) return explicit;
  if (!req) return "system";
  const userId = (req as any).userId;
  if (userId) return String(userId);
  if (req.sessionID) return req.sessionID;
  return "anonymous";
}

export interface CaptureOptions {
  req?: Request | null;
  distinctId?: string | null;
  event: string;
  properties?: Record<string, unknown>;
}

/**
 * Send an event. Skips bots and silently no-ops when PostHog is disabled.
 */
export function captureEvent(opts: CaptureOptions): void {
  if (!client) return;
  if (opts.req && isBotRequest(opts.req)) return;
  client.capture({
    distinctId: resolveDistinctId(opts.req ?? null, opts.distinctId ?? null),
    event: opts.event,
    properties: opts.properties,
  });
}

/**
 * Capture an error in PostHog (in addition to console.error). Silently
 * no-ops when PostHog is disabled. Bots are filtered.
 */
export function captureExceptionEvent(
  error: unknown,
  opts: { req?: Request | null; distinctId?: string | null } = {},
): void {
  if (!client) return;
  if (opts.req && isBotRequest(opts.req)) return;
  const id = resolveDistinctId(opts.req ?? null, opts.distinctId ?? null);
  const err = error instanceof Error ? error : new Error(String(error));
  client.captureException(err, id);
}

/**
 * Tie a previously-anonymous distinctId (from session/sessionID) to a real
 * userId after the visitor registers. After this call, future events for
 * the userId carry the same person record.
 */
export function aliasIdentity(anonId: string, userId: string): void {
  if (!client || !anonId || !userId || anonId === userId) return;
  client.alias({ distinctId: userId, alias: anonId });
}

/**
 * Add or update properties on a person record (creates the person if it
 * doesn't exist). Use right after register or login.
 */
export function identifyPerson(
  userId: string,
  properties: Record<string, unknown> = {},
): void {
  if (!client || !userId) return;
  client.identify({ distinctId: userId, properties });
}

/** Flush in-flight events on graceful shutdown (SIGTERM/SIGINT). */
export async function shutdownPosthog(): Promise<void> {
  if (!client) return;
  try {
    await client.shutdown();
  } catch (err) {
    console.error("[posthog] shutdown error:", err);
  }
}
