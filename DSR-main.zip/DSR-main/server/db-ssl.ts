import fs from "fs";

export type DatabaseSslConfig = false | {
  rejectUnauthorized: boolean;
  ca?: string;
};

const SSL_DISABLE_MODES = new Set(["disable", "disabled", "false", "0"]);
const SSL_VERIFY_MODES = new Set(["verify-ca", "verify-full"]);

export function isLocalDatabaseUrl(url: string): boolean {
  return /(?:^|@|\b)(localhost|127\.0\.0\.1)(?::|\/|$)/i.test(url);
}

function readFirstEnv(...keys: string[]): string {
  for (const key of keys) {
    const value = String(process.env[key] || "").trim();
    if (value) return value;
  }
  return "";
}

function readBooleanEnv(key: string): boolean | null {
  const value = String(process.env[key] || "").trim().toLowerCase();
  if (!value) return null;
  if (["1", "true", "yes", "y"].includes(value)) return true;
  if (["0", "false", "no", "n"].includes(value)) return false;
  return null;
}

function readSslMode(databaseUrl: string): string {
  const explicit = readFirstEnv("DATABASE_SSL_MODE", "PGSSLMODE").toLowerCase();
  if (explicit) return explicit;

  try {
    return new URL(databaseUrl).searchParams.get("sslmode")?.trim().toLowerCase() || "";
  } catch {
    return "";
  }
}

function normalizePem(value: string): string {
  return value.replace(/\\n/g, "\n").trim();
}

function readDatabaseCa(): string | undefined {
  const inline = readFirstEnv("DATABASE_SSL_CA", "DATABASE_CA_CERT", "PGSSLROOTCERT_INLINE");
  if (inline) return normalizePem(inline);

  const base64 = readFirstEnv("DATABASE_SSL_CA_BASE64", "DATABASE_CA_CERT_BASE64");
  if (base64) {
    try {
      return Buffer.from(base64, "base64").toString("utf8").trim();
    } catch (err: any) {
      console.warn("[db] Ignoring invalid DATABASE_SSL_CA_BASE64:", err?.message || err);
    }
  }

  const caPath = readFirstEnv("DATABASE_SSL_CA_PATH", "DATABASE_CA_CERT_PATH", "PGSSLROOTCERT");
  if (caPath) {
    try {
      return fs.readFileSync(caPath, "utf8").trim();
    } catch (err: any) {
      console.warn("[db] Ignoring unreadable database CA file:", err?.message || err);
    }
  }

  return undefined;
}

export function getDatabaseSslConfig(databaseUrl: string): DatabaseSslConfig {
  if (!databaseUrl || isLocalDatabaseUrl(databaseUrl)) return false;

  const sslMode = readSslMode(databaseUrl);
  if (SSL_DISABLE_MODES.has(sslMode)) return false;

  const ca = readDatabaseCa();
  const explicitRejectUnauthorized = readBooleanEnv("DATABASE_SSL_REJECT_UNAUTHORIZED");
  const rejectUnauthorized = explicitRejectUnauthorized ?? Boolean(ca || SSL_VERIFY_MODES.has(sslMode));

  return ca
    ? { rejectUnauthorized, ca }
    : { rejectUnauthorized };
}
