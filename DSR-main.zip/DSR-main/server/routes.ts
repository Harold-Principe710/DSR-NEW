import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getAdminPixProductLabel, getPixRequestProductName, resolvePixProductKey } from "./pix-product-catalog";
import { getRandomPixCustomerData, redactPixCustomerData } from "./pix-customer-data";
import { getAppDateRangeFromQuery } from "./timezone";
import { setupSession, withSessionId, requireAuth } from "./sessionAuth";
import {
  abTestingMiddleware,
  AB_PREVIEW_TOKEN_TTL_MS,
  invalidateAbTestsCache,
  resolveAssignmentBySlug,
  signAbPreviewToken,
} from "./abTesting";
import { isBotRequest } from "./botDetection";
import { notifyImageCompleted, notifyImageFailed, notifyPixPaid } from "./websocket";
import {
  ADMIN_CUSTOMER_RESPONSE_KINDS,
  ADMIN_CUSTOMER_SORT_DIRECTIONS,
  ADMIN_CUSTOMER_SORT_FIELDS,
  ADMIN_PIX_PRODUCT_KEYS,
  FUNNEL_STEP_LABELS as ADMIN_FUNNEL_STEP_LABELS,
} from "@shared/admin-types";
import {
  generatedImages,
  pixPayments,
  userCredits,
  creditTransactions,
  type PixPayment,
  funnelStepEnum,
  type FunnelStep,
  funnelSessions,
  funnelEvents,
  videoPovRequests,
  KIE_AI_COSTS,
  applyKieCostMargin,
  paymentGateways,
  paymentGatewayTests,
  paymentGatewayTestVariants,
  paymentGatewayTransactions,
  type PaymentGateway,
  type PaymentGatewayTest,
  type PaymentGatewayTestVariant,
  type VideoPovRequest,
  isVideoPovPreviewAnalysisStatus,
} from "@shared/schema";
import { registerFunnelSchema, loginFunnelSchema } from "@shared/models/auth";
import { users } from "@shared/models/auth";
import { db } from "./db";
import { eq, and, or, sql, gte, lte, asc, desc, inArray, isNull } from "drizzle-orm";
import bcrypt from "bcryptjs";
import multer from "multer";
import path from "path";
import fs from "fs";
import { Readable } from "stream";
import sharp from "sharp";
import crypto from "crypto";
import heicConvert from "heic-convert";
import { z } from "zod";
import { uploadReferenceImageToCloudinary } from "./reference-image-storage";
import {
  captureEvent as posthogCapture,
  captureExceptionEvent as posthogCaptureException,
  aliasIdentity as posthogAlias,
  identifyPerson as posthogIdentify,
} from "./posthog";
import {
  analyzePovPreviewImage,
  buildPovPreviewVideoKey,
  getPovFallbackPreviewVideoUrl,
  getPovPreviewPosterUrl,
  getPovPreviewVideoUrl,
  isKnownPovPreviewVideoKey,
  isRetryablePovPreviewAnalysisError,
  normalizePovPreviewPosition,
  type PovPreviewAnalysisResult,
} from "./pov-preview";

const MAX_UTM_LEN = 64;
function sanitizeUtm(value: unknown): string | null {
  const str = typeof value === "string" ? value.trim() : "";
  if (!str) return null;
  return str.slice(0, MAX_UTM_LEN);
}

// ── Directories ──────────────────────────────────────────────────────
const TEMP_UPLOAD_DIR = path.join(process.cwd(), "tmp", "uploads");
const PERSISTENT_UPLOAD_DIR = path.join(process.cwd(), "uploads");
const TEMP_FILE_TTL_MS = 14 * 24 * 60 * 60 * 1000; // 14 days
const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
const IMAGE_OUTPUT_QUALITY = 92;
const PRIVILEGED_LOGIN_WINDOW_MS = 15 * 60 * 1000;
const PRIVILEGED_LOGIN_LOCKOUT_MS = 15 * 60 * 1000;
const PRIVILEGED_LOGIN_MAX_ATTEMPTS = 5;
const FREE_GENERATION_WINDOW_MS = 60 * 60 * 1000;
const FREE_GENERATION_MAX_PER_IP = 3;
const VIDEO_POV_REQUEST_REUSE_WINDOW_MS = 10 * 60 * 1000;
const VIDEO_POV_REQUEST_RATE_WINDOW_MS = 60 * 1000;
const VIDEO_POV_REQUEST_RATE_MAX = 5;
const FUNNEL_EVENT_MAX_BODY_BYTES = 16 * 1024;
const FUNNEL_EVENT_RATE_WINDOW_MS = 60 * 1000;
const FUNNEL_EVENT_RATE_MAX_PER_IP = 120;
const FUNNEL_EVENT_RATE_MAX_PER_SESSION = 80;
const FUNNEL_EVENT_RATE_MAX_KEYS = 10000;
const FUNNEL_EVENT_METADATA_MAX_KEYS = 32;
const FUNNEL_EVENT_METADATA_STRING_MAX = 512;
const FUNNEL_EVENT_METADATA_URL_MAX = 1024;
const REFERENCE_UPLOAD_ACCEPTED_EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".webp", ".gif", ".heic", ".heif"]);
const REFERENCE_UPLOAD_ACCEPTED_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/heic",
  "image/heif",
  "image/heic-sequence",
  "image/heif-sequence",
  "application/octet-stream",
]);
const HEIC_BRANDS = new Set(["heic", "heix", "hevc", "hevx", "heim", "heis", "mif1", "msf1"]);
const dummyPrivilegedPasswordHash = bcrypt.hashSync(crypto.randomBytes(32).toString("hex"), 10);
const missingPrivilegedConfigWarnings = new Set<string>();
const freeGenerationAttempts = new Map<string, { count: number; resetAt: number }>();
const videoPovRequestAttempts = new Map<string, { count: number; resetAt: number }>();
const funnelEventAttempts = new Map<string, { count: number; resetAt: number }>();
const povPreviewAnalysisScheduled = new Set<string>();
const povPreviewAnalysisInFlight = new Set<string>();
const povPreviewAnalysisRetryAttempts = new Map<string, number>();
const povPreviewPrewarmCache = new Map<string, {
  status: "processing" | "completed" | "failed";
  userId: string;
  sessionId: string | null;
  imageUrl: string;
  startedAt: number;
  updatedAt: number;
  promise?: Promise<PovPreviewAnalysisResult>;
  result?: PovPreviewAnalysisResult;
  error?: string;
}>();
const POV_PREVIEW_PREWARM_TTL_MS = 10 * 60 * 1000;
const POV_PREVIEW_RETRY_DELAYS_MS = [3000, 10000, 20000];

const DEFAULT_GENERATED_MEDIA_ALLOWED_HOSTS = [
  "res.cloudinary.com",
  "cloudinary.com",
  "kie.ai",
  "kieai.com",
  "kiecdn.com",
  "kie-cdn.com",
  "aiquickdraw.com",
];

function createConcurrencyLimiter(maxConcurrent: number) {
  let activeCount = 0;
  const queue: Array<() => void> = [];

  const next = () => {
    activeCount -= 1;
    const runQueued = queue.shift();
    runQueued?.();
  };

  return async function runWithLimit<T>(task: () => Promise<T>): Promise<T> {
    if (activeCount >= maxConcurrent) {
      await new Promise<void>((resolve) => {
        queue.push(resolve);
      });
    }

    activeCount += 1;

    try {
      return await task();
    } finally {
      next();
    }
  };
}

const referenceUploadProcessingLimit = createConcurrencyLimiter(2);
const povPreviewAnalysisLimit = createConcurrencyLimiter(2);

if (!fs.existsSync(TEMP_UPLOAD_DIR)) fs.mkdirSync(TEMP_UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(PERSISTENT_UPLOAD_DIR)) fs.mkdirSync(PERSISTENT_UPLOAD_DIR, { recursive: true });

function normalizeHost(value: unknown): string {
  const raw = String(value || "").trim();
  if (!raw) return "";

  try {
    return new URL(raw.includes("://") ? raw : `https://${raw}`).host.toLowerCase();
  } catch {
    return raw.split("/")[0]?.toLowerCase() || "";
  }
}

function getPublicHost(req?: express.Request): string {
  const configured = normalizeHost(process.env.PUBLIC_DOMAIN);
  if (configured) return configured;
  if (process.env.NODE_ENV !== "production") return normalizeHost(req?.headers.host);
  return "";
}

function getHostname(host: string): string {
  return host.split(":")[0]?.trim().toLowerCase() || "";
}

function buildLocalReferenceUploadUrl(req: express.Request, fileId: string) {
  const protocolHeader = req.headers["x-forwarded-proto"];
  const protocol = Array.isArray(protocolHeader)
    ? protocolHeader[0]
    : protocolHeader || req.protocol || process.env.PUBLIC_PROTOCOL || "https";
  const host = getPublicHost(req);
  if (!host) {
    throw new Error("PUBLIC_DOMAIN precisa estar configurado para expor uploads locais em produção.");
  }

  return `${protocol}://${host}/api/uploads/${fileId}.jpg`;
}

function inferMediaContentType(
  url: string,
  upstreamType: string | null,
  buf: Buffer,
): string {
  const normalizedUpstreamType = String(upstreamType || "")
    .split(";")[0]
    .trim()
    .toLowerCase();

  if (normalizedUpstreamType.startsWith("image/") || normalizedUpstreamType.startsWith("video/")) {
    return normalizedUpstreamType;
  }

  const ext = url.split(".").pop()?.split("?")[0]?.toLowerCase();
  const contentTypesByExt: Record<string, string> = {
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    webp: "image/webp",
    gif: "image/gif",
    mp4: "video/mp4",
  };

  if (ext && contentTypesByExt[ext]) {
    return contentTypesByExt[ext];
  }

  const signature = buf.subarray(0, 16).toString("hex");
  if (signature.startsWith("89504e470d0a1a0a")) return "image/png";
  if (signature.startsWith("ffd8ff")) return "image/jpeg";
  if (buf.subarray(0, 6).toString("ascii") === "GIF87a" || buf.subarray(0, 6).toString("ascii") === "GIF89a") {
    return "image/gif";
  }
  if (buf.subarray(0, 4).toString("ascii") === "RIFF" && buf.subarray(8, 12).toString("ascii") === "WEBP") {
    return "image/webp";
  }

  return "application/octet-stream";
}

function applyProxyMediaHeaders(
  res: express.Response,
  options: {
    url: string;
    upstreamType: string | null;
    buf: Buffer;
    cacheControl: string;
  },
) {
  res.setHeader("Cache-Control", options.cacheControl);
  if (options.cacheControl.includes("private")) {
    res.setHeader("Vary", "Cookie");
  }
  res.setHeader("Content-Type", inferMediaContentType(options.url, options.upstreamType, options.buf));
  res.setHeader("Content-Length", String(options.buf.byteLength));
  res.setHeader("Content-Disposition", "inline");
  res.setHeader("X-Content-Type-Options", "nosniff");
}

async function streamProxiedMedia(
  req: express.Request,
  res: express.Response,
  options: {
    url: string;
    cacheControl: string;
  },
): Promise<boolean> {
  const headers: Record<string, string> = {};
  const range = req.headers.range;
  if (typeof range === "string" && range.trim()) {
    headers.Range = range;
  }

  const upstream = await fetch(options.url, { headers });
  if (!upstream.ok && upstream.status !== 206) {
    return false;
  }

  res.status(upstream.status === 206 ? 206 : 200);
  res.setHeader("Cache-Control", options.cacheControl);
  if (options.cacheControl.includes("private")) {
    res.setHeader("Vary", "Cookie");
  }
  res.setHeader("Content-Type", inferMediaContentType(options.url, upstream.headers.get("content-type"), Buffer.alloc(0)));
  res.setHeader("Content-Disposition", "inline");
  res.setHeader("X-Content-Type-Options", "nosniff");

  const passthroughHeaders = ["content-length", "content-range", "accept-ranges", "etag", "last-modified"] as const;
  for (const header of passthroughHeaders) {
    const value = upstream.headers.get(header);
    if (value) res.setHeader(header, value);
  }
  if (!res.hasHeader("Accept-Ranges")) {
    res.setHeader("Accept-Ranges", "bytes");
  }

  if (!upstream.body) {
    res.end();
    return true;
  }

  Readable.fromWeb(upstream.body as any)
    .on("error", () => res.destroy())
    .pipe(res);
  return true;
}

function getGeneratedMediaAllowedHosts() {
  const configured = String(process.env.GENERATED_MEDIA_ALLOWED_HOSTS || "")
    .split(",")
    .map((host) => host.trim().toLowerCase())
    .filter(Boolean);
  return configured.length > 0 ? configured : DEFAULT_GENERATED_MEDIA_ALLOWED_HOSTS;
}

function isAllowedGeneratedMediaUrl(value: unknown) {
  if (typeof value !== "string" || !value.trim()) return false;

  try {
    const parsed = new URL(value);
    if (parsed.protocol !== "https:") return false;
    const hostname = parsed.hostname.toLowerCase();

    return getGeneratedMediaAllowedHosts().some((allowedHost) => {
      const normalized = allowedHost.replace(/^\*\./, "").toLowerCase();
      return hostname === normalized || hostname.endsWith(`.${normalized}`);
    });
  } catch {
    return false;
  }
}

function isAllowedPovPreviewAnalysisImageUrl(value: unknown, req?: express.Request) {
  if (typeof value !== "string" || !value.trim()) return false;

  try {
    const parsed = new URL(value);
    if (parsed.protocol !== "https:") return false;
    const hostname = parsed.hostname.toLowerCase();
    const requestHost = getHostname(normalizeHost(req?.headers.host));
    const publicHost = getHostname(getPublicHost());
    const allowedHosts = new Set([
      ...getGeneratedMediaAllowedHosts(),
      publicHost,
      ...(process.env.NODE_ENV !== "production" && requestHost ? [requestHost] : []),
    ].filter(Boolean));

    return Array.from(allowedHosts).some((allowedHost) => {
      const normalized = allowedHost.replace(/^\*\./, "").toLowerCase();
      return hostname === normalized || hostname.endsWith(`.${normalized}`);
    });
  } catch {
    return false;
  }
}

function sanitizePovPreviewError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error || "erro desconhecido");
  return message.slice(0, 500);
}

function buildPovPreviewPrewarmKey(userId: string, sessionId: string | null | undefined, imageUrl: string) {
  const imageHash = crypto.createHash("sha256").update(imageUrl).digest("base64url").slice(0, 24);
  return `${userId}:${sessionId || "no-session"}:${imageHash}`;
}

function getPovPreviewPrewarmEntry(userId: string, sessionId: string | null | undefined, imageUrl: string) {
  const now = Date.now();
  for (const [key, entry] of Array.from(povPreviewPrewarmCache.entries())) {
    if (now - entry.updatedAt > POV_PREVIEW_PREWARM_TTL_MS) povPreviewPrewarmCache.delete(key);
  }

  const key = buildPovPreviewPrewarmKey(userId, sessionId, imageUrl);
  const entry = povPreviewPrewarmCache.get(key);
  if (!entry || now - entry.updatedAt > POV_PREVIEW_PREWARM_TTL_MS) {
    if (entry) povPreviewPrewarmCache.delete(key);
    return null;
  }
  return entry;
}

function startPovPreviewPrewarm(params: {
  userId: string;
  sessionId: string | null;
  imageUrl: string;
}) {
  const existing = getPovPreviewPrewarmEntry(params.userId, params.sessionId, params.imageUrl);
  if (existing && (existing.status === "processing" || existing.status === "completed")) return existing;

  const openAiApiKey = process.env.OPENAI_API_KEY;
  const kieApiKey = process.env.KIE_API_KEY;
  if ((!openAiApiKey && !kieApiKey) || process.env.POV_PREVIEW_ANALYSIS_ENABLED === "false") return null;

  const key = buildPovPreviewPrewarmKey(params.userId, params.sessionId, params.imageUrl);
  const entry: NonNullable<ReturnType<typeof getPovPreviewPrewarmEntry>> = {
    status: "processing",
    userId: params.userId,
    sessionId: params.sessionId,
    imageUrl: params.imageUrl,
    startedAt: Date.now(),
    updatedAt: Date.now(),
  };

  entry.promise = analyzePovPreviewImage({ openAiApiKey, kieApiKey, imageUrl: params.imageUrl })
    .then((result) => {
      entry.status = "completed";
      entry.result = result;
      entry.error = undefined;
      entry.updatedAt = Date.now();
      return result;
    })
    .catch((error) => {
      entry.status = "failed";
      entry.error = sanitizePovPreviewError(error);
      entry.updatedAt = Date.now();
      throw error;
    });
  void entry.promise.catch(() => {});

  povPreviewPrewarmCache.set(key, entry);
  return entry;
}

function readPovPreviewAnalysisStatus(value: unknown) {
  return isVideoPovPreviewAnalysisStatus(value) ? value : "failed";
}

async function applyPovPreviewAnalysisToRequest(params: {
  request: VideoPovRequest;
  analysis: PovPreviewAnalysisResult;
  position: NonNullable<ReturnType<typeof normalizePovPreviewPosition>>;
}) {
  const previewVideoKey = buildPovPreviewVideoKey({ ...params.analysis, position: params.position });
  const previewVideoUrl = getPovPreviewVideoUrl(previewVideoKey);

  if (!previewVideoUrl) {
    throw new Error(`Preview nao configurado para ${previewVideoKey}`);
  }
  if (!isAllowedGeneratedMediaUrl(previewVideoUrl)) {
    throw new Error(`URL de preview nao permitida para ${previewVideoKey}`);
  }

  povPreviewAnalysisRetryAttempts.delete(params.request.id);
  await storage.updateVideoPovRequest(params.request.id, {
    previewAnalysisStatus: "completed",
    previewAnalysisProvider: params.analysis.provider,
    previewAnalysisError: null,
    previewVisualTone: params.analysis.skinTone,
    previewBodyType: params.analysis.bodyType,
    previewVideoKey,
    previewResolvedAt: new Date(),
  });
}

function schedulePovPreviewRetry(requestId: string, error: unknown) {
  if (!isRetryablePovPreviewAnalysisError(error)) return false;

  const attempts = povPreviewAnalysisRetryAttempts.get(requestId) || 0;
  if (attempts >= POV_PREVIEW_RETRY_DELAYS_MS.length) return false;

  const delayMs = POV_PREVIEW_RETRY_DELAYS_MS[attempts];
  povPreviewAnalysisRetryAttempts.set(requestId, attempts + 1);
  setTimeout(() => schedulePovPreviewAnalysis(requestId), delayMs);
  return true;
}

function consumeVideoPovRequestAttempt(userId: string): boolean {
  const now = Date.now();

  if (videoPovRequestAttempts.size > 5000) {
    for (const [key, attempt] of Array.from(videoPovRequestAttempts.entries())) {
      if (attempt.resetAt <= now) videoPovRequestAttempts.delete(key);
    }
  }

  const current = videoPovRequestAttempts.get(userId);
  if (!current || current.resetAt <= now) {
    videoPovRequestAttempts.set(userId, { count: 1, resetAt: now + VIDEO_POV_REQUEST_RATE_WINDOW_MS });
    return true;
  }

  if (current.count >= VIDEO_POV_REQUEST_RATE_MAX) return false;
  current.count += 1;
  return true;
}

async function runPovPreviewAnalysis(requestId: string) {
  if (povPreviewAnalysisInFlight.has(requestId)) return;

  povPreviewAnalysisInFlight.add(requestId);

  try {
    const request = await storage.getVideoPovRequest(requestId);
    if (!request) return;
    if (request.previewVideoKey && readPovPreviewAnalysisStatus(request.previewAnalysisStatus) === "completed") return;

    const openAiApiKey = process.env.OPENAI_API_KEY;
    const kieApiKey = process.env.KIE_API_KEY;
    if (!openAiApiKey && !kieApiKey) {
      await storage.updateVideoPovRequest(request.id, {
        previewAnalysisStatus: "failed",
        previewAnalysisError: "OPENAI_API_KEY e KIE_API_KEY nao configuradas",
      });
      return;
    }

    const sourceImageUrl = request.previewAnalysisImageUrl;
    if (!sourceImageUrl || !isAllowedPovPreviewAnalysisImageUrl(sourceImageUrl)) {
      await storage.updateVideoPovRequest(request.id, {
        previewAnalysisStatus: "failed",
        previewAnalysisError: "Imagem de analise ausente ou nao permitida",
      });
      return;
    }

    const position = normalizePovPreviewPosition(request.position);
    if (!position) {
      await storage.updateVideoPovRequest(request.id, {
        previewAnalysisStatus: "failed",
        previewAnalysisError: "Posicao sem preview personalizado",
      });
      return;
    }

    await storage.updateVideoPovRequest(request.id, {
      previewAnalysisStatus: "processing",
      previewAnalysisError: null,
    });

    const prewarmEntry = getPovPreviewPrewarmEntry(request.userId, request.sessionId, sourceImageUrl);
    if (prewarmEntry?.status === "completed" && prewarmEntry.result) {
      await applyPovPreviewAnalysisToRequest({ request, analysis: prewarmEntry.result, position });
      return;
    }
    if (prewarmEntry?.promise && prewarmEntry.status === "processing") {
      const prewarmedAnalysis = await prewarmEntry.promise;
      await applyPovPreviewAnalysisToRequest({ request, analysis: prewarmedAnalysis, position });
      return;
    }

    const analysis = await analyzePovPreviewImage({
      openAiApiKey,
      kieApiKey,
      imageUrl: sourceImageUrl,
    });
    await applyPovPreviewAnalysisToRequest({ request, analysis, position });
  } catch (error) {
    console.error("[pov-preview] analysis error:", error);
    const willRetry = schedulePovPreviewRetry(requestId, error);
    await storage.updateVideoPovRequest(requestId, {
      previewAnalysisStatus: willRetry ? "pending" : "failed",
      previewAnalysisError: sanitizePovPreviewError(error),
    }).catch(() => {});
  } finally {
    povPreviewAnalysisInFlight.delete(requestId);
  }
}

function schedulePovPreviewAnalysis(requestId: string) {
  if (process.env.POV_PREVIEW_ANALYSIS_ENABLED === "false") return;
  if (povPreviewAnalysisScheduled.has(requestId) || povPreviewAnalysisInFlight.has(requestId)) return;
  povPreviewAnalysisScheduled.add(requestId);
  void povPreviewAnalysisLimit(() => runPovPreviewAnalysis(requestId))
    .finally(() => {
      povPreviewAnalysisScheduled.delete(requestId);
    });
}

function resolvePovPreviewUpstreamUrl(request: {
  position: string;
  previewVideoKey?: string | null;
}): { url: string | null; fallback: boolean } {
  if (request.previewVideoKey && isKnownPovPreviewVideoKey(request.previewVideoKey)) {
    const selectedUrl = getPovPreviewVideoUrl(request.previewVideoKey);
    if (selectedUrl && isAllowedGeneratedMediaUrl(selectedUrl)) return { url: selectedUrl, fallback: false };
  }

  const fallbackUrl = getPovFallbackPreviewVideoUrl(request.position);
  return {
    url: fallbackUrl && isAllowedGeneratedMediaUrl(fallbackUrl) ? fallbackUrl : null,
    fallback: true,
  };
}

function appendQueryParam(pathname: string, key: string, value: string) {
  const separator = pathname.includes("?") ? "&" : "?";
  return `${pathname}${separator}${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
}

function getRequestTimestampVersion(value: unknown): string {
  if (value instanceof Date && Number.isFinite(value.getTime())) return String(value.getTime());
  if (typeof value === "string" || typeof value === "number") {
    const parsed = new Date(value);
    if (Number.isFinite(parsed.getTime())) return String(parsed.getTime());
  }
  return "";
}

function buildPovPreviewMediaVersion(
  request: {
    createdAt?: unknown;
    updatedAt?: unknown;
    previewResolvedAt?: unknown;
  },
  previewAnalysisStatus: string,
  resolved: { fallback: boolean },
) {
  const timestamp = resolved.fallback
    ? getRequestTimestampVersion(request.updatedAt) || getRequestTimestampVersion(request.createdAt)
    : getRequestTimestampVersion(request.previewResolvedAt) || getRequestTimestampVersion(request.updatedAt);
  return `${resolved.fallback ? "fallback" : "custom"}:${previewAnalysisStatus}:${timestamp || "0"}`;
}

// ── Temp file registry ───────────────────────────────────────────────
const tempFileRegistry: Map<string, { path: string; expiresAt: number }> = new Map();

function cleanupExpiredFiles() {
  const now = Date.now();
  for (const [id, entry] of Array.from(tempFileRegistry.entries())) {
    if (entry.expiresAt <= now) {
      try { if (fs.existsSync(entry.path)) fs.unlinkSync(entry.path); } catch { }
      tempFileRegistry.delete(id);
    }
  }
}

function cleanupOrphanedFiles() {
  try {
    if (!fs.existsSync(TEMP_UPLOAD_DIR)) return;
    const now = Date.now();
    for (const file of fs.readdirSync(TEMP_UPLOAD_DIR)) {
      const filePath = path.join(TEMP_UPLOAD_DIR, file);
      try {
        const stats = fs.statSync(filePath);
        if (now - stats.mtimeMs > TEMP_FILE_TTL_MS) fs.unlinkSync(filePath);
      } catch { }
    }
  } catch { }
}

cleanupOrphanedFiles();
setInterval(() => { cleanupExpiredFiles(); cleanupOrphanedFiles(); }, 5 * 60 * 1000);

// ── Multer ───────────────────────────────────────────────────────────
const tempFileStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, TEMP_UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const uniqueId = crypto.randomBytes(16).toString("hex");
    const ext = path.extname(file.originalname) || ".jpg";
    cb(null, `${uniqueId}${ext}`);
  },
});

const uploadMiddleware = multer({
  storage: tempFileStorage,
  limits: { fileSize: MAX_UPLOAD_BYTES },
  fileFilter: (_req, file, cb) => {
    const extension = path.extname(file.originalname || "").toLowerCase();
    const mimeType = String(file.mimetype || "").toLowerCase();
    const isAcceptedByMime = REFERENCE_UPLOAD_ACCEPTED_MIME_TYPES.has(mimeType);
    const isAcceptedByExtension = REFERENCE_UPLOAD_ACCEPTED_EXTENSIONS.has(extension);

    (isAcceptedByMime || isAcceptedByExtension)
      ? cb(null, true)
      : cb(new Error("Tipo não suportado. Use JPEG, PNG, WebP, GIF, HEIC ou HEIF."));
  },
});

type SupportedUploadKind = "jpeg" | "png" | "webp" | "gif" | "heic";

type NormalizedReferenceUpload = {
  aspectRatio: string;
  finalBuffer: Buffer;
  finalHeight: number;
  finalWidth: number;
  originalHeight: number;
  originalWidth: number;
  padded: boolean;
};

function isHeicMimeType(value: string) {
  return value === "image/heic" || value === "image/heif" || value === "image/heic-sequence" || value === "image/heif-sequence";
}

function detectUploadKind(buffer: Buffer): SupportedUploadKind | null {
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return "jpeg";
  }

  if (
    buffer.length >= 8 &&
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a
  ) {
    return "png";
  }

  if (
    buffer.length >= 12 &&
    buffer.toString("ascii", 0, 4) === "RIFF" &&
    buffer.toString("ascii", 8, 12) === "WEBP"
  ) {
    return "webp";
  }

  if (
    buffer.length >= 6 &&
    (buffer.toString("ascii", 0, 6) === "GIF87a" || buffer.toString("ascii", 0, 6) === "GIF89a")
  ) {
    return "gif";
  }

  if (buffer.length >= 12 && buffer.toString("ascii", 4, 8) === "ftyp") {
    const majorBrand = buffer.toString("ascii", 8, 12).toLowerCase();
    if (HEIC_BRANDS.has(majorBrand)) {
      return "heic";
    }
  }

  return null;
}

async function convertHeicBufferToJpeg(buffer: Buffer) {
  const converted = await heicConvert({
    buffer,
    format: "JPEG",
    quality: 0.95,
  });

  return Buffer.isBuffer(converted) ? converted : Buffer.from(converted);
}

async function normalizeReferenceUpload(rawBuffer: Buffer, uploadKind: SupportedUploadKind): Promise<NormalizedReferenceUpload> {
  const inputBuffer = uploadKind === "heic"
    ? await convertHeicBufferToJpeg(rawBuffer)
    : rawBuffer;

  const { data: normalizedBuffer, info: normalizedInfo } = await sharp(inputBuffer, { animated: uploadKind === "gif" })
    .rotate()
    .flatten({ background: { r: 0, g: 0, b: 0 } })
    .jpeg({ quality: IMAGE_OUTPUT_QUALITY, mozjpeg: true })
    .toBuffer({ resolveWithObject: true });

  const originalWidth = normalizedInfo.width || 1;
  const originalHeight = normalizedInfo.height || 1;
  const closest = findClosestRatio(originalWidth, originalHeight);
  const padding = computePadding(originalWidth, originalHeight, closest.w, closest.h);
  const padded = padding.top > 0 || padding.bottom > 0 || padding.left > 0 || padding.right > 0;

  const finalBuffer = padded
    ? await sharp(normalizedBuffer)
      .extend({
        top: padding.top,
        bottom: padding.bottom,
        left: padding.left,
        right: padding.right,
        background: { r: 0, g: 0, b: 0, alpha: 1 },
      })
      .jpeg({ quality: IMAGE_OUTPUT_QUALITY, mozjpeg: true })
      .toBuffer()
    : normalizedBuffer;

  return {
    aspectRatio: closest.label,
    finalBuffer,
    finalHeight: padded ? padding.finalH : originalHeight,
    finalWidth: padded ? padding.finalW : originalWidth,
    originalHeight,
    originalWidth,
    padded,
  };
}

const VALID_RATIOS = [
  { label: "1:1", w: 1, h: 1 },
  { label: "4:3", w: 4, h: 3 },
  { label: "3:4", w: 3, h: 4 },
  { label: "16:9", w: 16, h: 9 },
  { label: "9:16", w: 9, h: 16 },
  { label: "2:3", w: 2, h: 3 },
  { label: "3:2", w: 3, h: 2 },
];

function findClosestRatio(imgW: number, imgH: number) {
  const imgRatio = imgW / imgH;
  let best = VALID_RATIOS[0];
  let bestDiff = Infinity;
  for (const ratio of VALID_RATIOS) {
    const diff = Math.abs(imgRatio - ratio.w / ratio.h);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = ratio;
    }
  }
  return best;
}

function computePadding(imgW: number, imgH: number, ratioW: number, ratioH: number) {
  const kX = Math.ceil(imgW / ratioW);
  const kY = Math.ceil(imgH / ratioH);
  const k = Math.max(kX, kY);

  const finalW = k * ratioW;
  const finalH = k * ratioH;

  if (finalW === imgW && finalH === imgH) {
    return { top: 0, bottom: 0, left: 0, right: 0, finalW: imgW, finalH: imgH };
  }

  const totalPadW = finalW - imgW;
  const totalPadH = finalH - imgH;

  const padTop = Math.floor(totalPadH / 2);
  const padBottom = totalPadH - padTop;
  const padLeft = Math.floor(totalPadW / 2);
  const padRight = totalPadW - padLeft;

  return { top: padTop, bottom: padBottom, left: padLeft, right: padRight, finalW, finalH };
}

const QWEN2_EDIT_PROMPT = "I WANT THIS WOMAN COMPLETELY NAKED ON A BED, HER BUTT STICKING OUT IN A SEXUAL POSITION. SHE MUST BE LOOKING BACK, HER FACE MUST BE VISIBLE. NEGATIVE PROMPT: DO NOT ADD TEXT OR SYMBOLS TO THE IMAGE.";

const generatedImageRequestSchema = z.object({
  referenceImageUrls: z.array(z.string().min(1).max(2048)).min(1).max(3),
  quantity: z.coerce.number().int().min(1).max(10).optional(),
  funnelFree: z.boolean().optional(),
});

const gatewaySlugSchema = z
  .string()
  .trim()
  .min(1)
  .max(64)
  .regex(/^[a-z0-9][a-z0-9-]*$/, "Slug deve conter apenas letras minúsculas, números e hífens");

const paymentGatewayCreateSchema = z.object({
  name: z.string().trim().min(1).max(80),
  slug: gatewaySlugSchema,
  provider: z.enum(["blackcat", "woovi", "custom"]).default("custom"),
  status: z.enum(["active", "paused"]).default("active"),
  description: z.string().trim().max(240).optional().nullable(),
});

const paymentGatewayUpdateSchema = z.object({
  name: z.string().trim().min(1).max(80).optional(),
  status: z.enum(["active", "paused"]).optional(),
  description: z.string().trim().max(240).optional().nullable(),
});

const paymentGatewayTestVariantInputSchema = z.object({
  gatewayId: z.string().min(1),
  name: z.string().trim().min(1).max(80).optional(),
  weight: z.number().min(0).max(100),
});

const paymentGatewayTestCreateSchema = z.object({
  name: z.string().trim().min(1).max(80),
  slug: gatewaySlugSchema,
  status: z.enum(["active", "paused"]).default("active"),
  variants: z.array(paymentGatewayTestVariantInputSchema).min(2).max(8),
});

const paymentGatewayTestUpdateSchema = z.object({
  status: z.enum(["active", "paused", "ended"]).optional(),
  variants: z.array(z.object({ id: z.string().min(1), weight: z.number().min(0).max(100) })).optional(),
});

function weightsSumTo100(variants: Array<{ weight: number }>) {
  const total = variants.reduce((sum, variant) => sum + variant.weight, 0);
  return Math.abs(total - 100) < 0.01;
}

function resolvePixCreditAmount(planId: string, amountCents: number): number {
  const PLAN_CREDIT_AMOUNTS: Record<string, number> = {
    "pix-tester-1000": 0,
    "1-foto": 1,
    "1-foto-1990": 1,
    "video-pov-990": 1,
    "video-pov-promo-1990": 1,
    "pack-fotos-1990": 3,
    "pack-fotos-2990": 3,
    "video-pov-1990": 3,
    "video-pov-2990": 3,
    "video-pov-pack-2990": 6,
    "video-pov-pack-3990": 6,
    "10-fotos": 10,
    "10-fotos-5990": 10,
    "ilimitado": 10,
    "ilimitado-pack-fotos-4490": 10,
    "10-fotos-1-video": 11,
    "10-fotos-1-video-7990": 11,
  };

  const explicit = PLAN_CREDIT_AMOUNTS[planId] ?? 0;
  if (explicit > 0) return explicit;
  if (amountCents === 990) return 1;
  if (amountCents === 1990) return 3;
  if (amountCents === 2990) return 6;
  if (amountCents === 4990) return 10;
  if (amountCents === 6990) return 11;
  return 0;
}

async function fetchWithServerTimeout(
  input: string,
  init: RequestInit,
  timeoutMs: number,
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } catch (error: any) {
    if (error?.name === "AbortError") {
      throw new Error(`Timeout after ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

type PrivilegedScope = "admin" | "caller";

type PrivilegedAuthConfig = {
  passwordHashEnv: string;
  usernameEnv: string;
};

type PrivilegedLoginAttempt = {
  count: number;
  firstFailureAt: number;
  lockedUntil: number;
};

const PRIVILEGED_AUTH_CONFIGS: Record<PrivilegedScope, PrivilegedAuthConfig> = {
  admin: {
    usernameEnv: "ADMIN_USERNAME",
    passwordHashEnv: "ADMIN_PASSWORD_HASH",
  },
  caller: {
    usernameEnv: "CALLER_USERNAME",
    passwordHashEnv: "CALLER_PASSWORD_HASH",
  },
};

const privilegedLoginAttempts = new Map<string, PrivilegedLoginAttempt>();

function getPrivilegedConfig(scope: PrivilegedScope) {
  const config = PRIVILEGED_AUTH_CONFIGS[scope];
  const username = process.env[config.usernameEnv]?.trim() || "";
  const passwordHash = process.env[config.passwordHashEnv]?.trim() || "";
  const isConfigured = Boolean(username && passwordHash);

  if (!isConfigured && !missingPrivilegedConfigWarnings.has(scope)) {
    missingPrivilegedConfigWarnings.add(scope);
    console.warn(`[auth] ${scope} login disabled: missing ${config.usernameEnv} and/or ${config.passwordHashEnv}`);
  }

  return {
    ...config,
    username,
    passwordHash,
    isConfigured,
  };
}

function safeStringEqual(left: string, right: string) {
  const leftHash = crypto.createHash("sha256").update(left).digest();
  const rightHash = crypto.createHash("sha256").update(right).digest();
  return crypto.timingSafeEqual(leftHash, rightHash);
}

function comparePrivilegedPassword(password: string, passwordHash: string) {
  try {
    return bcrypt.compareSync(password, passwordHash);
  } catch (error) {
    console.error("[auth] privileged password compare failed:", error);
    return false;
  }
}

const REDACTED = "[REDACTED]";
const REDACTED_RAW_PAYLOAD = "[REDACTED_RAW_PAYLOAD]";
const MAX_STORED_PAYLOAD_STRING_LENGTH = 500;

const SENSITIVE_PAYLOAD_KEYS = new Set([
  "authorization",
  "cookie",
  "setcookie",
  "xsignature",
  "xwebhooksignature",
  "xblackcatsignature",
  "xinternalsignature",
  "password",
  "secret",
  "token",
  "apikey",
  "api_key",
  "email",
  "phone",
  "telefone",
  "document",
  "documento",
  "cpf",
  "name",
  "nome",
  "qrcode",
  "brcode",
  "brcodebase64",
  "copypaste",
  "pixcode",
]);

function normalizePayloadKey(key: string) {
  return key.toLowerCase().replace(/[^a-z0-9]/g, "");
}

function shouldRedactPayloadKey(key: string) {
  const normalized = normalizePayloadKey(key);
  if (SENSITIVE_PAYLOAD_KEYS.has(normalized)) return true;
  return (
    normalized.includes("password") ||
    normalized.includes("secret") ||
    normalized.includes("token") ||
    normalized.includes("authorization") ||
    normalized.includes("signature") ||
    normalized.includes("credential") ||
    normalized.includes("email") ||
    normalized.includes("phone") ||
    normalized.includes("telefone") ||
    normalized.includes("document") ||
    normalized.includes("documento") ||
    normalized.includes("cpf") ||
    ((normalized.includes("customer") || normalized.includes("buyer") || normalized.includes("payer")) &&
      normalized.includes("name"))
  );
}

function redactSensitivePayload(value: unknown, depth = 0): unknown {
  if (value === null || value === undefined) return value;
  if (depth > 6) return "[REDACTED_DEPTH_LIMIT]";

  if (typeof value === "string") {
    return value.length > MAX_STORED_PAYLOAD_STRING_LENGTH
      ? `${value.slice(0, MAX_STORED_PAYLOAD_STRING_LENGTH)}...`
      : value;
  }

  if (typeof value !== "object") return value;

  if (Array.isArray(value)) {
    return value.slice(0, 50).map((item) => redactSensitivePayload(item, depth + 1));
  }

  const output: Record<string, unknown> = {};
  for (const [key, nestedValue] of Object.entries(value as Record<string, unknown>)) {
    if (normalizePayloadKey(key) === "raw") {
      output[key] = REDACTED_RAW_PAYLOAD;
      continue;
    }

    output[key] = shouldRedactPayloadKey(key)
      ? REDACTED
      : redactSensitivePayload(nestedValue, depth + 1);
  }
  return output;
}

function redactPayloadRecord(value: unknown): Record<string, unknown> {
  const redacted = redactSensitivePayload(value);
  return redacted && typeof redacted === "object" && !Array.isArray(redacted)
    ? redacted as Record<string, unknown>
    : { value: redacted };
}

function redactHeaderMap(headers: Record<string, string>): Record<string, string> {
  const redacted = redactPayloadRecord(headers);
  return Object.fromEntries(
    Object.entries(redacted).map(([key, value]) => [key, typeof value === "string" ? value : String(value)]),
  );
}

function redactWorkerResponseForLog(text: string): Record<string, unknown> {
  const bodyLength = Buffer.byteLength(text || "", "utf8");
  const trimmed = String(text || "").trim();
  if (!trimmed) return { bodyLength, empty: true };

  try {
    return { bodyLength, json: redactPayloadRecord(JSON.parse(trimmed)) };
  } catch {
    return { bodyLength, body: REDACTED_RAW_PAYLOAD };
  }
}

function buildInternalSignedJsonRequest(body: Record<string, unknown>, secret: string): { body: string; headers: Record<string, string> } {
  const payload = JSON.stringify(body);
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const signature = crypto
    .createHmac("sha256", secret)
    .update(`${timestamp}.`)
    .update(Buffer.from(payload, "utf8"))
    .digest("hex");

  return {
    body: payload,
    headers: {
      "Content-Type": "application/json",
      "x-internal-timestamp": timestamp,
      "x-internal-signature": `sha256=${signature}`,
      "x-internal-source": "desireai-api",
    },
  };
}

// ── Webhook HMAC verification ─────────────────────────────────────────
// Used by /api/webhooks/pix to reject forged
// payment notifications. Each webhook reads its own secret from env
// (PIX_WEBHOOK_SECRET). When the secret is unset,
// verification is skipped but a loud error is logged so the gap is visible
// in logs — staged rollout while the provider dashboard is configured.
type WebhookSignatureResult =
  | { ok: true }
  | { ok: false; reason: "missing_header" | "mismatch" };

function readSignatureHeader(req: any, headerNames: string[]): string | null {
  for (const name of headerNames) {
    const raw = req.headers[name];
    const value = Array.isArray(raw) ? raw[0] : raw;
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return null;
}

function verifyWebhookSignature(
  rawBody: Buffer | string | undefined,
  signatureHeader: string | null,
  secret: string,
): WebhookSignatureResult {
  if (!signatureHeader) return { ok: false, reason: "missing_header" };
  if (!rawBody) return { ok: false, reason: "missing_header" };

  const bodyBuffer = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(String(rawBody), "utf8");
  // Accept "sha256=<hex>" or bare "<hex>" / "<base64>" — providers vary.
  const provided = signatureHeader.replace(/^sha256=/i, "");

  const expectedHex = crypto.createHmac("sha256", secret).update(bodyBuffer).digest("hex");
  if (provided.length === expectedHex.length) {
    try {
      if (crypto.timingSafeEqual(Buffer.from(provided, "hex"), Buffer.from(expectedHex, "hex"))) {
        return { ok: true };
      }
    } catch {
      // Fall through to base64 attempt — provided wasn't valid hex.
    }
  }

  const expectedB64 = crypto.createHmac("sha256", secret).update(bodyBuffer).digest("base64");
  if (provided.length === expectedB64.length) {
    try {
      if (crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(expectedB64))) {
        return { ok: true };
      }
    } catch {
      // Same fallback: invalid base64 / length mismatch is a mismatch.
    }
  }

  return { ok: false, reason: "mismatch" };
}

type WebhookGuardOutcome =
  | { allow: true; verified: boolean }
  | { allow: false; reason: "missing_secret" | "missing_header" | "mismatch" };

function guardWebhookSignature({
  scope,
  secretEnvVar,
  headerNames,
  req,
}: {
  scope: string;
  secretEnvVar: string;
  headerNames: string[];
  req: any;
}): WebhookGuardOutcome {
  const secret = (process.env[secretEnvVar] || "").trim();
  if (!secret) {
    console.error(
      `[${scope}] SECURITY: ${secretEnvVar} not configured. ` +
      `Configure the secret on the provider dashboard and set ${secretEnvVar} to enforce.`,
    );
    if (process.env.NODE_ENV === "production") {
      return { allow: false, reason: "missing_secret" };
    }
    return { allow: true, verified: false };
  }

  const signatureHeader = readSignatureHeader(req, headerNames);
  const result = verifyWebhookSignature(req.rawBody, signatureHeader, secret);
  if (result.ok) return { allow: true, verified: true };

  console.warn(`[${scope}] Webhook signature rejected`, {
    reason: result.reason,
    headerPresent: Boolean(signatureHeader),
    headersTried: headerNames,
  });
  return { allow: false, reason: result.reason };
}

function verifyInternalGatewaySignature(req: any, secret: string): boolean {
  const timestamp = String(req.headers["x-internal-timestamp"] || "").trim();
  const signature = String(req.headers["x-internal-signature"] || "").trim();
  if (!timestamp || !signature || !req.rawBody) return false;

  const timestampMs = Number(timestamp) * 1000;
  if (!Number.isFinite(timestampMs) || Math.abs(Date.now() - timestampMs) > 5 * 60 * 1000) {
    return false;
  }

  const bodyBuffer = Buffer.isBuffer(req.rawBody) ? req.rawBody : Buffer.from(String(req.rawBody), "utf8");
  const expected = crypto
    .createHmac("sha256", secret)
    .update(`${timestamp}.`)
    .update(bodyBuffer)
    .digest("hex");
  const provided = signature.replace(/^sha256=/i, "");

  try {
    return provided.length === expected.length
      && crypto.timingSafeEqual(Buffer.from(provided, "hex"), Buffer.from(expected, "hex"));
  } catch {
    return false;
  }
}

function verifyInternalBearerSecret(req: any, secret: string): boolean {
  const authorization = String(req.headers["authorization"] || "").trim();
  const bearer = authorization.toLowerCase().startsWith("bearer ")
    ? authorization.slice("bearer ".length).trim()
    : "";
  const direct = String(req.headers["x-internal-secret"] || "").trim();
  const candidate = bearer || direct;
  return Boolean(candidate) && safeStringEqual(candidate, secret);
}

function normalizeClientIp(value: unknown) {
  const raw = String(value || "unknown").trim();
  return raw.replace(/^::ffff:/, "") || "unknown";
}

function reserveFreeGenerationAttempt(req: any, sessionId: string): { ok: true } | { ok: false; retryAfterSeconds: number } {
  const now = Date.now();
  const ip = normalizeClientIp(req.ip || req.socket?.remoteAddress);
  const keys = [`ip:${ip}`, `session:${sessionId}`];

  for (const [key, entry] of Array.from(freeGenerationAttempts.entries())) {
    if (entry.resetAt <= now) freeGenerationAttempts.delete(key);
  }

  for (const key of keys) {
    const entry = freeGenerationAttempts.get(key);
    const max = key.startsWith("session:") ? 1 : FREE_GENERATION_MAX_PER_IP;
    if (entry && entry.count >= max) {
      return {
        ok: false,
        retryAfterSeconds: Math.max(1, Math.ceil((entry.resetAt - now) / 1000)),
      };
    }
  }

  for (const key of keys) {
    const current = freeGenerationAttempts.get(key);
    freeGenerationAttempts.set(key, {
      count: (current?.count ?? 0) + 1,
      resetAt: current?.resetAt ?? now + FREE_GENERATION_WINDOW_MS,
    });
  }

  return { ok: true };
}

function releaseFreeGenerationKey(key: string) {
  const current = freeGenerationAttempts.get(key);
  if (!current) return;
  const nextCount = current.count - 1;
  if (nextCount <= 0) {
    freeGenerationAttempts.delete(key);
    return;
  }
  freeGenerationAttempts.set(key, { ...current, count: nextCount });
}

function releaseFreeGenerationAttempt(req: any, sessionId: string) {
  const ip = normalizeClientIp(req.ip || req.socket?.remoteAddress);
  releaseFreeGenerationKey(`ip:${ip}`);
  releaseFreeGenerationKey(`session:${sessionId}`);
}

function releaseFreeGenerationSessionAttempt(sessionId?: string | null) {
  if (!sessionId) return;
  releaseFreeGenerationKey(`session:${sessionId}`);
}

function getPrivilegedAttemptKey(scope: PrivilegedScope, req: any) {
  const ip = normalizeClientIp(req.ip || req.socket?.remoteAddress);
  return `${scope}:${ip}`;
}

function getPrivilegedLockoutRemainingMs(scope: PrivilegedScope, req: any) {
  const key = getPrivilegedAttemptKey(scope, req);
  const current = privilegedLoginAttempts.get(key);
  if (!current) return 0;

  const now = Date.now();
  if (current.lockedUntil > now) {
    return current.lockedUntil - now;
  }

  if (now - current.firstFailureAt > PRIVILEGED_LOGIN_WINDOW_MS) {
    privilegedLoginAttempts.delete(key);
  }

  return 0;
}

function registerPrivilegedLoginFailure(scope: PrivilegedScope, req: any) {
  const key = getPrivilegedAttemptKey(scope, req);
  const now = Date.now();
  const current = privilegedLoginAttempts.get(key);

  if (!current || now - current.firstFailureAt > PRIVILEGED_LOGIN_WINDOW_MS) {
    privilegedLoginAttempts.set(key, {
      count: 1,
      firstFailureAt: now,
      lockedUntil: 0,
    });
    return 0;
  }

  const nextCount = current.count + 1;
  const lockedUntil = nextCount >= PRIVILEGED_LOGIN_MAX_ATTEMPTS ? now + PRIVILEGED_LOGIN_LOCKOUT_MS : 0;
  privilegedLoginAttempts.set(key, {
    count: nextCount,
    firstFailureAt: current.firstFailureAt,
    lockedUntil,
  });

  return lockedUntil > now ? lockedUntil - now : 0;
}

function clearPrivilegedLoginFailures(scope: PrivilegedScope, req: any) {
  privilegedLoginAttempts.delete(getPrivilegedAttemptKey(scope, req));
}

function formatRetryDelayMs(ms: number) {
  const totalSeconds = Math.max(1, Math.ceil(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  if (minutes <= 0) return `${seconds}s`;
  if (seconds === 0) return `${minutes} min`;
  return `${minutes} min ${seconds}s`;
}

const FUNNEL_STEP_LABELS: Record<FunnelStep, string> = {
  visitor_entered: "Visitantes",
  photo_uploaded: "Upou foto",
  generated_photo_viewed: "Viu foto gerada",
  offer_viewed: "Viu oferta",
  offer_responded: "Respondeu à oferta",
  video_loading_screen: "Tela de loading do vídeo",
  video_loaded: "Vídeo carregado",
  pix_generated: "PIX gerado",
  pix_paid: "PIX pago",
};

const FUNNEL_STEP_ORDER: FunnelStep[] = [
  "visitor_entered",
  "photo_uploaded",
  "generated_photo_viewed",
  "offer_viewed",
  "offer_responded",
  "video_loading_screen",
  "video_loaded",
  "pix_generated",
  "pix_paid",
];

const JOURNEY_EXTERNAL_REF_SEPARATOR = "::";

// In-memory cache for the journey-tree endpoint (admin-only, not user-facing).
// LRU-capped to bound memory under custom date-range churn.
const JOURNEY_TREE_CACHE_TTL_MS = 30_000;
const JOURNEY_TREE_CACHE_MAX_ENTRIES = 32;
const ADMIN_ANALYTICS_MAX_RANGE_DAYS = 90;
const JOURNEY_TREE_MAX_RANGE_DAYS = ADMIN_ANALYTICS_MAX_RANGE_DAYS;
const MS_PER_DAY = 24 * 60 * 60 * 1000;
const journeyTreeCache = new Map<string, { ts: number; data: unknown }>();

function journeyTreeCacheGet(key: string) {
  const hit = journeyTreeCache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.ts >= JOURNEY_TREE_CACHE_TTL_MS) {
    journeyTreeCache.delete(key);
    return null;
  }
  // refresh recency for LRU eviction
  journeyTreeCache.delete(key);
  journeyTreeCache.set(key, hit);
  return hit.data;
}

function journeyTreeCacheSet(key: string, data: unknown) {
  if (journeyTreeCache.size >= JOURNEY_TREE_CACHE_MAX_ENTRIES) {
    const oldestKey = journeyTreeCache.keys().next().value;
    if (oldestKey !== undefined) journeyTreeCache.delete(oldestKey);
  }
  journeyTreeCache.set(key, { ts: Date.now(), data });
}

type JourneyNodeDefinition = {
  id: string;
  label: string;
  x: number;
  y: number;
};

const JOURNEY_NODES: JourneyNodeDefinition[] = [
  { id: "landing_home", label: "Landing inicial", x: 40, y: 230 },
  { id: "landing_photo_uploaded", label: "Foto enviada", x: 300, y: 230 },
  { id: "landing_generated_photo", label: "Foto gerada vista", x: 560, y: 230 },
  { id: "landing_offer", label: "Oferta visualizada", x: 820, y: 230 },
  { id: "landing_offer_responded", label: "Resposta à oferta", x: 1080, y: 230 },
  { id: "login_page", label: "Login / cadastro", x: 300, y: 70 },
  { id: "video_loading_page", label: "Loading vídeo POV", x: 1340, y: 70 },
  { id: "pack_loading_page", label: "Loading pack fotos", x: 1340, y: 390 },
  { id: "video_loaded_page", label: "Vídeo pronto", x: 1600, y: 70 },
  { id: "pack_loaded_page", label: "Pack pronto", x: 1600, y: 390 },
  { id: "app_dashboard", label: "Painel", x: 1340, y: 230 },
  { id: "app_gallery", label: "Galeria", x: 1600, y: 230 },
  { id: "app_settings", label: "Configurações", x: 1860, y: 230 },
  { id: "pix_generated_landing", label: "PIX gerado (landing)", x: 1860, y: 520 },
  { id: "pix_paid_landing", label: "PIX pago (landing)", x: 2120, y: 520 },
  { id: "pix_generated_video", label: "PIX gerado (loading vídeo)", x: 1860, y: 40 },
  { id: "pix_paid_video", label: "PIX pago (loading vídeo)", x: 2120, y: 40 },
  { id: "pix_generated_pack", label: "PIX gerado (loading pack)", x: 1860, y: 390 },
  { id: "pix_paid_pack", label: "PIX pago (loading pack)", x: 2120, y: 390 },
  { id: "pix_generated_dashboard", label: "PIX gerado (painel)", x: 1860, y: 150 },
  { id: "pix_paid_dashboard", label: "PIX pago (painel)", x: 2120, y: 150 },
  { id: "pix_generated_gallery", label: "PIX gerado (galeria)", x: 1860, y: 230 },
  { id: "pix_paid_gallery", label: "PIX pago (galeria)", x: 2120, y: 230 },
  { id: "pix_generated_settings", label: "PIX gerado (configurações)", x: 1860, y: 310 },
  { id: "pix_paid_settings", label: "PIX pago (configurações)", x: 2120, y: 310 },
  { id: "pix_tester_page", label: "Página teste PIX", x: 1600, y: 650 },
  { id: "pix_generated_tester", label: "PIX gerado (teste)", x: 1860, y: 650 },
  { id: "pix_paid_tester", label: "PIX pago (teste)", x: 2120, y: 650 },
];

const JOURNEY_EDGES: Array<{ source: string; target: string }> = [
  { source: "landing_home", target: "landing_photo_uploaded" },
  { source: "landing_photo_uploaded", target: "landing_generated_photo" },
  { source: "landing_generated_photo", target: "landing_offer" },
  { source: "landing_offer", target: "landing_offer_responded" },
  { source: "landing_home", target: "login_page" },
  { source: "landing_offer_responded", target: "video_loading_page" },
  { source: "landing_offer_responded", target: "pack_loading_page" },
  { source: "video_loading_page", target: "video_loaded_page" },
  { source: "pack_loading_page", target: "pack_loaded_page" },
  { source: "landing_offer_responded", target: "app_dashboard" },
  { source: "app_dashboard", target: "app_gallery" },
  { source: "app_gallery", target: "app_settings" },
  { source: "landing_offer", target: "pix_generated_landing" },
  { source: "pix_generated_landing", target: "pix_paid_landing" },
  { source: "video_loaded_page", target: "pix_generated_video" },
  { source: "pix_generated_video", target: "pix_paid_video" },
  { source: "pack_loaded_page", target: "pix_generated_pack" },
  { source: "pix_generated_pack", target: "pix_paid_pack" },
  { source: "app_dashboard", target: "pix_generated_dashboard" },
  { source: "pix_generated_dashboard", target: "pix_paid_dashboard" },
  { source: "app_gallery", target: "pix_generated_gallery" },
  { source: "pix_generated_gallery", target: "pix_paid_gallery" },
  { source: "app_settings", target: "pix_generated_settings" },
  { source: "pix_generated_settings", target: "pix_paid_settings" },
  { source: "pix_tester_page", target: "pix_generated_tester" },
  { source: "pix_generated_tester", target: "pix_paid_tester" },
];

function getSessionId(req: any): string {
  return req.sessionID || `anonymous-${Math.random().toString(36).slice(2)}`;
}

function sanitizeJourneyNode(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim().toLowerCase();
  if (!trimmed) return null;
  return /^[a-z0-9_-]+$/.test(trimmed) ? trimmed : null;
}

const publicFunnelEventSchema = z.object({
  step: z.enum(funnelStepEnum.enumValues as [FunnelStep, ...FunnelStep[]]),
  eventName: z.string().trim().min(1).max(120).optional(),
  idempotencyKey: z.string().trim().min(1).max(180).optional(),
  metadata: z.record(z.unknown()).optional().default({}),
  journeyNode: z.string().trim().max(80).optional(),
  journeyPath: z.string().trim().max(240).optional(),
  customerName: z.string().trim().max(120).optional().nullable(),
  customerEmail: z.string().trim().max(254).optional().nullable(),
  utm_source: z.string().trim().max(256).optional().nullable(),
  utm_medium: z.string().trim().max(256).optional().nullable(),
  utm_campaign: z.string().trim().max(256).optional().nullable(),
  utm_content: z.string().trim().max(256).optional().nullable(),
  utm_term: z.string().trim().max(256).optional().nullable(),
}).strict();

const PUBLIC_FUNNEL_METADATA_ALLOWED_KEYS = new Set([
  "amountCents",
  "appPaymentId",
  "aspectRatio",
  "cardId",
  "creditAmount",
  "externalReference",
  "funnelBranch",
  "gatewayId",
  "gatewaySlug",
  "hole",
  "imageId",
  "journeyNode",
  "journeyPath",
  "offer",
  "paymentId",
  "planId",
  "position",
  "provider",
  "requestAmountCents",
  "requestId",
  "requestStatus",
  "saleId",
  "screen",
  "sexType",
  "source",
  "speechType",
  "status",
  "testId",
  "testSlug",
  "transactionId",
  "url",
  "variant",
  "variantId",
]);

function getRequestBodySizeBytes(req: any): number {
  const rawBody = req.rawBody;
  if (Buffer.isBuffer(rawBody)) return rawBody.byteLength;
  if (typeof rawBody === "string") return Buffer.byteLength(rawBody);
  const contentLength = Number(req.headers?.["content-length"] || 0);
  return Number.isFinite(contentLength) ? contentLength : 0;
}

function pruneFunnelEventAttempts(now: number) {
  if (funnelEventAttempts.size <= FUNNEL_EVENT_RATE_MAX_KEYS) return;
  for (const [key, attempt] of Array.from(funnelEventAttempts.entries())) {
    if (attempt.resetAt <= now) funnelEventAttempts.delete(key);
  }
}

function reserveFunnelEventAttempt(req: any): { ok: true } | { ok: false; retryAfterSeconds: number } {
  const now = Date.now();
  pruneFunnelEventAttempts(now);

  const ip = normalizeClientIp(req.ip || req.socket?.remoteAddress);
  const sessionId = String(req.sessionID || "").trim().slice(0, 128) || "anonymous";
  const limits = [
    { key: `funnel:ip:${ip}`, max: FUNNEL_EVENT_RATE_MAX_PER_IP },
    { key: `funnel:session:${sessionId}`, max: FUNNEL_EVENT_RATE_MAX_PER_SESSION },
  ];

  let retryAfterSeconds = 1;
  for (const { key, max } of limits) {
    const attempt = funnelEventAttempts.get(key);
    if (!attempt || attempt.resetAt <= now) continue;
    if (attempt.count >= max) {
      retryAfterSeconds = Math.max(retryAfterSeconds, Math.ceil((attempt.resetAt - now) / 1000));
      return { ok: false, retryAfterSeconds };
    }
  }

  for (const { key } of limits) {
    const current = funnelEventAttempts.get(key);
    funnelEventAttempts.set(key, {
      count: current && current.resetAt > now ? current.count + 1 : 1,
      resetAt: current && current.resetAt > now ? current.resetAt : now + FUNNEL_EVENT_RATE_WINDOW_MS,
    });
  }

  return { ok: true };
}

type SanitizedFunnelMetadata = Record<string, string | number | boolean | null>;

function sanitizeFunnelEventMetadata(metadata: unknown): SanitizedFunnelMetadata {
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) return {};

  const sanitized: SanitizedFunnelMetadata = {};
  for (const [key, value] of Object.entries(metadata as Record<string, unknown>)) {
    if (Object.keys(sanitized).length >= FUNNEL_EVENT_METADATA_MAX_KEYS) break;
    if (!PUBLIC_FUNNEL_METADATA_ALLOWED_KEYS.has(key)) continue;

    if (key === "journeyNode") {
      const journeyNode = sanitizeJourneyNode(value);
      if (journeyNode) sanitized[key] = journeyNode;
      continue;
    }

    if (typeof value === "string") {
      const maxLength = key === "url" ? FUNNEL_EVENT_METADATA_URL_MAX : FUNNEL_EVENT_METADATA_STRING_MAX;
      sanitized[key] = value.trim().slice(0, maxLength);
    } else if (typeof value === "number" && Number.isFinite(value) && Math.abs(value) <= Number.MAX_SAFE_INTEGER) {
      sanitized[key] = value;
    } else if (typeof value === "boolean" || value === null) {
      sanitized[key] = value;
    }
  }

  return sanitized;
}

function normalizedOptionalText(value: string | null | undefined): string | null {
  const trimmed = typeof value === "string" ? value.trim() : "";
  return trimmed || null;
}

type ParsedExternalReference =
  | { type: "legacy"; sessionId: string; journeyNode: string | null }
  | { type: "ab"; testSlug: string; variantId: string };

function parseExternalReference(value: unknown): ParsedExternalReference & { sessionId: string; journeyNode: string | null } {
  const raw = String(value || "").trim();
  if (!raw) return { type: "legacy", sessionId: "", journeyNode: null };

  // A/B test reference: "ab|<testSlug>|<variantId>". Carries no funnel session,
  // so funnel-side fields are returned empty and the conversion is recorded
  // separately against the variant.
  if (raw.startsWith("ab|")) {
    const parts = raw.split("|");
    const testSlug = (parts[1] || "").trim();
    const variantId = (parts[2] || "").trim();
    return { type: "ab", testSlug, variantId, sessionId: "", journeyNode: null };
  }

  // App-level references such as dai_<pixPaymentId> are audit metadata, not
  // funnel session ids. Payment attribution must come from appPaymentId or the
  // provider transaction id.
  if (raw.startsWith("dai_")) {
    return { type: "legacy", sessionId: "", journeyNode: null };
  }

  // Historical externalrefs may carry a legacy "_v2nodata" suffix from the
  // retired A/B test. Strip it so webhooks for in-flight charges still match.
  const withoutLegacySuffix = raw.endsWith("_v2nodata") ? raw.slice(0, -"_v2nodata".length) : raw;
  const splitIndex = withoutLegacySuffix.indexOf(JOURNEY_EXTERNAL_REF_SEPARATOR);
  if (splitIndex === -1) {
    return { type: "legacy", sessionId: withoutLegacySuffix, journeyNode: null };
  }
  const sessionId = withoutLegacySuffix.slice(0, splitIndex).trim();
  const journeyNodeRaw = withoutLegacySuffix.slice(splitIndex + JOURNEY_EXTERNAL_REF_SEPARATOR.length);
  return { type: "legacy", sessionId, journeyNode: sanitizeJourneyNode(journeyNodeRaw) };
}

function readExternalReferenceFromBody(body: Record<string, any>): string {
  const nested =
    body.data && typeof body.data === "object" && !Array.isArray(body.data)
      ? body.data as Record<string, any>
      : {};

  return String(
    body.externalReference
      ?? body.externalRef
      ?? body.externalref
      ?? body.external_reference
      ?? nested.externalReference
      ?? nested.externalRef
      ?? nested.externalref
      ?? nested.external_reference
      ?? "",
  ).trim();
}

function readNestedRecord(...values: unknown[]): Record<string, any> {
  for (const value of values) {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      return value as Record<string, any>;
    }
  }
  return {};
}

function readFirstString(...values: unknown[]): string {
  for (const value of values) {
    const text = String(value ?? "").trim();
    if (text) return text;
  }
  return "";
}

function normalizeObjectLookupKey(key: string) {
  return key.toLowerCase().replace(/[^a-z0-9]/g, "");
}

function normalizePixCopyPaste(value: unknown): string {
  if (typeof value !== "string") return "";
  const trimmed = value.trim();
  const pixStart = trimmed.indexOf("000201");
  const candidate = pixStart >= 0 ? trimmed.slice(pixStart) : trimmed;
  const terminatorIndex = candidate.search(/["'<>\\{}]/);
  const clean = (terminatorIndex > 0 ? candidate.slice(0, terminatorIndex) : candidate).replace(/[\r\n]/g, "");
  if (!clean) return "";

  const lower = clean.toLowerCase();
  const looksLikePixEmv = clean.startsWith("000201") && lower.includes("br.gov.bcb.pix");
  return looksLikePixEmv && clean.length >= 60 ? clean : "";
}

function readFirstPixCopyPaste(...values: unknown[]): string {
  for (const value of values) {
    const pixCode = normalizePixCopyPaste(value);
    if (pixCode) return pixCode;
  }
  return "";
}

const PIX_COPY_PASTE_KEYS = new Set([
  "brcode",
  "brcodebase64",
  "code",
  "copypaste",
  "emv",
  "emvqrcode",
  "pixbrcode",
  "pixcode",
  "pixcopypaste",
  "qrcode",
  "qrcodepix",
  "qrcodetext",
]);

function findPixCopyPasteInPayload(value: unknown, depth = 0): string {
  if (depth > 6 || value === null || value === undefined) return "";
  const direct = normalizePixCopyPaste(value);
  if (direct) return direct;

  if (Array.isArray(value)) {
    for (const item of value.slice(0, 20)) {
      const found = findPixCopyPasteInPayload(item, depth + 1);
      if (found) return found;
    }
    return "";
  }

  if (typeof value !== "object") return "";
  const record = value as Record<string, unknown>;
  for (const [key, nestedValue] of Object.entries(record)) {
    if (!PIX_COPY_PASTE_KEYS.has(normalizeObjectLookupKey(key))) continue;
    const found = normalizePixCopyPaste(nestedValue);
    if (found) return found;
  }

  for (const nestedValue of Object.values(record)) {
    const found = findPixCopyPasteInPayload(nestedValue, depth + 1);
    if (found) return found;
  }
  return "";
}

const PROVIDER_TRANSACTION_ID_KEYS = new Set([
  "abacatepayid",
  "gatewaypaymentid",
  "orderid",
  "paymentid",
  "providerpaymentid",
  "saleid",
  "transactionid",
]);

function findFirstStringByPayloadKeys(value: unknown, keys: Set<string>, depth = 0): string {
  if (depth > 5 || value === null || value === undefined || typeof value !== "object") return "";

  if (Array.isArray(value)) {
    for (const item of value.slice(0, 20)) {
      const found = findFirstStringByPayloadKeys(item, keys, depth + 1);
      if (found) return found;
    }
    return "";
  }

  const record = value as Record<string, unknown>;
  for (const [key, nestedValue] of Object.entries(record)) {
    if (!keys.has(normalizeObjectLookupKey(key))) continue;
    const found = readFirstString(nestedValue);
    if (found) return found;
  }

  for (const nestedValue of Object.values(record)) {
    const found = findFirstStringByPayloadKeys(nestedValue, keys, depth + 1);
    if (found) return found;
  }
  return "";
}

function readFirstNumber(...values: unknown[]): number | null {
  for (const value of values) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value === "string" && value.trim()) {
      const parsed = Number(value.replace(",", "."));
      if (Number.isFinite(parsed)) return parsed;
    }
  }
  return null;
}

function parseOptionalDate(...values: unknown[]): Date | null {
  const raw = readFirstString(...values);
  if (!raw) return null;
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? null : date;
}

function normalizeAmountCents(...values: unknown[]): number | null {
  const amount = readFirstNumber(...values);
  if (amount === null) return null;
  if (Math.abs(amount) < 1000 && !Number.isInteger(amount)) {
    return Math.round(amount * 100);
  }
  return Math.round(amount);
}

type WorkerPaymentStatus =
  | "created"
  | "paid"
  | "failed"
  | "expired"
  | "cancelled"
  | "refunded"
  | "chargedback"
  | "unknown";

function normalizeWorkerPaymentStatus(status: string, eventName: string): WorkerPaymentStatus {
  const raw = `${status} ${eventName}`.trim().toLowerCase();
  if (!raw) return "unknown";
  const tokens = raw.split(/[^a-z0-9]+/).filter(Boolean);
  const hasToken = (...values: string[]) => values.some((value) => tokens.includes(value));
  const hasPhrase = (...values: string[]) => values.some((value) => raw.includes(value));

  if (hasToken("chargeback", "chargedback") || hasPhrase("charge back", "charged back")) return "chargedback";
  if (hasToken("refund", "refunded", "reembolso", "estorno")) return "refunded";
  if (hasToken("expired", "expirado") || hasPhrase("expire")) return "expired";
  if (hasToken("cancel", "canceled", "cancelled", "cancelado") || hasPhrase("cancel")) return "cancelled";
  if (hasToken("fail", "failed", "refused", "rejected", "recusado") || hasPhrase("recus")) return "failed";
  if (
    hasToken("unpaid", "unapproved") ||
    hasPhrase("not_paid", "not paid", "nao_pago", "não_pago", "nao pago", "não pago")
  ) {
    return "unknown";
  }
  if (hasToken("paid", "approved", "confirmed", "aprovado", "pago", "settled", "succeeded", "completed")) return "paid";
  if (hasToken("created", "pending", "waiting", "gerado")) return "created";
  return "unknown";
}

function readPaymentWebhookNested(body: Record<string, any>) {
  return readNestedRecord(
    body.data,
    body.payment,
    body.transaction,
    body.sale,
    body.order,
    body.pix,
    body,
  );
}

type NormalizedWorkerPaymentEvent = ReturnType<typeof normalizeWorkerPaymentEvent>;

function isTerminalWorkerPaymentStatus(status: WorkerPaymentStatus): boolean {
  return status === "paid" || status === "refunded" || status === "chargedback";
}

function getTerminalWorkerEventAmountError(event: NormalizedWorkerPaymentEvent, payment: PixPayment): string | null {
  if (!isTerminalWorkerPaymentStatus(event.status)) return null;
  if (event.amountCents === null || !Number.isFinite(event.amountCents)) {
    return "Evento terminal sem amountCents confiável";
  }
  if (event.amountCents !== payment.amountCents) {
    return `Valor do evento (${event.amountCents}) diverge do pagamento (${payment.amountCents})`;
  }
  return null;
}

function normalizeWorkerPaymentEvent(body: Record<string, any>, headers: Record<string, string>) {
  const nested = readPaymentWebhookNested(body);
  const pix = readNestedRecord(nested.pix, body.pix);
  const gateway = readNestedRecord(body.gateway, nested.gateway);
  const routingAssignment = readNestedRecord(body.routingAssignment, nested.routingAssignment, body.assignment, nested.assignment);
  const eventName = readFirstString(
    headers["x-webhook-event"],
    headers["x-worker-event"],
    body.event,
    body.eventName,
    nested.event,
    nested.eventName,
  );
  const rawStatus = readFirstString(body.status, body.paymentStatus, nested.status, nested.paymentStatus);
  const status = normalizeWorkerPaymentStatus(rawStatus, eventName);
  const transactionId = readFirstString(
    body.transactionId,
    body.gatewayPaymentId,
    body.saleId,
    body.orderId,
    body.id,
    nested.transactionId,
    nested.gatewayPaymentId,
    nested.saleId,
    nested.orderId,
    nested.id,
  );
  const appPaymentId = readFirstString(
    body.appPaymentId,
    body.pixPaymentId,
    body.paymentId,
    nested.appPaymentId,
    nested.pixPaymentId,
    nested.paymentId,
  );
  const externalReference = readExternalReferenceFromBody(body);
  const paidAt = parseOptionalDate(body.paidAt, body.approvedDate, body.approvedAt, nested.paidAt, nested.approvedDate, nested.approvedAt);
  const refundedAt = parseOptionalDate(
    body.refundedAt,
    body.refundAt,
    body.chargebackAt,
    body.chargedBackAt,
    nested.refundedAt,
    nested.refundAt,
    nested.chargebackAt,
    nested.chargedBackAt,
  );
  const amountCents = normalizeAmountCents(body.amountCents, body.amount, body.total, nested.amountCents, nested.amount, nested.total);
  const paymentData = readNestedRecord(nested.paymentData, body.paymentData, nested.pix?.paymentData, body.pix?.paymentData);
  const qrcode = readFirstPixCopyPaste(
    pix.qrcode,
    pix.qrCode,
    pix.copyPaste,
    pix.brCode,
    pix.pixCode,
    pix.emv,
    paymentData.copyPaste,
    paymentData.qrCode,
    paymentData.qrcode,
    paymentData.pixCode,
    paymentData.brCode,
    paymentData.emv,
    body.qrcode,
    body.qrCode,
    body.copyPaste,
    body.brCode,
    body.pixCode,
    body.code,
    nested.qrcode,
    nested.qrCode,
    nested.copyPaste,
    nested.brCode,
    nested.pixCode,
    nested.code,
    findPixCopyPasteInPayload(body),
  );
  const eventTimestamp = parseOptionalDate(body.timestamp, nested.timestamp, body.createdAt, nested.createdAt, paidAt?.toISOString(), refundedAt?.toISOString());
  const provider = readFirstString(body.provider, nested.provider, body.gatewayProvider, nested.gatewayProvider, gateway.provider);
  const gatewaySlug = readFirstString(body.gatewaySlug, nested.gatewaySlug, gateway.slug, routingAssignment.gatewaySlug);
  const gatewayId = readFirstString(body.gatewayId, nested.gatewayId, gateway.id, routingAssignment.gatewayId);
  const testId = readFirstString(body.testId, nested.testId, body.gatewayTestId, nested.gatewayTestId, routingAssignment.testId);
  const variantId = readFirstString(body.variantId, nested.variantId, body.gatewayVariantId, nested.gatewayVariantId, routingAssignment.variantId);
  const idempotencyKey = readFirstString(
    body.idempotencyKey,
    body.webhookId,
    body.eventId,
    nested.idempotencyKey,
    nested.webhookId,
    nested.eventId,
  ) || `pix-worker:${status}:${transactionId || appPaymentId || externalReference || "unknown"}:${eventTimestamp?.toISOString() || "no-ts"}`;

  return {
    eventName: eventName || `transaction.${status}`,
    rawStatus,
    status,
    transactionId,
    appPaymentId,
    externalReference,
    paidAt,
    refundedAt,
    eventTimestamp,
    amountCents,
    qrcode,
    provider,
    gatewaySlug,
    gatewayId,
    testId,
    variantId,
    idempotencyKey,
  };
}

function normalizeSessionAbAssignments(value: unknown): Record<string, string> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const assignments: Record<string, string> = {};
  for (const [testSlug, variantId] of Object.entries(value as Record<string, unknown>)) {
    const cleanTestSlug = String(testSlug || "").trim();
    const cleanVariantId = typeof variantId === "string" ? variantId.trim() : "";
    if (cleanTestSlug && cleanVariantId) {
      assignments[cleanTestSlug] = cleanVariantId;
    }
  }
  return assignments;
}

function filterPreviewAbAssignments(assignments: Record<string, string>, previewAssignments: Record<string, string>) {
  return Object.fromEntries(
    Object.entries(assignments).filter(([testSlug, variantId]) => previewAssignments[testSlug] !== variantId),
  );
}

function normalizeTrackableSessionAbAssignments(session: any): Record<string, string> {
  return filterPreviewAbAssignments(
    normalizeSessionAbAssignments(session?.abAssignment),
    normalizeSessionAbAssignments(session?.abPreviewAssignment),
  );
}

const ADMIN_EVENT_METADATA_ALLOWED_KEYS = new Set([
  "amountCents",
  "blackcatEvent",
  "callbackStatus",
  "cardId",
  "componentKey",
  "creditAmount",
  "externalReference",
  "hole",
  "journeyNode",
  "journeyPath",
  "lookupSource",
  "paymentId",
  "planId",
  "position",
  "provider",
  "rawStatus",
  "requestAmountCents",
  "requestId",
  "requestStatus",
  "saleEvent",
  "sexType",
  "speechType",
  "testSlug",
  "transactionId",
  "variantId",
]);

function sanitizeAdminEventMetadata(metadata: unknown): Record<string, string | number | boolean> {
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) return {};

  const sanitized: Record<string, string | number | boolean> = {};
  for (const [key, value] of Object.entries(metadata as Record<string, unknown>)) {
    if (!ADMIN_EVENT_METADATA_ALLOWED_KEYS.has(key)) continue;
    if (typeof value === "string") sanitized[key] = value.slice(0, 256);
    else if (typeof value === "number" || typeof value === "boolean") sanitized[key] = value;
  }
  return sanitized;
}

function toAdminSessionDetailsDto(session: typeof funnelSessions.$inferSelect) {
  return {
    sessionId: session.sessionId,
    userId: session.userId,
    customerName: session.customerName,
    customerEmail: session.customerEmail,
    uploadedPhotoUrl: null,
    generatedPhotoUrl: null,
    isPaid: session.isPaid,
    paidAt: session.paidAt,
    saleAmountCents: session.saleAmountCents,
    saleProvider: session.saleProvider,
    saleEvent: session.saleEvent,
    visitorFirstSeenAt: session.visitorFirstSeenAt,
    visitorLastSeenAt: session.visitorLastSeenAt,
    currentStep: session.currentStep,
    maxStepReached: session.maxStepReached,
    utmSource: session.utmSource,
    utmMedium: session.utmMedium,
    utmCampaign: session.utmCampaign,
    utmContent: session.utmContent,
    utmTerm: session.utmTerm,
  };
}

function mapPixJourneyNode(baseNode: string | null, step: "pix_generated" | "pix_paid") {
  const nodeByParent: Record<string, { generated: string; paid: string }> = {
    landing_home: { generated: "pix_generated_landing", paid: "pix_paid_landing" },
    landing_offer: { generated: "pix_generated_landing", paid: "pix_paid_landing" },
    video_loading_page: { generated: "pix_generated_video", paid: "pix_paid_video" },
    pack_loading_page: { generated: "pix_generated_pack", paid: "pix_paid_pack" },
    app_dashboard: { generated: "pix_generated_dashboard", paid: "pix_paid_dashboard" },
    app_gallery: { generated: "pix_generated_gallery", paid: "pix_paid_gallery" },
    app_settings: { generated: "pix_generated_settings", paid: "pix_paid_settings" },
    pix_tester_page: { generated: "pix_generated_tester", paid: "pix_paid_tester" },
  };
  const resolved = baseNode ? nodeByParent[baseNode] : null;
  if (resolved) return step === "pix_generated" ? resolved.generated : resolved.paid;
  return step === "pix_generated" ? "pix_generated_landing" : "pix_paid_landing";
}

function inferJourneyNode(event: {
  step: FunnelStep;
  eventName: string;
  metadata: Record<string, unknown>;
}): string | null {
  const explicitNode = sanitizeJourneyNode(event.metadata.journeyNode);
  if (explicitNode) {
    if (event.step === "pix_generated" || event.step === "pix_paid") {
      return mapPixJourneyNode(explicitNode, event.step);
    }
    return explicitNode;
  }

  const eventName = event.eventName;
  if (eventName === "landing.entered") return "landing_home";
  if (eventName === "login.entered") return "login_page";
  if (eventName === "landing.photo_uploaded") return "landing_photo_uploaded";
  if (eventName === "landing.generated_photo_viewed") return "landing_generated_photo";
  if (eventName === "landing.offer_viewed") return "landing_offer";
  if (eventName === "landing.offer_card_clicked" || eventName === "landing.pack_photos_submit" || eventName === "landing.video_pov_submit") {
    return "landing_offer_responded";
  }
  if (eventName === "video_pov.loading_screen_entered") return "video_loading_page";
  if (eventName === "video_pov.loaded") return "video_loaded_page";
  if (eventName === "pack_photos.loading_screen_entered") return "pack_loading_page";
  if (eventName === "pack_photos.loaded") return "pack_loaded_page";

  if (event.step === "pix_generated" || event.step === "pix_paid") {
    return mapPixJourneyNode(null, event.step);
  }
  if (event.step === "visitor_entered") return "landing_home";
  if (event.step === "photo_uploaded") return "landing_photo_uploaded";
  if (event.step === "generated_photo_viewed") return "landing_generated_photo";
  if (event.step === "offer_viewed") return "landing_offer";
  if (event.step === "offer_responded") return "landing_offer_responded";
  if (event.step === "video_loading_screen") return "video_loading_page";
  if (event.step === "video_loaded") return "video_loaded_page";

  return null;
}

function parseDateRange(query: any) {
  return getAppDateRangeFromQuery(query);
}

function getAdminDateRangeError(
  dateFrom: Date,
  dateTo: Date,
  maxRangeDays = ADMIN_ANALYTICS_MAX_RANGE_DAYS,
): string | null {
  const rangeMs = dateTo.getTime() - dateFrom.getTime();
  if (rangeMs < 0) {
    return "Data inicial deve ser anterior ou igual à data final.";
  }

  if (rangeMs > maxRangeDays * MS_PER_DAY) {
    return `Janela máxima permitida: ${maxRangeDays} dias.`;
  }

  return null;
}

const adminSessionIdParamSchema = z.object({
  sessionId: z.string().min(1).max(128),
});

const adminCustomerQuerySchema = z.object({
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(1).max(100).optional().default(20),
  search: z.string().optional().default(""),
  paymentStatus: z.enum(["paid", "unpaid", "all"]).optional().default("all"),
  leadStage: z.enum(["all", "photo_generated", "generation_error", "first_screen"]).optional().default("all"),
  responseKind: z.enum(ADMIN_CUSTOMER_RESPONSE_KINDS).optional(),
  pixProduct: z.enum(ADMIN_PIX_PRODUCT_KEYS).optional(),
  sortBy: z.enum(ADMIN_CUSTOMER_SORT_FIELDS).optional(),
  sortDir: z.enum(ADMIN_CUSTOMER_SORT_DIRECTIONS).optional(),
});

const adminResponseQuerySchema = z.object({
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(1).max(100).optional().default(20),
  search: z.string().trim().max(256).optional().default(""),
  paymentStatus: z.enum(["paid", "unpaid", "all"]).optional().default("all"),
});

const adminRealPreviewLogsQuerySchema = z.object({
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(1).max(50).optional().default(20),
  search: z.string().trim().max(256).optional().default(""),
});

function requireAdminAuth(req: any, res: any, next: any) {
  const session = req.session as any;
  if (session?.adminAuthenticated === true) return next();
  return res.status(401).json({ message: "Não autenticado como admin" });
}

function requireCallerAuth(req: any, res: any, next: any) {
  const session = req.session as any;
  if (session?.callerAuthenticated === true) return next();
  return res.status(401).json({ message: "Não autenticado como caller" });
}

function regenerateSession(req: any): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    req.session.regenerate((err: any) => (err ? reject(err) : resolve()));
  });
}

function saveSession(req: any): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    req.session.save((err: any) => (err ? reject(err) : resolve()));
  });
}

function destroySession(req: any): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    req.session.destroy((err: any) => (err ? reject(err) : resolve()));
  });
}

function firstHeaderValue(value: unknown): string {
  if (Array.isArray(value)) return String(value[0] || "");
  return String(value || "");
}

function normalizeOrigin(value: string | null | undefined): string | null {
  const trimmed = String(value || "").trim();
  if (!trimmed || trimmed === "null") return null;

  try {
    return new URL(trimmed).origin.toLowerCase();
  } catch {
    return null;
  }
}

function originsFromPublicDomain(value: string | undefined): string[] {
  const trimmed = String(value || "").trim().replace(/\/+$/, "");
  if (!trimmed) return [];
  if (/^https?:\/\//i.test(trimmed)) {
    const origin = normalizeOrigin(trimmed);
    return origin ? [origin] : [];
  }
  return [`https://${trimmed}`.toLowerCase(), `http://${trimmed}`.toLowerCase()];
}

function getExpectedRequestOrigins(req: any): Set<string> {
  const forwardedProto = firstHeaderValue(req.headers["x-forwarded-proto"]).split(",")[0].trim();
  const forwardedHost = firstHeaderValue(req.headers["x-forwarded-host"]).split(",")[0].trim();
  const protocol = forwardedProto || req.protocol || "https";
  const host = forwardedHost || firstHeaderValue(req.headers.host);
  const origins = new Set<string>();

  const requestOrigin = normalizeOrigin(host ? `${protocol}://${host}` : null);
  if (requestOrigin) origins.add(requestOrigin);
  for (const origin of originsFromPublicDomain(process.env.PUBLIC_DOMAIN)) {
    origins.add(origin);
  }
  for (const origin of String(process.env.ADMIN_ALLOWED_ORIGINS || "").split(",")) {
    const normalized = normalizeOrigin(origin);
    if (normalized) origins.add(normalized);
  }
  return origins;
}

function requireSameOriginAdminMutation(req: any, res: any, next: any) {
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) return next();

  const requestOrigin =
    normalizeOrigin(firstHeaderValue(req.headers.origin)) ||
    normalizeOrigin(firstHeaderValue(req.headers.referer));
  const allowedOrigins = getExpectedRequestOrigins(req);

  if (requestOrigin && allowedOrigins.has(requestOrigin)) return next();

  console.warn("[admin-csrf] Mutating admin request rejected", {
    method: req.method,
    path: req.path,
    hasOrigin: Boolean(req.headers.origin),
    hasReferer: Boolean(req.headers.referer),
    requestOrigin,
    allowedOrigins: Array.from(allowedOrigins),
  });
  return res.status(403).json({ message: "Origem inválida para ação administrativa" });
}

function toAdminGeneratedPhotoUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  const match = url.match(/^\/api\/generated-images\/([^/]+)\/image$/);
  if (!match) return url;
  return `/api/admin/generated-images/${match[1]}/image`;
}

// ── KIE API task helper ─────────────────────────────────────────────
function getImageWebhookSecret() {
  return (process.env.KIE_WEBHOOK_SECRET || process.env.KIE_API_KEY || "").trim();
}

function signImageWebhookToken(imageId: string) {
  const secret = getImageWebhookSecret();
  if (!secret) return "";
  return crypto.createHmac("sha256", secret).update(imageId).digest("hex");
}

function verifyImageWebhookToken(req: any, imageId: string) {
  const expected = signImageWebhookToken(imageId);
  if (!expected) return false;

  const rawHeader = req.headers["x-image-webhook-token"];
  const headerToken = Array.isArray(rawHeader) ? rawHeader[0] : rawHeader;
  const provided = String(req.query?.token || headerToken || "").trim();
  if (!provided || provided.length !== expected.length) return false;

  try {
    return crypto.timingSafeEqual(Buffer.from(provided, "hex"), Buffer.from(expected, "hex"));
  } catch {
    return false;
  }
}

function readKieCallbackTaskId(callbackData: any) {
  return String(
    callbackData?.data?.taskId
      ?? callbackData?.data?.task_id
      ?? callbackData?.taskId
      ?? callbackData?.task_id
      ?? "",
  ).trim();
}

const callKieTask = async (modelName: string, input: any, callbackUrl: string, apiKey: string): Promise<any> => {
  const payload = { model: modelName, input: { ...input, nsfw_checker: false }, callBackUrl: callbackUrl };
  console.log(`[KIE] Calling model=${modelName}, callbackConfigured=${Boolean(callbackUrl)}`);
  const resp = await fetch("https://api.kie.ai/api/v1/jobs/createTask", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify(payload),
  });
  let data: any;
  try { data = JSON.parse(await resp.text()); } catch {
    throw new Error(`KIE API returned non-JSON response (HTTP ${resp.status})`);
  }
  console.log("[KIE] Task response", {
    modelName,
    httpStatus: resp.status,
    code: data?.code ?? null,
    hasTaskId: Boolean(data?.data?.taskId),
  });
  return data;
};

// ── Image polling (fallback if webhook missed) ───────────────────────
function startImagePolling(imageId: string, taskId: string, apiKey: string) {
  const MAX_POLLS = 40; // 10 minutes at 15s intervals
  const POLL_INTERVAL_MS = 15000;
  let pollCount = 0;

  const poll = async () => {
    pollCount++;
    try {
      const image = await storage.getGeneratedImage(imageId);
      if (!image || image.status === "completed" || image.status === "failed") return;

      const response = await fetch(`https://api.kie.ai/api/v1/jobs/recordInfo?taskId=${taskId}`, {
        method: "GET",
        headers: { Authorization: `Bearer ${apiKey}` },
      });

      let data: any;
      try { data = JSON.parse(await response.text()); } catch {
        if (pollCount < MAX_POLLS) setTimeout(poll, POLL_INTERVAL_MS);
        return;
      }

      if (data.code !== 200 || !data.data) {
        if (pollCount < MAX_POLLS) setTimeout(poll, POLL_INTERVAL_MS);
        return;
      }

      const taskData = data.data;

      if (taskData.state === "success" && taskData.resultJson) {
        let resultUrls: string[] = [];
        try {
          const parsed = typeof taskData.resultJson === "string" ? JSON.parse(taskData.resultJson) : taskData.resultJson;
          resultUrls = parsed.resultUrls || [];
        } catch { }

        if (resultUrls.length > 0 && isAllowedGeneratedMediaUrl(resultUrls[0])) {
          const completion = await storage.completeGeneratedImageIfActive(imageId, resultUrls[0], new Date());
          if (completion.transitioned && completion.image) {
            notifyImageCompleted(completion.image.userId, completion.image);
          }
        } else if (resultUrls.length > 0) {
          console.warn("[ImagePoll] Ignoring generated media URL outside allowlist", { imageId });
          const failMsg = "URL de mídia não permitida";
          const failure = await storage.failGeneratedImageAndRefundIfActive(imageId, failMsg, `Reembolso: ${failMsg}`);
          if (failure.transitioned) {
            if (failure.freeSessionId) releaseFreeGenerationSessionAttempt(failure.freeSessionId);
            if (failure.image) notifyImageFailed(failure.image.userId, failure.image);
          }
        }
        return;
      }

      if (taskData.state === "fail") {
        const failMsg = taskData.failMsg || "Falha na geração de imagem";
        const failure = await storage.failGeneratedImageAndRefundIfActive(
          imageId,
          failMsg,
          "Reembolso: falha na geração de imagem"
        );
        if (failure.transitioned) {
          if (failure.freeSessionId) releaseFreeGenerationSessionAttempt(failure.freeSessionId);
          if (failure.image) notifyImageFailed(failure.image.userId, failure.image);
        }
        return;
      }

      if (pollCount < MAX_POLLS) {
        setTimeout(poll, POLL_INTERVAL_MS);
      } else {
        const failure = await storage.failGeneratedImageAndRefundIfActive(
          imageId,
          "Tempo limite excedido",
          "Reembolso: timeout na geração de imagem"
        );
        if (failure.transitioned) {
          if (failure.freeSessionId) releaseFreeGenerationSessionAttempt(failure.freeSessionId);
          if (failure.image) notifyImageFailed(failure.image.userId, failure.image);
        }
      }
    } catch (error) {
      console.error(`[ImagePoll] Exception (poll ${pollCount}):`, error);
      if (pollCount < MAX_POLLS) setTimeout(poll, POLL_INTERVAL_MS);
    }
  };

  // Start polling after 1 minute (60000ms)
  setTimeout(poll, 60000);
}

// ── Register routes ──────────────────────────────────────────────────
export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  await setupSession(app);

  // A/B test split: must run after session is set up but before any static
  // route or SPA handler so the variant is assigned before the page loads.
  app.use(abTestingMiddleware);

  // Serve static uploads
  app.use("/uploads", express.static(PERSISTENT_UPLOAD_DIR));
  app.use("/api/admin", requireSameOriginAdminMutation);

  async function trackFunnelStep(
    req: any,
    payload: {
      step: FunnelStep;
      eventName?: string;
      idempotencyKey?: string;
      metadata?: Record<string, unknown>;
      customerName?: string | null;
      customerEmail?: string | null;
      uploadedPhotoUrl?: string | null;
      generatedPhotoUrl?: string | null;
      utm_source?: string | null;
      utm_medium?: string | null;
      utm_campaign?: string | null;
      utm_content?: string | null;
      utm_term?: string | null;
      isPaid?: boolean;
      paidAt?: Date | null;
      saleAmountCents?: number | null;
      saleTransactionId?: string | null;
      saleProvider?: string | null;
      saleEvent?: string | null;
    }
  ) {
    const sessionId = getSessionId(req);
    const userId = (req?.session as any)?.userId || null;
    const metadata = { ...(payload.metadata || {}) } as Record<string, unknown>;

    await storage.upsertFunnelSession({
      sessionId,
      userId,
      step: payload.step,
      customerName: payload.customerName,
      customerEmail: payload.customerEmail,
      uploadedPhotoUrl: payload.uploadedPhotoUrl,
      generatedPhotoUrl: payload.generatedPhotoUrl,
      utmSource: payload.utm_source,
      utmMedium: payload.utm_medium,
      utmCampaign: payload.utm_campaign,
      utmContent: payload.utm_content,
      utmTerm: payload.utm_term,
      isPaid: payload.isPaid,
      paidAt: payload.paidAt,
      saleAmountCents: payload.saleAmountCents,
      saleTransactionId: payload.saleTransactionId,
      saleProvider: payload.saleProvider,
      saleEvent: payload.saleEvent,
    });
    const createdEvent = await storage.createFunnelEvent({
      sessionId,
      userId,
      step: payload.step,
      eventName: payload.eventName || payload.step,
      idempotencyKey: payload.idempotencyKey || null,
      metadata,
    });
    if (!createdEvent && payload.idempotencyKey) {
      console.warn("[funnel-events] Event deduplicated by idempotency key", {
        sessionId,
        step: payload.step,
        idempotencyKey: payload.idempotencyKey,
      });
    }
  }

  async function resolvePixPaymentAttributionSessionId(payment: PixPayment, fallbackSessionId?: string | null): Promise<string | null> {
    let attributionSessionId: string | null = payment.sessionId ?? fallbackSessionId ?? null;
    if (attributionSessionId) return attributionSessionId;

    const [latestSession] = await db
      .select({ sessionId: funnelSessions.sessionId })
      .from(funnelSessions)
      .where(eq(funnelSessions.userId, payment.userId))
      .orderBy(sql`${funnelSessions.visitorLastSeenAt} desc`)
      .limit(1);
    attributionSessionId = latestSession?.sessionId ?? null;

    if (attributionSessionId) {
      console.warn("[PIX] Falling back to latest-session attribution", {
        paymentId: payment.id,
        userId: payment.userId,
        attributionSessionId,
      });
    }

    return attributionSessionId;
  }

  async function findPixPaymentForWorkerEvent({
    appPaymentId,
    transactionId,
    externalReference,
    allowExternalReferenceFallback = true,
  }: {
    appPaymentId?: string | null;
    transactionId?: string | null;
    externalReference?: string | null;
    allowExternalReferenceFallback?: boolean;
  }): Promise<{ payment?: PixPayment; source: "app_payment_id" | "pix_abacate_id" | "external_reference" | "none" }> {
    const cleanAppPaymentId = String(appPaymentId || "").trim();
    if (cleanAppPaymentId) {
      const payment = await storage.getPixPayment(cleanAppPaymentId);
      if (payment) return { payment, source: "app_payment_id" };
    }

    const cleanTransactionId = String(transactionId || "").trim();
    if (cleanTransactionId) {
      const paymentByPixId = await storage.getPixPaymentByAbacateId(cleanTransactionId);
      if (paymentByPixId) return { payment: paymentByPixId, source: "pix_abacate_id" };
    }

    const cleanExternalReference = String(externalReference || "").trim();
    if (allowExternalReferenceFallback && cleanExternalReference) {
      const [row] = await db
        .select()
        .from(pixPayments)
        .where(eq(pixPayments.externalReference, cleanExternalReference))
        .orderBy(desc(pixPayments.createdAt))
        .limit(1);
      if (row) return { payment: row, source: "external_reference" };
    }

    return { source: "none" };
  }

  async function resolvePixPaymentJourneyNode(payment: PixPayment, externalReference?: string | null): Promise<string | null> {
    const parsedExternal = parseExternalReference(externalReference || payment.externalReference || "");
    if (parsedExternal.journeyNode) return parsedExternal.journeyNode;
    return null;
  }

  async function confirmPendingPixPaymentAtomically(paymentId: string, confirmedAt: Date): Promise<{
    payment: PixPayment;
    alreadyPaid: boolean;
    oldBalance: number | null;
    newBalance: number | null;
    revealDebit: number;
  }> {
    return await db.transaction(async (tx) => {
      const [lockedPayment] = await tx
        .select()
        .from(pixPayments)
        .where(eq(pixPayments.id, paymentId))
        .for("update")
        .limit(1);

      if (!lockedPayment) {
        throw new Error(`PIX payment not found: ${paymentId}`);
      }

      if (["paid", "refunded", "chargedback"].includes(lockedPayment.status)) {
        return {
          payment: lockedPayment,
          alreadyPaid: true,
          oldBalance: null,
          newBalance: null,
          revealDebit: 0,
        };
      }

      let [credits] = await tx
        .select()
        .from(userCredits)
        .where(eq(userCredits.userId, lockedPayment.userId))
        .for("update")
        .limit(1);

      if (!credits) {
        await tx
          .insert(userCredits)
          .values({ userId: lockedPayment.userId, balance: 0 })
          .onConflictDoNothing({ target: userCredits.userId });

        [credits] = await tx
          .select()
          .from(userCredits)
          .where(eq(userCredits.userId, lockedPayment.userId))
          .for("update")
          .limit(1);

        if (!credits) {
          throw new Error("Falha ao criar carteira de créditos");
        }
      }

      const oldBalance = credits.balance;
      const revealDebit = Math.min(1, Math.max(0, oldBalance + lockedPayment.creditAmount));
      const dailyAccumulated = credits.dailyCreditsAccumulated || 0;
      const dailyToConsume = Math.min(dailyAccumulated, revealDebit);
      const newBalance = oldBalance + lockedPayment.creditAmount - revealDebit;

      await tx
        .update(pixPayments)
        .set({
          status: "paid",
          paidAt: confirmedAt,
          lastEvent: "pix.payment_confirmed",
          lastEventAt: confirmedAt,
        })
        .where(eq(pixPayments.id, lockedPayment.id));

      await tx
        .update(userCredits)
        .set({
          balance: newBalance,
          totalPurchased: credits.totalPurchased + lockedPayment.creditAmount,
          totalSpent: credits.totalSpent + revealDebit,
          dailyCreditsAccumulated: dailyAccumulated - dailyToConsume,
          updatedAt: confirmedAt,
        })
        .where(eq(userCredits.id, credits.id));

      if (revealDebit > 0) {
        await tx.insert(creditTransactions).values({
          userId: lockedPayment.userId,
          amount: -revealDebit,
          type: "image_reveal",
          description: "Desborrar imagem após pagamento PIX",
        });
      }

      await tx.update(generatedImages)
        .set({ revealedAt: confirmedAt })
        .where(eq(generatedImages.userId, lockedPayment.userId));

      await tx.update(users)
        .set({ role: "user" })
        .where(eq(users.id, lockedPayment.userId));

      return {
        payment: {
          ...lockedPayment,
          status: "paid",
          paidAt: confirmedAt,
        },
        alreadyPaid: false,
        oldBalance,
        newBalance,
        revealDebit,
      };
    });
  }

  async function confirmPixPaymentFromCallback({
    payment,
    transactionId,
    provider,
    saleEvent,
    paidAt,
    externalReference,
    callbackMetadata = {},
    fallbackSessionId = null,
  }: {
    payment: PixPayment;
    transactionId: string;
    provider: "pix-worker";
    saleEvent: string;
    paidAt?: Date | null;
    externalReference?: string | null;
    callbackMetadata?: Record<string, unknown>;
    fallbackSessionId?: string | null;
  }): Promise<{
    alreadyPaid: boolean;
    attributionSessionId: string | null;
    ab: { attempted: number; inserted: number; variantIds: string[]; source: "payment" | "session" | "none" };
  }> {
    const confirmedAt = paidAt && !Number.isNaN(paidAt.getTime()) ? paidAt : new Date();
    const confirmation = await confirmPendingPixPaymentAtomically(payment.id, confirmedAt);
    const confirmedPayment = confirmation.payment;
    const alreadyPaid = confirmation.alreadyPaid;

    if (!alreadyPaid) {
      notifyPixPaid(confirmedPayment.userId, {
        paymentId: confirmedPayment.id,
        creditAmount: confirmedPayment.creditAmount,
        status: "paid",
      });

      console.log(
        `[PIX] Payment confirmed — provider=${provider}`,
        `| transactionId=${transactionId}`,
        `| paymentId=${confirmedPayment.id}`,
        `| userId=${confirmedPayment.userId}`,
        `| amountCents=${confirmedPayment.amountCents}`,
        `| creditAmount=${confirmedPayment.creditAmount}`,
        `| oldBalance=${confirmation.oldBalance}`,
        `| newBalance=${confirmation.newBalance} (after -${confirmation.revealDebit} reveal debit)`,
      );
      console.log(`[PIX Audit] provider=${provider} userId=${confirmedPayment.userId} paymentId=${confirmedPayment.id} credited=${confirmedPayment.creditAmount} debited=${confirmation.revealDebit} oldBalance=${confirmation.oldBalance} newBalance=${confirmation.newBalance}`);
    } else {
      console.log(`[PIX] Payment ${transactionId} already marked as paid; reconciling funnel and A/B attribution.`);
    }

    const attributionSessionId = await resolvePixPaymentAttributionSessionId(confirmedPayment, fallbackSessionId);
    const attributionJourneyNode = mapPaymentJourneyNodeForStep(
      await resolvePixPaymentJourneyNode(confirmedPayment, externalReference),
      "pix_paid",
    );
    if (attributionSessionId) {
      await storage.upsertFunnelSession({
        sessionId: attributionSessionId,
        userId: confirmedPayment.userId,
        step: "pix_paid",
        isPaid: true,
        paidAt: confirmedAt,
        saleAmountCents: confirmedPayment.amountCents,
        saleTransactionId: transactionId,
        saleProvider: provider,
        saleEvent,
      });
      await storage.createFunnelEvent({
        sessionId: attributionSessionId,
        userId: confirmedPayment.userId,
        step: "pix_paid",
        eventName: "pix.payment_confirmed",
        idempotencyKey: `pix_paid:${provider}:${transactionId}`,
        metadata: {
          transactionId,
          paymentId: confirmedPayment.id,
          amountCents: confirmedPayment.amountCents,
          provider,
          saleEvent,
          externalReference: externalReference ?? confirmedPayment.externalReference ?? null,
          ...callbackMetadata,
          journeyNode: attributionJourneyNode,
        },
      });
    }

    const ab = await storage.recordAbConversionsForAssignments({
      assignments: confirmedPayment.abAssignments,
      sessionId: attributionSessionId ?? confirmedPayment.sessionId ?? null,
      transactionId,
      amountCents: confirmedPayment.amountCents,
      externalReference: externalReference ?? confirmedPayment.externalReference ?? null,
    });

    if (ab.attempted > 0) {
      console.log("[PIX] A/B conversions reconciled", {
        provider,
        transactionId,
        attempted: ab.attempted,
        inserted: ab.inserted,
        source: ab.source,
        variantIds: ab.variantIds,
      });
    }

    return { alreadyPaid, attributionSessionId, ab };
  }

  async function applyPixPaymentReversalFromCallback({
    payment,
    transactionId,
    reversalStatus,
    saleEvent,
    reversedAt,
    externalReference,
    callbackMetadata = {},
  }: {
    payment: PixPayment;
    transactionId: string;
    reversalStatus: "refunded" | "chargedback";
    saleEvent: string;
    reversedAt?: Date | null;
    externalReference?: string | null;
    callbackMetadata?: Record<string, unknown>;
  }): Promise<{ alreadyReversed: boolean; revokedCredits: number; unrecoveredCredits: number }> {
    const occurredAt = reversedAt && !Number.isNaN(reversedAt.getTime()) ? reversedAt : new Date();

    const result = await db.transaction(async (tx) => {
      const [lockedPayment] = await tx
        .select()
        .from(pixPayments)
        .where(eq(pixPayments.id, payment.id))
        .for("update")
        .limit(1);

      if (!lockedPayment) {
        throw new Error(`PIX payment not found: ${payment.id}`);
      }

      if (lockedPayment.status === "refunded" || lockedPayment.status === "chargedback") {
        return { payment: lockedPayment, alreadyReversed: true, revokedCredits: 0, unrecoveredCredits: 0 };
      }

      let revokedCredits = 0;
      let unrecoveredCredits = 0;
      if (lockedPayment.status === "paid") {
        let [credits] = await tx
          .select()
          .from(userCredits)
          .where(eq(userCredits.userId, lockedPayment.userId))
          .for("update")
          .limit(1);

        if (!credits) {
          await tx
            .insert(userCredits)
            .values({ userId: lockedPayment.userId, balance: 0 })
            .onConflictDoNothing({ target: userCredits.userId });

          [credits] = await tx
            .select()
            .from(userCredits)
            .where(eq(userCredits.userId, lockedPayment.userId))
            .for("update")
            .limit(1);

          if (!credits) {
            throw new Error("Falha ao criar carteira de créditos");
          }
        }

        revokedCredits = Math.min(Math.max(credits.balance, 0), lockedPayment.creditAmount);
        unrecoveredCredits = Math.max(0, lockedPayment.creditAmount - revokedCredits);

        await tx
          .update(userCredits)
          .set({
            balance: credits.balance - revokedCredits,
            totalPurchased: sql`greatest(0, ${userCredits.totalPurchased} - ${lockedPayment.creditAmount})`,
            updatedAt: occurredAt,
          })
          .where(eq(userCredits.id, credits.id));

        await tx.insert(creditTransactions).values({
          userId: lockedPayment.userId,
          amount: -revokedCredits,
          type: reversalStatus === "chargedback" ? "payment_chargeback" : "payment_refund",
          description: `${reversalStatus === "chargedback" ? "Chargeback" : "Reembolso"} PIX ${transactionId}`,
        });
      }

      const [updatedPayment] = await tx
        .update(pixPayments)
        .set({
          status: reversalStatus,
          refundedAt: occurredAt,
          lastEvent: saleEvent,
          lastEventAt: occurredAt,
        })
        .where(eq(pixPayments.id, lockedPayment.id))
        .returning();

      return {
        payment: updatedPayment ?? { ...lockedPayment, status: reversalStatus, refundedAt: occurredAt },
        alreadyReversed: false,
        revokedCredits,
        unrecoveredCredits,
      };
    });

    const attributionSessionId = await resolvePixPaymentAttributionSessionId(result.payment);
    if (attributionSessionId) {
      await storage.upsertFunnelSession({
        sessionId: attributionSessionId,
        userId: result.payment.userId,
        isPaid: false,
        saleAmountCents: result.payment.amountCents,
        saleTransactionId: transactionId,
        saleProvider: "pix-worker",
        saleEvent,
      });
    }

    posthogCapture({
      distinctId: attributionSessionId || result.payment.userId || transactionId,
      event: reversalStatus === "chargedback" ? "pix_chargeback" : "pix_refunded",
      properties: {
        transaction_id: transactionId,
        payment_id: result.payment.id,
        amount_cents: result.payment.amountCents,
        revoked_credits: result.revokedCredits,
        unrecovered_credits: result.unrecoveredCredits,
        external_reference: externalReference ?? result.payment.externalReference ?? null,
        ...callbackMetadata,
      },
    });

    if (result.unrecoveredCredits > 0) {
      console.warn("[PIX] Reversal could not revoke all credits", {
        paymentId: result.payment.id,
        transactionId,
        reversalStatus,
        revokedCredits: result.revokedCredits,
        unrecoveredCredits: result.unrecoveredCredits,
      });
    }

    return {
      alreadyReversed: result.alreadyReversed,
      revokedCredits: result.revokedCredits,
      unrecoveredCredits: result.unrecoveredCredits,
    };
  }

  type WorkerGatewayTransactionStatus = "pending" | "paid" | "failed" | "expired" | "cancelled" | "refunded" | "chargedback";

  function mapWorkerEventToGatewayTransactionStatus(event: NormalizedWorkerPaymentEvent): WorkerGatewayTransactionStatus {
    if (event.status === "paid") return "paid";
    if (event.status === "refunded") return "refunded";
    if (event.status === "chargedback") return "chargedback";
    if (event.status === "failed") return "failed";
    if (event.status === "expired") return "expired";
    if (event.status === "cancelled") return "cancelled";
    return "pending";
  }

  function isTerminalWorkerGatewayStatus(status: WorkerGatewayTransactionStatus): boolean {
    return status === "paid" || status === "refunded" || status === "chargedback";
  }

  function resolveMonotonicWorkerGatewayStatus(
    current: WorkerGatewayTransactionStatus,
    incoming: WorkerGatewayTransactionStatus,
  ): WorkerGatewayTransactionStatus {
    if (current === "chargedback") return current;
    if (current === "refunded") return incoming === "chargedback" ? "chargedback" : current;
    if (current === "paid" && !isTerminalWorkerGatewayStatus(incoming)) return current;
    if (incoming === "refunded" || incoming === "chargedback") return incoming;
    if (incoming === "paid") return "paid";
    if (current === "expired" || current === "cancelled") {
      return incoming === "pending" || incoming === "failed" ? current : incoming;
    }
    return incoming;
  }

  async function resolveWorkerGatewayReference(event: NormalizedWorkerPaymentEvent) {
    let gateway: PaymentGateway | null = null;
    if (event.gatewayId) {
      const [row] = await db.select().from(paymentGateways).where(eq(paymentGateways.id, event.gatewayId)).limit(1);
      gateway = row ?? null;
    }
    if (!gateway && event.gatewaySlug) {
      const [row] = await db.select().from(paymentGateways).where(eq(paymentGateways.slug, event.gatewaySlug)).limit(1);
      gateway = row ?? null;
    }

    let variant: PaymentGatewayTestVariant | null = null;
    if (event.variantId) {
      const [row] = await db.select().from(paymentGatewayTestVariants).where(eq(paymentGatewayTestVariants.id, event.variantId)).limit(1);
      variant = row ?? null;
    }

    return {
      gatewayId: gateway?.id ?? null,
      testId: variant?.testId ?? event.testId ?? null,
      variantId: variant?.id ?? null,
      provider: event.provider || gateway?.provider || "pix-worker",
    };
  }

  async function upsertWorkerGatewayTransaction(
    payment: PixPayment,
    event: NormalizedWorkerPaymentEvent,
    redactedPayload: Record<string, unknown>,
  ) {
    const transactionId = event.transactionId || payment.abacatePayId;
    const gatewayReference = await resolveWorkerGatewayReference(event);
    const incomingStatus = mapWorkerEventToGatewayTransactionStatus(event);
    const externalReference = event.externalReference || payment.externalReference || `dai_${payment.id}`;
    const paidAt = event.paidAt && !Number.isNaN(event.paidAt.getTime())
      ? event.paidAt
      : incomingStatus === "paid"
        ? event.eventTimestamp ?? new Date()
        : undefined;
    const refundedAt = event.refundedAt && !Number.isNaN(event.refundedAt.getTime())
      ? event.refundedAt
      : (incomingStatus === "refunded" || incomingStatus === "chargedback")
        ? event.eventTimestamp ?? new Date()
        : undefined;

    const [existing] = await db
      .select()
      .from(paymentGatewayTransactions)
      .where(eq(paymentGatewayTransactions.pixPaymentId, payment.id))
      .limit(1);

    const baseData: Partial<typeof paymentGatewayTransactions.$inferInsert> = {
      gatewayId: gatewayReference.gatewayId,
      testId: gatewayReference.testId,
      variantId: gatewayReference.variantId,
      provider: gatewayReference.provider,
      providerTransactionId: transactionId || null,
      externalReference,
      status: incomingStatus,
      amountCents: event.amountCents ?? payment.amountCents,
      responsePayload: redactedPayload,
      lastEvent: event.eventName,
      ...(paidAt ? { paidAt } : {}),
      ...(refundedAt ? { refundedAt } : {}),
      updatedAt: new Date(),
    };

    if (existing) {
      const status = resolveMonotonicWorkerGatewayStatus(
        existing.status as WorkerGatewayTransactionStatus,
        incomingStatus,
      );
      await db
        .update(paymentGatewayTransactions)
        .set({ ...baseData, status })
        .where(eq(paymentGatewayTransactions.id, existing.id));
      return;
    }

    try {
      const insertData: typeof paymentGatewayTransactions.$inferInsert = {
        pixPaymentId: payment.id,
        gatewayId: gatewayReference.gatewayId,
        testId: gatewayReference.testId,
        variantId: gatewayReference.variantId,
        provider: gatewayReference.provider,
        providerTransactionId: transactionId || null,
        externalReference,
        status: incomingStatus,
        amountCents: event.amountCents ?? payment.amountCents,
        planId: null,
        journeyNode: sanitizeJourneyNode(parseExternalReference(externalReference).journeyNode),
        requestPayload: null,
        responsePayload: redactedPayload,
        lastEvent: event.eventName,
        ...(paidAt ? { paidAt } : {}),
        ...(refundedAt ? { refundedAt } : {}),
        updatedAt: new Date(),
      };
      await db.insert(paymentGatewayTransactions).values(insertData);
    } catch (error: any) {
      if (error?.code === "23505") {
        const [conflicting] = await db
          .select()
          .from(paymentGatewayTransactions)
          .where(and(
            eq(paymentGatewayTransactions.provider, gatewayReference.provider),
            eq(paymentGatewayTransactions.providerTransactionId, transactionId),
          ))
          .limit(1);
        const status = conflicting
          ? resolveMonotonicWorkerGatewayStatus(conflicting.status as WorkerGatewayTransactionStatus, incomingStatus)
          : incomingStatus;
        await db
          .update(paymentGatewayTransactions)
          .set({ ...baseData, status })
          .where(and(
            eq(paymentGatewayTransactions.provider, gatewayReference.provider),
            eq(paymentGatewayTransactions.providerTransactionId, transactionId),
          ));
        return;
      }
      throw error;
    }
  }

  function mapPaymentJourneyNodeForStep(baseNode: string | null, step: "pix_generated" | "pix_paid"): string | null {
    if (!baseNode) return null;
    if (baseNode.startsWith("pix_generated_") || baseNode.startsWith("pix_paid_")) return baseNode;
    return mapPixJourneyNode(baseNode, step);
  }

  app.post("/api/admin/login", async (req: any, res) => {
    try {
      const config = getPrivilegedConfig("admin");
      if (!config.isConfigured) {
        return res.status(503).json({ message: "Login administrativo não configurado no servidor" });
      }

      const lockoutRemainingMs = getPrivilegedLockoutRemainingMs("admin", req);
      if (lockoutRemainingMs > 0) {
        res.setHeader("Retry-After", String(Math.ceil(lockoutRemainingMs / 1000)));
        return res.status(429).json({ message: `Muitas tentativas. Tente novamente em ${formatRetryDelayMs(lockoutRemainingMs)}.` });
      }

      const username = String(req.body?.username || "");
      const password = String(req.body?.password || "");

      const isValidUser = safeStringEqual(username, config.username);
      const isValidPassword = comparePrivilegedPassword(password, isValidUser ? config.passwordHash : dummyPrivilegedPasswordHash);

      if (!(isValidUser && isValidPassword)) {
        const retryAfterMs = registerPrivilegedLoginFailure("admin", req);
        if (retryAfterMs > 0) {
          res.setHeader("Retry-After", String(Math.ceil(retryAfterMs / 1000)));
          return res.status(429).json({ message: `Muitas tentativas. Tente novamente em ${formatRetryDelayMs(retryAfterMs)}.` });
        }
        return res.status(401).json({ message: "Credenciais inválidas" });
      }

      clearPrivilegedLoginFailures("admin", req);
      await regenerateSession(req);

      (req.session as any).callerAuthenticated = false;
      (req.session as any).callerUsername = null;
      (req.session as any).adminAuthenticated = true;
      (req.session as any).adminUsername = config.username;
      await saveSession(req);

      return res.json({ success: true, username: config.username });
    } catch (error) {
      console.error("[admin-login] Error:", error);
      return res.status(500).json({ message: "Erro ao fazer login admin" });
    }
  });

  app.post("/api/admin/logout", requireAdminAuth, async (req: any, res) => {
    try {
      await destroySession(req);
      res.clearCookie("connect.sid");
      res.json({ success: true });
    } catch (error) {
      console.error("[admin-logout] Error:", error);
      res.status(500).json({ message: "Erro ao sair do admin" });
    }
  });

  app.get("/api/admin/me", (req: any, res) => {
    const isAdmin = (req.session as any)?.adminAuthenticated === true;
    if (!isAdmin) return res.status(401).json({ message: "Não autenticado" });
    return res.json({
      authenticated: true,
      username: (req.session as any)?.adminUsername || null,
    });
  });

  // ── Caller auth block ──────────────────────────────────────────────────────
  app.post("/api/caller/login", async (req: any, res) => {
    try {
      const config = getPrivilegedConfig("caller");
      if (!config.isConfigured) {
        return res.status(503).json({ message: "Login de caller não configurado no servidor" });
      }

      const lockoutRemainingMs = getPrivilegedLockoutRemainingMs("caller", req);
      if (lockoutRemainingMs > 0) {
        res.setHeader("Retry-After", String(Math.ceil(lockoutRemainingMs / 1000)));
        return res.status(429).json({ message: `Muitas tentativas. Tente novamente em ${formatRetryDelayMs(lockoutRemainingMs)}.` });
      }

      const username = String(req.body?.username || "");
      const password = String(req.body?.password || "");

      const isValidUser = safeStringEqual(username, config.username);
      const isValidPassword = comparePrivilegedPassword(password, isValidUser ? config.passwordHash : dummyPrivilegedPasswordHash);

      if (!(isValidUser && isValidPassword)) {
        const retryAfterMs = registerPrivilegedLoginFailure("caller", req);
        if (retryAfterMs > 0) {
          res.setHeader("Retry-After", String(Math.ceil(retryAfterMs / 1000)));
          return res.status(429).json({ message: `Muitas tentativas. Tente novamente em ${formatRetryDelayMs(retryAfterMs)}.` });
        }
        return res.status(401).json({ message: "Credenciais inválidas" });
      }

      clearPrivilegedLoginFailures("caller", req);
      await regenerateSession(req);

      (req.session as any).adminAuthenticated = false;
      (req.session as any).adminUsername = null;
      (req.session as any).callerAuthenticated = true;
      (req.session as any).callerUsername = config.username;
      await saveSession(req);

      return res.json({ success: true, username: config.username });
    } catch (error) {
      console.error("[caller-login] Error:", error);
      return res.status(500).json({ message: "Erro ao fazer login caller" });
    }
  });

  app.post("/api/caller/logout", requireCallerAuth, async (req: any, res) => {
    try {
      await destroySession(req);
      res.clearCookie("connect.sid");
      res.json({ success: true });
    } catch (error) {
      console.error("[caller-logout] Error:", error);
      res.status(500).json({ message: "Erro ao sair do caller" });
    }
  });

  app.get("/api/caller/me", (req: any, res) => {
    const isCaller = (req.session as any)?.callerAuthenticated === true;
    if (!isCaller) return res.status(401).json({ message: "Não autenticado" });
    return res.json({
      authenticated: true,
      username: (req.session as any)?.callerUsername || null,
    });
  });

  app.get("/api/caller/customers", requireCallerAuth, async (req: any, res) => {
    try {
      const { dateFrom, dateTo } = parseDateRange(req.query);
      const page = Math.max(1, Number(req.query?.page || 1));
      const pageSize = Math.min(100, Math.max(1, Number(req.query?.pageSize || 20)));
      const paymentStatus = String(req.query?.paymentStatus || "all") as "paid" | "unpaid" | "all";
      const leadStage = String(req.query?.leadStage || "all") as "all" | "photo_generated" | "generation_error" | "first_screen";

      const result = await storage.getAdminCustomers({
        dateFrom,
        dateTo,
        search: String(req.query?.search || ""),
        paymentStatus,
        leadStage,
        limit: pageSize,
        offset: (page - 1) * pageSize,
      });

      const userIds = Array.from(new Set(result.rows.map((row) => row.userId).filter(Boolean) as string[]));
      const userRows = await storage.getUsersByIds(userIds);
      const usersById = new Map(userRows.map((u) => [u.id, u] as const));

      const rows = result.rows.map((row) => {
        const user = row.userId ? usersById.get(row.userId) : undefined;
        const productKey = resolvePixProductKey({
          planId: row.pixPlanId,
          journeyNode: row.pixJourneyNode,
          amountCents: row.saleAmountCents,
        });

        return {
          sessionId: row.sessionId,
          uploadedPhotoUrl: row.uploadedPhotoUrl,
          generatedPhotoUrl: toAdminGeneratedPhotoUrl(row.generatedPhotoUrl),
          username: user?.username || row.customerName || row.userId || row.sessionId,
          paymentStatus: row.isPaid ? "paid" : "unpaid",
          contactEmail: row.customerEmail || user?.email || null,
          contactPhone: null,
          purchasedProductLabel: productKey ? getAdminPixProductLabel(productKey) : null,
          paidAmountCents: row.saleAmountCents ?? null,
          createdAt: row.visitorFirstSeenAt,
        };
      });

      res.json({
        page,
        pageSize,
        total: result.total,
        rows,
      });
    } catch (error) {
      console.error("[caller-customers] Error:", error);
      res.status(500).json({ message: "Erro ao carregar clientes" });
    }
  });
  // ── End caller auth block ──────────────────────────────────────────────────

  app.post("/api/funnel/events", async (req: any, res) => {
    try {
      // Silently accept and drop tracking events from bots/automation. We
      // return 200 so the client doesn't see a different code path that
      // could be used to fingerprint the filter.
      if (isBotRequest(req)) {
        return res.json({ success: true, skipped: "bot" });
      }

      if (getRequestBodySizeBytes(req) > FUNNEL_EVENT_MAX_BODY_BYTES) {
        return res.status(413).json({ message: "Evento muito grande" });
      }

      const rateLimit = reserveFunnelEventAttempt(req);
      if (!rateLimit.ok) {
        res.setHeader("Retry-After", String(rateLimit.retryAfterSeconds));
        return res.status(429).json({ message: "Muitos eventos. Tente novamente em instantes." });
      }

      const parsed = publicFunnelEventSchema.safeParse(req.body ?? {});
      if (!parsed.success) {
        return res.status(400).json({ message: "Evento inválido" });
      }

      const event = parsed.data;
      await trackFunnelStep(req, {
        step: event.step,
        eventName: event.eventName || event.step,
        idempotencyKey: event.idempotencyKey,
        metadata: sanitizeFunnelEventMetadata({
          journeyNode: event.journeyNode,
          journeyPath: event.journeyPath,
          ...event.metadata,
        }),
        customerName: normalizedOptionalText(event.customerName),
        customerEmail: normalizedOptionalText(event.customerEmail),
        utm_source: sanitizeUtm(event.utm_source),
        utm_medium: sanitizeUtm(event.utm_medium),
        utm_campaign: sanitizeUtm(event.utm_campaign),
        utm_content: sanitizeUtm(event.utm_content),
        utm_term: sanitizeUtm(event.utm_term),
      });

      return res.json({ success: true });
    } catch (error) {
      console.error("[funnel-events] Error:", error);
      return res.status(500).json({ message: "Erro ao registrar evento" });
    }
  });

  // DesireAI generates a single image per session (Seedream/Qwen2 edit). The
  // closest matching entry in the shared KIE_AI_COSTS table is "image_default"
  // (Imagem 4K). We apply the standard margin so the figure shown in the
  // dashboard reflects the same per-credit reckoning used elsewhere.
  const ADMIN_PER_IMAGE_USD = applyKieCostMargin(
    KIE_AI_COSTS["image_default"]?.usdCost ?? 0,
  );
  const computeApiCostUsd = (generatedMediaCount: number) =>
    Number((generatedMediaCount * ADMIN_PER_IMAGE_USD).toFixed(2));

  app.get("/api/admin/funnel", requireAdminAuth, async (req: any, res) => {
    try {
      const { dateFrom, dateTo } = parseDateRange(req.query);
      const rangeError = getAdminDateRangeError(dateFrom, dateTo);
      if (rangeError) return res.status(400).json({ message: rangeError });

      const counts = await storage.getFunnelStepCounts(dateFrom, dateTo);
      const generatedMediaCount = await storage.getGeneratedMediaCountInRange(dateFrom, dateTo);
      const pixMetrics = await storage.getPixPaymentMetricsInRange(dateFrom, dateTo);
      const apiCostUsd = computeApiCostUsd(generatedMediaCount);
      const pixPaidOverCreatedRate = pixMetrics.created > 0
        ? Number(((pixMetrics.converted / pixMetrics.created) * 100).toFixed(1))
        : 0;
      const top = Math.max(1, counts.visitor_entered || 0);

      const steps = FUNNEL_STEP_ORDER
        .map((step, idx, arr) => {
          const current = counts[step] || 0;
          const prevStep = idx > 0 ? arr[idx - 1] : null;
          const prev = prevStep ? counts[prevStep] || 0 : current;
          const convPrev = idx === 0 ? 100 : prev > 0 ? (current / prev) * 100 : 0;
          const convTop = top > 0 ? (current / top) * 100 : 0;
          return {
            step,
            label: FUNNEL_STEP_LABELS[step],
            total: current,
            conversionVsPrevious: Number(convPrev.toFixed(2)),
            conversionVsTop: Number(convTop.toFixed(2)),
          };
        });

      res.json({
        dateFrom,
        dateTo,
        steps,
        generatedMediaCount,
        apiCostUsd,
        pixPaymentsCreated: pixMetrics.created,
        pixPaymentsConverted: pixMetrics.converted,
        pixPaymentsPaid: pixMetrics.paid,
        pixPaymentsActivePaid: pixMetrics.activePaid,
        pixPaymentsRefunded: pixMetrics.refunded,
        pixPaymentsChargedback: pixMetrics.chargedback,
        pixGrossRevenueCents: pixMetrics.grossRevenueCents,
        pixRefundedCents: pixMetrics.refundedCents,
        pixNetRevenueCents: pixMetrics.netRevenueCents,
        pixPaidOverCreatedRate,
      });
    } catch (error) {
      console.error("[admin-funnel] Error:", error);
      res.status(500).json({ message: "Erro ao carregar funil" });
    }
  });

  app.get("/api/admin/journey-map", requireAdminAuth, async (req: any, res) => {

    try {
      const { dateFrom, dateTo } = parseDateRange(req.query);
      const rangeError = getAdminDateRangeError(dateFrom, dateTo);
      if (rangeError) return res.status(400).json({ message: rangeError });

      const generatedMediaCount = await storage.getGeneratedMediaCountInRange(dateFrom, dateTo);
      const pixMetrics = await storage.getPixPaymentMetricsInRange(dateFrom, dateTo);
      const apiCostUsd = computeApiCostUsd(generatedMediaCount);
      const pixPaidOverCreatedRate = pixMetrics.created > 0
        ? Number(((pixMetrics.converted / pixMetrics.created) * 100).toFixed(1))
        : 0;

      const rawEvents = await db
        .select({
          sessionId: funnelEvents.sessionId,
          step: funnelEvents.step,
          eventName: funnelEvents.eventName,
          metadata: funnelEvents.metadata,
          occurredAt: funnelEvents.occurredAt,
        })
        .from(funnelEvents)
        .where(and(gte(funnelEvents.occurredAt, dateFrom), lte(funnelEvents.occurredAt, dateTo)))
        .orderBy(asc(funnelEvents.sessionId), asc(funnelEvents.occurredAt), asc(funnelEvents.createdAt));

      const nodeSessions = new Map<string, Set<string>>();
      const eventsBySession = new Map<string, Array<{ nodeId: string; occurredAt: Date | null }>>();
      const knownNodeIds = new Set(JOURNEY_NODES.map((node) => node.id));

      for (const event of rawEvents) {
        const metadata = (event.metadata && typeof event.metadata === "object")
          ? event.metadata as Record<string, unknown>
          : {};
        const nodeId = inferJourneyNode({
          step: event.step,
          eventName: event.eventName,
          metadata,
        });
        if (!nodeId || !knownNodeIds.has(nodeId)) continue;

        const nodeSet = nodeSessions.get(nodeId) || new Set<string>();
        nodeSet.add(event.sessionId);
        nodeSessions.set(nodeId, nodeSet);

        const list = eventsBySession.get(event.sessionId) || [];
        list.push({ nodeId, occurredAt: event.occurredAt });
        eventsBySession.set(event.sessionId, list);
      }

      const edgeSessions = new Map<string, Set<string>>();
      eventsBySession.forEach((sessionEvents, sessionId) => {
        sessionEvents.sort((a: { nodeId: string; occurredAt: Date | null }, b: { nodeId: string; occurredAt: Date | null }) => {
          const timeA = a.occurredAt ? new Date(a.occurredAt).getTime() : 0;
          const timeB = b.occurredAt ? new Date(b.occurredAt).getTime() : 0;
          return timeA - timeB;
        });
        const compact: string[] = [];
        for (const event of sessionEvents) {
          if (compact[compact.length - 1] !== event.nodeId) {
            compact.push(event.nodeId);
          }
        }
        for (let index = 1; index < compact.length; index += 1) {
          const source = compact[index - 1];
          const target = compact[index];
          const edgeKey = `${source}->${target}`;
          const set = edgeSessions.get(edgeKey) || new Set<string>();
          set.add(sessionId);
          edgeSessions.set(edgeKey, set);
        }
      });

      const rootTotal = nodeSessions.get("landing_home")?.size || 0;
      const derivedNodeTotals = new Map<string, number>();
      for (const node of JOURNEY_NODES) {
        derivedNodeTotals.set(node.id, nodeSessions.get(node.id)?.size || 0);
      }
      const liftParentFromPix = (parentNode: string, pixGeneratedNode: string) => {
        const parent = derivedNodeTotals.get(parentNode) || 0;
        const child = derivedNodeTotals.get(pixGeneratedNode) || 0;
        if (child > parent) derivedNodeTotals.set(parentNode, child);
      };
      liftParentFromPix("landing_offer", "pix_generated_landing");
      liftParentFromPix("video_loaded_page", "pix_generated_video");
      liftParentFromPix("pack_loaded_page", "pix_generated_pack");
      liftParentFromPix("app_dashboard", "pix_generated_dashboard");
      liftParentFromPix("app_gallery", "pix_generated_gallery");
      liftParentFromPix("app_settings", "pix_generated_settings");

      const topTotal = rootTotal;

      const incomingByTarget = new Map<string, Array<{ source: string; total: number }>>();
      for (const edge of JOURNEY_EDGES) {
        const edgeKey = `${edge.source}->${edge.target}`;
        const total = edgeSessions.get(edgeKey)?.size || 0;
        const list = incomingByTarget.get(edge.target) || [];
        list.push({ source: edge.source, total });
        incomingByTarget.set(edge.target, list);
      }

      const nodes = JOURNEY_NODES.map((node) => {
        const total = derivedNodeTotals.get(node.id) || 0;
        const incoming = incomingByTarget.get(node.id) || [];
        const bestIncoming = incoming.sort((a, b) => b.total - a.total)[0];
        const previousTotal = bestIncoming ? (derivedNodeTotals.get(bestIncoming.source) || 0) : topTotal;
        const conversionVsPrevious = node.id === "landing_home"
          ? (total > 0 ? 100 : 0)
          : previousTotal > 0 ? Number(((total / previousTotal) * 100).toFixed(2)) : 0;
        const conversionVsTop = topTotal > 0 ? Number(((total / topTotal) * 100).toFixed(2)) : 0;
        return {
          id: node.id,
          label: node.label,
          position: { x: node.x, y: node.y },
          total,
          conversionVsPrevious,
          conversionVsTop,
          lowConversion: node.id !== "landing_home" && conversionVsPrevious < 30,
        };
      });

      const edges = JOURNEY_EDGES.map((edge) => {
        const edgeKey = `${edge.source}->${edge.target}`;
        const total = edgeSessions.get(edgeKey)?.size || 0;
        const sourceTotal = derivedNodeTotals.get(edge.source) || 0;
        const conversionVsSource = sourceTotal > 0
          ? Number(((total / sourceTotal) * 100).toFixed(2))
          : 0;
        return {
          id: edgeKey,
          source: edge.source,
          target: edge.target,
          total,
          conversionVsSource,
        };
      });

      const pixGroups = [
        { parent: "landing_home", generated: "pix_generated_landing", paid: "pix_paid_landing", label: "Landing inicial" },
        { parent: "video_loading_page", generated: "pix_generated_video", paid: "pix_paid_video", label: "Loading vídeo POV" },
        { parent: "pack_loading_page", generated: "pix_generated_pack", paid: "pix_paid_pack", label: "Loading pack fotos" },
        { parent: "app_dashboard", generated: "pix_generated_dashboard", paid: "pix_paid_dashboard", label: "Painel" },
        { parent: "app_gallery", generated: "pix_generated_gallery", paid: "pix_paid_gallery", label: "Galeria" },
        { parent: "app_settings", generated: "pix_generated_settings", paid: "pix_paid_settings", label: "Configurações" },
      ].map((group) => {
        const generatedTotal = nodeSessions.get(group.generated)?.size || 0;
        const paidTotal = nodeSessions.get(group.paid)?.size || 0;
        return {
          label: group.label,
          parentNode: group.parent,
          pixGenerated: generatedTotal,
          pixPaid: paidTotal,
          pixConversionRate: generatedTotal > 0 ? Number(((paidTotal / generatedTotal) * 100).toFixed(2)) : 0,
        };
      });

      // ── Linear funnel steps data ──────────────────────────────
      const LINEAR_FUNNEL: Array<{ id: string; label: string; nodes: string[] }> = [
        { id: "visitors", label: "Visitantes", nodes: ["landing_home"] },
        { id: "upload", label: "Upload de foto", nodes: ["landing_photo_uploaded"] },
        { id: "generated", label: "Foto gerada vista", nodes: ["landing_generated_photo"] },
        { id: "offer", label: "Oferta visualizada", nodes: ["landing_offer"] },
        { id: "offer_responded", label: "Respondeu oferta", nodes: ["landing_offer_responded"] },
        { id: "pix_generated", label: "PIX gerado", nodes: ["pix_generated_landing", "pix_generated_video", "pix_generated_pack", "pix_generated_dashboard", "pix_generated_gallery", "pix_generated_settings"] },
        { id: "pix_paid", label: "PIX pago", nodes: ["pix_paid_landing", "pix_paid_video", "pix_paid_pack", "pix_paid_dashboard", "pix_paid_gallery", "pix_paid_settings"] },
      ];
      const funnelSteps = LINEAR_FUNNEL.map((step, idx) => {
        const sessionIds = new Set<string>();
        for (const nid of step.nodes) {
          const s = nodeSessions.get(nid);
          if (s) s.forEach((sid) => sessionIds.add(sid));
        }
        const total = sessionIds.size;
        const prevTotal = idx > 0 ? (() => {
          const prevStep = LINEAR_FUNNEL[idx - 1];
          const prevSessions = new Set<string>();
          for (const nid of prevStep.nodes) {
            const s = nodeSessions.get(nid);
            if (s) s.forEach((sid) => prevSessions.add(sid));
          }
          return prevSessions.size;
        })() : total;
        const topRef = (() => {
          const firstStep = LINEAR_FUNNEL[0];
          const firstSessions = new Set<string>();
          for (const nid of firstStep.nodes) {
            const s = nodeSessions.get(nid);
            if (s) s.forEach((sid) => firstSessions.add(sid));
          }
          return firstSessions.size;
        })();
        return {
          id: step.id,
          label: step.label,
          total,
          conversionVsPrevious: idx === 0 ? (total > 0 ? 100 : 0) : prevTotal > 0 ? Number(((total / prevTotal) * 100).toFixed(1)) : 0,
          conversionVsTop: topRef > 0 ? Number(((total / topRef) * 100).toFixed(1)) : 0,
        };
      });

      res.json({
        dateFrom,
        dateTo,
        nodes,
        edges,
        generatedMediaCount,
        apiCostUsd,
        pixPaymentsCreated: pixMetrics.created,
        pixPaymentsConverted: pixMetrics.converted,
        pixPaymentsPaid: pixMetrics.paid,
        pixPaymentsActivePaid: pixMetrics.activePaid,
        pixPaymentsRefunded: pixMetrics.refunded,
        pixPaymentsChargedback: pixMetrics.chargedback,
        pixGrossRevenueCents: pixMetrics.grossRevenueCents,
        pixRefundedCents: pixMetrics.refundedCents,
        pixNetRevenueCents: pixMetrics.netRevenueCents,
        pixPaidOverCreatedRate,
        summary: {
          topTotal,
          uniqueSessions: rootTotal,
        },
        pixByPage: pixGroups,
        funnelSteps,
      });
    } catch (error) {
      console.error("[admin-journey-map] Error:", error);
      res.status(500).json({ message: "Erro ao carregar mapa de jornada" });
    }
  });

  // ── Admin Journey Tree (funnel full view) ──────────────────────
  // Uses the same funnel_events table and groups sessions into a tree of
  // nodes, including breakdowns for POV filters, offer button clicks, and
  // upsell origin + paid status.
  app.get("/api/admin/funnel/journey-tree", requireAdminAuth, async (req: any, res) => {
    try {
      const { dateFrom, dateTo, preset } = parseDateRange(req.query);

      const rangeError = getAdminDateRangeError(dateFrom, dateTo, JOURNEY_TREE_MAX_RANGE_DAYS);
      if (rangeError) return res.status(400).json({ message: rangeError });

      const cacheKey = `${dateFrom.toISOString()}|${dateTo.toISOString()}|${preset}`;
      const cached = journeyTreeCacheGet(cacheKey);
      if (cached) return res.json(cached);

      const rawEventsResult = await db.execute(sql`
        with cohort as (
          select distinct fe.session_id
          from funnel_events fe
          where fe.occurred_at >= ${dateFrom}
            and fe.occurred_at <= ${dateTo}
            and (
              fe.event_name = 'landing.entered'
              or fe.event_name = 'visitor_entered'
              or fe.event_name = 'landing.photo_uploaded'
              or fe.event_name = 'upload.reference_image'
            )
        )
        select
          fe.session_id as "sessionId",
          fe.step,
          fe.event_name as "eventName",
          fe.metadata,
          fe.occurred_at as "occurredAt"
        from funnel_events fe
        join cohort c on c.session_id = fe.session_id
        where fe.occurred_at >= ${dateFrom}
          and fe.occurred_at <= ${dateTo}
        order by fe.session_id asc, fe.occurred_at asc, fe.created_at asc
      `);
      const rawEvents: Array<{
        sessionId: string;
        step: FunnelStep;
        eventName: string;
        metadata: Record<string, unknown> | null;
        occurredAt: Date | null;
      }> = rawEventsResult.rows.map((row: any) => ({
        sessionId: String(row.sessionId || ""),
        step: row.step as FunnelStep,
        eventName: String(row.eventName || ""),
        metadata: row.metadata && typeof row.metadata === "object" && !Array.isArray(row.metadata)
          ? row.metadata as Record<string, unknown>
          : null,
        occurredAt: row.occurredAt ? new Date(row.occurredAt) : null,
      }));

      type Row = typeof rawEvents[number];
      const sessionIdsByKey = new Map<string, Set<string>>();
      const addSession = (key: string, sid: string) => {
        const s = sessionIdsByKey.get(key) || new Set<string>();
        s.add(sid);
        sessionIdsByKey.set(key, s);
      };

      const povPositionSessions = new Map<string, Set<string>>();
      const povOfferSessions = new Map<string, Set<string>>();
      const packOfferSessions = new Map<string, Set<string>>();
      const wantMoreDestSessions = new Map<string, Set<string>>();
      const upsellOriginSessions = new Map<string, Set<string>>();
      const upsellPaidBySession = new Map<string, boolean>();
      const upsellOriginBySession = new Map<string, string>();
      const landingLoginSuccessSessions = new Set<string>();
      const generatedPhotoSessions = new Set<string>();

      // Last pix_paid journeyNode per session before the upsell view
      const lastPixPaidNodeBySession = new Map<string, string>();

      const mdString = (md: unknown, key: string): string | null => {
        if (!md || typeof md !== "object") return null;
        const v = (md as Record<string, unknown>)[key];
        return typeof v === "string" && v.length > 0 ? v : null;
      };

      for (const ev of rawEvents as Row[]) {
        const sid = ev.sessionId;
        const step = ev.step;
        const eventName = ev.eventName || "";
        const md = ev.metadata || {};

        if (eventName === "landing.entered" || eventName === "visitor_entered") addSession("step1_upload", sid);
        if (eventName === "landing.photo_uploaded" || step === "photo_uploaded") addSession("step1_upload", sid);
        if (eventName === "landing.funnel_login_success" || eventName === "login.signup_success" || eventName === "login.login_success") {
          addSession("step2_login", sid);
          landingLoginSuccessSessions.add(sid);
        }
        if (eventName === "landing.generated_photo_viewed" || step === "generated_photo_viewed") {
          addSession("step3_home", sid);
          generatedPhotoSessions.add(sid);
        }

        if (eventName === "landing.want_more_clicked") addSession("branch_want_more", sid);

        if (eventName === "landing.credits_popup_plan_clicked") {
          addSession("branch_want_more", sid);
          const planId = mdString(md, "planId") || "unknown";
          addSession(`want_more_dest_${planId}`, sid);
          const destSet = wantMoreDestSessions.get(planId) || new Set<string>();
          destSet.add(sid);
          wantMoreDestSessions.set(planId, destSet);
        }

        if (eventName === "landing.offer_card_clicked") {
          const cardId = mdString(md, "cardId");
          if (cardId === "positions") addSession("branch_card_pack", sid);
          else if (cardId === "pov") addSession("branch_card_pov", sid);
        }

        if (eventName === "landing.pack_photos_submit") addSession("step4_pack", sid);
        // Use the server-side event so step4_pov matches what the customer
        // list and /api/admin/responses/video-pov detect (i.e., POV submits
        // that actually persisted a videoPovRequests row). The client-side
        // "landing.video_pov_submit" still maps to landing_offer_responded
        // in inferJourneyNode for the legacy journey-map.
        if (eventName === "offer.video_pov_submitted") {
          addSession("step4_pov", sid);
          const position = mdString(md, "position");
          if (position) {
            const set = povPositionSessions.get(position) || new Set<string>();
            set.add(sid);
            povPositionSessions.set(position, set);
          }
        }

        if (eventName === "pack_photos.loading_screen_entered") addSession("step5_pack", sid);
        if (eventName === "video_pov.loading_screen_entered") addSession("step5_pov", sid);
        if (eventName === "pack_photos.loaded") addSession("step6_pack", sid);
        if (eventName === "video_pov.loaded") addSession("step6_pov", sid);

        if (eventName === "pack_photos.offer_clicked") {
          const planId = mdString(md, "planId") || "unknown";
          const set = packOfferSessions.get(planId) || new Set<string>();
          set.add(sid);
          packOfferSessions.set(planId, set);
        }
        if (eventName === "video_pov.offer_clicked") {
          const planId = mdString(md, "planId") || "unknown";
          const set = povOfferSessions.get(planId) || new Set<string>();
          set.add(sid);
          povOfferSessions.set(planId, set);
        }

        // Track last pix_paid journeyNode per session for upsell origin.
        // Relies on the orderBy (occurredAt, createdAt asc) to preserve
        // chronological order — without the createdAt tiebreaker two events
        // sharing a timestamp would have non-deterministic ordering.
        if (step === "pix_paid") {
          const jn = mdString(md, "journeyNode") || "";
          if (jn) lastPixPaidNodeBySession.set(sid, jn);
        }

        if (eventName === "upsell.instapro_viewed") {
          addSession("step7_upsell", sid);
          const origin = lastPixPaidNodeBySession.get(sid) || "unknown";
          upsellOriginBySession.set(sid, origin);
          const set = upsellOriginSessions.get(origin) || new Set<string>();
          set.add(sid);
          upsellOriginSessions.set(origin, set);
        }
        if (eventName === "upsell.instapro_paid") {
          upsellPaidBySession.set(sid, true);
          if (!upsellOriginBySession.has(sid)) {
            const origin = lastPixPaidNodeBySession.get(sid) || "unknown";
            upsellOriginBySession.set(sid, origin);
          }
          addSession("step7_upsell", sid);
        }
      }

      // Historical sessions did not emit a dedicated landing login success
      // event. In this funnel, reaching the generated-photo home implies that
      // the embedded user/password form succeeded, so keep the visual journey
      // coherent while the new server-side event takes over going forward.
      Array.from(generatedPhotoSessions).forEach((sid) => addSession("step2_login", sid));
      const inferredLoginSessions = new Set(
        Array.from(generatedPhotoSessions).filter((sid) => !landingLoginSuccessSessions.has(sid)),
      );

      const countOf = (key: string) => sessionIdsByKey.get(key)?.size || 0;

      // Origin labels are matched by exact prefix to avoid false positives
      // (e.g. a hypothetical "landing_offer_responded" would otherwise match
      // the "landing" rule). Whitelist explicit prefixes from JOURNEY_NODES.
      const mapOriginToLabel = (origin: string): string => {
        if (origin.startsWith("pix_paid_landing") || origin.startsWith("pix_generated_landing")) return "Etapa 3 (direto — Ilimitado)";
        if (origin.startsWith("pix_paid_video") || origin.startsWith("pix_generated_video")) return "Etapa 6 (Vídeo POV)";
        if (origin.startsWith("pix_paid_pack") || origin.startsWith("pix_generated_pack")) return "Etapa 6 (Pack de Fotos)";
        if (origin.startsWith("pix_paid_dashboard") || origin.startsWith("pix_paid_gallery") || origin.startsWith("pix_paid_settings")) return "Painel / Pós-compra";
        return "Origem não identificada";
      };

      const upsellPaidCount = upsellPaidBySession.size;
      const upsellOriginBreakdown = (() => {
        const grouped = new Map<string, number>();
        upsellOriginSessions.forEach((set, origin) => {
          const label = mapOriginToLabel(origin);
          grouped.set(label, (grouped.get(label) || 0) + set.size);
        });
        const total = Array.from(grouped.values()).reduce((a, b) => a + b, 0) || 1;
        return Array.from(grouped.entries())
          .sort((a, b) => b[1] - a[1])
          .map(([label, count]) => ({ key: label, label, count, pct: Number(((count / total) * 100).toFixed(1)) }));
      })();

      const breakdownFrom = (
        map: Map<string, Set<string>>,
        labels: Record<string, string>,
      ): Array<{ key: string; label: string; count: number; pct: number }> => {
        const entries = Array.from(map.entries()).map(([key, set]) => ({ key, count: set.size }));
        const total = entries.reduce((a, b) => a + b.count, 0) || 1;
        return entries
          .sort((a, b) => b.count - a.count)
          .map(({ key, count }) => ({
            key,
            label: labels[key] || key,
            count,
            pct: Number(((count / total) * 100).toFixed(1)),
          }));
      };

      const POV_POSITION_LABELS: Record<string, string> = {
        de_quatro: "De quatro",
        papai_mamae: "Papai mamãe",
        sentando: "Sentando",
      };
      const POV_OFFER_LABELS: Record<string, string> = {
        ilimitado: "Uso diário ilimitado",
        "video-pov-pack-2990": "Vídeo POV + Pack de fotos",
        "video-pov-1990": "Apenas Vídeo POV",
      };
      const PACK_OFFER_LABELS: Record<string, string> = {
        ilimitado: "Uso diário ilimitado",
        "video-pov-pack-2990": "Pack de fotos + Vídeo POV",
        "pack-fotos-1990": "Apenas Pack de Fotos",
      };
      const WANT_MORE_DEST_LABELS: Record<string, string> = {
        ilimitado: "Uso Diário Ilimitado",
        "10-fotos": "Pack de fotos",
        "10-fotos-1-video": "Vídeo POV",
      };
      const step2LoginTotal = countOf("step2_login");
      const step2LoginBreakdown = step2LoginTotal > 0
        ? [
          {
            key: "confirmed",
            label: "Formulário confirmado",
            count: landingLoginSuccessSessions.size,
            pct: Number(((landingLoginSuccessSessions.size / step2LoginTotal) * 100).toFixed(1)),
          },
          {
            key: "inferred_generated",
            label: "Histórico inferido pela foto gerada",
            count: inferredLoginSessions.size,
            pct: Number(((inferredLoginSessions.size / step2LoginTotal) * 100).toFixed(1)),
          },
        ].filter((entry) => entry.count > 0)
        : undefined;

      // ── Tree nodes with pre-computed positions ─────────────────
      type NodeDef = {
        id: string;
        label: string;
        short?: string;
        x: number;
        y: number;
        parent?: string;
        count: number;
        breakdown?: Array<{ key: string; label: string; count: number; pct: number }>;
        accent?: "primary" | "pack" | "pov" | "upsell";
      };

      const COL = 320;
      const LANE_PACK = -340;
      const LANE_TRUNK = 0;
      const LANE_POV = 340;

      const nodes: NodeDef[] = [
        { id: "step1_upload", label: "1. Página de upload", x: 0 * COL, y: LANE_TRUNK, count: countOf("step1_upload"), accent: "primary" },
        { id: "step2_login", label: "2. Login e carregamento", x: 1 * COL, y: LANE_TRUNK, parent: "step1_upload", count: countOf("step2_login"), breakdown: step2LoginBreakdown, accent: "primary" },
        { id: "step3_home", label: "3. Home — Foto gerada", x: 2 * COL, y: LANE_TRUNK, parent: "step2_login", count: countOf("step3_home"), accent: "primary" },

        { id: "branch_card_pack", label: "Card Pack de fotos", x: 3 * COL, y: LANE_PACK, parent: "step3_home", count: countOf("branch_card_pack"), accent: "pack" },
        {
          id: "branch_want_more", label: 'Botão "Quer ver mais"', x: 3 * COL, y: LANE_TRUNK, parent: "step3_home",
          count: countOf("branch_want_more"),
          breakdown: breakdownFrom(wantMoreDestSessions, WANT_MORE_DEST_LABELS),
          accent: "primary",
        },
        { id: "branch_card_pov", label: "Card Vídeo POV", x: 3 * COL, y: LANE_POV, parent: "step3_home", count: countOf("branch_card_pov"), accent: "pov" },

        { id: "step4_pack", label: "4. Pack — Modal enviado", x: 4 * COL, y: LANE_PACK, parent: "branch_card_pack", count: countOf("step4_pack"), accent: "pack" },
        {
          id: "step4_pov", label: "4. Vídeo POV — Modal enviado", x: 4 * COL, y: LANE_POV, parent: "branch_card_pov",
          count: countOf("step4_pov"),
          breakdown: breakdownFrom(povPositionSessions, POV_POSITION_LABELS),
          accent: "pov",
        },

        { id: "step5_pack", label: "5. Pack — Loading", x: 5 * COL, y: LANE_PACK, parent: "step4_pack", count: countOf("step5_pack"), accent: "pack" },
        { id: "step5_pov", label: "5. Vídeo POV — Loading", x: 5 * COL, y: LANE_POV, parent: "step4_pov", count: countOf("step5_pov"), accent: "pov" },

        {
          id: "step6_pack", label: "6. Pack — Ofertas", x: 6 * COL, y: LANE_PACK, parent: "step5_pack",
          count: countOf("step6_pack"),
          breakdown: breakdownFrom(packOfferSessions, PACK_OFFER_LABELS),
          accent: "pack",
        },
        {
          id: "step6_pov", label: "6. Vídeo POV — Ofertas", x: 6 * COL, y: LANE_POV, parent: "step5_pov",
          count: countOf("step6_pov"),
          breakdown: breakdownFrom(povOfferSessions, POV_OFFER_LABELS),
          accent: "pov",
        },

        {
          id: "step7_upsell", label: "7. Upsell InstaPro", x: 7 * COL, y: LANE_TRUNK, parent: "step3_home",
          count: countOf("step7_upsell"),
          breakdown: [
            ...upsellOriginBreakdown,
            ...(countOf("step7_upsell") > 0 ? [{
              key: "paid_status",
              label: `Pagou upsell: ${upsellPaidCount} / ${countOf("step7_upsell")}`,
              count: upsellPaidCount,
              pct: Number(((upsellPaidCount / Math.max(1, countOf("step7_upsell"))) * 100).toFixed(1)),
            }] : []),
          ],
          accent: "upsell",
        },
      ];

      const edges: Array<{ id: string; source: string; target: string; count: number; conversionPct: number }> = [];
      const byId = new Map(nodes.map((n) => [n.id, n] as const));
      for (const n of nodes) {
        if (!n.parent) continue;
        const parentNode = byId.get(n.parent);
        const pCount = parentNode?.count || 0;
        const conv = pCount > 0 ? Number(((n.count / pCount) * 100).toFixed(1)) : 0;
        edges.push({ id: `${n.parent}->${n.id}`, source: n.parent, target: n.id, count: n.count, conversionPct: conv });
      }

      const nodesWithConversion = nodes.map((n) => {
        const parent = n.parent ? byId.get(n.parent) : null;
        const parentCount = parent?.count || 0;
        const conversionFromParent = n.parent
          ? parentCount > 0 ? Number(((n.count / parentCount) * 100).toFixed(1)) : 0
          : 100;
        return { ...n, conversionFromParent };
      });

      const totalSessions = countOf("step1_upload") || Math.max(...nodes.map((n) => n.count), 0);

      const payload = {
        dateFrom,
        dateTo,
        preset,
        totals: { sessions: totalSessions },
        nodes: nodesWithConversion,
        edges,
        generatedAt: new Date().toISOString(),
      };

      journeyTreeCacheSet(cacheKey, payload);
      res.json(payload);
    } catch (error) {
      console.error("[admin-journey-tree] Error:", error);
      res.status(500).json({ message: "Erro ao carregar jornada do funil" });
    }
  });

  app.get("/api/admin/customers", requireAdminAuth, async (req: any, res) => {
    try {
      const { dateFrom, dateTo } = parseDateRange(req.query);
      const rangeError = getAdminDateRangeError(dateFrom, dateTo);
      if (rangeError) return res.status(400).json({ message: rangeError });

      const parsedQuery = adminCustomerQuerySchema.safeParse(req.query);
      if (!parsedQuery.success) {
        return res.status(400).json({
          message: "Parâmetros inválidos para a lista de clientes",
          issues: parsedQuery.error.issues,
        });
      }

      const {
        page,
        pageSize,
        search,
        paymentStatus,
        leadStage,
        responseKind,
        pixProduct,
        sortBy,
        sortDir,
      } = parsedQuery.data;

      const result = await storage.getAdminCustomers({
        dateFrom,
        dateTo,
        search,
        paymentStatus,
        leadStage,
        responseKind,
        pixProduct,
        sortBy,
        sortDir,
        limit: pageSize,
        offset: (page - 1) * pageSize,
      });

      const userIds = Array.from(new Set(result.rows.map((row) => row.userId).filter(Boolean) as string[]));
      const userRows = await storage.getUsersByIds(userIds);
      const usersById = new Map(userRows.map((u) => [u.id, u] as const));

      const rows = result.rows.map((row) => {
        const user = row.userId ? usersById.get(row.userId) : undefined;
        const productKey = resolvePixProductKey({
          planId: row.pixPlanId,
          journeyNode: row.pixJourneyNode,
          amountCents: row.saleAmountCents,
        });

        return {
          sessionId: row.sessionId,
          userId: row.userId,
          uploadedPhotoUrl: row.uploadedPhotoUrl,
          generatedPhotoUrl: toAdminGeneratedPhotoUrl(row.generatedPhotoUrl),
          username: user?.username || row.customerName || row.userId || row.sessionId,
          paymentStatus: row.isPaid ? "paid" : "unpaid",
          contactEmail: row.customerEmail || user?.email || null,
          contactPhone: null,
          purchasedProductLabel: productKey ? getAdminPixProductLabel(productKey) : null,
          paidAmountCents: row.saleAmountCents ?? null,
          createdAt: row.createdAt,
          visitorLastSeenAt: row.visitorLastSeenAt,
          maxStepReached: row.maxStepReached,
          maxStepReachedLabel: ADMIN_FUNNEL_STEP_LABELS[row.maxStepReached],
          packResponse: row.packResponse,
          videoPovResponse: row.videoPovResponse,
        };
      });

      res.json({
        page,
        pageSize,
        total: result.total,
        rows,
      });
    } catch (error) {
      console.error("[admin-customers] Error:", error);
      res.status(500).json({ message: "Erro ao carregar clientes" });
    }
  });

  app.get("/api/admin/customers/:sessionId", requireAdminAuth, async (req: any, res) => {
    try {
      const parsed = adminSessionIdParamSchema.safeParse(req.params);
      if (!parsed.success) {
        return res.status(400).json({ message: "Identificador de sessão inválido" });
      }
      const { sessionId } = parsed.data;
      const details = await storage.getFunnelSessionDetails(sessionId);
      if (!details.session) return res.status(404).json({ message: "Sessão não encontrada" });

      const user = details.session.userId
        ? await storage.getUser(details.session.userId)
        : undefined;

      return res.json({
        session: toAdminSessionDetailsDto(details.session),
        events: details.events.map((event) => ({
          id: event.id,
          step: event.step,
          eventName: event.eventName,
          occurredAt: event.occurredAt,
          metadata: sanitizeAdminEventMetadata(event.metadata),
        })),
        images: [],
        loginData: user
          ? {
            userId: user.id,
            username: user.username ?? null,
            email: user.email ?? null,
          }
          : null,
      });
    } catch (error) {
      console.error("[admin-customer-details] Error:", error);
      return res.status(500).json({ message: "Erro ao carregar detalhes da sessão" });
    }
  });

  app.get("/api/admin/responses/packs", requireAdminAuth, async (req: any, res) => {
    try {
      const { dateFrom, dateTo } = parseDateRange(req.query);
      const rangeError = getAdminDateRangeError(dateFrom, dateTo);
      if (rangeError) return res.status(400).json({ message: rangeError });

      const parsedQuery = adminResponseQuerySchema.safeParse(req.query);
      if (!parsedQuery.success) {
        return res.status(400).json({
          message: "Parâmetros inválidos para respostas de packs",
          issues: parsedQuery.error.issues,
        });
      }
      const { page, pageSize, search, paymentStatus } = parsedQuery.data;

      const result = await storage.getAdminPackResponses({
        dateFrom,
        dateTo,
        search,
        paymentStatus,
        limit: pageSize,
        offset: (page - 1) * pageSize,
      });

      const rows = result.rows.map((row) => ({
        ...row,
        username: row.username || row.customerName || row.userId || row.sessionId,
        contactEmail: row.email || row.customerEmail || null,
        contactPhone: null as string | null,
      }));

      res.json({
        page,
        pageSize,
        total: result.total,
        rows,
      });
    } catch (error) {
      console.error("[admin-pack-responses] Error:", error);
      res.status(500).json({ message: "Erro ao carregar respostas de packs" });
    }
  });

  app.get("/api/admin/responses/video-pov", requireAdminAuth, async (req: any, res) => {
    try {
      const { dateFrom, dateTo } = parseDateRange(req.query);
      const rangeError = getAdminDateRangeError(dateFrom, dateTo);
      if (rangeError) return res.status(400).json({ message: rangeError });

      const parsedQuery = adminResponseQuerySchema.safeParse(req.query);
      if (!parsedQuery.success) {
        return res.status(400).json({
          message: "Parâmetros inválidos para respostas de vídeo POV",
          issues: parsedQuery.error.issues,
        });
      }
      const { page, pageSize, search, paymentStatus } = parsedQuery.data;

      const result = await storage.getAdminVideoPovResponses({
        dateFrom,
        dateTo,
        search,
        paymentStatus,
        limit: pageSize,
        offset: (page - 1) * pageSize,
      });

      const rows = result.rows.map((row) => ({
        ...row,
        username: row.username || row.customerName || row.userId || row.sessionId,
        contactEmail: row.email || row.customerEmail || null,
        contactPhone: null as string | null,
      }));

      res.json({
        page,
        pageSize,
        total: result.total,
        rows,
      });
    } catch (error) {
      console.error("[admin-video-pov-responses] Error:", error);
      res.status(500).json({ message: "Erro ao carregar respostas de vídeo POV" });
    }
  });

  app.get("/api/admin/real-preview-logs", requireAdminAuth, async (req: any, res) => {
    try {
      const { dateFrom, dateTo } = parseDateRange(req.query);
      const rangeError = getAdminDateRangeError(dateFrom, dateTo);
      if (rangeError) return res.status(400).json({ message: rangeError });

      const parsedQuery = adminRealPreviewLogsQuerySchema.safeParse(req.query);
      if (!parsedQuery.success) {
        return res.status(400).json({
          message: "Parâmetros inválidos para logs do Real Preview",
          issues: parsedQuery.error.issues,
        });
      }

      const { page, pageSize, search } = parsedQuery.data;
      const result = await storage.getAdminRealPreviewLogs({
        dateFrom,
        dateTo,
        search,
        limit: pageSize,
        offset: (page - 1) * pageSize,
      });

      res.json({
        dateFrom,
        dateTo,
        page,
        pageSize,
        total: result.total,
        summary: result.summary,
        rows: result.rows,
      });
    } catch (error) {
      console.error("[admin-real-preview-logs] Error:", error);
      res.status(500).json({ message: "Erro ao carregar logs do Real Preview" });
    }
  });

  // ── GET /api/admin/generated-images/:id/image — proxy para admin ──────
  app.get("/api/admin/generated-images/:id/image", requireAdminAuth, async (req: any, res) => {
    try {
      const image = await storage.getGeneratedImage(String(req.params.id || ""));
      if (!image) return res.status(404).json({ message: "Não encontrado" });
      if (!image.imageUrl) return res.status(404).json({ message: "Imagem ainda não gerada" });
      if (!isAllowedGeneratedMediaUrl(image.imageUrl)) {
        return res.status(502).json({ message: "URL de imagem não permitida" });
      }

      const upstream = await fetch(image.imageUrl);
      if (!upstream.ok) return res.status(502).json({ message: "Erro ao buscar imagem" });

      const buf = Buffer.from(await upstream.arrayBuffer());
      applyProxyMediaHeaders(res, {
        url: image.imageUrl,
        upstreamType: upstream.headers.get("content-type"),
        buf,
        cacheControl: "private, max-age=3600",
      });
      return res.send(buf);
    } catch (error: any) {
      console.error("[admin-image-proxy]", error.message);
      return res.status(500).json({ message: "Erro ao servir imagem" });
    }
  });

  // ── A/B testing — admin CRUD + visitor assignment ───────────────
  const abSlugSchema = z
    .string()
    .trim()
    .min(1)
    .max(64)
    .regex(/^[a-z0-9][a-z0-9-]*$/, "Slug deve conter apenas letras minúsculas, números e hífens");
  const abPathSchema = z
    .string()
    .trim()
    .min(1)
    .max(128)
    .regex(/^\/[a-zA-Z0-9/_-]*$/, "Caminho deve começar com / e usar apenas letras, números, _, -, /");
  const abVariantInputSchema = z.object({
    name: z.string().trim().min(1).max(80),
    slug: abSlugSchema,
    componentKey: z
      .string()
      .trim()
      .min(1)
      .max(64)
      .regex(/^[a-z0-9][a-z0-9-]*$/),
    weight: z.number().min(0).max(100),
  });
  const abCreateTestSchema = z.object({
    name: z.string().trim().min(1).max(80),
    slug: abSlugSchema,
    publicPath: abPathSchema,
    variants: z.array(abVariantInputSchema).min(2).max(8),
  });
  const abUpdateTestSchema = z.object({
    name: z.string().trim().min(1).max(80).optional(),
    status: z.enum(["active", "paused", "ended"]).optional(),
    variants: z
      .array(z.object({ id: z.string().min(1), weight: z.number().min(0).max(100) }))
      .optional(),
  });

  function assertWeightsSum(variants: Array<{ weight: number }>) {
    const total = variants.reduce((sum, v) => sum + v.weight, 0);
    return Math.abs(total - 100) < 0.01;
  }

  // GET /api/admin/ab-tests — list every test with its variants
  app.get("/api/admin/ab-tests", requireAdminAuth, async (_req: any, res) => {
    try {
      const tests = await storage.getAllAbTestsWithVariants();
      res.json({ tests });
    } catch (error: any) {
      console.error("[ab-tests] list error:", error);
      res.status(500).json({ message: "Erro ao listar testes" });
    }
  });

  // POST /api/admin/ab-tests — create test + variants
  app.post("/api/admin/ab-tests", requireAdminAuth, async (req: any, res) => {
    const parsed = abCreateTestSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: parsed.error.errors[0]?.message || "Dados inválidos" });
    }
    if (!assertWeightsSum(parsed.data.variants)) {
      return res.status(400).json({ message: "A soma dos pesos deve ser 100%" });
    }
    const slugs = new Set(parsed.data.variants.map((v) => v.slug));
    if (slugs.size !== parsed.data.variants.length) {
      return res.status(400).json({ message: "Slugs de variantes devem ser únicos" });
    }
    try {
      const activePathConflict = await storage.getActiveAbTestByPublicPath(parsed.data.publicPath);
      if (activePathConflict) {
        return res.status(409).json({ message: "Já existe um teste ativo para este caminho público" });
      }

      const test = await storage.createAbTestWithVariants(
        {
          name: parsed.data.name,
          slug: parsed.data.slug,
          publicPath: parsed.data.publicPath,
        },
        parsed.data.variants,
      );
      invalidateAbTestsCache();
      res.json({ test });
    } catch (error: any) {
      if (error?.code === "23505") {
        const constraint = String(error?.constraint || "");
        const message = constraint.includes("active_public_path")
          ? "Já existe um teste ativo para este caminho público"
          : "Slug já está em uso";
        return res.status(409).json({ message });
      }
      console.error("[ab-tests] create error:", error);
      res.status(500).json({ message: "Erro ao criar teste" });
    }
  });

  // PATCH /api/admin/ab-tests/:id — update name/status or variant weights
  app.patch("/api/admin/ab-tests/:id", requireAdminAuth, async (req: any, res) => {
    const id = String(req.params.id || "").trim();
    if (!id) return res.status(400).json({ message: "ID inválido" });
    const parsed = abUpdateTestSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: parsed.error.errors[0]?.message || "Dados inválidos" });
    }
    if (parsed.data.variants && parsed.data.variants.length > 0) {
      if (!assertWeightsSum(parsed.data.variants)) {
        return res.status(400).json({ message: "A soma dos pesos deve ser 100%" });
      }
    }
    try {
      const existing = await storage.getAbTestWithVariants(id);
      if (!existing) return res.status(404).json({ message: "Teste não encontrado" });

      if (parsed.data.variants && parsed.data.variants.length > 0) {
        const submittedIds = new Set(parsed.data.variants.map((variant) => variant.id));
        if (submittedIds.size !== parsed.data.variants.length) {
          return res.status(400).json({ message: "IDs de variantes devem ser únicos" });
        }

        const existingIds = new Set(existing.variants.map((variant) => variant.id));
        const hasCompleteVariantSet = submittedIds.size === existingIds.size
          && Array.from(existingIds).every((variantId) => submittedIds.has(variantId));
        if (!hasCompleteVariantSet) {
          return res.status(400).json({ message: "Envie pesos para todas as variantes do teste" });
        }
      }

      const nextStatus = parsed.data.status ?? existing.status;
      if (nextStatus === "active") {
        const activePathConflict = await storage.getActiveAbTestByPublicPath(existing.publicPath, id);
        if (activePathConflict) {
          return res.status(409).json({ message: "Já existe um teste ativo para este caminho público" });
        }
      }

      const test = await storage.updateAbTest(
        id,
        { status: parsed.data.status, name: parsed.data.name },
        parsed.data.variants,
      );
      if (!test) return res.status(404).json({ message: "Teste não encontrado" });
      invalidateAbTestsCache();
      res.json({ test });
    } catch (error: any) {
      if (error?.code === "23505") {
        return res.status(409).json({ message: "Já existe um teste ativo para este caminho público" });
      }
      console.error("[ab-tests] update error:", error);
      res.status(500).json({ message: "Erro ao atualizar teste" });
    }
  });

  // DELETE /api/admin/ab-tests/:id — soft-end the test
  app.delete("/api/admin/ab-tests/:id", requireAdminAuth, async (req: any, res) => {
    const id = String(req.params.id || "").trim();
    if (!id) return res.status(400).json({ message: "ID inválido" });
    try {
      await storage.endAbTest(id);
      invalidateAbTestsCache();
      res.json({ success: true });
    } catch (error: any) {
      console.error("[ab-tests] end error:", error);
      res.status(500).json({ message: "Erro ao encerrar teste" });
    }
  });

  // GET /api/admin/ab-tests/:id/stats — per-variant analytics
  app.get("/api/admin/ab-tests/:id/stats", requireAdminAuth, async (req: any, res) => {
    const id = String(req.params.id || "").trim();
    if (!id) return res.status(400).json({ message: "ID inválido" });
    try {
      const test = await storage.getAbTestWithVariants(id);
      if (!test) return res.status(404).json({ message: "Teste não encontrado" });
      const stats = await storage.getAbTestStats(id);
      const since = test.createdAt ?? new Date(0);
      const [funnelSessionsCount, visitorEnteredCount] = await Promise.all([
        storage.getDistinctFunnelSessionsSince(since),
        storage.getFunnelVisitorEnteredSince(since),
      ]);
      const serverSideVisits = stats.variants.reduce((sum, v) => sum + v.visits, 0);
      const previewTokenExpiresAtMs = Date.now() + AB_PREVIEW_TOKEN_TTL_MS;
      const variants = stats.variants.map((variant) => ({
        ...variant,
        previewToken: signAbPreviewToken(test.slug, variant.componentKey, previewTokenExpiresAtMs),
        previewTokenExpiresAt: new Date(previewTokenExpiresAtMs).toISOString(),
      }));
      res.json({
        test,
        ...stats,
        variants,
        integrity: {
          serverSideVisits,
          funnelSessionsCount,
          visitorEnteredCount,
          since: since.toISOString(),
        },
      });
    } catch (error: any) {
      console.error("[ab-tests] stats error:", error);
      res.status(500).json({ message: "Erro ao carregar estatísticas" });
    }
  });

  // GET /api/ab/assignment?testSlug=xxx — frontend reads variant
  app.get("/api/ab/assignment", async (req: any, res) => {
    const testSlug = String(req.query?.testSlug || "").trim();
    if (!testSlug) {
      return res.status(400).json({ message: "testSlug obrigatório" });
    }
    // Bots get a "no assignment" response so they never end up in stats.
    if (isBotRequest(req)) {
      return res.json({ componentKey: null });
    }
    try {
      const result = await resolveAssignmentBySlug(req, testSlug);
      if (!result) {
        return res.json({ componentKey: null });
      }
      const variant = result.test.variants.find((v) => v.id === result.variantId);
      res.json({
        componentKey: variant?.componentKey ?? null,
        variantId: result.variantId,
        testSlug: result.test.slug,
      });
    } catch (error: any) {
      console.error("[ab-assignment] error:", error);
      res.status(500).json({ message: "Erro ao buscar atribuição" });
    }
  });

  // ── Worker gateway config — admin orchestration metadata ───────────
  app.get("/api/admin/payment-gateways", requireAdminAuth, async (req: any, res) => {
    try {
      const { dateFrom, dateTo } = parseDateRange(req.query);
      const rangeError = getAdminDateRangeError(dateFrom, dateTo);
      if (rangeError) return res.status(400).json({ message: rangeError });
      const gatewayChargeCreatedAt = sql<Date>`coalesce(${pixPayments.createdAt}, ${paymentGatewayTransactions.createdAt})`;
      const gatewayPaidAt = sql<Date>`coalesce(${pixPayments.paidAt}, ${paymentGatewayTransactions.paidAt})`;
      const gatewayRefundedAt = sql<Date>`coalesce(${pixPayments.refundedAt}, ${paymentGatewayTransactions.refundedAt})`;
      const gatewayPaymentStatus = sql<string>`coalesce(${pixPayments.status}::text, ${paymentGatewayTransactions.status}::text)`;
      const gatewayAmountCents = sql<number>`coalesce(${pixPayments.amountCents}, ${paymentGatewayTransactions.amountCents})`;
      const gatewayHasGeneratedPix = sql<boolean>`(${pixPayments.id} is null or ${pixPayments.brCode} is not null)`;
      const gatewayMetricsRange = or(
        and(gte(gatewayChargeCreatedAt, dateFrom), lte(gatewayChargeCreatedAt, dateTo)),
        and(gte(gatewayPaidAt, dateFrom), lte(gatewayPaidAt, dateTo)),
        and(gte(gatewayRefundedAt, dateFrom), lte(gatewayRefundedAt, dateTo)),
      );
      const pixWithoutGatewayRange = or(
        and(gte(pixPayments.createdAt, dateFrom), lte(pixPayments.createdAt, dateTo)),
        and(gte(pixPayments.paidAt, dateFrom), lte(pixPayments.paidAt, dateTo)),
        and(gte(pixPayments.refundedAt, dateFrom), lte(pixPayments.refundedAt, dateTo)),
      );

      const [gateways, testRows, gatewayStatsRows, variantStatsRows, unassignedStatsRows, pixWithoutGatewayStatsRows, recentTransactionRows] = await Promise.all([
        db.select().from(paymentGateways).orderBy(asc(paymentGateways.createdAt)),
        db
          .select({
            test: paymentGatewayTests,
            variant: paymentGatewayTestVariants,
            gateway: paymentGateways,
          })
          .from(paymentGatewayTests)
          .leftJoin(paymentGatewayTestVariants, eq(paymentGatewayTestVariants.testId, paymentGatewayTests.id))
          .leftJoin(paymentGateways, eq(paymentGatewayTestVariants.gatewayId, paymentGateways.id))
          .orderBy(desc(paymentGatewayTests.createdAt), asc(paymentGatewayTestVariants.createdAt)),
        db
          .select({
            gatewayId: paymentGatewayTransactions.gatewayId,
            generated: sql<number>`count(*) filter (
              where ${gatewayChargeCreatedAt} >= ${dateFrom}
                and ${gatewayChargeCreatedAt} <= ${dateTo}
                and ${gatewayHasGeneratedPix}
            )::int`,
            converted: sql<number>`count(*) filter (
              where ${gatewayChargeCreatedAt} >= ${dateFrom}
                and ${gatewayChargeCreatedAt} <= ${dateTo}
                and ${gatewayHasGeneratedPix}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            )::int`,
            paid: sql<number>`count(*) filter (
              where ${gatewayPaidAt} >= ${dateFrom}
                and ${gatewayPaidAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            )::int`,
            activePaid: sql<number>`count(*) filter (
              where ${gatewayPaidAt} >= ${dateFrom}
                and ${gatewayPaidAt} <= ${dateTo}
                and ${gatewayPaymentStatus} = 'paid'
            )::int`,
            refunded: sql<number>`count(*) filter (
              where ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} = 'refunded'
            )::int`,
            chargedback: sql<number>`count(*) filter (
              where ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} = 'chargedback'
            )::int`,
            revenueCents: sql<number>`coalesce(sum(${gatewayAmountCents}) filter (
              where ${gatewayPaidAt} >= ${dateFrom}
                and ${gatewayPaidAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            ), 0)::int`,
            refundedCents: sql<number>`coalesce(sum(${gatewayAmountCents}) filter (
              where ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('refunded', 'chargedback')
            ), 0)::int`,
            lastCreatedAt: sql<Date>`max(${gatewayChargeCreatedAt}) filter (
              where ${gatewayChargeCreatedAt} >= ${dateFrom}
                and ${gatewayChargeCreatedAt} <= ${dateTo}
            )`,
          })
          .from(paymentGatewayTransactions)
          .leftJoin(pixPayments, eq(paymentGatewayTransactions.pixPaymentId, pixPayments.id))
          .where(gatewayMetricsRange)
          .groupBy(paymentGatewayTransactions.gatewayId),
        db
          .select({
            variantId: paymentGatewayTransactions.variantId,
            generated: sql<number>`count(*) filter (
              where ${gatewayChargeCreatedAt} >= ${dateFrom}
                and ${gatewayChargeCreatedAt} <= ${dateTo}
                and ${gatewayHasGeneratedPix}
            )::int`,
            converted: sql<number>`count(*) filter (
              where ${gatewayChargeCreatedAt} >= ${dateFrom}
                and ${gatewayChargeCreatedAt} <= ${dateTo}
                and ${gatewayHasGeneratedPix}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            )::int`,
            paid: sql<number>`count(*) filter (
              where ${gatewayPaidAt} >= ${dateFrom}
                and ${gatewayPaidAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            )::int`,
            refunded: sql<number>`count(*) filter (
              where ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} = 'refunded'
            )::int`,
            chargedback: sql<number>`count(*) filter (
              where ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} = 'chargedback'
            )::int`,
            revenueCents: sql<number>`coalesce(sum(${gatewayAmountCents}) filter (
              where ${gatewayPaidAt} >= ${dateFrom}
                and ${gatewayPaidAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            ), 0)::int`,
            refundedCents: sql<number>`coalesce(sum(${gatewayAmountCents}) filter (
              where ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('refunded', 'chargedback')
            ), 0)::int`,
          })
          .from(paymentGatewayTransactions)
          .leftJoin(pixPayments, eq(paymentGatewayTransactions.pixPaymentId, pixPayments.id))
          .where(gatewayMetricsRange)
          .groupBy(paymentGatewayTransactions.variantId),
        db
          .select({
            generated: sql<number>`count(*) filter (
              where ${paymentGatewayTransactions.gatewayId} is null
                and ${gatewayChargeCreatedAt} >= ${dateFrom}
                and ${gatewayChargeCreatedAt} <= ${dateTo}
                and ${gatewayHasGeneratedPix}
            )::int`,
            converted: sql<number>`count(*) filter (
              where ${paymentGatewayTransactions.gatewayId} is null
                and ${gatewayChargeCreatedAt} >= ${dateFrom}
                and ${gatewayChargeCreatedAt} <= ${dateTo}
                and ${gatewayHasGeneratedPix}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            )::int`,
            paid: sql<number>`count(*) filter (
              where ${paymentGatewayTransactions.gatewayId} is null
                and ${gatewayPaidAt} >= ${dateFrom}
                and ${gatewayPaidAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            )::int`,
            refunded: sql<number>`count(*) filter (
              where ${paymentGatewayTransactions.gatewayId} is null
                and ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} = 'refunded'
            )::int`,
            chargedback: sql<number>`count(*) filter (
              where ${paymentGatewayTransactions.gatewayId} is null
                and ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} = 'chargedback'
            )::int`,
            revenueCents: sql<number>`coalesce(sum(${gatewayAmountCents}) filter (
              where ${paymentGatewayTransactions.gatewayId} is null
                and ${gatewayPaidAt} >= ${dateFrom}
                and ${gatewayPaidAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('paid', 'refunded', 'chargedback')
            ), 0)::int`,
            refundedCents: sql<number>`coalesce(sum(${gatewayAmountCents}) filter (
              where ${paymentGatewayTransactions.gatewayId} is null
                and ${gatewayRefundedAt} >= ${dateFrom}
                and ${gatewayRefundedAt} <= ${dateTo}
                and ${gatewayPaymentStatus} in ('refunded', 'chargedback')
            ), 0)::int`,
          })
          .from(paymentGatewayTransactions)
          .leftJoin(pixPayments, eq(paymentGatewayTransactions.pixPaymentId, pixPayments.id))
          .where(gatewayMetricsRange),
        db
          .select({
            generated: sql<number>`count(*) filter (
              where ${pixPayments.brCode} is not null
                and ${pixPayments.createdAt} >= ${dateFrom}
                and ${pixPayments.createdAt} <= ${dateTo}
            )::int`,
            converted: sql<number>`count(*) filter (
              where ${pixPayments.brCode} is not null
                and ${pixPayments.createdAt} >= ${dateFrom}
                and ${pixPayments.createdAt} <= ${dateTo}
                and ${pixPayments.status} in ('paid', 'refunded', 'chargedback')
            )::int`,
            paid: sql<number>`count(*) filter (
              where ${pixPayments.paidAt} is not null
                and ${pixPayments.paidAt} >= ${dateFrom}
                and ${pixPayments.paidAt} <= ${dateTo}
                and ${pixPayments.status} in ('paid', 'refunded', 'chargedback')
            )::int`,
            refunded: sql<number>`count(*) filter (
              where ${pixPayments.status} = 'refunded'
                and ${pixPayments.refundedAt} is not null
                and ${pixPayments.refundedAt} >= ${dateFrom}
                and ${pixPayments.refundedAt} <= ${dateTo}
            )::int`,
            chargedback: sql<number>`count(*) filter (
              where ${pixPayments.status} = 'chargedback'
                and ${pixPayments.refundedAt} is not null
                and ${pixPayments.refundedAt} >= ${dateFrom}
                and ${pixPayments.refundedAt} <= ${dateTo}
            )::int`,
            revenueCents: sql<number>`coalesce(sum(${pixPayments.amountCents}) filter (
              where ${pixPayments.paidAt} is not null
                and ${pixPayments.paidAt} >= ${dateFrom}
                and ${pixPayments.paidAt} <= ${dateTo}
                and ${pixPayments.status} in ('paid', 'refunded', 'chargedback')
            ), 0)::int`,
            refundedCents: sql<number>`coalesce(sum(${pixPayments.amountCents}) filter (
              where ${pixPayments.status} in ('refunded', 'chargedback')
                and ${pixPayments.refundedAt} is not null
                and ${pixPayments.refundedAt} >= ${dateFrom}
                and ${pixPayments.refundedAt} <= ${dateTo}
            ), 0)::int`,
          })
          .from(pixPayments)
          .leftJoin(paymentGatewayTransactions, eq(paymentGatewayTransactions.pixPaymentId, pixPayments.id))
          .where(and(isNull(paymentGatewayTransactions.id), pixWithoutGatewayRange)),
        db
          .select({
            transaction: paymentGatewayTransactions,
            gateway: paymentGateways,
            test: paymentGatewayTests,
            variant: paymentGatewayTestVariants,
          })
          .from(paymentGatewayTransactions)
          .leftJoin(pixPayments, eq(paymentGatewayTransactions.pixPaymentId, pixPayments.id))
          .leftJoin(paymentGateways, eq(paymentGatewayTransactions.gatewayId, paymentGateways.id))
          .leftJoin(paymentGatewayTests, eq(paymentGatewayTransactions.testId, paymentGatewayTests.id))
          .leftJoin(paymentGatewayTestVariants, eq(paymentGatewayTransactions.variantId, paymentGatewayTestVariants.id))
          .where(gatewayMetricsRange)
          .orderBy(desc(paymentGatewayTransactions.createdAt))
          .limit(30),
      ]);

      const statsByGatewayId = new Map(gatewayStatsRows.map((row) => [row.gatewayId, row]));
      const statsByVariantId = new Map(variantStatsRows.map((row) => [row.variantId, row]));
      const testMap = new Map<string, PaymentGatewayTest & { variants: Array<PaymentGatewayTestVariant & { gateway: PaymentGateway | null; generated: number; converted: number; paid: number; refunded: number; chargedback: number; conversionRate: number; revenueCents: number; refundedCents: number; netRevenueCents: number }> }>();

      for (const row of testRows) {
        if (!row.test) continue;
        const current = testMap.get(row.test.id) ?? { ...row.test, variants: [] };
        if (row.variant) {
          const stats = statsByVariantId.get(row.variant.id);
          const generated = Number(stats?.generated || 0);
          const converted = Number(stats?.converted || 0);
          current.variants.push({
            ...row.variant,
            gateway: row.gateway ?? null,
            generated,
            converted,
            paid: Number(stats?.paid || 0),
            refunded: Number(stats?.refunded || 0),
            chargedback: Number(stats?.chargedback || 0),
            conversionRate: generated > 0 ? converted / generated : 0,
            revenueCents: Number(stats?.revenueCents || 0),
            refundedCents: Number(stats?.refundedCents || 0),
            netRevenueCents: Number(stats?.revenueCents || 0) - Number(stats?.refundedCents || 0),
          });
        }
        testMap.set(row.test.id, current);
      }

      const unassignedStats = unassignedStatsRows[0];
      const pixWithoutGatewayStats = pixWithoutGatewayStatsRows[0];
      const unassignedGenerated = Number(unassignedStats?.generated || 0) + Number(pixWithoutGatewayStats?.generated || 0);
      const unassignedPaid = Number(unassignedStats?.paid || 0) + Number(pixWithoutGatewayStats?.paid || 0);
      const unassignedConverted = Number(unassignedStats?.converted || 0) + Number(pixWithoutGatewayStats?.converted || 0);
      const unassignedRefunded = Number(unassignedStats?.refunded || 0) + Number(pixWithoutGatewayStats?.refunded || 0);
      const unassignedChargedback = Number(unassignedStats?.chargedback || 0) + Number(pixWithoutGatewayStats?.chargedback || 0);
      const unassignedRevenueCents = Number(unassignedStats?.revenueCents || 0) + Number(pixWithoutGatewayStats?.revenueCents || 0);
      const unassignedRefundedCents = Number(unassignedStats?.refundedCents || 0) + Number(pixWithoutGatewayStats?.refundedCents || 0);

      res.json({
        dateFrom: dateFrom.toISOString(),
        dateTo: dateTo.toISOString(),
        gateways: gateways.map((gateway) => {
          const stats = statsByGatewayId.get(gateway.id);
          const generated = Number(stats?.generated || 0);
          const paid = Number(stats?.paid || 0);
          const converted = Number(stats?.converted || 0);
          return {
            ...gateway,
            generated,
            converted,
            paid,
            activePaid: Number(stats?.activePaid || 0),
            refunded: Number(stats?.refunded || 0),
            chargedback: Number(stats?.chargedback || 0),
            conversionRate: generated > 0 ? converted / generated : 0,
            revenueCents: Number(stats?.revenueCents || 0),
            refundedCents: Number(stats?.refundedCents || 0),
            netRevenueCents: Number(stats?.revenueCents || 0) - Number(stats?.refundedCents || 0),
            lastCreatedAt: stats?.lastCreatedAt ?? null,
          };
        }),
        tests: Array.from(testMap.values()),
        fallback: {
          generated: unassignedGenerated,
          converted: unassignedConverted,
          paid: unassignedPaid,
          refunded: unassignedRefunded,
          chargedback: unassignedChargedback,
          conversionRate: unassignedGenerated > 0 ? unassignedConverted / unassignedGenerated : 0,
          revenueCents: unassignedRevenueCents,
          refundedCents: unassignedRefundedCents,
          netRevenueCents: unassignedRevenueCents - unassignedRefundedCents,
          failedGatewayAttempts: 0,
        },
        recentTransactions: recentTransactionRows.map((row) => ({
          id: row.transaction.id,
          pixPaymentId: row.transaction.pixPaymentId,
          gatewayId: row.transaction.gatewayId,
          provider: row.transaction.provider,
          providerTransactionId: row.transaction.providerTransactionId,
          externalReference: row.transaction.externalReference,
          status: row.transaction.status,
          amountCents: row.transaction.amountCents,
          planId: row.transaction.planId,
          lastEvent: row.transaction.lastEvent,
          createdAt: row.transaction.createdAt,
          paidAt: row.transaction.paidAt,
          gateway: row.gateway ? { id: row.gateway.id, name: row.gateway.name, slug: row.gateway.slug } : null,
          test: row.test ? { id: row.test.id, name: row.test.name, slug: row.test.slug } : null,
          variant: row.variant ? { id: row.variant.id, name: row.variant.name } : null,
          errorMessage: row.transaction.errorMessage,
          fallbackReason: null,
          fallbackDetail: null,
          attemptedGatewaySlug: null,
          attemptedGatewayProvider: null,
          failedGatewayTransactionId: null,
          failedPixPaymentId: null,
        })),
        diagnostics: { degraded: false, errors: [] },
      });
    } catch (error: any) {
      console.error("[payment-gateways] list error:", error);
      res.status(500).json({ message: "Erro ao carregar gateways de pagamento" });
    }
  });

  app.post("/api/admin/payment-gateways", requireAdminAuth, async (req: any, res) => {
    const parsed = paymentGatewayCreateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: parsed.error.errors[0]?.message || "Dados inválidos" });
    try {
      const [gateway] = await db.insert(paymentGateways).values({
        ...parsed.data,
        description: parsed.data.description ?? null,
        updatedAt: new Date(),
      }).returning();
      res.json({ gateway });
    } catch (error: any) {
      if (error?.code === "23505") return res.status(409).json({ message: "Slug já está em uso" });
      console.error("[payment-gateways] create error:", error);
      res.status(500).json({ message: "Erro ao criar gateway" });
    }
  });

  app.patch("/api/admin/payment-gateways/:id", requireAdminAuth, async (req: any, res) => {
    const id = String(req.params.id || "").trim();
    if (!id) return res.status(400).json({ message: "ID inválido" });
    const parsed = paymentGatewayUpdateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: parsed.error.errors[0]?.message || "Dados inválidos" });
    try {
      const [gateway] = await db.update(paymentGateways).set({ ...parsed.data, updatedAt: new Date() }).where(eq(paymentGateways.id, id)).returning();
      if (!gateway) return res.status(404).json({ message: "Gateway não encontrado" });
      res.json({ gateway });
    } catch (error: any) {
      console.error("[payment-gateways] update error:", error);
      res.status(500).json({ message: "Erro ao atualizar gateway" });
    }
  });

  app.post("/api/admin/payment-gateway-tests", requireAdminAuth, async (req: any, res) => {
    const parsed = paymentGatewayTestCreateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: parsed.error.errors[0]?.message || "Dados inválidos" });
    if (!weightsSumTo100(parsed.data.variants)) return res.status(400).json({ message: "A soma dos pesos deve ser 100%" });
    try {
      const gatewayIds = Array.from(new Set(parsed.data.variants.map((variant) => variant.gatewayId)));
      const existingGateways = await db.select().from(paymentGateways).where(inArray(paymentGateways.id, gatewayIds));
      if (existingGateways.length !== gatewayIds.length) return res.status(400).json({ message: "Um ou mais gateways não existem" });
      const gatewayById = new Map(existingGateways.map((gateway) => [gateway.id, gateway]));
      const test = await db.transaction(async (tx) => {
        const [created] = await tx.insert(paymentGatewayTests).values({
          name: parsed.data.name,
          slug: parsed.data.slug,
          status: parsed.data.status,
          updatedAt: new Date(),
        }).returning();
        await tx.insert(paymentGatewayTestVariants).values(parsed.data.variants.map((variant) => ({
          testId: created.id,
          gatewayId: variant.gatewayId,
          name: variant.name?.trim() || gatewayById.get(variant.gatewayId)?.name || "Gateway",
          weight: variant.weight,
        })));
        return created;
      });
      res.json({ test });
    } catch (error: any) {
      if (error?.code === "23505") return res.status(409).json({ message: "Slug já está em uso" });
      console.error("[payment-gateway-tests] create error:", error);
      res.status(500).json({ message: "Erro ao criar teste de gateway" });
    }
  });

  app.patch("/api/admin/payment-gateway-tests/:id", requireAdminAuth, async (req: any, res) => {
    const id = String(req.params.id || "").trim();
    if (!id) return res.status(400).json({ message: "ID inválido" });
    const parsed = paymentGatewayTestUpdateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: parsed.error.errors[0]?.message || "Dados inválidos" });
    if (parsed.data.variants && !weightsSumTo100(parsed.data.variants)) return res.status(400).json({ message: "A soma dos pesos deve ser 100%" });
    try {
      const [existing] = await db.select().from(paymentGatewayTests).where(eq(paymentGatewayTests.id, id)).limit(1);
      if (!existing) return res.status(404).json({ message: "Teste não encontrado" });
      if (parsed.data.variants) {
        const currentVariants = await db.select({ id: paymentGatewayTestVariants.id }).from(paymentGatewayTestVariants).where(eq(paymentGatewayTestVariants.testId, id));
        const currentIds = new Set(currentVariants.map((variant) => variant.id));
        const submittedIds = new Set(parsed.data.variants.map((variant) => variant.id));
        const isComplete = currentIds.size === submittedIds.size && Array.from(currentIds).every((variantId) => submittedIds.has(variantId));
        if (!isComplete) return res.status(400).json({ message: "Envie pesos para todas as variantes" });
      }
      await db.transaction(async (tx) => {
        if (parsed.data.status) {
          await tx.update(paymentGatewayTests).set({ status: parsed.data.status, updatedAt: new Date() }).where(eq(paymentGatewayTests.id, id));
        }
        if (parsed.data.variants) {
          for (const variant of parsed.data.variants) {
            await tx.update(paymentGatewayTestVariants).set({ weight: variant.weight }).where(and(eq(paymentGatewayTestVariants.id, variant.id), eq(paymentGatewayTestVariants.testId, id)));
          }
        }
      });
      res.json({ success: true });
    } catch (error: any) {
      console.error("[payment-gateway-tests] update error:", error);
      res.status(500).json({ message: "Erro ao atualizar teste de gateway" });
    }
  });

  app.get("/api/internal/payment-gateway-config", async (req: any, res) => {
    const secret = (process.env.DESIREAI_INTERNAL_SECRET || "").trim();
    if (!secret) {
      console.error("[payment-gateway-config] DESIREAI_INTERNAL_SECRET not configured");
      return res.status(503).json({ message: "Endpoint interno não configurado" });
    }
    if (!verifyInternalBearerSecret(req, secret)) {
      return res.status(401).json({ message: "Não autorizado" });
    }

    try {
      const [gateways, activeTests] = await Promise.all([
        db
          .select({
            id: paymentGateways.id,
            name: paymentGateways.name,
            slug: paymentGateways.slug,
            provider: paymentGateways.provider,
            description: paymentGateways.description,
          })
          .from(paymentGateways)
          .where(eq(paymentGateways.status, "active"))
          .orderBy(asc(paymentGateways.createdAt)),
        db
          .select()
          .from(paymentGatewayTests)
          .where(eq(paymentGatewayTests.status, "active"))
          .orderBy(desc(paymentGatewayTests.createdAt))
          .limit(1),
      ]);

      const activeTest = activeTests[0] ?? null;
      const variants = activeTest
        ? await db
          .select({
            id: paymentGatewayTestVariants.id,
            testId: paymentGatewayTestVariants.testId,
            gatewayId: paymentGatewayTestVariants.gatewayId,
            name: paymentGatewayTestVariants.name,
            weight: paymentGatewayTestVariants.weight,
            gateway: {
              id: paymentGateways.id,
              name: paymentGateways.name,
              slug: paymentGateways.slug,
              provider: paymentGateways.provider,
            },
          })
          .from(paymentGatewayTestVariants)
          .innerJoin(paymentGateways, eq(paymentGatewayTestVariants.gatewayId, paymentGateways.id))
          .where(and(
            eq(paymentGatewayTestVariants.testId, activeTest.id),
            eq(paymentGateways.status, "active"),
          ))
          .orderBy(asc(paymentGatewayTestVariants.createdAt))
        : [];

      res.json({
        generatedAt: new Date().toISOString(),
        gateways,
        activeTest: activeTest ? {
          id: activeTest.id,
          name: activeTest.name,
          slug: activeTest.slug,
          variants,
        } : null,
      });
    } catch (error: any) {
      console.error("[payment-gateway-config] error:", error);
      res.status(500).json({ message: "Erro ao carregar configuração de gateways" });
    }
  });

  // ── IP Whitelist — skip all blocking for these IPs ──
  const IP_WHITELIST = new Set(["187.19.173.252", "191.57.5.210"]);

  function getClientIp(req: any): string {
    const forwarded = req.headers["x-forwarded-for"];
    if (forwarded) return String(forwarded).split(",")[0].trim();
    return req.ip || req.socket?.remoteAddress || "";
  }

  // ── POST /api/fingerprint/check-visitor — detect recurring visitors ──
  app.post("/api/fingerprint/check-visitor", async (req, res) => {
    try {
      const { visitorId } = req.body ?? {};
      if (!visitorId || typeof visitorId !== "string") {
        return res.json({ registered: false });
      }

      // Look up all users linked to this visitorId
      const matches = await storage.findUsersByFingerprint(visitorId);
      if (matches.length === 0) {
        return res.json({ registered: false });
      }

      // Check if any linked user has a paid PIX (= active plan)
      for (const match of matches) {
        const [paidPix] = await db
          .select({ id: pixPayments.id })
          .from(pixPayments)
          .where(and(eq(pixPayments.userId, match.userId), eq(pixPayments.status, "paid")))
          .limit(1);
        if (paidPix) {
          return res.json({ registered: true, hasActivePlan: true });
        }
      }

      // Registered but no active plan → show paywall
      return res.json({ registered: true, hasActivePlan: false });
    } catch (error: any) {
      console.error("[fingerprint/check-visitor] Error:", error);
      // Fail open — don't block legitimate users on errors
      return res.json({ registered: false });
    }
  });

  // ── POST /api/auth/register-funnel ────────────────────────────────
  app.post("/api/auth/register-funnel", withSessionId, async (req: any, res) => {
    try {
      const parsed = registerFunnelSchema.safeParse(req.body);
      if (!parsed.success) {
        const firstError = parsed.error.errors[0]?.message || "Dados inválidos";
        return res.status(400).json({ message: firstError });
      }

      const { username, password, visitorId, source } = parsed.data;
      const isLandingEmbeddedLogin = source === "landing_embedded_login";
      const existingSession = req.session as any;
      if (existingSession?.userId) {
        const currentUser = await storage.getUser(existingSession.userId);
        if (currentUser) {
          existingSession.allowFunnelFreeGeneration = true;
          await new Promise<void>((resolve, reject) => {
            req.session.save((err: any) => {
              if (err) reject(err);
              else resolve();
            });
          });
          if (isLandingEmbeddedLogin) {
            await trackFunnelStep(req, {
              step: "photo_uploaded",
              eventName: "landing.funnel_login_success",
              idempotencyKey: `landing:funnel_login_success:${getSessionId(req)}`,
              customerName: currentUser.username,
              metadata: {
                source,
                alreadyAuthenticated: true,
              },
            });
          }
          return res.json({
            success: true,
            alreadyAuthenticated: true,
            user: {
              id: currentUser.id,
              username: currentUser.username,
            },
          });
        }
      }

      const oldUserId = req.userId;

      const ensureUserCreditsInTx = async (tx: any, userId: string) => {
        await tx
          .insert(userCredits)
          .values({
            userId,
            balance: 0,
            totalPurchased: 0,
            totalSpent: 0,
            hasPurchased: false,
            dailyCreditsAccumulated: 0,
            lastDailyCredits: new Date(),
          })
          .onConflictDoNothing({ target: userCredits.userId });
      };

      const transferAnonymousStateInTx = async (tx: any, anonymousUserId: string | null | undefined, targetUserId: string) => {
        if (!anonymousUserId || anonymousUserId === targetUserId) return;

        await tx.update(generatedImages)
          .set({ userId: targetUserId })
          .where(eq(generatedImages.userId, anonymousUserId));

        await tx.update(pixPayments)
          .set({ userId: targetUserId })
          .where(or(eq(pixPayments.userId, anonymousUserId), eq(pixPayments.sessionId, anonymousUserId)));

        await tx.update(videoPovRequests)
          .set({ userId: targetUserId, updatedAt: new Date() })
          .where(eq(videoPovRequests.userId, anonymousUserId));

        const [anonymousCredits] = await tx
          .select()
          .from(userCredits)
          .where(eq(userCredits.userId, anonymousUserId))
          .for("update")
          .limit(1);

        if (!anonymousCredits) return;

        await tx.update(userCredits)
          .set({
            balance: sql`${userCredits.balance} + ${anonymousCredits.balance}`,
            totalPurchased: sql`${userCredits.totalPurchased} + ${anonymousCredits.totalPurchased}`,
            totalSpent: sql`${userCredits.totalSpent} + ${anonymousCredits.totalSpent}`,
            updatedAt: new Date(),
          })
          .where(eq(userCredits.userId, targetUserId));

        await tx.update(creditTransactions)
          .set({ userId: targetUserId })
          .where(eq(creditTransactions.userId, anonymousUserId));

        await tx.delete(userCredits)
          .where(eq(userCredits.userId, anonymousUserId));
      };

      const finishFunnelRegistration = async (
        user: typeof users.$inferSelect,
        options: { recoveredExistingUser?: boolean } = {},
      ) => {
        const session = req.session as any;
        session.userId = user.id;
        session.allowFunnelFreeGeneration = true;
        await saveSession(req);

        req.userId = user.id;

        try {
          await storage.upsertFunnelSession({
            sessionId: getSessionId(req),
            userId: user.id,
          });
        } catch (err) {
          console.error("[register-funnel] Error linking funnel session:", err);
        }

        if (isLandingEmbeddedLogin) {
          try {
            await trackFunnelStep(req, {
              step: "photo_uploaded",
              eventName: "landing.funnel_login_success",
              idempotencyKey: `landing:funnel_login_success:${getSessionId(req)}`,
              customerName: user.username,
              metadata: {
                source,
                recoveredExistingUser: options.recoveredExistingUser === true,
              },
            });
          } catch (err) {
            console.error("[register-funnel] Error tracking signup success:", err);
          }
        }

        if (visitorId && typeof visitorId === "string" && visitorId.trim()) {
          try {
            await storage.upsertUserFingerprint({
              userId: user.id,
              fingerprintId: visitorId.trim(),
            });
          } catch (err) {
            console.error("[register-funnel] Error saving visitorId:", err);
          }
        }

        try {
          const anonId = req.sessionID || null;
          if (anonId) posthogAlias(anonId, String(user.id));
          posthogIdentify(String(user.id), { username: user.username });
          posthogCapture({
            req,
            distinctId: String(user.id),
            event: options.recoveredExistingUser ? "user registration recovered" : "user registered",
            properties: { username: user.username },
          });
        } catch (err) {
          console.error("[register-funnel] Error sending analytics:", err);
        }

        return res.json({
          success: true,
          recoveredExistingUser: options.recoveredExistingUser === true,
          user: {
            id: user.id,
            username: user.username,
          },
        });
      };

      const [existingUser] = await db
        .select()
        .from(users)
        .where(eq(users.username, username))
        .limit(1);

      if (existingUser) {
        if (existingUser.isDeactivated) {
          return res.status(403).json({ message: "Esta conta foi desativada" });
        }

        const passwordMatches = existingUser.passwordHash
          ? await bcrypt.compare(password, existingUser.passwordHash)
          : false;
        if (!passwordMatches) {
          return res.status(409).json({ message: "Este username já está em uso" });
        }

        await db.transaction(async (tx) => {
          await ensureUserCreditsInTx(tx, existingUser.id);
          await transferAnonymousStateInTx(tx, oldUserId, existingUser.id);
        });

        return await finishFunnelRegistration(existingUser, { recoveredExistingUser: true });
      }

      const passwordHash = await bcrypt.hash(password, 10);

      const newUser = await db.transaction(async (tx) => {
        const [createdUser] = await tx
          .insert(users)
          .values({
            username,
            passwordHash,
            role: "visitor",
          })
          .onConflictDoNothing({ target: users.username })
          .returning();

        if (!createdUser) return null;

        await ensureUserCreditsInTx(tx, createdUser.id);
        await transferAnonymousStateInTx(tx, oldUserId, createdUser.id);
        return createdUser;
      });

      if (!newUser) {
        const [racedUser] = await db
          .select()
          .from(users)
          .where(eq(users.username, username))
          .limit(1);

        if (!racedUser || !racedUser.passwordHash || racedUser.isDeactivated) {
          return res.status(409).json({ message: "Este username já está em uso" });
        }

        const passwordMatches = await bcrypt.compare(password, racedUser.passwordHash);
        if (!passwordMatches) {
          return res.status(409).json({ message: "Este username já está em uso" });
        }

        await db.transaction(async (tx) => {
          await ensureUserCreditsInTx(tx, racedUser.id);
          await transferAnonymousStateInTx(tx, oldUserId, racedUser.id);
        });

        return await finishFunnelRegistration(racedUser, { recoveredExistingUser: true });
      }

      return await finishFunnelRegistration(newUser);
    } catch (error: any) {
      posthogCaptureException(error, { req });
      console.error("Error in register-funnel:", error);
      res.status(500).json({ message: "Erro ao criar conta" });
    }
  });

  // ── POST /api/auth/send-verification (FAKE) ─────────────
  // This endpoint is invoked by the Fingerprint EmailVerificationGate.
  // We do NOT send any real email, it's just a visual barrier to stick bots in an infinite loop.
  app.post("/api/auth/send-verification", async (req, res) => {
    // Artificial delay to make it look legit
    await new Promise((resolve) => setTimeout(resolve, 800));
    res.json({ success: true });
  });

  // ── POST /api/video-pov-requests — save landing POV preferences ─────
  const POV_POSITION_OPTIONS = ["de_quatro", "papai_mamae", "sentando", "mamando"] as const;
  const POV_HOLE_OPTIONS = ["buceta", "cuzinho", "boca"] as const;
  const POV_SEX_TYPE_OPTIONS = ["amorzinho", "hard_fuck", "misturado"] as const;
  const POV_SPEECH_TYPE_OPTIONS = ["carinhosa", "ninfomaniaca", "sexo_agressivo"] as const;

  app.post("/api/video-pov-preview/prewarm", withSessionId, async (req: any, res) => {
    try {
      if (!req.userId) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const generatedImageId = typeof req.body?.generatedImageId === "string"
        ? req.body.generatedImageId.trim()
        : "";
      if (!generatedImageId) {
        return res.status(400).json({ message: "Imagem gerada obrigatória" });
      }

      const generatedImage = await storage.getGeneratedImage(generatedImageId);
      const isCompletedOwnerImage = generatedImage
        && generatedImage.userId === req.userId
        && generatedImage.status === "completed"
        && Boolean(generatedImage.imageUrl);

      if (!isCompletedOwnerImage) {
        return res.status(403).json({ message: "Finalize a geração da imagem antes de preparar o vídeo POV." });
      }

      const requestSessionId = getSessionId(req);
      const [funnelSession] = await db
        .select({ uploadedPhotoUrl: funnelSessions.uploadedPhotoUrl })
        .from(funnelSessions)
        .where(eq(funnelSessions.sessionId, requestSessionId))
        .limit(1);

      const previewAnalysisImageUrl = isAllowedPovPreviewAnalysisImageUrl(funnelSession?.uploadedPhotoUrl, req)
        ? funnelSession?.uploadedPhotoUrl ?? null
        : null;

      if (!previewAnalysisImageUrl) {
        return res.status(202).json({
          success: false,
          status: "skipped",
          message: "Imagem de análise indisponível",
        });
      }

      const entry = startPovPreviewPrewarm({
        userId: String(req.userId),
        sessionId: requestSessionId,
        imageUrl: previewAnalysisImageUrl,
      });

      return res.status(202).json({
        success: Boolean(entry),
        status: entry?.status || "disabled",
      });
    } catch (error: any) {
      console.error("[video-pov-preview-prewarm] Error:", error);
      return res.status(500).json({ message: "Falha ao preparar preview do vídeo POV" });
    }
  });

  app.post("/api/video-pov-requests", withSessionId, async (req: any, res) => {
    try {
      if (!req.userId) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const { position, hole, sexType, speechType } = req.body ?? {};
      const generatedImageId = typeof req.body?.generatedImageId === "string"
        ? req.body.generatedImageId.trim()
        : "";
      const requestSessionId = getSessionId(req);

      if (!POV_POSITION_OPTIONS.includes(position)) {
        return res.status(400).json({ message: "Posição inválida" });
      }
      if (!POV_HOLE_OPTIONS.includes(hole)) {
        return res.status(400).json({ message: "Buraco inválido" });
      }
      if (!POV_SEX_TYPE_OPTIONS.includes(sexType)) {
        return res.status(400).json({ message: "Tipo de foda inválido" });
      }
      if (!POV_SPEECH_TYPE_OPTIONS.includes(speechType)) {
        return res.status(400).json({ message: "Tipo de fala e gemidos inválido" });
      }

      if (!consumeVideoPovRequestAttempt(String(req.userId))) {
        return res.status(429).json({ message: "Muitas tentativas. Tente novamente em alguns segundos." });
      }

      if (generatedImageId) {
        const generatedImage = await storage.getGeneratedImage(generatedImageId);
        const isCompletedOwnerImage = generatedImage
          && generatedImage.userId === req.userId
          && generatedImage.status === "completed"
          && Boolean(generatedImage.imageUrl);

        if (!isCompletedOwnerImage) {
          return res.status(403).json({ message: "Finalize a geração da imagem antes de gerar o vídeo POV." });
        }
      } else {
        const hasCompleted = await storage.userHasCompletedGeneratedImage(req.userId);
        if (!hasCompleted) {
          return res.status(403).json({ message: "Finalize a geração da imagem antes de gerar o vídeo POV." });
        }
      }

      const [funnelSession] = await db
        .select({ uploadedPhotoUrl: funnelSessions.uploadedPhotoUrl })
        .from(funnelSessions)
        .where(eq(funnelSessions.sessionId, requestSessionId))
        .limit(1);

      const previewAnalysisImageUrl = isAllowedPovPreviewAnalysisImageUrl(funnelSession?.uploadedPhotoUrl, req)
        ? funnelSession?.uploadedPhotoUrl ?? null
        : null;
      const canRunPreviewAnalysis = Boolean(previewAnalysisImageUrl && normalizePovPreviewPosition(position));

      const recentRequest = await storage.getRecentVideoPovRequestByFingerprint(req.userId, requestSessionId, {
        position,
        hole,
        sexType,
        speechType,
        previewAnalysisImageUrl,
        since: new Date(Date.now() - VIDEO_POV_REQUEST_REUSE_WINDOW_MS),
      });

      if (recentRequest) {
        const recentPreviewStatus = readPovPreviewAnalysisStatus(recentRequest.previewAnalysisStatus);
        const shouldReuseRecentRequest = recentPreviewStatus !== "failed" || !canRunPreviewAnalysis;
        if (
          shouldReuseRecentRequest
          && canRunPreviewAnalysis
          && recentRequest.previewAnalysisImageUrl
          && recentPreviewStatus !== "completed"
          && recentPreviewStatus !== "failed"
        ) {
          schedulePovPreviewAnalysis(recentRequest.id);
        }

        if (shouldReuseRecentRequest) {
          await trackFunnelStep(req, {
            step: "offer_responded",
            eventName: "offer.video_pov_submitted",
            idempotencyKey: `offer_responded:${requestSessionId}:${recentRequest.id}`,
            metadata: {
              requestId: recentRequest.id,
              position,
              hole,
              sexType,
              speechType,
              previewAnalysisStatus: recentPreviewStatus === "failed"
                ? "fallback"
                : recentPreviewStatus,
              reused: true,
            },
          });

          return res.json({
            success: true,
            requestId: recentRequest.id,
            previewAnalysisStatus: recentPreviewStatus === "failed"
              ? "fallback"
              : recentPreviewStatus,
            reused: true,
          });
        }
      }

      const request = await storage.createVideoPovRequest(req.userId, {
        sessionId: requestSessionId,
        position,
        hole,
        sexType,
        speechType,
        amountCents: 1990,
        previewAnalysisImageUrl,
        previewAnalysisStatus: canRunPreviewAnalysis ? "pending" : "failed",
      });

      await trackFunnelStep(req, {
        step: "offer_responded",
        eventName: "offer.video_pov_submitted",
        idempotencyKey: `offer_responded:${requestSessionId}:${request.id}`,
        metadata: {
          requestId: request.id,
          position,
          hole,
          sexType,
          speechType,
          previewAnalysisStatus: canRunPreviewAnalysis ? "pending" : "fallback",
        },
      });

      posthogCapture({
        req,
        distinctId: String(req.userId),
        event: "video pov requested",
        properties: {
          position,
          hole,
          sex_type: sexType,
          speech_type: speechType,
          request_id: request.id,
          preview_analysis_enabled: canRunPreviewAnalysis,
        },
      });

      if (canRunPreviewAnalysis) {
        schedulePovPreviewAnalysis(request.id);
      }

      res.json({
        success: true,
        requestId: request.id,
        previewAnalysisStatus: canRunPreviewAnalysis ? "pending" : "fallback",
      });
    } catch (error: any) {
      posthogCaptureException(error, { req });
      console.error("[video-pov-requests] Error:", error);
      res.status(500).json({ message: "Falha ao salvar preferências do vídeo POV" });
    }
  });

  app.get("/api/video-pov-requests/:requestId/preview", withSessionId, async (req: any, res) => {
    try {
      if (!req.userId) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const request = await storage.getVideoPovRequest(String(req.params.requestId || ""));
      if (!request || request.userId !== req.userId) {
        return res.status(404).json({ message: "Preview não encontrado" });
      }

      const hasCompleted = await storage.userHasCompletedGeneratedImage(req.userId);
      if (!hasCompleted) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const previewAnalysisStatus = readPovPreviewAnalysisStatus(request.previewAnalysisStatus);
      if (
        previewAnalysisStatus !== "completed"
        && previewAnalysisStatus !== "failed"
        && request.previewAnalysisImageUrl
      ) {
        schedulePovPreviewAnalysis(request.id);
      }

      const resolved = resolvePovPreviewUpstreamUrl(request);
      if (!resolved.url) {
        return res.status(404).json({ message: "Preview não configurado" });
      }
      const posterUrl = !resolved.fallback ? getPovPreviewPosterUrl(request.previewVideoKey) : null;
      const safePosterUrl = posterUrl && isAllowedGeneratedMediaUrl(posterUrl) ? posterUrl : null;
      const mediaVersion = buildPovPreviewMediaVersion(request, previewAnalysisStatus, resolved);
      const streamPath = appendQueryParam(`/api/video-pov-requests/${request.id}/preview/stream`, "v", mediaVersion);
      const posterPath = appendQueryParam(`/api/video-pov-requests/${request.id}/preview/poster`, "v", mediaVersion);

      res.setHeader("Cache-Control", "private, no-store");
      res.json({
        status: previewAnalysisStatus,
        fallback: resolved.fallback,
        provider: request.previewAnalysisProvider,
        videoUrl: streamPath,
        posterUrl: safePosterUrl ? posterPath : null,
      });
    } catch (error: any) {
      console.error("[video-pov-preview]", error.message);
      res.status(500).json({ message: "Erro ao preparar preview" });
    }
  });

  app.get("/api/video-pov-requests/:requestId/preview/stream", withSessionId, async (req: any, res) => {
    try {
      if (!req.userId) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const request = await storage.getVideoPovRequest(String(req.params.requestId || ""));
      if (!request || request.userId !== req.userId) {
        return res.status(404).json({ message: "Preview não encontrado" });
      }

      const hasCompleted = await storage.userHasCompletedGeneratedImage(req.userId);
      if (!hasCompleted) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const resolved = resolvePovPreviewUpstreamUrl(request);
      if (!resolved.url) {
        return res.status(404).json({ message: "Preview não configurado" });
      }
      if (!isAllowedGeneratedMediaUrl(resolved.url)) {
        return res.status(502).json({ message: "URL de preview não permitida" });
      }

      const streamed = await streamProxiedMedia(req, res, {
        url: resolved.url,
        cacheControl: "private, max-age=300",
      });
      if (!streamed) return res.status(502).json({ message: "Erro ao buscar preview" });
      return;
    } catch (error: any) {
      console.error("[video-pov-preview-stream]", error.message);
      res.status(500).json({ message: "Erro ao servir preview" });
    }
  });

  app.get("/api/video-pov-requests/:requestId/preview/poster", withSessionId, async (req: any, res) => {
    try {
      if (!req.userId) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const request = await storage.getVideoPovRequest(String(req.params.requestId || ""));
      if (!request || request.userId !== req.userId) {
        return res.status(404).json({ message: "Thumbnail não encontrada" });
      }

      const hasCompleted = await storage.userHasCompletedGeneratedImage(req.userId);
      if (!hasCompleted) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const resolved = resolvePovPreviewUpstreamUrl(request);
      if (resolved.fallback) {
        return res.status(404).json({ message: "Thumbnail não configurada" });
      }

      const url = getPovPreviewPosterUrl(request.previewVideoKey);
      if (!url) {
        return res.status(404).json({ message: "Thumbnail não configurada" });
      }
      if (!isAllowedGeneratedMediaUrl(url)) {
        return res.status(502).json({ message: "URL de thumbnail não permitida" });
      }

      const streamed = await streamProxiedMedia(req, res, {
        url,
        cacheControl: "private, max-age=300",
      });
      if (!streamed) return res.status(502).json({ message: "Erro ao buscar thumbnail" });
      return;
    } catch (error: any) {
      console.error("[video-pov-preview-poster]", error.message);
      res.status(500).json({ message: "Erro ao servir thumbnail" });
    }
  });

  // ── POST /api/pix/create — Cloudflare Worker PIX charge creation ─────
  const PIX_TESTER_PLAN_ID = "pix-tester-1000";
  const PIX_TESTER_PRODUCT_NAME = "PIX Teste DesireAI";

  const getPixWorkerCreateUrl = () => {
    const explicitUrl = (process.env.PIX_WORKER_CREATE_URL || "").trim();
    if (explicitUrl) return explicitUrl;

    const gatewayBaseUrl = (process.env.PAYMENT_GATEWAY_URL || "").trim().replace(/\/+$/, "");
    return gatewayBaseUrl ? `${gatewayBaseUrl}/v1/internal/payments/pix` : "";
  };
  const getPixWorkerBearerSecret = () => (
    process.env.GATEWAY_INTERNAL_SECRET
    || process.env.PAYMENT_GATEWAY_INTERNAL_SECRET
    || ""
  ).trim();
  const getPixWorkerSigningSecret = () => (process.env.DESIREAI_INTERNAL_SECRET || "").trim();

  async function waitForPixCreateDbFallback(paymentId: string): Promise<{
    payment: PixPayment | null;
    qrcode: string;
    transactionId: string;
  }> {
    for (let attempt = 0; attempt < 6; attempt += 1) {
      const payment = await storage.getPixPayment(paymentId).catch(() => null);
      const qrcode = normalizePixCopyPaste(payment?.brCode);
      const transactionId = payment?.abacatePayId && !payment.abacatePayId.startsWith("pending:")
        ? payment.abacatePayId
        : "";
      if (payment && (qrcode || transactionId)) {
        return { payment, qrcode, transactionId };
      }
      if (attempt < 5) {
        await new Promise((resolve) => setTimeout(resolve, 250));
      }
    }
    return { payment: null, qrcode: "", transactionId: "" };
  }

  function getPixWorkerCreateSoftTimeoutMs() {
    const configured = Number(process.env.PIX_WORKER_CREATE_SOFT_TIMEOUT_MS);
    return Number.isFinite(configured) && configured >= 1000 && configured <= 12000 ? configured : 3000;
  }

  function getPixWorkerCreateHardTimeoutMs() {
    const configured = Number(process.env.PIX_WORKER_CREATE_TIMEOUT_MS || process.env.PIX_LEGACY_CREATE_TIMEOUT_MS);
    return Number.isFinite(configured) && configured >= 5000 && configured <= 60000 ? configured : 45000;
  }

  function getPixWorkerCreateStatusUrl(paymentId: string) {
    const createUrl = getPixWorkerCreateUrl().replace(/\/+$/, "");
    return createUrl ? `${createUrl}/${encodeURIComponent(paymentId)}` : "";
  }

  function isTerminalPixPaymentStatus(status: unknown) {
    return status === "paid" || status === "refunded" || status === "chargedback";
  }

  function buildPixCreatePayload(payment: PixPayment, saleId: string, cleanQrcode: string) {
    return {
      success: true,
      appPaymentId: payment.id,
      saleId,
      qrcode: cleanQrcode,
      copyPaste: cleanQrcode,
      brCode: cleanQrcode,
      pix: {
        qrcode: cleanQrcode,
        copyPaste: cleanQrcode,
        brCode: cleanQrcode,
      },
    };
  }

  function buildPixCreatePendingPayload(payment: PixPayment) {
    return {
      success: false,
      status: "creating",
      retryable: true,
      appPaymentId: payment.id,
      message: "Cobrança PIX em criação. Aguarde alguns segundos.",
    };
  }

  function readPixCreateResultFromPayload(data: any) {
    const qrcode = readFirstPixCopyPaste(
      data?.pix?.qrcode,
      data?.pix?.qrCode,
      data?.pix?.copyPaste,
      data?.pix?.brCode,
      data?.pix?.pixCode,
      data?.pix?.emv,
      data?.data?.paymentData?.copyPaste,
      data?.data?.paymentData?.qrCode,
      data?.data?.paymentData?.qrcode,
      data?.data?.paymentData?.pixCode,
      data?.data?.paymentData?.brCode,
      data?.data?.paymentData?.emv,
      data?.data?.pix?.qrcode,
      data?.data?.pix?.qrCode,
      data?.data?.pix?.copyPaste,
      data?.data?.pix?.brCode,
      data?.data?.pix?.pixCode,
      data?.qrcode,
      data?.qrCode,
      data?.copyPaste,
      data?.pixCode,
      data?.brCode,
      data?.code,
      findPixCopyPasteInPayload(data),
    );

    const saleId = readFirstString(
      data?.gatewayPaymentId,
      data?.transactionId,
      data?.saleId,
      data?.id,
      data?.paymentId,
      data?.orderId,
      data?.data?.transactionId,
      data?.data?.gatewayPaymentId,
      data?.data?.saleId,
      data?.data?.id,
      data?.data?.paymentId,
      data?.data?.orderId,
      findFirstStringByPayloadKeys(data, PROVIDER_TRANSACTION_ID_KEYS),
    );

    return { qrcode, saleId };
  }

  async function readPixWorkerJsonResponse(response: Response) {
    const text = await response.text();
    if (!response.ok || !text?.trim()) {
      throw new Error(`Worker create HTTP ${response.status}: ${redactWorkerResponseForLog(text)}`);
    }

    try {
      return JSON.parse(text);
    } catch {
      throw new Error(`Worker create non-JSON: ${redactWorkerResponseForLog(text)}`);
    }
  }

  async function persistPixWorkerCreateResult(params: {
    payment: PixPayment;
    data: any;
    saleId: string;
    qrcode: string;
    amountCents: number;
    externalref: string;
  }) {
    const cleanQrcode = params.qrcode.replace(/[\r\n]/g, "");
    const nextStatus = isTerminalPixPaymentStatus(params.payment.status) ? params.payment.status : "pending";
    const lastEvent = params.data?.event || "transaction.created";

    await db.update(pixPayments).set({
      abacatePayId: String(params.saleId),
      brCode: cleanQrcode,
      status: nextStatus,
      lastEvent,
      lastEventAt: new Date(),
    }).where(eq(pixPayments.id, params.payment.id));

    const savedPayment: PixPayment = {
      ...params.payment,
      abacatePayId: String(params.saleId),
      brCode: cleanQrcode,
      status: nextStatus,
      lastEvent,
      lastEventAt: new Date(),
    };

    const workerCreateEvent = normalizeWorkerPaymentEvent({
      ...params.data,
      appPaymentId: savedPayment.id,
      transactionId: String(params.saleId),
      externalReference: params.externalref,
      amountCents: params.amountCents,
      qrcode: cleanQrcode,
      event: lastEvent,
      status: params.data?.status || "PENDING",
    }, {});
    await upsertWorkerGatewayTransaction(savedPayment, workerCreateEvent, redactPayloadRecord(params.data));
    return { savedPayment, cleanQrcode };
  }

  async function completePixCreateFromWorkerPayload(params: {
    payment: PixPayment;
    data: any;
    amountCents: number;
    externalref: string;
  }) {
    let { qrcode, saleId } = readPixCreateResultFromPayload(params.data);

    if (!qrcode || !saleId) {
      const fallback = await waitForPixCreateDbFallback(params.payment.id);
      if (fallback.payment) params.payment = fallback.payment;
      if (!qrcode) qrcode = fallback.qrcode;
      if (!saleId) saleId = fallback.transactionId;
    }

    if (!qrcode) {
      throw new Error("PIX não encontrado na resposta do servidor de pagamento");
    }
    if (!saleId) {
      throw new Error("ID da cobrança não retornado pelo servidor de pagamento");
    }

    const persisted = await persistPixWorkerCreateResult({
      payment: params.payment,
      data: params.data,
      saleId,
      qrcode,
      amountCents: params.amountCents,
      externalref: params.externalref,
    });
    return { ...persisted, saleId };
  }

  async function markPixCreateAsyncFailure(paymentId: string, error: unknown) {
    const payment = await storage.getPixPayment(paymentId).catch(() => null);
    if (!payment || payment.brCode || isTerminalPixPaymentStatus(payment.status)) return;
    await db.update(pixPayments).set({
      status: "failed",
      lastEvent: "worker_create_async_failed",
      lastEventAt: new Date(),
    }).where(eq(pixPayments.id, paymentId));
    console.error("[PIX] Async worker create failed", {
      paymentId,
      message: error instanceof Error ? error.message : String(error || "unknown"),
    });
  }

  app.post("/api/pix/create", withSessionId, async (req: any, res) => {
    try {
      const {
        amount,
        planId = "",
        journeyNode = "",
        journeyPath = "",
        utm_source   = "",
        utm_medium   = "",
        utm_campaign = "",
        utm_content  = "",
        utm_term     = "",
      } = req.body;

      // Validate amount (must be a positive integer in cents)
      const amountCents = parseInt(amount, 10);
      if (isNaN(amountCents) || amountCents <= 0) {
        return res.status(400).json({ message: "Valor inválido" });
      }

      // Strict planId → expected amount pairing. Prevents amount tampering
      // (e.g. paying R$ 9,90 for a plan labelled "IA Ilimitada 15 dias").
      const PLAN_PRICES: Record<string, number> = {
        "1-foto": 990,
        "pack-fotos-1990": 1990,
        "video-pov-990": 990,
        "video-pov-1990": 1990,
        "video-pov-pack-2990": 2990,
        "10-fotos": 4990,
        "10-fotos-1-video": 6990,
        "ilimitado": 4990,
        "ilimitado-pack-fotos-4490": 4490,
        "upsell-instapro-semanal": 5990,
        "pix-tester-1000": 1000,
        // A/B test "landing-pricing" variant B — todos os preços +R$10
        // (exceto ilimitado, que mantém R$ 49,90).
        "1-foto-1990": 1990,
        "pack-fotos-2990": 2990,
        "video-pov-promo-1990": 1990,
        "video-pov-2990": 2990,
        "video-pov-pack-3990": 3990,
        "10-fotos-5990": 5990,
        "10-fotos-1-video-7990": 7990,
      };
      const normalizedPlanId = typeof planId === "string" ? planId.trim() : "";
      const isPixTesterPlan = normalizedPlanId === PIX_TESTER_PLAN_ID;
      const expectedAmount = PLAN_PRICES[normalizedPlanId];
      if (!expectedAmount || expectedAmount !== amountCents) {
        return res.status(400).json({ message: "Plano inválido" });
      }

      console.log(`[PIX] Creating charge — userId=${req.userId}, amountCents=${amountCents}`);

      const sessionId = getSessionId(req);
      const normalizedJourneyNode = sanitizeJourneyNode(journeyNode);
      const paymentUserId = isPixTesterPlan ? sessionId : req.userId;

      const abAssignments = normalizeTrackableSessionAbAssignments(req.session as any);
      const hasAbAssignments = Object.keys(abAssignments).length > 0;
      const externalref = normalizedJourneyNode
        ? `${sessionId}${JOURNEY_EXTERNAL_REF_SEPARATOR}${normalizedJourneyNode}`
        : sessionId;

      const user = req.userId ? await storage.getUser(req.userId).catch(() => undefined) : undefined;
      const emailForWebhook = (user?.email || "").trim() || "nao_preenchido";
      let pixCustomerData: Awaited<ReturnType<typeof getRandomPixCustomerData>>;
      try {
        pixCustomerData = await getRandomPixCustomerData();
      } catch (error: any) {
        console.error("[PIX] Customer data unavailable:", {
          message: error?.message,
          code: error?.code,
        });
        return res.status(503).json({ message: "Dados do cliente PIX indisponíveis" });
      }
      const pixCustomer = {
        name: pixCustomerData.name,
        email: pixCustomerData.email,
        phone: pixCustomerData.phone,
        document: pixCustomerData.document,
        documentType: pixCustomerData.documentType,
        ip: getClientIp(req) || null,
      };
      const pixProductKey = isPixTesterPlan
        ? null
        : resolvePixProductKey({
          planId: typeof planId === "string" ? planId : "",
          journeyNode: normalizedJourneyNode || "",
          amountCents,
        });
      const pixProductName = isPixTesterPlan
        ? PIX_TESTER_PRODUCT_NAME
        : getPixRequestProductName(pixProductKey ?? "unlimited_daily");

      console.log(`[PIX] Product name resolved — planId=${planId}, journeyNode=${normalizedJourneyNode}, name="${pixProductName}"`);

      const creditAmount = resolvePixCreditAmount(normalizedPlanId, amountCents);
      let savedPayment: PixPayment;
      try {
        savedPayment = await storage.createPixPayment({
          userId: paymentUserId,
          sessionId,
          abacatePayId: `pending:${crypto.randomUUID()}`,
          externalReference: externalref,
          abAssignments: hasAbAssignments ? abAssignments : null,
          creditAmount,
          amountCents,
          brCode: null,
          brCodeBase64: null,
          status: "pending"
        });
      } catch (err: any) {
        console.error("[PIX] Error preparing payment tracking:", err);
        return res.status(500).json({ message: "Erro ao preparar cobrança PIX" });
      }

      const tracking = {
        src: null,
        sck: null,
        utm_source: sanitizeUtm(utm_source),
        utm_medium: sanitizeUtm(utm_medium),
        utm_campaign: sanitizeUtm(utm_campaign),
        utm_content: sanitizeUtm(utm_content),
        utm_term: sanitizeUtm(utm_term),
      };

      const workerPixRequestPayload = {
        appPaymentId: savedPayment.id,
        amount: amountCents,
        amountCents,
        currency: "BRL",
        externalref,
        externalReference: externalref,
        sessionId,
        userId: isPixTesterPlan ? "" : String(req.userId || ""),
        planId: normalizedPlanId,
        productName: pixProductName,
        creditAmount,
        journeyNode: normalizedJourneyNode || null,
        journeyPath: typeof journeyPath === "string" ? journeyPath : "",
        testMode: isPixTesterPlan,
        abAssignments: hasAbAssignments ? abAssignments : {},
        tracking,
        utm_source,
        utm_medium,
        utm_campaign,
        utm_content,
        utm_term,
        "e-mail": pixCustomer.email,
        leadEmail: emailForWebhook.includes("@") ? emailForWebhook : null,
        name: pixProductName,
        customer: pixCustomer,
        customerName: pixCustomer.name,
        customerEmail: pixCustomer.email,
        customerPhone: pixCustomer.phone,
        customerDocument: pixCustomer.document,
        customerDocumentType: pixCustomer.documentType,
        nome: pixCustomer.name,
        telefone: pixCustomer.phone,
        cpf: pixCustomer.document,
      };

      const pixWorkerCreateUrl = getPixWorkerCreateUrl();
      if (!pixWorkerCreateUrl) {
        console.error("[PIX] PIX_WORKER_CREATE_URL not configured");
        return res.status(503).json({ message: "Servidor de pagamento não configurado" });
      }

      const pixWorkerBearerSecret = getPixWorkerBearerSecret();
      if (!pixWorkerBearerSecret) {
        console.error("[PIX] GATEWAY_INTERNAL_SECRET not configured for worker create auth");
        await db.update(pixPayments).set({
          status: "failed",
          lastEvent: "worker_auth_not_configured",
          lastEventAt: new Date(),
        }).where(eq(pixPayments.id, savedPayment.id));
        return res.status(503).json({ message: "Servidor de pagamento não configurado" });
      }

      const signingSecret = getPixWorkerSigningSecret();
      const workerRequest = signingSecret
        ? buildInternalSignedJsonRequest(workerPixRequestPayload, signingSecret)
        : {
          body: JSON.stringify(workerPixRequestPayload),
          headers: { "Content-Type": "application/json" },
        };

      const workerFetchPromise = fetchWithServerTimeout(pixWorkerCreateUrl, {
        method: "POST",
        headers: {
          ...workerRequest.headers,
          Authorization: `Bearer ${pixWorkerBearerSecret}`,
        },
        body: workerRequest.body,
      }, getPixWorkerCreateHardTimeoutMs())
        .then(async (response) => {
          const data = await readPixWorkerJsonResponse(response);
          if (response.status === 202 || data?.status === "creating") {
            return { creating: true as const, data };
          }
          const completed = await completePixCreateFromWorkerPayload({
            payment: savedPayment,
            data,
            amountCents,
            externalref,
          });
          return { creating: false as const, data, ...completed };
        });

      let workerResult: Awaited<typeof workerFetchPromise> | null = null;
      try {
        const softTimeoutMs = getPixWorkerCreateSoftTimeoutMs();
        workerResult = await Promise.race([
          workerFetchPromise,
          new Promise<null>((resolve) => setTimeout(() => resolve(null), softTimeoutMs)),
        ]);
      } catch (err: any) {
        await markPixCreateAsyncFailure(savedPayment.id, err);
        return res.status(502).json({ message: "Erro ao criar cobrança PIX" });
      }

      if (!workerResult) {
        await db.update(pixPayments).set({
          status: "pending",
          lastEvent: "worker_create_pending",
          lastEventAt: new Date(),
        }).where(eq(pixPayments.id, savedPayment.id));
        void workerFetchPromise
          .then((asyncResult) => {
            if (!asyncResult.creating) {
              console.log(`[PIX] Async charge created — saleId=${asyncResult.saleId}, appPaymentId=${savedPayment.id}`);
            }
          })
          .catch((error) => markPixCreateAsyncFailure(savedPayment.id, error));

        return res.status(202).json(buildPixCreatePendingPayload(savedPayment));
      }

      if (workerResult.creating) {
        await db.update(pixPayments).set({
          status: "pending",
          lastEvent: "worker_create_pending",
          lastEventAt: new Date(),
        }).where(eq(pixPayments.id, savedPayment.id));
        return res.status(202).json(buildPixCreatePendingPayload(savedPayment));
      }

      savedPayment = workerResult.savedPayment;
      const { saleId, cleanQrcode } = workerResult;
      console.log(`[PIX] Charge created — saleId=${saleId}, userId=${req.userId}, sessionId=${sessionId}, amountCents=${amountCents}, creditAmount=${creditAmount}`);

      try {
        await trackFunnelStep(req, {
          step: "pix_generated",
          eventName: "pix.charge_created",
          idempotencyKey: `pix_generated:${sessionId}:${saleId}`,
          customerEmail: emailForWebhook,
          utm_source,
          utm_medium,
          utm_campaign,
          utm_content,
          utm_term,
          saleAmountCents: amountCents,
          saleTransactionId: String(saleId),
          saleProvider: "pix-worker",
          saleEvent: "created",
          metadata: {
            journeyNode: normalizedJourneyNode,
            journeyPath: typeof journeyPath === "string" ? journeyPath : "",
            planId: typeof planId === "string" ? planId : "",
            externalref,
          },
        });
      } catch (err: any) {
        console.error("[PIX] Charge created but funnel tracking failed", {
          paymentId: savedPayment.id,
          saleId: String(saleId),
          message: err?.message || "unknown",
        });
      }

      try {
        posthogCapture({
          req,
          distinctId: String(req.userId),
          event: "pix payment created",
          properties: {
            plan_id: normalizedPlanId || null,
            amount_cents: amountCents,
            credit_amount: creditAmount,
            journey_node: normalizedJourneyNode || null,
            sale_id: String(saleId),
            provider: "pix-worker",
            utm_source: sanitizeUtm(utm_source),
            utm_medium: sanitizeUtm(utm_medium),
            utm_campaign: sanitizeUtm(utm_campaign),
            ab_assignments: hasAbAssignments ? abAssignments : null,
          },
        });
      } catch (err: any) {
        console.error("[PIX] Charge created but PostHog capture failed", {
          paymentId: savedPayment.id,
          saleId: String(saleId),
          message: err?.message || "unknown",
        });
      }

      res.json(buildPixCreatePayload(savedPayment, saleId, cleanQrcode));
    } catch (error: any) {
      posthogCaptureException(error, { req });
      console.error("[PIX] Error creating charge:", error);
      res.status(500).json({ message: "Falha ao processar pagamento PIX" });
    }
  });

  app.get("/api/pix/create-status/:paymentId", withSessionId, async (req: any, res) => {
    try {
      const paymentId = String(req.params.paymentId || "").trim();
      const payment = paymentId ? await storage.getPixPayment(paymentId) : null;
      if (!payment) return res.status(404).json({ status: "not_found" });

      if (payment.userId !== req.userId && payment.sessionId !== getSessionId(req)) {
        return res.status(403).json({ status: "forbidden" });
      }

      const localQrcode = normalizePixCopyPaste(payment.brCode);
      const localSaleId = payment.abacatePayId && !payment.abacatePayId.startsWith("pending:")
        ? payment.abacatePayId
        : "";
      if (localQrcode && localSaleId) {
        return res.json(buildPixCreatePayload(payment, localSaleId, localQrcode));
      }

      const statusUrl = getPixWorkerCreateStatusUrl(payment.id);
      const bearerSecret = getPixWorkerBearerSecret();
      if (!statusUrl || !bearerSecret) {
        return res.status(202).json(buildPixCreatePendingPayload(payment));
      }

      let workerResponse: Response;
      try {
        workerResponse = await fetchWithServerTimeout(statusUrl, {
          method: "GET",
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${bearerSecret}`,
          },
        }, 5000);
      } catch (error: any) {
        console.warn("[PIX] Worker create-status request failed", {
          paymentId: payment.id,
          message: error?.message || "unknown",
        });
        return res.status(202).json(buildPixCreatePendingPayload(payment));
      }

      if (workerResponse.status === 404) {
        return res.status(202).json(buildPixCreatePendingPayload(payment));
      }

      let data: any;
      try {
        data = await readPixWorkerJsonResponse(workerResponse);
      } catch (error: any) {
        console.warn("[PIX] Worker create-status invalid response", {
          paymentId: payment.id,
          message: error?.message || "unknown",
        });
        return res.status(202).json(buildPixCreatePendingPayload(payment));
      }

      if (workerResponse.status === 202 || data?.status === "creating") {
        return res.status(202).json(buildPixCreatePendingPayload(payment));
      }
      if (data?.status === "failed") {
        return res.status(502).json({ message: data?.message || "Falha ao criar cobrança PIX" });
      }

      const completed = await completePixCreateFromWorkerPayload({
        payment,
        data,
        amountCents: payment.amountCents,
        externalref: payment.externalReference || payment.sessionId || payment.id,
      });

      return res.json(buildPixCreatePayload(completed.savedPayment, completed.saleId, completed.cleanQrcode));
    } catch (error: any) {
      console.error("[PIX create-status] Error:", error);
      res.status(500).json({ message: "Erro ao consultar criação do PIX" });
    }
  });

  function shouldDedupePaymentWebhookStatus(status: unknown): boolean {
    return status === "processed" || status === "ignored";
  }

  async function handleWorkerPaymentWebhook(req: any, res: any, authMode: "public-webhook" | "internal-worker") {
    if (authMode === "public-webhook") {
      const signatureCheck = guardWebhookSignature({
        scope: "pix-worker-webhook",
        secretEnvVar: "PIX_WEBHOOK_SECRET",
        headerNames: ["x-webhook-signature", "x-signature", "x-worker-signature"],
        req,
      });
      if (!signatureCheck.allow) {
        return res.status(401).json({ error: "Unauthorized", message: "Assinatura do webhook inválida" });
      }
    } else {
      const secret = (process.env.DESIREAI_INTERNAL_SECRET || "").trim();
      if (!secret) {
        console.error("[pix-worker-internal] DESIREAI_INTERNAL_SECRET not configured");
        return res.status(503).json({ message: "Endpoint interno não configurado" });
      }
      if (!verifyInternalGatewaySignature(req, secret)) {
        return res.status(401).json({ message: "Assinatura interna inválida" });
      }
    }

    const body = (req.body ?? {}) as Record<string, any>;
    const headerMap: Record<string, string> = {};
    Object.entries(req.headers || {}).forEach(([key, value]) => {
      if (typeof value === "string") headerMap[key.toLowerCase()] = value;
      else if (Array.isArray(value)) headerMap[key.toLowerCase()] = value.join(",");
    });
    const event = normalizeWorkerPaymentEvent(body, headerMap);
    const redactedPayload = redactPayloadRecord(body);
    const redactedHeaders = redactHeaderMap(headerMap);

    console.log("[pix-worker-webhook] Incoming event", {
      authMode,
      eventName: event.eventName,
      status: event.status,
      rawStatus: event.rawStatus || null,
      transactionId: event.transactionId || null,
      appPaymentId: event.appPaymentId || null,
      externalReference: event.externalReference || null,
      idempotencyKey: event.idempotencyKey,
    });

    if (!event.transactionId && !event.appPaymentId && !event.externalReference) {
      return res.status(400).json({ message: "transactionId, appPaymentId ou externalReference obrigatório" });
    }

    const existing = await storage.getPaymentWebhookLogByIdempotencyKey(event.idempotencyKey);
    if (existing) {
      if (shouldDedupePaymentWebhookStatus(existing.status)) {
        return res.status(200).json({ success: true, duplicate: true });
      }
      await storage.updatePaymentWebhookLog(event.idempotencyKey, {
        status: "received",
        errorMessage: null,
        processedAt: null,
      });
    } else {
      try {
        await storage.createPaymentWebhookLog({
          source: "pix-worker",
          transactionId: event.transactionId || null,
          appPaymentId: event.appPaymentId || null,
          externalReference: event.externalReference || null,
          event: event.eventName,
          idempotencyKey: event.idempotencyKey,
          payload: redactedPayload,
          headers: redactedHeaders,
          status: "received",
        });
      } catch (error: any) {
        if (error?.code === "23505") {
          const conflicting = await storage.getPaymentWebhookLogByIdempotencyKey(event.idempotencyKey);
          if (conflicting && shouldDedupePaymentWebhookStatus(conflicting.status)) {
            return res.status(200).json({ success: true, duplicate: true });
          }
          await storage.updatePaymentWebhookLog(event.idempotencyKey, {
            status: "received",
            errorMessage: null,
            processedAt: null,
          });
        } else {
          throw error;
        }
      }
    }

    try {
      if (isTerminalWorkerPaymentStatus(event.status) && !event.transactionId && !event.appPaymentId) {
        await storage.updatePaymentWebhookLog(event.idempotencyKey, {
          status: "failed",
          errorMessage: "Evento terminal sem appPaymentId ou transactionId",
        });
        return res.status(422).json({
          success: false,
          status: "ambiguous_reference",
          message: "Evento terminal exige appPaymentId ou transactionId",
        });
      }

      const paymentLookup = await findPixPaymentForWorkerEvent({
        appPaymentId: event.appPaymentId,
        transactionId: event.transactionId,
        externalReference: event.externalReference,
        allowExternalReferenceFallback: !isTerminalWorkerPaymentStatus(event.status),
      });
      let payment = paymentLookup.payment;
      if (!payment) {
        await storage.updatePaymentWebhookLog(event.idempotencyKey, {
          status: "payment_not_found",
          errorMessage: "Pagamento não encontrado",
        });
        console.warn("[pix-worker-webhook] Payment not found", {
          transactionId: event.transactionId || null,
          appPaymentId: event.appPaymentId || null,
          externalReference: event.externalReference || null,
          lookupSource: paymentLookup.source,
        });
        return res.status(202).json({ success: false, status: "payment_not_found" });
      }

      const amountError = getTerminalWorkerEventAmountError(event, payment);
      if (amountError) {
        await storage.updatePaymentWebhookLog(event.idempotencyKey, {
          status: "failed",
          errorMessage: amountError,
        });
        console.warn("[pix-worker-webhook] Terminal event rejected", {
          reason: "amount_mismatch",
          transactionId: event.transactionId || null,
          appPaymentId: event.appPaymentId || null,
          paymentId: payment.id,
          eventAmountCents: event.amountCents,
          paymentAmountCents: payment.amountCents,
        });
        return res.status(422).json({
          success: false,
          status: "amount_mismatch",
          message: "Valor do evento diverge da cobrança",
        });
      }

      const providerTransactionId = event.transactionId || payment.abacatePayId;
      if (providerTransactionId && providerTransactionId !== payment.abacatePayId) {
        await db
          .update(pixPayments)
          .set({
            abacatePayId: providerTransactionId,
            lastEvent: event.eventName,
            lastEventAt: new Date(),
          })
          .where(eq(pixPayments.id, payment.id));
        payment = { ...payment, abacatePayId: providerTransactionId };
      }

      await upsertWorkerGatewayTransaction(payment, event, redactedPayload);

      let result: Record<string, unknown> = {};
      if (event.status === "paid") {
        const confirmation = await confirmPixPaymentFromCallback({
          payment,
          transactionId: providerTransactionId,
          provider: "pix-worker",
          saleEvent: event.eventName,
          paidAt: event.paidAt,
          externalReference: event.externalReference || payment.externalReference,
          callbackMetadata: {
            workerEvent: event.eventName,
            rawStatus: event.rawStatus || null,
            lookupSource: paymentLookup.source,
            amountCents: event.amountCents,
          },
          fallbackSessionId: payment.sessionId,
        });
        result = { alreadyPaid: confirmation.alreadyPaid };
      } else if (event.status === "refunded" || event.status === "chargedback") {
        const reversal = await applyPixPaymentReversalFromCallback({
          payment,
          transactionId: providerTransactionId,
          reversalStatus: event.status,
          saleEvent: event.eventName,
          reversedAt: event.refundedAt,
          externalReference: event.externalReference || payment.externalReference,
          callbackMetadata: {
            workerEvent: event.eventName,
            rawStatus: event.rawStatus || null,
            lookupSource: paymentLookup.source,
            amountCents: event.amountCents,
          },
        });
        result = reversal;
      } else if (event.status === "failed" || event.status === "expired" || event.status === "cancelled" || event.status === "created") {
        const nextStatus = event.status === "created" ? "pending" : event.status;
        const shouldUpdateStatus = !["paid", "refunded", "chargedback"].includes(payment.status);
        const updateData: Partial<PixPayment> = {
          lastEvent: event.eventName,
          lastEventAt: new Date(),
        };
        if (shouldUpdateStatus) updateData.status = nextStatus;
        if (event.qrcode && !payment.brCode) updateData.brCode = event.qrcode.replace(/[\r\n]/g, "");
        await db.update(pixPayments).set(updateData).where(eq(pixPayments.id, payment.id));
      } else {
        await storage.updatePaymentWebhookLog(event.idempotencyKey, {
          status: "ignored",
          processedAt: new Date(),
          errorMessage: `Status não reconhecido: ${event.rawStatus || event.eventName}`,
        });
        return res.status(200).json({ success: true, ignored: true, status: event.status });
      }

      await storage.updatePaymentWebhookLog(event.idempotencyKey, {
        status: "processed",
        processedAt: new Date(),
      });
      return res.json({
        success: true,
        status: event.status,
        paymentId: payment.id,
        ...result,
      });
    } catch (error: any) {
      await storage.updatePaymentWebhookLog(event.idempotencyKey, {
        status: "failed",
        errorMessage: error?.message || "Erro ao processar evento do worker",
      });
      console.error("[pix-worker-webhook] Error while processing", {
        idempotencyKey: event.idempotencyKey,
        eventName: event.eventName,
        status: event.status,
        transactionId: event.transactionId || null,
        message: error?.message || "unknown",
        stack: error?.stack || null,
      });
      return res.status(500).json({ message: "Falha ao processar evento de pagamento" });
    }
  }

  // ── POST /api/webhooks/pix — Cloudflare Worker payment events ───────
  app.post("/api/webhooks/pix", async (req: any, res) => {
    try {
      return await handleWorkerPaymentWebhook(req, res, "public-webhook");
    } catch (error: any) {
      console.error("[pix-worker-webhook] Error:", error);
      return res.status(500).json({ message: "Erro ao receber webhook PIX" });
    }
  });

  app.post("/api/internal/payment-events/worker", async (req: any, res) => {
    try {
      return await handleWorkerPaymentWebhook(req, res, "internal-worker");
    } catch (error: any) {
      console.error("[pix-worker-internal] Error:", error);
      return res.status(500).json({ message: "Erro ao receber evento interno de pagamento" });
    }
  });

  // Backward-compatible alias while the worker deploy rolls forward.
  app.post("/api/internal/payment-events/gateway", async (req: any, res) => {
    try {
      return await handleWorkerPaymentWebhook(req, res, "internal-worker");
    } catch (error: any) {
      console.error("[pix-worker-internal:legacy-alias] Error:", error);
      return res.status(500).json({ message: "Erro ao receber evento interno de pagamento" });
    }
  });

  // ── GET /api/pix/status/:paymentId — PIX payment status polling ──
  app.get("/api/pix/status/:paymentId", withSessionId, async (req: any, res) => {
    try {
      const { paymentId } = req.params;
      const cleanPaymentId = String(paymentId || "").trim();
      const paymentLookup = await findPixPaymentForWorkerEvent({
        appPaymentId: cleanPaymentId,
        transactionId: cleanPaymentId,
      });
      const payment = paymentLookup.payment;
      if (!payment) {
        return res.status(404).json({ status: "not_found" });
      }
      // Only allow the owner to check their own payment
      if (payment.userId !== req.userId && payment.sessionId !== getSessionId(req)) {
        return res.status(403).json({ status: "forbidden" });
      }
      res.json({ status: payment.status, creditAmount: payment.creditAmount });
    } catch (error) {
      console.error("[PIX Status] Error:", error);
      res.status(500).json({ status: "error" });
    }
  });

  // ── POST /api/uploads/reference-image ────────────────────────────
  app.post("/api/uploads/reference-image", withSessionId, async (req: any, res) => {
    let shouldKeepFinalFile = false;
    let finalPath: string | null = null;
    let storageMode: "cloudinary" | "temporary_local" = "temporary_local";

    try {
      await new Promise<void>((resolve, reject) => {
        uploadMiddleware.single("image")(req, res, (error: any) => {
          if (error) {
            reject(error);
            return;
          }

          resolve();
        });
      });
    } catch (error: any) {
      if (error instanceof multer.MulterError) {
        if (error.code === "LIMIT_FILE_SIZE") {
          return res.status(413).json({ message: "A imagem excede o limite de 10 MB." });
        }

        return res.status(400).json({ message: "Não foi possível processar o upload da imagem." });
      }

      return res.status(400).json({
        message: typeof error?.message === "string" && error.message.trim()
          ? error.message
          : "Não foi possível enviar a imagem.",
      });
    }

    try {
      if (!req.file) return res.status(400).json({ message: "Nenhum arquivo enviado" });

      const fileId = path.basename(req.file.filename, path.extname(req.file.filename));
      const uploadPath = req.file.path;
      const mimeType = String(req.file.mimetype || "").toLowerCase();
      const extension = path.extname(req.file.originalname || "").toLowerCase();
      const rawBuffer = await fs.promises.readFile(uploadPath);
      const detectedKind = detectUploadKind(rawBuffer);

      if (!detectedKind) {
        return res.status(415).json({ message: "Não foi possível identificar o formato da imagem. Use JPEG, PNG, WebP, GIF, HEIC ou HEIF." });
      }

      if (isHeicMimeType(mimeType) || extension === ".heic" || extension === ".heif") {
        if (detectedKind !== "heic") {
          return res.status(415).json({ message: "O arquivo enviado não parece ser um HEIC/HEIF válido." });
        }
      }

      const normalized = await referenceUploadProcessingLimit(() => normalizeReferenceUpload(rawBuffer, detectedKind));

      if (normalized.padded) {
        console.log(
          `[Upload] Normalized ${detectedKind.toUpperCase()} ${normalized.originalWidth}x${normalized.originalHeight} → ${normalized.finalWidth}x${normalized.finalHeight} (ratio ${normalized.aspectRatio}, padded)`,
        );
      } else {
        console.log(
          `[Upload] Normalized ${detectedKind.toUpperCase()} ${normalized.originalWidth}x${normalized.originalHeight} → ${normalized.finalWidth}x${normalized.finalHeight} (ratio ${normalized.aspectRatio}, no padding)`,
        );
      }

      let publicUrl: string;

      try {
        const cloudinaryUrl = await uploadReferenceImageToCloudinary({
          buffer: normalized.finalBuffer,
          fileId,
        });

        if (cloudinaryUrl) {
          publicUrl = cloudinaryUrl;
          storageMode = "cloudinary";
        } else {
          finalPath = path.join(TEMP_UPLOAD_DIR, `${fileId}.jpg`);
          await fs.promises.writeFile(finalPath, normalized.finalBuffer);
          tempFileRegistry.set(fileId, { path: finalPath, expiresAt: Date.now() + TEMP_FILE_TTL_MS });
          shouldKeepFinalFile = true;
          publicUrl = buildLocalReferenceUploadUrl(req, fileId);
        }
      } catch (cloudinaryError) {
        console.error("[Upload] Falha ao enviar foto de referência para o Cloudinary:", cloudinaryError);

        finalPath = path.join(TEMP_UPLOAD_DIR, `${fileId}.jpg`);
        await fs.promises.writeFile(finalPath, normalized.finalBuffer);
        tempFileRegistry.set(fileId, { path: finalPath, expiresAt: Date.now() + TEMP_FILE_TTL_MS });
        shouldKeepFinalFile = true;
        publicUrl = buildLocalReferenceUploadUrl(req, fileId);
      }

      await trackFunnelStep(req, {
        step: "photo_uploaded",
        eventName: "upload.reference_image",
        idempotencyKey: `photo_uploaded:${getSessionId(req)}:${fileId}`,
        uploadedPhotoUrl: publicUrl,
        metadata: {
          fileId,
          inputKind: detectedKind,
          aspectRatio: normalized.aspectRatio,
          originalWidth: normalized.originalWidth,
          originalHeight: normalized.originalHeight,
          finalWidth: normalized.finalWidth,
          finalHeight: normalized.finalHeight,
          padded: normalized.padded,
        },
      });

      posthogCapture({
        req,
        distinctId: String(req.userId),
        event: "reference image uploaded",
        properties: {
          file_id: fileId,
          storage_mode: storageMode,
          aspect_ratio: normalized.aspectRatio,
          input_kind: detectedKind,
          padded: normalized.padded,
        },
      });

      res.json({
        url: publicUrl,
        fileId,
        storage: storageMode,
        inputKind: detectedKind,
        aspectRatio: normalized.aspectRatio,
        originalWidth: normalized.originalWidth,
        originalHeight: normalized.originalHeight,
        finalWidth: normalized.finalWidth,
        finalHeight: normalized.finalHeight,
        padded: normalized.padded,
        expiresIn: storageMode === "temporary_local" ? TEMP_FILE_TTL_MS / 1000 : null,
      });
    } catch (error) {
      console.error("Upload error:", error);
      const uploadErrorMessage = error instanceof Error ? error.message : "";
      const isDecodeError = /heic|heif|decode|unsupported|corrupt|corrupted|invalid/i.test(uploadErrorMessage);
      res.status(isDecodeError ? 415 : 500).json({
        message: isDecodeError
          ? "Não foi possível processar a imagem enviada. Tente outra foto ou exporte em JPEG."
          : "Erro ao fazer upload do arquivo",
      });
    } finally {
      const uploadPath = req.file?.path;
      const uploadExtension = req.file?.filename ? path.extname(req.file.filename) : "";
      const uploadFileId = req.file?.filename ? path.basename(req.file.filename, uploadExtension) : "";
      const normalizedPath = uploadFileId ? path.join(TEMP_UPLOAD_DIR, `${uploadFileId}.jpg`) : null;

      if (!shouldKeepFinalFile && uploadFileId) {
        tempFileRegistry.delete(uploadFileId);
      }

      if (uploadPath && (!shouldKeepFinalFile || uploadPath !== normalizedPath)) {
        fs.promises.unlink(uploadPath).catch(() => {});
      }

      if (!shouldKeepFinalFile && finalPath && finalPath !== uploadPath) {
        fs.promises.unlink(finalPath).catch(() => {});
      }
    }
  });

  // ── GET /api/uploads/:fileId ──────────────────────────────────────
  app.get("/api/uploads/:fileId", (req, res) => {
    try {
      const fileIdWithExt = req.params.fileId;
      const originalExt = path.extname(fileIdWithExt);
      const ext = originalExt.toLowerCase();
      const fileId = path.basename(fileIdWithExt, originalExt);

      let entry = tempFileRegistry.get(fileId);
      let filePath: string;

      if (entry) {
        if (Date.now() > entry.expiresAt) {
          tempFileRegistry.delete(fileId);
          if (fs.existsSync(entry.path)) fs.unlinkSync(entry.path);
          return res.status(404).json({ message: "Arquivo expirado" });
        }
        filePath = entry.path;
      } else {
        let possiblePath = path.join(TEMP_UPLOAD_DIR, `${fileId}${ext}`);
        if (!fs.existsSync(possiblePath)) possiblePath = path.join(TEMP_UPLOAD_DIR, `${fileId}${originalExt}`);
        if (!fs.existsSync(possiblePath)) return res.status(404).json({ message: "Arquivo não encontrado ou expirado" });

        const stats = fs.statSync(possiblePath);
        if (Date.now() - stats.mtimeMs > TEMP_FILE_TTL_MS) {
          fs.unlinkSync(possiblePath);
          return res.status(404).json({ message: "Arquivo expirado" });
        }

        tempFileRegistry.set(fileId, { path: possiblePath, expiresAt: stats.mtimeMs + TEMP_FILE_TTL_MS });
        filePath = possiblePath;
      }

      if (!fs.existsSync(filePath)) {
        tempFileRegistry.delete(fileId);
        return res.status(404).json({ message: "Arquivo não encontrado" });
      }

      const mimeTypes: Record<string, string> = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
        ".webp": "image/webp", ".gif": "image/gif",
      };

      res.setHeader("Content-Type", mimeTypes[ext] || "application/octet-stream");
      res.setHeader("Cache-Control", "public, max-age=3600");
      fs.createReadStream(filePath).pipe(res);
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "Erro ao baixar arquivo" });
    }
  });

  // ── POST /api/generated-images ────────────────────────────────────
  app.post("/api/generated-images", withSessionId, async (req: any, res) => {
    try {
      const userId = req.userId;
      const sessionUserId = (req.session as any)?.userId || null;
      const requestSessionId = getSessionId(req);
      const parsed = generatedImageRequestSchema.safeParse(req.body ?? {});
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.errors[0]?.message || "Dados inválidos" });
      }

      const { referenceImageUrls } = parsed.data;
      const prompt = QWEN2_EDIT_PROMPT;
      const selectedAspectRatio = "1:1";
      const referenceImageUrl = referenceImageUrls[0];

      if (!referenceImageUrl) {
        return res.status(400).json({ message: "A imagem de referência é obrigatória" });
      }

      const isFunnelFree = parsed.data.funnelFree === true;
      const baseCreditCost = 1;
      const bulkQty = isFunnelFree ? 1 : Math.max(1, Math.min(10, Math.floor(Number(parsed.data.quantity) || 1)));
      const totalCreditCost = baseCreditCost * bulkQty;
      const KIE_API_KEY = process.env.KIE_API_KEY;
      if (!KIE_API_KEY) {
        return res.status(500).json({ message: "API key não configurada" });
      }

      let freeSlotReserved = false;

      if (isFunnelFree) {
        const hasFreshFunnelFreeAllowance = (req.session as any)?.allowFunnelFreeGeneration === true;
        if (sessionUserId && !hasFreshFunnelFreeAllowance) {
          return res.status(403).json({ message: "A geração gratuita só está disponível antes do cadastro." });
        }

        const [funnelSession] = await db
          .select({ uploadedPhotoUrl: funnelSessions.uploadedPhotoUrl })
          .from(funnelSessions)
          .where(eq(funnelSessions.sessionId, requestSessionId))
          .limit(1);

        if (!funnelSession?.uploadedPhotoUrl || funnelSession.uploadedPhotoUrl !== referenceImageUrl) {
          return res.status(403).json({ message: "Envie uma foto nesta sessão antes de gerar a imagem gratuita." });
        }

        const [existingFreeUse] = await db
          .select({ id: generatedImages.id })
          .from(generatedImages)
          .where(and(
            eq(generatedImages.userId, userId),
            inArray(generatedImages.status, ["pending", "processing", "completed"]),
          ))
          .limit(1);

        if (existingFreeUse) {
          return res.status(403).json({ message: "A geração gratuita já foi utilizada nesta sessão." });
        }

        const freeSlot = reserveFreeGenerationAttempt(req, requestSessionId);
        if (!freeSlot.ok) {
          res.setHeader("Retry-After", String(freeSlot.retryAfterSeconds));
          return res.status(429).json({ message: "Muitas gerações gratuitas. Tente novamente mais tarde." });
        }
        freeSlotReserved = true;
      } else {
        if (!sessionUserId) {
          return res.status(401).json({ message: "Faça login para gerar novas imagens." });
        }

        const credits = await storage.getUserCredits(userId);
        if (!credits || credits.balance < totalCreditCost) {
          return res.status(400).json({ message: "Créditos insuficientes" });
        }
      }

      const host = process.env.PUBLIC_DOMAIN || req.get("host");
      const protocol = req.headers["x-forwarded-proto"] || req.protocol || "https";

      const createdImages: any[] = [];
      const basePerItem = Math.floor(totalCreditCost / bulkQty);
      const remainder = totalCreditCost % bulkQty;

      for (let i = 0; i < bulkQty; i++) {
        const itemCreditCost = isFunnelFree ? 0 : (i < remainder ? basePerItem + 1 : basePerItem);
        let creditsDebited = false;

        const image = await storage.createGeneratedImage(userId, {
          prompt,
          model: "default",
          aspectRatio: selectedAspectRatio,
          creditCost: itemCreditCost,
          sessionId: requestSessionId,
        });

        const webhookToken = signImageWebhookToken(image.id);
        if (!webhookToken) {
          await storage.updateGeneratedImage(image.id, { status: "failed", errorMessage: "Webhook de imagem não configurado" });
          if (isFunnelFree && freeSlotReserved) {
            releaseFreeGenerationAttempt(req, requestSessionId);
            freeSlotReserved = false;
          }
          createdImages.push({ ...image, status: "failed", errorMessage: "Webhook de imagem não configurado" });
          continue;
        }
        const callbackUrl = `${protocol}://${host}/api/webhooks/generated-image/${image.id}?token=${webhookToken}`;

        try {
          if (!isFunnelFree && itemCreditCost > 0) {
            await storage.consumeCreditsWithDailyFirst(userId, itemCreditCost);
            await storage.createCreditTransaction({
              userId,
              amount: -itemCreditCost,
              type: "image_generation",
              description: "Geração de imagem",
            });
            creditsDebited = true;
          }

          const qwenInput = {
            prompt,
            image_url: referenceImageUrl,
            image_size: "1:1",
            output_format: "png",
          };
          const kieData = await callKieTask("qwen2/image-edit", qwenInput, callbackUrl, KIE_API_KEY);
          console.log("[KIE] Final model used: qwen2/image-edit");

          if (!kieData || kieData.code !== 200 || !kieData.data?.taskId) {
            const errMsg = kieData?.msg || `Falha ao iniciar geração (code: ${kieData?.code})`;
            await storage.updateGeneratedImage(image.id, { status: "failed", errorMessage: errMsg });
            if (creditsDebited && itemCreditCost > 0) {
              await storage.updateCredits(userId, itemCreditCost, false);
              await storage.createCreditTransaction({
                userId,
                amount: itemCreditCost,
                type: "refund",
                description: `Reembolso: ${errMsg}`,
              });
            }
            if (isFunnelFree && freeSlotReserved) {
              releaseFreeGenerationAttempt(req, requestSessionId);
              freeSlotReserved = false;
            }
            createdImages.push({ ...image, status: "failed", errorMessage: errMsg });
          } else {
            await storage.updateGeneratedImage(image.id, { taskId: kieData.data.taskId, status: "processing" });
            createdImages.push({ ...image, status: "processing", taskId: kieData.data.taskId });
            startImagePolling(image.id, kieData.data.taskId, KIE_API_KEY);
            posthogCapture({
              req,
              distinctId: String(userId),
              event: "image generation started",
              properties: {
                image_id: image.id,
                funnel_free: isFunnelFree,
                credit_cost: itemCreditCost,
                quantity: bulkQty,
              },
            });
          }
        } catch (error: any) {
          console.error(`[KIE] Error:`, error);
          await storage.updateGeneratedImage(image.id, { status: "failed", errorMessage: error.message });
          if (creditsDebited && itemCreditCost > 0) {
            await storage.updateCredits(userId, itemCreditCost, false);
            await storage.createCreditTransaction({
              userId,
              amount: itemCreditCost,
              type: "refund",
              description: `Reembolso: ${error.message || "falha ao iniciar geração"}`,
            });
          }
          if (isFunnelFree && freeSlotReserved) {
            releaseFreeGenerationAttempt(req, requestSessionId);
            freeSlotReserved = false;
          }
          createdImages.push({ ...image, status: "failed", errorMessage: error.message });
        }

        if (i < bulkQty - 1) await new Promise(r => setTimeout(r, 100));
      }
      res.json(bulkQty > 1 ? createdImages : (createdImages[0] || { message: "Falha na geração" }));
    } catch (error) {
      console.error("Error creating generated image:", error);
      res.status(500).json({ message: "Falha ao criar imagem" });
    }
  });

  // ── GET /api/generated-images — fetch user history ─────────────────
  app.get("/api/generated-images", withSessionId, async (req: any, res) => {
    try {
      const userId = req.userId;
      const images = await storage.getGeneratedImages(userId);
      res.json(images);
    } catch (error) {
      console.error("Error fetching images:", error);
      res.status(500).json({ message: "Falha ao buscar imagens" });
    }
  });

  // ── GET /api/card-image/:cardId — proxy card media (URLs hidden) ──
  const VALID_CARD_IDS = ["positions", "pov", "pov_modal_header"] as const;
  const REQUIRED_CARD_IDS = ["positions", "pov"] as const;
  type CardId = typeof VALID_CARD_IDS[number];
  const CARD_POSTER_FILES: Partial<Record<CardId, string>> = {
    pov: "pov.jpg",
    pov_modal_header: "pov-modal-header.jpg",
  };

  async function hasCompletedGeneratedImageForCurrentSession(req: any): Promise<boolean> {
    const currentUserId = typeof req.userId === "string" ? req.userId : "";
    if (!currentUserId) return false;

    if (await storage.userHasCompletedGeneratedImage(currentUserId)) return true;

    const sessionId = getSessionId(req);
    if (!sessionId || sessionId === currentUserId) return false;
    return await storage.userHasCompletedGeneratedImage(sessionId);
  }

  function denyCardMediaAccess(res: express.Response) {
    res.setHeader("Cache-Control", "private, no-store");
    return res.status(403).json({ message: "Acesso negado" });
  }

  function getAndroidSafeCardMediaUrl(cardId: CardId, url: string): string {
    if (cardId !== "positions") return url;

    try {
      const parsed = new URL(url);
      const marker = "/image/upload/";
      const markerIndex = parsed.pathname.indexOf(marker);
      if (parsed.hostname !== "res.cloudinary.com" || markerIndex < 0) return url;

      const prefix = parsed.pathname.slice(0, markerIndex + marker.length);
      const suffix = parsed.pathname.slice(markerIndex + marker.length);
      const jpegSuffix = suffix.replace(/\.[a-z0-9]+$/i, ".jpg");
      parsed.pathname = `${prefix}f_jpg,q_auto/${jpegSuffix}`;
      return parsed.toString();
    } catch {
      return url;
    }
  }

  // Parse card media map once on boot/deploy.
  // To apply changes in `.env`, restart/redeploy the server process.
  let cardImageUrls: Record<string, string> = {};
  try {
    const parsedJson = JSON.parse(process.env.CARD_IMAGES_JSON || "{}") as Record<string, unknown>;
    const cleanedJson = Object.fromEntries(
      Object.entries(parsedJson).filter(
        ([, value]) => typeof value === "string" && value.trim().length > 0,
      ),
    ) as Record<string, string>;

    // Preferred explicit env vars (as requested), with JSON fallback for compatibility.
    const explicitEnvMap: Partial<Record<CardId, string>> = {
      positions: process.env.PACKFOTOS || undefined,
      pov: process.env.pov || process.env.POV || undefined,
      pov_modal_header: process.env.pov_modal_header || process.env.POV_MODAL_HEADER || undefined,
    };

    cardImageUrls = {
      ...cleanedJson,
      ...Object.fromEntries(
        Object.entries(explicitEnvMap).filter(
          ([, value]) => typeof value === "string" && value.trim().length > 0,
        ),
      ),
    };

    const missing = REQUIRED_CARD_IDS.filter((id) => !cardImageUrls[id]);
    if (missing.length > 0) {
      console.error(`[card-image] Missing required media keys: ${missing.join(", ")}. Define PACKFOTOS/pov or CARD_IMAGES_JSON.`);
    } else {
      console.log(`[card-image] configured required ids: ${REQUIRED_CARD_IDS.join(", ")} (env refs + CARD_IMAGES_JSON fallback)`);
    }
  } catch {
    console.error("[card-image] Failed to parse CARD_IMAGES_JSON");
  }

  app.get("/api/card-image/:cardId/poster", withSessionId, async (req: any, res) => {
    try {
      const { cardId } = req.params;
      if (!VALID_CARD_IDS.includes(cardId as CardId)) {
        return res.status(404).json({ message: "Card não encontrado" });
      }
      if (!req.userId) {
        return denyCardMediaAccess(res);
      }

      const hasCompleted = await hasCompletedGeneratedImageForCurrentSession(req);
      if (!hasCompleted) {
        return denyCardMediaAccess(res);
      }

      const posterFile = CARD_POSTER_FILES[cardId as CardId];
      if (!posterFile) {
        return res.status(404).json({ message: "Thumbnail não configurada" });
      }

      res.setHeader("Content-Type", "image/jpeg");
      res.setHeader("Cache-Control", "private, max-age=86400, immutable");
      res.setHeader("Vary", "Cookie");
      const posterPath = [
        path.resolve(process.cwd(), "dist", "public", "video-posters", posterFile),
        path.resolve(process.cwd(), "client", "public", "video-posters", posterFile),
      ].find((candidate) => fs.existsSync(candidate));

      if (!posterPath) {
        return res.status(404).json({ message: "Thumbnail não encontrada" });
      }

      return res.sendFile(posterPath);
    } catch (error: any) {
      console.error("[card-image-poster]", error.message);
      return res.status(500).json({ message: "Erro ao servir thumbnail" });
    }
  });

  app.get("/api/card-image/:cardId", withSessionId, async (req: any, res) => {
    try {
      const { cardId } = req.params;

      // Validate cardId
      if (!VALID_CARD_IDS.includes(cardId as CardId)) {
        return res.status(404).json({ message: "Card não encontrado" });
      }

      // Must be logged in
      if (!req.userId) {
        return denyCardMediaAccess(res);
      }

      // Must have at least one completed image
      const hasCompleted = await hasCompletedGeneratedImageForCurrentSession(req);
      if (!hasCompleted) {
        return denyCardMediaAccess(res);
      }

      const rawUrl = cardImageUrls[cardId];
      if (!rawUrl) {
        return res.status(404).json({ message: "Mídia não configurada" });
      }
      const url = getAndroidSafeCardMediaUrl(cardId as CardId, rawUrl);

      void trackFunnelStep(req, {
        step: "offer_viewed",
        eventName: "offer.media_viewed",
        idempotencyKey: `offer_viewed:${getSessionId(req)}:${cardId}`,
        metadata: { cardId },
      }).catch((error) => console.error("[card-image] tracking error:", error));

      const streamed = await streamProxiedMedia(req, res, {
        url,
        cacheControl: "private, max-age=86400, immutable",
      });
      if (!streamed) return res.status(502).json({ message: "Erro ao buscar mídia" });
      return;
    } catch (error: any) {
      console.error("[card-image]", error.message);
      res.status(500).json({ message: "Erro ao servir mídia" });
    }
  });

  // ── GET /api/generated-images/:id — single image metadata ───────────
  app.get("/api/generated-images/:id", withSessionId, async (req: any, res) => {
    try {
      const image = await storage.getGeneratedImage(req.params.id);
      if (!image || image.userId !== req.userId) return res.status(404).json({ message: "Não encontrado" });

      // Never expose the real imageUrl in the JSON response.
      // Replace with the proxy URL so no CDN URL leaks to the client.
      const safeImage = {
        ...image,
        imageUrl: image.imageUrl ? `/api/generated-images/${image.id}/image` : null,
      };
      res.json(safeImage);
    } catch (error) {
      res.status(500).json({ message: "Erro" });
    }
  });

  // ── GET /api/generated-images/:id/image — proxy (always unblurred) ───
  // The client always uses this URL as <img src>. Never receives the CDN URL.
  // Access control mirrors card-image: user must have at least one completed generation.
  app.get("/api/generated-images/:id/image", withSessionId, async (req: any, res) => {
    try {
      const image = await storage.getGeneratedImage(req.params.id);
      if (!image || image.userId !== req.userId) return res.status(404).json({ message: "Não encontrado" });
      if (!image.imageUrl) return res.status(404).json({ message: "Imagem ainda não gerada" });
      if (!isAllowedGeneratedMediaUrl(image.imageUrl)) {
        return res.status(502).json({ message: "URL de imagem não permitida" });
      }

      // Eligibility: must have at least one completed generated image (same as cards)
      const hasCompleted = await storage.userHasCompletedGeneratedImage(req.userId);
      if (!hasCompleted) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      void trackFunnelStep(req, {
        step: "generated_photo_viewed",
        eventName: "image.proxy_viewed",
        idempotencyKey: `generated_photo_viewed:${getSessionId(req)}:${image.id}`,
        generatedPhotoUrl: `/api/generated-images/${image.id}/image`,
        metadata: { imageId: image.id },
      }).catch((error) => console.error("[image-proxy] tracking error:", error));

      const streamed = await streamProxiedMedia(req, res, {
        url: image.imageUrl,
        cacheControl: "private, max-age=86400",
      });
      if (!streamed) return res.status(502).json({ message: "Erro ao buscar imagem" });
      return;
    } catch (error: any) {
      console.error("[image-proxy]", error.message);
      res.status(500).json({ message: "Erro ao servir imagem" });
    }
  });


  // ── POST /api/webhooks/generated-image/:imageId ────────────────────
  app.post("/api/webhooks/generated-image/:imageId", async (req, res) => {
    try {
      const { imageId } = req.params;
      const callbackData = req.body;

      if (!verifyImageWebhookToken(req, imageId)) {
        return res.status(401).json({ message: "Webhook de imagem não autorizado" });
      }

      console.log("[image-webhook] received", { imageId });

      const image = await storage.getGeneratedImage(imageId);
      if (!image) return res.status(404).json({ message: "Image not found" });
      if (image.status === "completed" || image.status === "failed") return res.json({ success: true });

      const callbackTaskId = readKieCallbackTaskId(callbackData);
      if (!image.taskId || !callbackTaskId || callbackTaskId !== image.taskId) {
        console.warn("[image-webhook] rejected callback with invalid task id", {
          imageId,
          hasStoredTaskId: Boolean(image.taskId),
          hasCallbackTaskId: Boolean(callbackTaskId),
        });
        return res.status(401).json({ message: "Task inválida" });
      }

      let imageUrl: string | null = null;
      let isSuccess = false;
      let errorMessage: string | null = null;

      const taskState = callbackData.data?.state;
      const resultJson = callbackData.data?.resultJson;

      if (taskState === "success" && resultJson) {
        try {
          const parsed = typeof resultJson === "string" ? JSON.parse(resultJson) : resultJson;
          const urls: string[] = parsed.resultUrls || [];
          if (urls.length > 0 && isAllowedGeneratedMediaUrl(urls[0])) {
            imageUrl = urls[0];
            isSuccess = true;
          } else if (urls.length > 0) {
            errorMessage = "URL de mídia não permitida";
          }
        } catch { }
      }

      if (!isSuccess && (taskState === "fail" || callbackData.code === 500)) {
        errorMessage = callbackData.data?.failMsg || callbackData.msg || "Falha na geração de imagem";
      }

      const webhookCompletionTime = new Date();
      const aiLatency = image.createdAt
        ? (webhookCompletionTime.getTime() - new Date(image.createdAt).getTime()) / 1000
        : null;

      if (isSuccess && imageUrl) {
        const completion = await storage.completeGeneratedImageIfActive(image.id, imageUrl, webhookCompletionTime);
        if (completion.transitioned && completion.image) {
          console.log("Image completed:", image.id);
          notifyImageCompleted(completion.image.userId, completion.image);
          posthogCapture({
            distinctId: String(image.userId),
            event: "image generation completed",
            properties: { image_id: image.id },
          });
          posthogCapture({
            distinctId: String(image.userId),
            event: "$ai_generation",
            properties: {
              $ai_trace_id: image.id,
              $ai_model: "qwen2/image-edit",
              $ai_provider: "kie.ai",
              $ai_base_url: "https://api.kie.ai",
              $ai_latency: aiLatency,
              $ai_http_status: 200,
              $ai_total_cost_usd: 0.0325,
              $ai_is_error: false,
            },
          });
        }
      } else if (errorMessage) {
        const failure = await storage.failGeneratedImageAndRefundIfActive(
          image.id,
          errorMessage,
          `Reembolso: ${errorMessage}`
        );
        if (failure.transitioned) {
          console.log("Image failed:", image.id, errorMessage);
          posthogCapture({
            distinctId: String(image.userId),
            event: "image generation failed",
            properties: { image_id: image.id, error_message: errorMessage },
          });
          posthogCapture({
            distinctId: String(image.userId),
            event: "$ai_generation",
            properties: {
              $ai_trace_id: image.id,
              $ai_model: "qwen2/image-edit",
              $ai_provider: "kie.ai",
              $ai_base_url: "https://api.kie.ai",
              $ai_latency: aiLatency,
              $ai_is_error: true,
              $ai_error: errorMessage,
            },
          });
          if (failure.freeSessionId) releaseFreeGenerationSessionAttempt(failure.freeSessionId);
          if (failure.image) notifyImageFailed(failure.image.userId, failure.image);
        }
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error processing image webhook:", error);
      res.status(500).json({ message: "Webhook processing error" });
    }
  });

  // ── POST /api/auth/login — username + password login ──────────────
  app.post("/api/auth/login", async (req: any, res) => {
    try {
      const parsed = loginFunnelSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.errors[0]?.message || "Dados inválidos" });
      }
      const { username, password } = parsed.data;

      const [user] = await db.select().from(users).where(eq(users.username, username)).limit(1);
      if (!user || !user.passwordHash) {
        return res.status(401).json({ message: "Usuário ou senha incorretos" });
      }
      if (user.isDeactivated) {
        return res.status(403).json({ message: "Esta conta foi desativada" });
      }

      const valid = await bcrypt.compare(password, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ message: "Usuário ou senha incorretos" });
      }

      // Set session
      const session = req.session as any;
      session.userId = user.id;
      await new Promise<void>((resolve, reject) => {
        req.session.save((err: any) => { if (err) reject(err); else resolve(); });
      });

      // Update last login
      await db.update(users).set({ lastLogin: new Date() }).where(eq(users.id, user.id));

      const anonId = req.sessionID || null;
      if (anonId) posthogAlias(anonId, String(user.id));
      posthogIdentify(String(user.id), { username: user.username });
      posthogCapture({
        req,
        distinctId: String(user.id),
        event: "user logged in",
        properties: {
          username: user.username,
        },
      });

      res.json({ success: true, user: { id: user.id, username: user.username } });
    } catch (error) {
      posthogCaptureException(error, { req });
      console.error("Error in login:", error);
      res.status(500).json({ message: "Erro ao fazer login" });
    }
  });

  // ── POST /api/auth/logout ─────────────────────────────────────────
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Erro ao sair" });
      }
      res.clearCookie("connect.sid");
      res.json({ success: true });
    });
  });

  // ── GET /api/user/me — current user info + hasPaidPix flag ────────
  app.get("/api/user/me", requireAuth, async (req: any, res) => {
    try {
      const userId = req.userId;
      const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
      if (!user) return res.status(404).json({ message: "Usuário não encontrado" });

      // Check if user has at least one paid PIX payment
      const [paidPix] = await db
        .select({ id: pixPayments.id })
        .from(pixPayments)
        .where(and(eq(pixPayments.userId, userId), eq(pixPayments.status, "paid")))
        .limit(1);

      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role || "visitor",
        hasPaidPix: !!paidPix,
      });
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar dados do usuário" });
    }
  });

  // ── PATCH /api/user/username — change username ────────────────────
  app.patch("/api/user/username", requireAuth, async (req: any, res) => {
    try {
      const { username } = req.body;
      if (!username || username.length < 3 || username.length > 20) {
        return res.status(400).json({ message: "Username deve ter entre 3 e 20 caracteres" });
      }
      if (!/^[a-zA-Z0-9._]+$/.test(username)) {
        return res.status(400).json({ message: "Username pode conter apenas letras, números, pontos e underscores" });
      }

      const [existing] = await db.select().from(users).where(eq(users.username, username)).limit(1);
      if (existing && existing.id !== req.userId) {
        return res.status(409).json({ message: "Este username já está em uso" });
      }

      await db.update(users).set({ username, updatedAt: new Date() }).where(eq(users.id, req.userId));
      res.json({ success: true, username });
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar username" });
    }
  });

  // ── PATCH /api/user/password — change password ────────────────────
  app.patch("/api/user/password", requireAuth, async (req: any, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Senha atual e nova senha são obrigatórias" });
      }
      if (newPassword.length < 6 || newPassword.length > 40) {
        return res.status(400).json({ message: "A nova senha deve ter entre 6 e 40 caracteres" });
      }

      const [user] = await db.select().from(users).where(eq(users.id, req.userId)).limit(1);
      if (!user || !user.passwordHash) {
        return res.status(400).json({ message: "Usuário inválido" });
      }

      const valid = await bcrypt.compare(currentPassword, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ message: "Senha atual incorreta" });
      }

      const newHash = await bcrypt.hash(newPassword, 10);
      await db.update(users).set({ passwordHash: newHash, updatedAt: new Date() }).where(eq(users.id, req.userId));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erro ao alterar senha" });
    }
  });

  // ── POST /api/user/clear-history — delete all generated images ────
  app.post("/api/user/clear-history", requireAuth, async (req: any, res) => {
    try {
      await db.delete(generatedImages).where(eq(generatedImages.userId, req.userId));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erro ao limpar histórico" });
    }
  });

  // ── POST /api/user/deactivate — soft-delete account ───────────────
  app.post("/api/user/deactivate", requireAuth, async (req: any, res) => {
    try {
      await db.update(users).set({ isDeactivated: true, updatedAt: new Date() }).where(eq(users.id, req.userId));
      posthogCapture({
        req,
        distinctId: String(req.userId),
        event: "account deactivated",
      });
      req.session.destroy(() => {
        res.clearCookie("connect.sid");
        res.json({ success: true });
      });
    } catch (error) {
      res.status(500).json({ message: "Erro ao desativar conta" });
    }
  });

  // ── DELETE /api/generated-images/:id — delete a single image ──────
  app.delete("/api/generated-images/:id", requireAuth, async (req: any, res) => {
    try {
      const imageId = req.params.id;
      const image = await storage.getGeneratedImage(imageId);
      if (!image || image.userId !== req.userId) {
        return res.status(404).json({ message: "Imagem não encontrada" });
      }
      await storage.deleteGeneratedImage(imageId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erro ao excluir imagem" });
    }
  });

  // ── GET /api/credits — user credit balance ─────────────────────────
  app.get("/api/credits", requireAuth, async (req: any, res) => {
    try {
      const userId = req.userId;
      let credits = await storage.getUserCredits(userId);
      if (!credits) credits = await storage.createUserCredits(userId, { initialBalance: 0 });
      res.json(credits);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar créditos" });
    }
  });

  return httpServer;
}
