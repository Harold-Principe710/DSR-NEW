import { ADMIN_PIX_PRODUCT_LABELS, type AdminPixProductKey } from "@shared/admin-types";

type PixProductDefinition = {
  requestName: string;
  adminLabel: string;
};

export type PixProductKey = AdminPixProductKey;

export const PIX_PRODUCTS: Record<PixProductKey, PixProductDefinition> = {
  single_photo: {
    requestName: "Ebook Foto Perfeita",
    adminLabel: ADMIN_PIX_PRODUCT_LABELS.single_photo,
  },
  pack_photos: {
    requestName: "Ebook Fotos Pro",
    adminLabel: ADMIN_PIX_PRODUCT_LABELS.pack_photos,
  },
  video_pov: {
    requestName: "Ebook Vídeos Pro",
    adminLabel: ADMIN_PIX_PRODUCT_LABELS.video_pov,
  },
  pack_photos_video_pov: {
    requestName: "Ebook Fotos e Vídeos Pro",
    adminLabel: ADMIN_PIX_PRODUCT_LABELS.pack_photos_video_pov,
  },
  video_pov_pack_photos: {
    requestName: "Ebook Vídeos e Fotos",
    adminLabel: ADMIN_PIX_PRODUCT_LABELS.video_pov_pack_photos,
  },
  unlimited_daily: {
    requestName: "Ebook Completo",
    adminLabel: ADMIN_PIX_PRODUCT_LABELS.unlimited_daily,
  },
  upsell_instapro_weekly: {
    requestName: "IA Ilimitada 15 dias",
    adminLabel: ADMIN_PIX_PRODUCT_LABELS.upsell_instapro_weekly,
  },
};

type ResolvePixProductKeyParams = {
  planId?: string | null;
  journeyNode?: string | null;
  requestName?: string | null;
  amountCents?: number | null;
};

function normalize(value?: string | null): string {
  return String(value || "").trim().toLowerCase();
}

export function resolvePixProductKey({
  planId,
  journeyNode,
  requestName,
  amountCents,
}: ResolvePixProductKeyParams): PixProductKey | null {
  const normalizedRequestName = normalize(requestName);
  if (normalizedRequestName) {
    const matchedEntry = Object.entries(PIX_PRODUCTS).find(([, definition]) => (
      normalize(definition.requestName) === normalizedRequestName
    ));
    if (matchedEntry) return matchedEntry[0] as PixProductKey;
  }

  const normalizedPlanId = normalize(planId);
  const normalizedJourneyNode = normalize(journeyNode);

  switch (normalizedPlanId) {
    case "1-foto":
    case "1-foto-1990":
      return "single_photo";
    case "pack-fotos-1990":
    case "pack-fotos-2990":
      return "pack_photos";
    case "video-pov-1990":
    case "video-pov-990":
    case "video-pov-promo-1990":
    case "video-pov-2990":
      return "video_pov";
    case "video-pov-pack-2990":
    case "video-pov-pack-3990":
      return normalizedJourneyNode.includes("pack")
        ? "pack_photos_video_pov"
        : "video_pov_pack_photos";
    case "ilimitado":
    case "ilimitado-pack-fotos-4490":
      return "unlimited_daily";
    case "upsell-instapro-semanal":
      return "upsell_instapro_weekly";
    // "10-fotos" (R$ 49,90) e "10-fotos-1-video" (R$ 69,90) — bem como suas
    // contrapartes do A/B "landing-pricing" — são SKUs do popup "Quer ver
    // mais" e não têm chave em PIX_PRODUCTS. Retornar null evita o mislabel
    // para "unlimited_daily" via fallback de amount.
    case "10-fotos":
    case "10-fotos-1-video":
    case "10-fotos-5990":
    case "10-fotos-1-video-7990":
      return null;
  }

  // Amount-only fallback used when the pix_generated event has no planId in
  // metadata. It is intentionally conservative: it only resolves keys when a
  // single SKU matches the amount. Ambiguous amounts (990, 4990, 6990)
  // overlap multiple SKUs, so we return null and let the admin UI show "—"
  // instead of mislabeling.
  switch (amountCents) {
    case 1990:
      return normalizedJourneyNode.includes("video") ? "video_pov" : "pack_photos";
    case 2990:
      return normalizedJourneyNode.includes("pack")
        ? "pack_photos_video_pov"
        : "video_pov_pack_photos";
    case 4990:
      // 4990 matches both "ilimitado" and "10-fotos". Disambiguate via
      // post-purchase journey nodes where ilimitado is sold; otherwise
      // bail out rather than guess.
      if (
        normalizedJourneyNode.includes("dashboard")
        || normalizedJourneyNode.includes("gallery")
        || normalizedJourneyNode.includes("settings")
      ) {
        return "unlimited_daily";
      }
      return null;
    case 5990:
      return "upsell_instapro_weekly";
    default:
      return null;
  }
}

export function getPixRequestProductName(productKey: PixProductKey): string {
  return PIX_PRODUCTS[productKey].requestName;
}

export function getAdminPixProductLabel(productKey: PixProductKey): string {
  return PIX_PRODUCTS[productKey].adminLabel;
}
