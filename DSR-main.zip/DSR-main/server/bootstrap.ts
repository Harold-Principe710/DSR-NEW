import { APP_TIME_ZONE } from "@shared/timezone";

process.env.TZ = APP_TIME_ZONE;

void import("./index");
