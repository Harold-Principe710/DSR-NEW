import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";
import { APP_TIME_ZONE } from "@shared/timezone";
import dns from "node:dns";
import { getDatabaseSslConfig } from "./db-ssl";

// Force IPv4 for database connection because DigitalOcean App Platform and Neon IPv6 can conflict
dns.setDefaultResultOrder("ipv4first");

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Determine if we're in production
const isProduction = process.env.NODE_ENV === "production";
const databaseUrl = process.env.DATABASE_URL;

// Configure pool with SSL for production and connection retry settings
export const pool = new Pool({
  connectionString: databaseUrl,
  ssl: getDatabaseSslConfig(databaseUrl),
  // Connection pool settings for reliability
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

// Log connection status on startup. Also enforce a statement_timeout so a
// stuck/slow query can't pin a pool slot indefinitely — without this, one slow
// SELECT can drain the 10-slot pool and stall every incoming request, which
// surfaces on the client as the landing "loading forever" symptom.
pool.on('connect', (client) => {
  console.log('[db] Pool client connected to database');
  void (async () => {
    try {
      await client.query(`SET TIME ZONE '${APP_TIME_ZONE}'`);
      await client.query("SET statement_timeout = 8000");
    } catch (err: any) {
      console.error('[db] Failed to initialize session settings:', err.message);
    }
  })();
});

pool.on('error', (err) => {
  console.error('[db] Unexpected pool error:', err.message);
});

// Test database connection (called asynchronously after server starts)
export async function testDatabaseConnection(): Promise<boolean> {
  try {
    const client = await pool.connect();
    console.log('[db] Database connection successful');
    client.release();
    return true;
  } catch (err: any) {
    console.error('[db] Database connection failed:', err.message);
    console.error('[db] DATABASE_URL exists:', !!process.env.DATABASE_URL);
    console.error('[db] Is production:', isProduction);
    return false;
  }
}

export const db = drizzle(pool, { schema });
