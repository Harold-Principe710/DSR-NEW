/**
 * Server entry. Kept intentionally minimal: only loads express + http +
 * compression + json parser, then binds the HTTP port. All heavy modules
 * (routes, storage, drizzle pool, websocket, posthog) are pulled in via the
 * dynamic `import("./bootstrap-app")` call below, so any slow side-effect
 * during their evaluation can never keep DigitalOcean's readiness probe from
 * reaching /health on port 8080.
 */
import express, { type Express } from "express";
import compression from "compression";
import { createServer } from "http";
import { APP_TIME_ZONE } from "@shared/timezone";

console.log("-> Iniciando processo do servidor...");

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

const app: Express = express();
const httpServer = createServer(app);

let isFullyInitialized = false;
let initializationError: string | null = null;
const isProduction = process.env.NODE_ENV === "production";

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    timeZone: APP_TIME_ZONE,
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}

function resolveListenPort(): number {
  const fallbackPort = isProduction ? "8080" : "5000";
  const rawPort = process.env.PORT?.trim() || fallbackPort;
  const port = Number(rawPort);
  if (!/^\d+$/.test(rawPort) || !Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`PORT inválida: ${rawPort}`);
  }
  return port;
}

// Health endpoints: registered FIRST, before any other middleware, so they
// keep working even if every later middleware misbehaves.
app.get("/health", (_req, res) => {
  res.status(200).json({
    status: "ok",
    ready: isFullyInitialized,
    error: initializationError,
  });
});

app.get("/ready", (_req, res) => {
  if (isFullyInitialized) {
    res.status(200).json({ status: "ready" });
  } else if (initializationError) {
    res.status(503).json({ status: "error", error: initializationError });
  } else {
    res.status(503).json({ status: "initializing" });
  }
});

// Compression + JSON parser must run on every request (webhooks need rawBody),
// so they are mounted before the dynamic bootstrap registers /api routes.
app.use(compression());
app.use(
  express.json({
    limit: "25mb",
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);
app.use(express.urlencoded({ extended: false }));

httpServer.on("error", (err: NodeJS.ErrnoException) => {
  console.error("[startup] httpServer error:", err.code, err.message);
  initializationError = `httpServer error: ${err.code || err.message}`;
});

const port = resolveListenPort();
httpServer.listen({ port, host: "0.0.0.0" }, () => {
  log(`serving on port ${port}`);
  void runBootstrap();
});

async function runBootstrap() {
  try {
    const { bootstrapApp } = await import("./bootstrap-app");
    await bootstrapApp(app, httpServer, {
      setReady: () => {
        isFullyInitialized = true;
      },
      setError: (message: string) => {
        initializationError = message;
      },
      log,
    });
  } catch (err: any) {
    initializationError = err?.message || String(err);
    log(`bootstrap failed: ${initializationError}`, "startup");
  }
}

const shutdown = async (signal: string) => {
  log(`Received ${signal}, exiting…`, "shutdown");
  try {
    const { shutdownPosthog } = await import("./posthog");
    await shutdownPosthog();
  } catch {
    // posthog might never have loaded; ignore.
  }
  process.exit(0);
};
process.on("SIGTERM", () => { void shutdown("SIGTERM"); });
process.on("SIGINT", () => { void shutdown("SIGINT"); });
