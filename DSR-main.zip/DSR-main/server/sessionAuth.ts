/**
 * Minimal session-only auth for DesireAI - NO user login/registration.
 * Uses express-session to assign a sessionId per visitor (as anonymous userId).
 */
import session from "express-session";
import connectPg from "connect-pg-simple";
import type { Request, Response, NextFunction } from "express";
import type { Express } from "express";
import { pool } from "./db";

let cachedSessionMiddleware: ReturnType<typeof session> | null = null;

function resolveSessionSecret(): string {
  const raw = (process.env.SESSION_SECRET || "").trim();
  const isPlaceholder = raw === "" || raw === "your_session_secret_key";

  if (process.env.NODE_ENV === "production" && isPlaceholder) {
    throw new Error("SESSION_SECRET inválido em produção. Defina um segredo forte (ex: openssl rand -hex 32).");
  }

  if (isPlaceholder) {
    console.warn("[session] SESSION_SECRET ausente/placeholder em desenvolvimento. Usando fallback temporário.");
    return "dev_secret_change_me";
  }

  if (raw.length < 16) {
    console.warn("[session] SESSION_SECRET curto; recomenda-se no mínimo 16 caracteres.");
  }

  return raw;
}

export function getSession() {
  if (cachedSessionMiddleware) return cachedSessionMiddleware;

  const sessionTtl = 30 * 24 * 60 * 60 * 1000; // 30 days
  const sessionSecret = resolveSessionSecret();

  const isDummyDb = process.env.DATABASE_URL?.includes("dummy");

  if (isDummyDb) {
    cachedSessionMiddleware = session({
      secret: sessionSecret,
      resave: false,
      saveUninitialized: true, // Create session on first visit
      cookie: {
        httpOnly: true,
        secure: false,
        sameSite: "lax",
        maxAge: sessionTtl,
      },
    });
    return cachedSessionMiddleware;
  }

  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    pool,
    createTableIfMissing: false,
    ttl: Math.floor(sessionTtl / 1000),
    tableName: "sessions",
  });

  cachedSessionMiddleware = session({
    secret: sessionSecret,
    store: sessionStore,
    resave: false,
    saveUninitialized: true,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: sessionTtl,
    },
  });
  return cachedSessionMiddleware;
}

export function setupSession(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());
}

/**
 * Middleware: assigns req.userId.
 * If the user registered via funnel (session.userId exists), use that.
 * Otherwise, fall back to sessionId for anonymous usage.
 */
export function withSessionId(req: Request, res: Response, next: NextFunction) {
  const session = req.session as any;
  if (session && session.userId) {
    (req as any).userId = session.userId;
  } else {
    const sid = (req.sessionID || "anonymous-" + Math.random().toString(36).slice(2));
    (req as any).userId = sid;
  }
  next();
}

/**
 * Middleware: requires user to be a registered user (has a real userId in session, not just sessionID).
 * Returns 401 if not authenticated.
 */
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const session = req.session as any;
  if (session && session.userId) {
    (req as any).userId = session.userId;
    next();
  } else {
    res.status(401).json({ message: "Não autenticado" });
  }
}
