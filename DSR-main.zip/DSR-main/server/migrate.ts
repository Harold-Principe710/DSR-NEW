import { spawn } from "child_process";
import pg from "pg";
import { getDatabaseSslConfig } from "./db-ssl";

const { Pool } = pg;

async function runPreMigrationIntegrityRepairs(): Promise<void> {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) return;

  const pool = new Pool({
    connectionString: databaseUrl,
    ssl: getDatabaseSslConfig(databaseUrl),
    max: 1,
    connectionTimeoutMillis: 10000,
  });

  try {
    await pool.query(`
      create table if not exists db_integrity_archives (
        id uuid primary key default gen_random_uuid(),
        archive_type text not null,
        entity_key text,
        row_data jsonb not null,
        archived_at timestamp not null default now()
      )
    `);

    const userCreditsExists = await pool.query<{ exists: boolean }>(
      "select to_regclass('public.user_credits') is not null as exists",
    );
    if (userCreditsExists.rows[0]?.exists) {
      await pool.query(`
        insert into db_integrity_archives (archive_type, entity_key, row_data)
        select 'user_credits_duplicate', user_id, to_jsonb(uc)
        from (
          select
            uc.*,
            row_number() over (
              partition by user_id
              order by updated_at desc nulls last, created_at desc nulls last, id desc
            ) as rn
          from user_credits uc
        ) uc
        where rn > 1
      `);

      await pool.query(`
        with ranked as (
          select
            uc.*,
            first_value(id) over (
              partition by user_id
              order by updated_at desc nulls last, created_at desc nulls last, id desc
            ) as canonical_id,
            count(*) over (partition by user_id) as duplicate_count
          from user_credits uc
        ),
        merged as (
          select
            user_id,
            max(canonical_id) as canonical_id,
            max(duplicate_count) as duplicate_count,
            sum(balance)::int as balance,
            sum(total_purchased)::int as total_purchased,
            sum(total_spent)::int as total_spent,
            bool_or(has_purchased) as has_purchased,
            min(plan_start_date) as plan_start_date,
            max(plan_end_date) as plan_end_date,
            bool_or(admin_assigned_plan) as admin_assigned_plan,
            max(last_plan_credit_grant) as last_plan_credit_grant,
            max(last_daily_credits) as last_daily_credits,
            sum(daily_credits_accumulated)::int as daily_credits_accumulated,
            bool_or(referral_reward_paid) as referral_reward_paid,
            sum(referral_count)::int as referral_count,
            sum(referral_credits_earned)::int as referral_credits_earned,
            bool_or(has_completed_onboarding) as has_completed_onboarding,
            sum(monthly_image_count)::int as monthly_image_count,
            sum(monthly_video_count)::int as monthly_video_count,
            max(last_monthly_reset) as last_monthly_reset,
            min(created_at) as created_at
          from ranked
          group by user_id
          having max(duplicate_count) > 1
        )
        update user_credits uc
        set
          balance = merged.balance,
          total_purchased = merged.total_purchased,
          total_spent = merged.total_spent,
          has_purchased = merged.has_purchased,
          plan_start_date = merged.plan_start_date,
          plan_end_date = merged.plan_end_date,
          admin_assigned_plan = merged.admin_assigned_plan,
          last_plan_credit_grant = merged.last_plan_credit_grant,
          last_daily_credits = merged.last_daily_credits,
          daily_credits_accumulated = merged.daily_credits_accumulated,
          referral_reward_paid = merged.referral_reward_paid,
          referral_count = merged.referral_count,
          referral_credits_earned = merged.referral_credits_earned,
          has_completed_onboarding = merged.has_completed_onboarding,
          monthly_image_count = merged.monthly_image_count,
          monthly_video_count = merged.monthly_video_count,
          last_monthly_reset = merged.last_monthly_reset,
          created_at = merged.created_at,
          updated_at = now()
        from merged
        where uc.id = merged.canonical_id
      `);

      await pool.query(`
        delete from user_credits uc
        using (
          select
            id,
            row_number() over (
              partition by user_id
              order by updated_at desc nulls last, created_at desc nulls last, id desc
            ) as rn
          from user_credits
        ) ranked
        where uc.id = ranked.id
          and ranked.rn > 1
      `);
    }

    const pixPaymentsExists = await pool.query<{ exists: boolean }>(
      "select to_regclass('public.pix_payments') is not null as exists",
    );
    if (pixPaymentsExists.rows[0]?.exists) {
      await pool.query(`
        insert into db_integrity_archives (archive_type, entity_key, row_data)
        select 'pix_payments_duplicate_provider_id', abacate_pay_id, to_jsonb(pp)
        from (
          select
            pp.*,
            row_number() over (
              partition by abacate_pay_id
              order by
                case status when 'paid' then 0 when 'pending' then 1 else 2 end,
                paid_at desc nulls last,
                created_at desc nulls last,
                id desc
            ) as rn
          from pix_payments pp
          where abacate_pay_id is not null
            and abacate_pay_id <> 'unknown'
            and abacate_pay_id not like 'pending:%'
        ) pp
        where rn > 1
      `);

      await pool.query(`
        update pix_payments pp
        set abacate_pay_id = concat(pp.abacate_pay_id, ':duplicate:', pp.id)
        from (
          select
            id,
            row_number() over (
              partition by abacate_pay_id
              order by
                case status when 'paid' then 0 when 'pending' then 1 else 2 end,
                paid_at desc nulls last,
                created_at desc nulls last,
                id desc
            ) as rn
          from pix_payments
          where abacate_pay_id is not null
            and abacate_pay_id <> 'unknown'
            and abacate_pay_id not like 'pending:%'
        ) ranked
        where pp.id = ranked.id
          and ranked.rn > 1
      `);
    }
  } catch (err: any) {
    const code = err?.code ? ` (${err.code})` : "";
    console.warn(`[migrate] Pre-migration integrity repair skipped/failed${code}:`, err?.message || err);
    if (process.env.NODE_ENV === "production") throw err;
  } finally {
    await pool.end();
  }
}

export async function runSchemaMigrations(): Promise<void> {
  console.log("[migrate] Starting database schema migration...");
  console.log("[migrate] Environment:", process.env.NODE_ENV || "unknown");
  console.log("[migrate] DATABASE_URL exists:", !!process.env.DATABASE_URL);

  await runPreMigrationIntegrityRepairs();

  return new Promise((resolve, reject) => {
    // Run drizzle-kit push without --force to protect production data
    // Auto-answer prompts with safe options (add constraints without truncating)
    const child = spawn("npx", ["drizzle-kit", "push"], {
      env: { ...process.env },
      stdio: "pipe", // Capture stdio so we can log it
      shell: false,
    });

    // Capture stdout
    child.stdout?.on('data', (data) => {
      const output = data.toString().trim();
      if (output) console.log(`[migrate] ${output}`);
    });

    // Capture stderr
    child.stderr?.on('data', (data) => {
      const output = data.toString().trim();
      if (output) console.error(`[migrate] ${output}`);
    });

    // Wait for prompts to appear, then send safe answers:
    // "n" = don't truncate tables (safe option for constraint prompts)
    // Multiple "n" to handle any number of prompts
    setTimeout(() => {
      try {
        if (child.stdin && !child.stdin.destroyed) {
          child.stdin.write("n\nn\nn\nn\nn\n");
          child.stdin.end();
        }
      } catch (err) {
        // Ignore EPIPE errors - happens when process already completed
      }
    }, 2000);

    // Handle stdin errors gracefully (e.g., EPIPE when process completes quickly)
    child.stdin?.on("error", () => {
      // Ignore - process likely completed without needing input
    });

    child.on("close", (code) => {
      if (code === 0) {
        console.log("[migrate] Database schema migration completed successfully");
        resolve();
      } else {
        console.error("[migrate] Database schema migration failed with code:", code);
        const error = new Error(`Database schema migration failed with code ${code}`);
        if (process.env.NODE_ENV === "production") {
          reject(error);
          return;
        }
        console.warn("[migrate] Warning: Migration failed but server will continue in development. Run 'npm run db:push' manually to fix schema.");
        resolve();
      }
    });

    child.on("error", (err) => {
      console.error("[migrate] Migration error:", err.message);
      if (process.env.NODE_ENV === "production") {
        reject(err);
        return;
      }
      console.warn("[migrate] Warning: Server will continue in development. Run 'npm run db:push' manually if needed.");
      resolve();
    });
  });
}
