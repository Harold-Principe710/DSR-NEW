import bcrypt from "bcryptjs";

async function main() {
  const rawPassword = process.argv[2];

  if (!rawPassword) {
    console.error('Uso: npm run hash:password -- "sua-senha"');
    process.exit(1);
  }

  const hash = await bcrypt.hash(rawPassword, 12);
  console.log(hash);
}

main().catch((error) => {
  console.error("Falha ao gerar hash:", error);
  process.exit(1);
});
