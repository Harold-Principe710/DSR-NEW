import { sql } from "drizzle-orm";
import { db } from "../server/db";

async function main() {
  const result = await db.execute(sql`
    with latest_event as (
      select distinct on (fe.session_id)
        fe.session_id,
        fe.step
      from funnel_events fe
      order by fe.session_id, fe.occurred_at desc nulls last, fe.created_at desc nulls last
    ),
    max_event as (
      select
        fe.session_id,
        max(fe.step) as step
      from funnel_events fe
      group by fe.session_id
    )
    update funnel_sessions fs
    set
      current_step = coalesce(le.step, fs.current_step),
      max_step_reached = greatest(
        fs.current_step,
        fs.max_step_reached,
        coalesce(me.step, fs.current_step)
      ),
      updated_at = now()
    from latest_event le
    full join max_event me on me.session_id = le.session_id
    where fs.session_id = coalesce(le.session_id, me.session_id)
    returning fs.session_id
  `);

  console.log(`[backfill-funnel-steps] Sessões atualizadas: ${result.rows.length}`);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("[backfill-funnel-steps] Falha:", error);
    process.exit(1);
  });
