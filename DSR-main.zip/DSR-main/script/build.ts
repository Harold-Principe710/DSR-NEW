import { spawn } from 'child_process';
import path from 'path';

const isWin = process.platform === "win32";
const npmCmd = isWin ? 'npm.cmd' : 'npm';
const npxCmd = isWin ? 'npx.cmd' : 'npx';

const runCommand = (cmd: string, args: string[]) => {
  return new Promise((resolve, reject) => {
    const process = spawn(cmd, args, { stdio: 'inherit' });
    process.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`Command ${cmd} ${args.join(' ')} failed with code ${code}`));
      } else {
        resolve(null);
      }
    });
  });
};

async function build() {
  try {
    console.log("Building client...");
    await runCommand(npxCmd, ['vite', 'build']);
    console.log("Building server...");
    await runCommand(npxCmd, ['esbuild', 'server/bootstrap.ts', '--platform=node', '--packages=external', '--bundle', '--format=cjs', '--outfile=dist/index.cjs']);
    console.log("Build complete.");
  } catch (error) {
    console.error("Build failed:", error);
    process.exit(1);
  }
}

build();
