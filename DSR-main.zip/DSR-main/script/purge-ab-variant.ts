import pg from "pg";

const { Pool } = pg;

const APPLY = process.argv.includes("--apply");

if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL não definido.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function main() {
  const client = await pool.connect();
  try {
    const { rows: [{ count }] } = await client.query<{ count: string }>(
      `SELECT COUNT(*)::text AS count FROM funnel_events WHERE metadata::jsonb ? 'abVariant'`,
    );
    console.log(`[purge-ab-variant] Eventos com metadata.abVariant: ${count}`);

    if (!APPLY) {
      console.log("[purge-ab-variant] Dry-run. Execute com --apply para remover.");
      return;
    }

    const res = await client.query(
      `UPDATE funnel_events
         SET metadata = (metadata::jsonb - 'abVariant')::json
       WHERE metadata::jsonb ? 'abVariant'`,
    );
    console.log(`[purge-ab-variant] Limpos ${res.rowCount} eventos.`);
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((error) => {
  console.error("[purge-ab-variant] Falha:", error);
  process.exit(1);
});
