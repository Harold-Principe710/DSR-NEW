import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, pgEnum, real, uniqueIndex, json, serial, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";

export const ADMIN_EMAILS = [
  "kjt62bh45c@privaterelay.appleid.com",
  "ramossavi@gmail.com",
];

export const planTierEnum = pgEnum("plan_tier", ["free", "starter", "creator", "pro", "enterprise"]);

export interface Feature {
  name: string;
  available: boolean;
  info?: string;
}

export const SUBSCRIPTION_PLANS = {
  free: {
    id: "free",
    name: "Gratuito",
    description: "Para experimentar a plataforma",
    monthlyPrice: 0,
    credits: 0,
    baseCreditPrice: 0.049,
    aiModels: ["runway", "seedance", "z_image", "default"] as const,
    speedMultiplier: 1,
    chatAccess: false,
    features: [
      { name: "60 créditos de boas-vindas", available: true },
      { name: "30 créditos diários (limitado)", available: true },
      { name: "Acesso ao Runway, Seedance 1.5 Pro e Z-Image", available: true },
    ],
  },
  starter: {
    id: "starter",
    name: "Starter",
    description: "Narração + Imagem",
    monthlyPrice: 47,
    credits: 1000,
    baseCreditPrice: 0.035,
    aiModels: ["sora2", "midjourney", "gpt4o", "elevenlabs", "default", "nano_banana", "nano_banana_2", "imagen4", "z_image", "flux2_pro", "grok"] as const,
    speedMultiplier: 1,
    maxConcurrentGenerations: 1,
    videoAccess: false,
    audioAccess: true,
    chatAccess: false,
    features: [
      { name: "8 modelos de IA de imagem", available: true, info: "Nano Banana Pro, Imagen 4, Midjourney, Z Image, Flux 2 Pro, Imagem 4K, Grok Imagine" },
      { name: "Editar Imagem", available: true, info: "Edite suas imagens intuitivamente através de um chat" },
      { name: "Funcionalidades exclusivas", available: true, info: "Geração em massa, Upscale para 4K, Gerar Imagem em todas IAs com 1 prompt, Expansão Inteligente de Imagem" },
      { name: "Narração com ElevenLabs", available: true },
      { name: "Transcrição de áudio", available: true },

    ],
  },
  creator: {
    id: "creator",
    name: "Creator",
    description: "Chat + Vídeo",
    monthlyPrice: 97,
    credits: 2500,
    baseCreditPrice: 0.035,
    aiModels: ["seedance", "sora2", "sora2_pro", "grok", "veo3_fast", "veo3_quality", "runway", "midjourney", "kling26", "kling30", "default", "nano_banana", "nano_banana_2", "imagen4", "z_image", "flux2_pro"] as const,
    speedMultiplier: 1,
    popular: true,
    maxConcurrentGenerations: -1,
    videoAccess: true,
    audioAccess: true,
    chatAccess: true,
    features: [
      { name: "Tudo do Starter +", available: true },
      { name: "9 IAs de vídeo", available: true, info: "Crie vídeos a partir de prompt ou imagens com Kling 3.0, Kling 2.6, Veo 3.1, Sora 2, Sora 2 Pro, Seedance 1.5 Pro, Grok, e Runway." },
      { name: "Menu Estilo Livre", available: true, info: "Acelere seu fluxo de trabalho usando nosso sistema de nodes drag and drop." },
      { name: "Mudar Personagem", available: true, info: "Troque a pessoa de um vídeo por qualquer outra com o Kling Motion 2.6" },
      { name: "Lip Sync", available: true, info: "Faça sincronização labial em vídeos com a tecnologia da InfiniteTalk" },
    ],
  },
  pro: {
    id: "pro", // Replaces scale
    name: "Pro",
    description: "Para profissionais e agências",
    monthlyPrice: 297,
    credits: 8500,
    baseCreditPrice: 0.029,
    aiModels: ["seedance", "sora2", "sora2_pro", "grok", "veo3_fast", "veo3_quality", "runway", "midjourney", "kling26", "kling30", "default", "nano_banana", "nano_banana_2", "imagen4", "z_image", "flux2_pro"] as const,
    speedMultiplier: 1.5,
    maxConcurrentGenerations: -1,
    videoAccess: true,
    audioAccess: true,
    chatAccess: true,
    features: [
      { name: "Tudo do Creator +", available: true },
      { name: "Processamento mais rápido", available: true },
      { name: "Early Access para novas IAs", available: true },
      { name: "Créditos avulsos mais baratos", available: true },

    ],
  },
  enterprise: {
    id: "enterprise", // Replaces big_scale
    name: "Enterprise",
    description: "Para empresas e grandes operações",
    monthlyPrice: 0, // Contact sales
    credits: 0, // Custom
    baseCreditPrice: 0.030,
    aiModels: ["seedance", "sora2", "sora2_pro", "grok", "veo3_fast", "veo3_quality", "runway", "midjourney", "kling26", "kling30", "default", "nano_banana", "nano_banana_2", "imagen4", "z_image", "flux2_pro"] as const,
    speedMultiplier: 2,
    maxConcurrentGenerations: -1,
    videoAccess: true,
    audioAccess: true,
    chatAccess: true,
    features: [
      { name: "Contas para equipes", available: true },
      { name: "Acesso à API privada", available: true },
      { name: "Sistema Whitelabel", available: true },
      { name: "Soluções personalizadas", available: true },
      { name: "SLA garantido", available: true },
      { name: "Account Manager dedicado", available: true },
    ],
  },
} as const;

export type PlanTier = keyof typeof SUBSCRIPTION_PLANS;
export type AIModelId = "sora2" | "sora2_pro" | "grok" | "veo3_fast" | "veo3_quality" | "seedance" | "runway" | "midjourney" | "kling26" | "gpt4o" | "elevenlabs" | "kling30" | "z_image" | "default" | "nano_banana" | "nano_banana_2" | "imagen4" | "flux2_pro";

export type ChatModelId =
  | "claude_sonnet_4_5"
  | "claude_haiku_4_5"
  | "gpt_5_2"
  | "gpt_5_mini"
  | "gpt_4o"
  | "gemini_3_pro"
  | "gemini_3_flash";

export const CHAT_MODELS: Record<ChatModelId, {
  name: string;
  apiModel: string;
  creditCost: number;
  description: string;
  vision: boolean;
  provider: "openai" | "anthropic" | "google";
}> = {
  "gpt_5_2": {
    name: "GPT-5.2",
    apiModel: "gpt-5.2",
    creditCost: 3,
    description: "Modelo mais inteligente da OpenAI",
    vision: true,
    provider: "openai"
  },
  "gpt_5_mini": {
    name: "GPT-5 Mini",
    apiModel: "gpt-5-mini",
    creditCost: 1,
    description: "Rápido e eficiente para tarefas simples",
    vision: true,
    provider: "openai"
  },
  "gpt_4o": {
    name: "GPT-4o",
    apiModel: "gpt-4o",
    creditCost: 2,
    description: "Versátil e equilibrado",
    vision: true,
    provider: "openai"
  },
  "claude_sonnet_4_5": {
    name: "Claude 4.5 Sonnet",
    apiModel: "claude-3-5-sonnet-latest", // Fallback to current available if 4.5 API name differs, but plan says verified
    creditCost: 3,
    description: "Equilíbrio ideal entre inteligência e velocidade",
    vision: true,
    provider: "anthropic"
  },
  "claude_haiku_4_5": {
    name: "Claude 4.5 Haiku",
    apiModel: "claude-3-5-haiku-latest",
    creditCost: 1,
    description: "Modelo mais rápido e econômico da Anthropic",
    vision: false, // Haiku historically text-focused, check if 4.5 has vision. Assuming text for now to be safe or true if known. 3.5 Haiku has no vision? Actually 3.5 Haiku does not support vision yet properly in all endpoints, stick to text to be safe unless verified.
    provider: "anthropic"
  },
  "gemini_3_pro": {
    name: "Gemini 3 Pro",
    apiModel: "gemini-1.5-pro", // Fallback to 1.5 if 3 not yet in SDK types
    creditCost: 3,
    description: "Melhor modelo do Google para raciocínio complexo",
    vision: true,
    provider: "google"
  },
  "gemini_3_flash": {
    name: "Gemini 3 Flash",
    apiModel: "gemini-1.5-flash",
    creditCost: 1,
    description: "Alta velocidade e baixa latência",
    vision: true,
    provider: "google"
  }
};


export function getMaxConcurrentGenerations(planTier: PlanTier): number {
  const plan = SUBSCRIPTION_PLANS[planTier];
  if ('maxConcurrentGenerations' in plan) {
    return plan.maxConcurrentGenerations;
  }
  return 1;
}

export function hasUnlimitedConcurrentGenerations(planTier: PlanTier): boolean {
  return getMaxConcurrentGenerations(planTier) === -1;
}

export function getAvailableModels(planTier: PlanTier): readonly AIModelId[] {
  return SUBSCRIPTION_PLANS[planTier].aiModels;
}

export function isModelAvailableForPlan(planTier: PlanTier, modelId: AIModelId): boolean {
  const availableModels = getAvailableModels(planTier);
  return availableModels.includes(modelId);
}


export function calculateCreditPrice(planTier: PlanTier, quantity: number): {
  subtotal: number;
  discount: number;
  discountPercent: number;
  total: number;
  pricePerCredit: number;
} {
  const plan = SUBSCRIPTION_PLANS[planTier];
  const basePrice = plan.baseCreditPrice;

  let discountPercent = 0;
  if (quantity >= 20000) {
    discountPercent = 10;
  } else if (quantity >= 10000) {
    discountPercent = 6;
  } else if (quantity >= 5000) {
    discountPercent = 6;
  } else if (quantity >= 2500) {
    discountPercent = 4;
  }

  const subtotal = quantity * basePrice;
  const discount = subtotal * (discountPercent / 100);
  const total = subtotal - discount;
  const pricePerCredit = total / quantity;

  return {
    subtotal: Math.round(subtotal * 100) / 100,
    discount: Math.round(discount * 100) / 100,
    discountPercent,
    total: Math.round(total * 100) / 100,
    pricePerCredit: Math.round(pricePerCredit * 1000) / 1000,
  };
}

export const KIE_COST_MARGIN = 1.1;

export function applyKieCostMargin(usd: number): number {
  return usd * KIE_COST_MARGIN;
}

export const KIE_AI_COSTS: Record<string, {
  usdCost: number;
  kieCredits: number;
  bigShortsCredits: number;
  description: string;
}> = {
  "seedance_4s_no_audio": { usdCost: 0.035, kieCredits: 7, bigShortsCredits: 60, description: "Seedance 1.5 Pro 480P 4s sem áudio" },
  "seedance_4s_audio": { usdCost: 0.07, kieCredits: 14, bigShortsCredits: 60, description: "Seedance 1.5 Pro 480P 4s com áudio" },
  "seedance_8s_no_audio": { usdCost: 0.07, kieCredits: 14, bigShortsCredits: 60, description: "Seedance 1.5 Pro 480P 8s sem áudio" },
  "seedance_8s_audio": { usdCost: 0.14, kieCredits: 28, bigShortsCredits: 60, description: "Seedance 1.5 Pro 480P 8s com áudio" },
  "seedance_12s_no_audio": { usdCost: 0.095, kieCredits: 19, bigShortsCredits: 60, description: "Seedance 1.5 Pro 480P 12s sem áudio" },
  "seedance_12s_audio": { usdCost: 0.19, kieCredits: 38, bigShortsCredits: 60, description: "Seedance 1.5 Pro 480P 12s com áudio" },
  "sora2_10s_audio": { usdCost: 0.15, kieCredits: 30, bigShortsCredits: 60, description: "Sora 2 10s com áudio" },
  "sora2_15s_audio": { usdCost: 0.175, kieCredits: 35, bigShortsCredits: 60, description: "Sora 2 15s com áudio" },
  "sora2_pro_standard_10s": { usdCost: 0.75, kieCredits: 150, bigShortsCredits: 120, description: "Sora 2 Pro Standard 10s" },
  "sora2_pro_standard_15s": { usdCost: 1.35, kieCredits: 270, bigShortsCredits: 120, description: "Sora 2 Pro Standard 15s" },
  "sora2_pro_high_10s": { usdCost: 1.65, kieCredits: 330, bigShortsCredits: 120, description: "Sora 2 Pro High 10s" },
  "sora2_pro_high_15s": { usdCost: 3.15, kieCredits: 630, bigShortsCredits: 120, description: "Sora 2 Pro High 15s" },
  "veo3_fast": { usdCost: 0.30, kieCredits: 60, bigShortsCredits: 120, description: "VEO 3.1 Fast" },
  "veo3_quality": { usdCost: 1.25, kieCredits: 250, bigShortsCredits: 400, description: "VEO 3.1 Quality" },
  "grok_6s": { usdCost: 0.10, kieCredits: 20, bigShortsCredits: 60, description: "Grok Imagine 6s" },
  "grok_10s": { usdCost: 0.15, kieCredits: 30, bigShortsCredits: 90, description: "Grok Imagine 10s" },
  "runway_5s_720p": { usdCost: 0.06, kieCredits: 12, bigShortsCredits: 30, description: "Runway 5s 720p" },
  "runway_10s_720p": { usdCost: 0.15, kieCredits: 30, bigShortsCredits: 60, description: "Runway 10s 720p" },
  "runway_5s_1080p": { usdCost: 0.15, kieCredits: 30, bigShortsCredits: 60, description: "Runway 5s 1080p" },
  "kling26_5s_no_audio": { usdCost: 0.28, kieCredits: 55, bigShortsCredits: 180, description: "Kling 2.6 5s sem áudio" },
  "kling26_5s_audio": { usdCost: 0.55, kieCredits: 110, bigShortsCredits: 220, description: "Kling 2.6 5s com áudio" },
  "kling26_10s_no_audio": { usdCost: 0.55, kieCredits: 110, bigShortsCredits: 300, description: "Kling 2.6 10s sem áudio" },
  "kling26_10s_audio": { usdCost: 1.10, kieCredits: 220, bigShortsCredits: 440, description: "Kling 2.6 10s com áudio" },
  // Kling 3.0 per-second costs (kieCredits and usdCost are PER SECOND, multiply by duration)
  "kling30_std_no_audio": { usdCost: 0.10, kieCredits: 20, bigShortsCredits: 30, description: "Kling 3.0 Std sem áudio (por segundo)" },
  "kling30_std_audio": { usdCost: 0.15, kieCredits: 30, bigShortsCredits: 45, description: "Kling 3.0 Std com áudio (por segundo)" },
  "kling30_pro_no_audio": { usdCost: 0.135, kieCredits: 27, bigShortsCredits: 41, description: "Kling 3.0 Pro sem áudio (por segundo)" },
  "kling30_pro_audio": { usdCost: 0.20, kieCredits: 40, bigShortsCredits: 60, description: "Kling 3.0 Pro com áudio (por segundo)" },

  // Lipsync (Infinitalk) - per second costs
  "lipsync_480p": { usdCost: 0.015, kieCredits: 3, bigShortsCredits: 3, description: "Infinitalk 480P (por segundo)" },
  "lipsync_720p": { usdCost: 0.06, kieCredits: 12, bigShortsCredits: 12, description: "Infinitalk 720P (por segundo)" },

  // Motion Control - per second costs
  "motion_720p": { usdCost: 0.03, kieCredits: 6, bigShortsCredits: 6, description: "Kling Motion Control 720p (por segundo)" },
  "motion_1080p": { usdCost: 0.045, kieCredits: 9, bigShortsCredits: 9, description: "Kling Motion Control 1080p (por segundo)" },

  // Image generation - per image costs
  "image_default": { usdCost: 0.0325, kieCredits: 6.5, bigShortsCredits: 6.5, description: "Imagem 4K (por imagem)" },

  "image_z_image": { usdCost: 0.004, kieCredits: 0.8, bigShortsCredits: 0.8, description: "Z-Image (por imagem)" },
  "image_nano_banana": { usdCost: 0.09, kieCredits: 18, bigShortsCredits: 18, description: "Nano Banana Pro (por imagem)" },
  "image_nano_banana_2": { usdCost: 0.08, kieCredits: 16, bigShortsCredits: 16, description: "Nano Banana 2 (por imagem - 1K)" },
  "image_grok": { usdCost: 0.02, kieCredits: 4, bigShortsCredits: 4, description: "Grok Imagine (por geração)" },
  "image_imagen4": { usdCost: 0.06, kieCredits: 12, bigShortsCredits: 12, description: "Imagen 4 (por imagem)" },
  "image_flux2_pro": { usdCost: 0.05, kieCredits: 10, bigShortsCredits: 10, description: "Flux 2 Pro (por imagem)" },
  "image_midjourney": { usdCost: 0.05, kieCredits: 10, bigShortsCredits: 10, description: "Midjourney (por imagem)" },

  // Background removal - per image
  "background_removal": { usdCost: 0.005, kieCredits: 1, bigShortsCredits: 1, description: "Remover fundo (por imagem)" },

  // Extended images (Ideogram) - per image
  "extend_turbo": { usdCost: 0.0175, kieCredits: 3.5, bigShortsCredits: 3.5, description: "Ideogram Turbo (por imagem)" },
  "extend_quality": { usdCost: 0.05, kieCredits: 10, bigShortsCredits: 10, description: "Ideogram Quality (por imagem)" },

  // Audio menu: ElevenLabs TTS (per minute), Sound Effect (per second), Transcribe (per unit)
  "elevenlabs_tts_per_min": { usdCost: 0.0175, kieCredits: 3.5, bigShortsCredits: 0, description: "ElevenLabs speech to audio (por minuto)" },
  "elevenlabs_sound_effect_per_sec": { usdCost: 0.0012, kieCredits: 0.24, bigShortsCredits: 0, description: "ElevenLabs Sound Effect V2 (por segundo)" },
  "elevenlabs_transcription_per_unit": { usdCost: 0.0025, kieCredits: 0.5, bigShortsCredits: 0, description: "Transcrever áudio (por transcrição)" },
};

/** Chars per minute for TTS duration estimation (~150 words/min × ~2.2 chars/word) */
export const ELEVENLABS_CHARS_PER_MINUTE = 330;

export function durationMinutesFromCharacterCount(characterCount: number): number {
  if (characterCount <= 0) return 0;
  return characterCount / ELEVENLABS_CHARS_PER_MINUTE;
}

export function calculateElevenLabsKieCost(durationMinutes: number): number {
  const entry = KIE_AI_COSTS["elevenlabs_tts_per_min"];
  return entry ? entry.usdCost * durationMinutes : 0;
}

export function getElevenLabsKieCredits(durationMinutes: number): number {
  const entry = KIE_AI_COSTS["elevenlabs_tts_per_min"];
  return entry ? Math.round(entry.kieCredits * durationMinutes * 100) / 100 : 0;
}

export function calculateSoundEffectKieCost(durationSeconds: number): number {
  const entry = KIE_AI_COSTS["elevenlabs_sound_effect_per_sec"];
  return entry ? entry.usdCost * durationSeconds : 0;
}

export function getSoundEffectKieCredits(durationSeconds: number): number {
  const entry = KIE_AI_COSTS["elevenlabs_sound_effect_per_sec"];
  return entry ? Math.round(entry.kieCredits * durationSeconds * 100) / 100 : 0;
}

export function calculateTranscriptionKieCost(): number {
  const entry = KIE_AI_COSTS["elevenlabs_transcription_per_unit"];
  return entry ? entry.usdCost : 0;
}

export function getTranscriptionKieCredits(): number {
  const entry = KIE_AI_COSTS["elevenlabs_transcription_per_unit"];
  return entry ? entry.kieCredits : 0;
}

function resolveKieCostKey(
  aiModel: AIModelId,
  duration: number,
  hasAudio: boolean = false,
  sora2ProQuality?: "standard" | "high",
  runwayQuality?: "720p" | "1080p",
  klingMode?: "std" | "pro",
): { key: string; perSecond: boolean } {
  switch (aiModel) {
    case "seedance":
      if (duration <= 4) return { key: hasAudio ? "seedance_4s_audio" : "seedance_4s_no_audio", perSecond: false };
      if (duration <= 8) return { key: hasAudio ? "seedance_8s_audio" : "seedance_8s_no_audio", perSecond: false };
      return { key: hasAudio ? "seedance_12s_audio" : "seedance_12s_no_audio", perSecond: false };
    case "sora2":
      return { key: duration > 10 ? "sora2_15s_audio" : "sora2_10s_audio", perSecond: false };
    case "sora2_pro":
      if (sora2ProQuality === "high") return { key: duration <= 10 ? "sora2_pro_high_10s" : "sora2_pro_high_15s", perSecond: false };
      return { key: duration <= 10 ? "sora2_pro_standard_10s" : "sora2_pro_standard_15s", perSecond: false };
    case "veo3_fast":
      return { key: "veo3_fast", perSecond: false };
    case "veo3_quality":
      return { key: "veo3_quality", perSecond: false };
    case "grok":
      return { key: duration === 10 ? "grok_10s" : "grok_6s", perSecond: false };
    case "runway":
      if (duration <= 5) return { key: runwayQuality === "1080p" ? "runway_5s_1080p" : "runway_5s_720p", perSecond: false };
      return { key: "runway_10s_720p", perSecond: false };
    case "kling26":
      if (duration <= 5) return { key: hasAudio ? "kling26_5s_audio" : "kling26_5s_no_audio", perSecond: false };
      return { key: hasAudio ? "kling26_10s_audio" : "kling26_10s_no_audio", perSecond: false };
    case "kling30": {
      const isPro = klingMode === "pro";
      if (isPro) return { key: hasAudio ? "kling30_pro_audio" : "kling30_pro_no_audio", perSecond: true };
      return { key: hasAudio ? "kling30_std_audio" : "kling30_std_no_audio", perSecond: true };
    }
    default:
      return { key: "", perSecond: false };
  }
}

export function calculateKieCost(
  aiModel: AIModelId,
  duration: number,
  hasAudio: boolean = false,
  sora2ProQuality?: "standard" | "high",
  runwayQuality?: "720p" | "1080p",
  klingMode?: "std" | "pro",
): number {
  const { key, perSecond } = resolveKieCostKey(aiModel, duration, hasAudio, sora2ProQuality, runwayQuality, klingMode);
  if (!key) return 0;
  const entry = KIE_AI_COSTS[key];
  if (!entry) return 0;
  return perSecond ? entry.usdCost * duration : entry.usdCost;
}

export function getKieCreditsForVideo(
  aiModel: AIModelId,
  duration: number,
  hasAudio: boolean = false,
  sora2ProQuality?: "standard" | "high",
  runwayQuality?: "720p" | "1080p",
  klingMode?: "std" | "pro",
): number {
  const { key, perSecond } = resolveKieCostKey(aiModel, duration, hasAudio, sora2ProQuality, runwayQuality, klingMode);
  if (!key) return 0;
  const entry = KIE_AI_COSTS[key];
  if (!entry) return 0;
  return perSecond ? Math.round(entry.kieCredits * duration) : entry.kieCredits;
}

// Lipsync Kie cost (Infinitalk)
export function calculateLipsyncKieCost(resolution: string, durationSeconds: number): number {
  const key = resolution === "720p" ? "lipsync_720p" : "lipsync_480p";
  const entry = KIE_AI_COSTS[key];
  return entry ? entry.usdCost * durationSeconds : 0;
}

// Motion Control Kie cost
export function calculateMotionKieCost(mode: string, durationSeconds: number): number {
  const key = mode === "1080p" ? "motion_1080p" : "motion_720p";
  const entry = KIE_AI_COSTS[key];
  return entry ? entry.usdCost * durationSeconds : 0;
}

// Image generation Kie cost by model
export function calculateImageKieCost(model: string): number {
  const modelMap: Record<string, string> = {
    default: "image_default",

    z_image: "image_z_image",
    nano_banana: "image_nano_banana",
    nano_banana_2: "image_nano_banana_2",
    grok: "image_grok",
    imagen4: "image_imagen4",
    flux2_pro: "image_flux2_pro",
    midjourney: "image_midjourney",
  };
  const key = modelMap[model] || "image_default";
  const entry = KIE_AI_COSTS[key];
  return entry ? entry.usdCost : 0;
}

// Background removal Kie cost (fixed per image)
export function calculateBackgroundRemovalKieCost(): number {
  const entry = KIE_AI_COSTS["background_removal"];
  return entry ? entry.usdCost : 0;
}

// Extended image (Ideogram) Kie cost
export function calculateExtendImageKieCost(mode: string): number {
  const key = mode === "quality" ? "extend_quality" : "extend_turbo";
  const entry = KIE_AI_COSTS[key];
  return entry ? entry.usdCost : 0;
}

// Kie CREDITS (not USD) for non-video entities
export function getLipsyncKieCredits(resolution: string, durationSeconds: number): number {
  const key = resolution === "720p" ? "lipsync_720p" : "lipsync_480p";
  const entry = KIE_AI_COSTS[key];
  return entry ? Math.round(entry.kieCredits * durationSeconds) : 0;
}

export function getMotionKieCredits(mode: string, durationSeconds: number): number {
  const key = mode === "1080p" ? "motion_1080p" : "motion_720p";
  const entry = KIE_AI_COSTS[key];
  return entry ? Math.round(entry.kieCredits * durationSeconds) : 0;
}

export function getImageKieCredits(model: string): number {
  const modelMap: Record<string, string> = {
    default: "image_default",

    z_image: "image_z_image",
    nano_banana: "image_nano_banana",
    nano_banana_2: "image_nano_banana_2",
    grok: "image_grok",
    imagen4: "image_imagen4",
    flux2_pro: "image_flux2_pro",
    midjourney: "image_midjourney",
  };
  const key = modelMap[model] || "image_default";
  const entry = KIE_AI_COSTS[key];
  return entry ? entry.kieCredits : 0;
}

export function getBackgroundRemovalKieCredits(): number {
  const entry = KIE_AI_COSTS["background_removal"];
  return entry ? entry.kieCredits : 0;
}

export function getExtendImageKieCredits(mode: string): number {
  const key = mode === "quality" ? "extend_quality" : "extend_turbo";
  const entry = KIE_AI_COSTS[key];
  return entry ? entry.kieCredits : 0;
}

export const userCredits = pgTable("user_credits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  balance: integer("balance").notNull().default(200),
  totalPurchased: integer("total_purchased").notNull().default(0),
  totalSpent: integer("total_spent").notNull().default(0),
  hasPurchased: boolean("has_purchased").notNull().default(false),
  planTier: planTierEnum("plan_tier").notNull().default("free"),
  planStartDate: timestamp("plan_start_date"),
  planEndDate: timestamp("plan_end_date"),
  adminAssignedPlan: boolean("admin_assigned_plan").notNull().default(false),
  lastPlanCreditGrant: timestamp("last_plan_credit_grant"),
  lastDailyCredits: timestamp("last_daily_credits"),
  dailyCreditsAccumulated: integer("daily_credits_accumulated").notNull().default(0),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  referralCode: text("referral_code").unique(),
  referredBy: varchar("referred_by"),
  referralRewardPaid: boolean("referral_reward_paid").notNull().default(false),
  referralCount: integer("referral_count").notNull().default(0),
  referralCreditsEarned: integer("referral_credits_earned").notNull().default(0),
  hasCompletedOnboarding: boolean("has_completed_onboarding").notNull().default(false),
  monthlyImageCount: integer("monthly_image_count").notNull().default(0),
  monthlyVideoCount: integer("monthly_video_count").notNull().default(0),
  lastMonthlyReset: timestamp("last_monthly_reset"),
  lastExpirationCheck: timestamp("last_expiration_check"),
  totalExpired: integer("total_expired").notNull().default(0),
  dailyClaimsCount: integer("daily_claims_count").notNull().default(0),
  enabledFeatures: json("enabled_features").$type<Record<string, boolean>>(),
  blocked: boolean("blocked").notNull().default(false),
  blockReason: text("block_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  uniqueIndex("idx_user_credits_user_id_unique").on(table.userId),
]);

export const vpnConfidenceEnum = pgEnum("vpn_confidence_score", ["low", "medium", "high"]);

export const userFingerprints = pgTable("user_fingerprints", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  fingerprintId: text("fingerprint_id").notNull(),
  ip: text("ip"),
  isVpn: boolean("is_vpn").notNull().default(false),
  isProxy: boolean("is_proxy").notNull().default(false),
  isTor: boolean("is_tor").notNull().default(false),
  vpnConfidenceScore: vpnConfidenceEnum("vpn_confidence_score").default("low"),
  vpnSuspected: boolean("vpn_suspected").notNull().default(false),
  affiliateLink: text("affiliate_link"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UserFingerprint = typeof userFingerprints.$inferSelect;

// Video Sessions — persistent session management for video generation

export const creditTransactions = pgTable("credit_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  amount: integer("amount").notNull(),
  type: text("type").notNull(),
  description: text("description"),
  videoId: varchar("video_id"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  // Partial unique indexes for WhatsApp share feature idempotency
  // These ensure only one initiation and one bonus per user
  uniqueIndex("idx_unique_whatsapp_share_initiated")
    .on(table.userId)
    .where(sql`type = 'whatsapp_share_initiated'`),
  uniqueIndex("idx_unique_whatsapp_bonus")
    .on(table.userId)
    .where(sql`type = 'whatsapp_bonus'`),
]);






export const userCreditsRelations = relations(userCredits, ({ }) => ({}));


export const creditTransactionsRelations = relations(creditTransactions, ({ }) => ({}));










// Image generation enums and tables
export const imageStatusEnum = pgEnum("image_status", ["pending", "processing", "completed", "failed"]);
export const imageModelEnum = pgEnum("image_model", ["default"]);
export const imageAspectRatioEnum = pgEnum("image_aspect_ratio", ["1:1", "4:3", "3:4", "16:9", "9:16", "2:3", "3:2", "21:9"]);

export const generatedImages = pgTable("generated_images", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  sessionId: varchar("session_id"),
  prompt: text("prompt").notNull(),
  negativePrompt: text("negative_prompt"),
  model: imageModelEnum("model").notNull(),
  aspectRatio: imageAspectRatioEnum("aspect_ratio").notNull().default("1:1"),
  creditCost: integer("credit_cost").notNull(),
  status: imageStatusEnum("status").notNull().default("pending"),
  taskId: text("task_id"),
  imageUrl: text("image_url"),
  errorMessage: text("error_message"),
  isFavorite: boolean("is_favorite").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  revealedAt: timestamp("revealed_at"),
}, (table) => [
  index("idx_generated_images_user_created_at").on(table.userId, table.createdAt),
  index("idx_generated_images_task_id").on(table.taskId),
  index("idx_generated_images_user_completed")
    .on(table.userId, table.status)
    .where(sql`${table.status} = 'completed' AND ${table.imageUrl} IS NOT NULL`),
]);

export const generatedImagesRelations = relations(generatedImages, ({ }) => ({}));

export const insertGeneratedImageSchema = createInsertSchema(generatedImages).omit({
  id: true,
  userId: true,
  creditCost: true,
  status: true,
  taskId: true,
  imageUrl: true,
  errorMessage: true,
  isFavorite: true,
  createdAt: true,
  completedAt: true,
});

export type GeneratedImage = typeof generatedImages.$inferSelect;
export type InsertGeneratedImage = z.infer<typeof insertGeneratedImageSchema>;

// Image Sessions — persistent session management for image generation
export const imageSessions = pgTable("image_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const imageSessionsRelations = relations(imageSessions, ({ }) => ({}));

export type ImageSession = typeof imageSessions.$inferSelect;
export type InsertImageSession = typeof imageSessions.$inferInsert;


// Image model configurations
export const IMAGE_MODELS = {
  default: {
    id: "default",
    name: "Imagem 4K",
    subtitle: "4K",
    description: "Imagens 4K de alta qualidade",
    creditCost: 12,
    hasNegativePrompt: false,
    maxPromptLength: 3000,
  },
} as const;

export type ImageModelKey = keyof typeof IMAGE_MODELS;
export type ImageAspectRatio = "1:1" | "4:3" | "3:4" | "16:9" | "9:16" | "2:3" | "3:2" | "21:9";

export const IMAGE_RATIOS: ImageAspectRatio[] = ["1:1", "4:3", "3:4", "16:9", "9:16", "2:3", "3:2", "21:9"];



export const insertCreditTransactionSchema = createInsertSchema(creditTransactions).omit({
  id: true,
  createdAt: true,
});

export type UserCredits = typeof userCredits.$inferSelect;
export type CreditTransaction = typeof creditTransactions.$inferSelect;
export type InsertCreditTransaction = z.infer<typeof insertCreditTransactionSchema>;




export const AI_MODELS = {
  seedance: {
    name: "Seedance 1.5 Pro",
    description: "High quality video with optional audio",
    durations: [4, 8, 12],
    creditCost: 50,
    hasAudioOption: true,
    maxImages: 1,
    creditCostByDuration: {
      4: { withoutAudio: 50, withAudio: 60 },
      8: { withoutAudio: 100, withAudio: 120 },
      12: { withoutAudio: 150, withAudio: 170 },
    },
  },

  sora2: {
    name: "Sora 2",
    description: "Quick, high-quality video generation",
    durations: [10, 15],
    creditCost: 60,
    maxImages: 5,
  },
  sora2_pro: {
    name: "Sora 2 Pro",
    description: "Premium quality with standard/high options",
    durations: [10, 15],
    creditCost: 300,
    maxImages: 5,
    hasQualityOption: true,
    creditCostByQuality: {
      10: { standard: 300, high: 660 },
      15: { standard: 540, high: 1280 },
    },
  },
  grok: {
    name: "Grok Imagine",
    description: "Creative video generation with native 4K upscale",
    durations: [6, 10],
    creditCost: 60,
    creditCostByDuration: {
      6: 60,
      10: 90,
    },
    maxImages: 5,
  },
  veo3_fast: {
    name: "Veo 3.1 Fast",
    description: "Fast generation with good quality",
    durations: [8],
    creditCost: 95,
    maxImages: 20,
  },
  veo3_quality: {
    name: "Veo 3.1 Quality",
    description: "Highest fidelity, premium quality",
    durations: [8],
    creditCost: 400,
    maxImages: 20,
  },
  runway: {
    name: "Runway",
    description: "High-quality cinematic video generation",
    durations: [5, 10],
    creditCost: 30,
    maxImages: 1,
    hasQualityOption: true,
    creditCostByDurationAndQuality: {
      5: { "720p": 30, "1080p": 60 },
      10: { "720p": 60, "1080p": null },
    },
  },
  midjourney: {
    name: "Midjourney",
    description: "Image to video with cinematic motion",
    durations: [5],
    creditCost: 120,
    maxImages: 1,
    imageToVideoOnly: true,
  },
  kling26: {
    name: "Kling 2.6",
    description: "Geração de vídeo com opção de áudio",
    durations: [5, 10],
    creditCost: 180,
    maxImages: 5,
    hasAudioOption: true,
    creditCostByDuration: {
      5: { withoutAudio: 180, withAudio: 220 },
      10: { withoutAudio: 300, withAudio: 440 },
    },
  },
  kling30: {
    name: "Kling 3.0",
    description: "Nova geração com qualidade superior e duração de até 15s",
    durations: [3, 5, 10, 15], // Flexible, but listed for reference
    creditCost: 135, // Calculated dynamically
    maxImages: 5,
    hasAudioOption: true,
    hasQualityOption: true, // For Pro/Std mode
  },
} as const;

export function getCompatibleModelsForImages(imageCount: number): AIModelKey[] {
  return (Object.keys(AI_MODELS) as AIModelKey[]).filter(modelId => {
    const model = AI_MODELS[modelId];
    const maxImages = (model as any).maxImages || 0;
    return maxImages >= imageCount;
  });
}

export type AIModelKey = keyof typeof AI_MODELS;
export type VideoFormat = "9:16" | "16:9" | "2:3" | "3:2" | "1:1" | "3:4" | "4:3" | "Auto";

// Admin audit log for tracking admin actions
export const adminAuditLog = pgTable("admin_audit_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  adminUserId: varchar("admin_user_id").notNull(),
  adminEmail: text("admin_email").notNull(),
  targetUserId: varchar("target_user_id"),
  action: text("action").notNull(),
  details: text("details"),
  previousValue: text("previous_value"),
  newValue: text("new_value"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type AdminAuditLog = typeof adminAuditLog.$inferSelect;
export type InsertAdminAuditLog = typeof adminAuditLog.$inferInsert;

// Affiliate Program Tables
export const affiliateStatusEnum = pgEnum("affiliate_status", ["pending", "active", "suspended", "rejected"]);
export const affiliateEarningStatusEnum = pgEnum("affiliate_earning_status", ["pending", "available", "paid", "reversed"]);
export const affiliatePayoutStatusEnum = pgEnum("affiliate_payout_status", ["pending", "approved", "paid", "rejected"]);

export const affiliates = pgTable("affiliates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().unique(),
  referralCode: varchar("referral_code", { length: 20 }).notNull().unique(),
  status: affiliateStatusEnum("status").default("pending").notNull(),
  commissionPercent: integer("commission_percent").default(20).notNull(),
  recurringCommissionPercent: integer("recurring_commission_percent").default(20).notNull(),
  pixKey: text("pix_key"),
  pixKeyType: text("pix_key_type"),
  totalEarnings: integer("total_earnings").default(0).notNull(),
  availableBalance: integer("available_balance").default(0).notNull(),
  paidTotal: integer("paid_total").default(0).notNull(),
  totalReferrals: integer("total_referrals").default(0).notNull(),
  subscribedReferrals: integer("subscribed_referrals").default(0).notNull(),
  payoutDays: integer("payout_days").default(30).notNull(),
  pixKeys: json("pix_keys").$type<{ key: string; keyType: string; createdAt: string }[]>().default([]),

  // New columns for Free Credits System
  freeCreditsEnabled: boolean("free_credits_enabled").default(false),
  freeCreditsAmount: integer("free_credits_amount").default(0),
  freePlanId: text("free_plan_id"),
  freePlanDays: integer("free_plan_days").default(7),
  photoUrl: text("photo_url"),
  displayName: text("display_name"),
  slug: text("slug").unique(),

  allowedMenuKeys: json("allowed_menu_keys").$type<string[]>().default([]),
  allowedModelIds: json("allowed_model_ids").$type<string[]>().default([]),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const affiliateReferrals = pgTable("affiliate_referrals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  affiliateId: varchar("affiliate_id").notNull(),
  referredUserId: varchar("referred_user_id").notNull().unique(),
  referralCode: varchar("referral_code", { length: 20 }).notNull(),
  status: text("status").default("registered").notNull(),
  firstSubscriptionId: varchar("first_subscription_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const affiliateEarnings = pgTable("affiliate_earnings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  affiliateId: varchar("affiliate_id").notNull(),
  referralId: varchar("referral_id").notNull(),
  stripeInvoiceId: varchar("stripe_invoice_id"),
  planTier: text("plan_tier").notNull(),
  grossAmount: integer("gross_amount").notNull(),
  commissionPercent: integer("commission_percent").notNull(),
  commissionAmount: integer("commission_amount").notNull(),
  status: affiliateEarningStatusEnum("status").default("pending").notNull(),
  creditedAt: timestamp("credited_at"),
  payoutDays: integer("payout_days"), // Snapshot of payout term at conversion time
  createdAt: timestamp("created_at").defaultNow(),
});

export const affiliatePayouts = pgTable("affiliate_payouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  affiliateId: varchar("affiliate_id").notNull(),
  amount: integer("amount").notNull(),
  pixKey: text("pix_key").notNull(),
  pixKeyType: text("pix_key_type"),
  status: affiliatePayoutStatusEnum("status").default("pending").notNull(),
  requestedAt: timestamp("requested_at").defaultNow(),
  approvedBy: varchar("approved_by"),
  approvedAt: timestamp("approved_at"),
  paidAt: timestamp("paid_at"),
  proofReference: text("proof_reference"),
  rejectionReason: text("rejection_reason"),
  notes: text("notes"),
});

export const insertAffiliateSchema = createInsertSchema(affiliates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  totalEarnings: true,
  availableBalance: true,
  paidTotal: true,
  totalReferrals: true,
  pixKeys: true,
});

export type Affiliate = typeof affiliates.$inferSelect;
export type InsertAffiliate = z.infer<typeof insertAffiliateSchema>;
export type AffiliateReferral = typeof affiliateReferrals.$inferSelect;
export type AffiliateEarning = typeof affiliateEarnings.$inferSelect;
export type AffiliatePayout = typeof affiliatePayouts.$inferSelect;

export const AFFILIATE_MENU_OPTIONS: { id: string; label: string; group: string }[] = [
  { id: "chat", label: "Chat", group: "Geral" },
  { id: "estilo-livre", label: "Estilo Livre", group: "Geral" },
  { id: "generate", label: "Gerar Vídeo", group: "Vídeo" },
  { id: "lip-sync", label: "Lip Sync", group: "Vídeo" },
  { id: "motion-control", label: "Mudar Personagem", group: "Vídeo" },
  { id: "criar-filme", label: "Criar Filme", group: "Vídeo" },
  { id: "videos", label: "Meus Vídeos", group: "Vídeo" },
  { id: "image-generate", label: "Gerar Imagem", group: "Imagem" },
  { id: "image-edit", label: "Editar Imagem", group: "Imagem" },
  { id: "remove-background", label: "Remover Fundo", group: "Imagem" },
  { id: "extend-image", label: "Extender Imagem", group: "Imagem" },
  { id: "voice", label: "Gerar Voz", group: "Áudio" },
  { id: "sound-effects", label: "Efeitos Sonoros", group: "Áudio" },
  { id: "transcribe", label: "Transcrever Áudio", group: "Áudio" },
];

export function getAffiliateModelOptions(): { id: string; name: string; group: string }[] {
  const videoModels = Object.entries(AI_MODELS).map(([id, model]) => ({
    id,
    name: model.name,
    group: "Vídeo",
  }));
  const imageModels = Object.entries(IMAGE_MODELS).map(([id, model]) => ({
    id,
    name: model.name,
    group: "Imagem",
  }));
  return [...videoModels, ...imageModels];
}



// Webhook logs table for member area webhook events
export const webhookLogs = pgTable("webhook_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  event: text("event").notNull(),
  email: text("email").notNull(),
  name: text("name"),
  status: text("status").notNull(),
  details: text("details"),
  rawPayload: text("raw_payload"),
  isTest: boolean("is_test").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const webhookLogsRelations = relations(webhookLogs, ({ }) => ({}));

export type WebhookLog = typeof webhookLogs.$inferSelect;
export type InsertWebhookLog = typeof webhookLogs.$inferInsert;

export const videoPovPreviewAnalysisStatuses = ["pending", "processing", "completed", "failed"] as const;
export type VideoPovPreviewAnalysisStatus = typeof videoPovPreviewAnalysisStatuses[number];
export function isVideoPovPreviewAnalysisStatus(value: unknown): value is VideoPovPreviewAnalysisStatus {
  return videoPovPreviewAnalysisStatuses.includes(value as VideoPovPreviewAnalysisStatus);
}
export const videoPovPreviewSkinTones = ["light", "dark"] as const;
export type VideoPovPreviewSkinTone = typeof videoPovPreviewSkinTones[number];
export const videoPovPreviewBodyTypes = ["slim", "full"] as const;
export type VideoPovPreviewBodyType = typeof videoPovPreviewBodyTypes[number];
export const videoPovPreviewProviders = ["gpt-5.3-chat-latest", "gemini-3-flash", "gemini-2.5-pro", "gemini-2.5-flash", "claude-haiku-4-5"] as const;
export type VideoPovPreviewProvider = typeof videoPovPreviewProviders[number];

// Video POV requests (landing upsell)
export const videoPovRequests = pgTable("video_pov_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  sessionId: varchar("session_id"),
  position: text("position").notNull(),
  hole: text("hole").notNull(),
  sexType: text("sex_type").notNull(),
  speechType: text("speech_type").notNull(),
  amountCents: integer("amount_cents").notNull().default(1990),
  status: text("status").notNull().default("pending_payment"),
  previewAnalysisImageUrl: text("preview_analysis_image_url"),
  previewAnalysisStatus: text("preview_analysis_status").notNull().default("pending"),
  previewAnalysisProvider: text("preview_analysis_provider"),
  previewAnalysisError: text("preview_analysis_error"),
  previewVisualTone: text("preview_visual_tone"),
  previewBodyType: text("preview_body_type"),
  previewVideoKey: text("preview_video_key"),
  previewResolvedAt: timestamp("preview_resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_video_pov_requests_user_created_at").on(table.userId, table.createdAt),
  index("idx_video_pov_requests_session_created_at").on(table.sessionId, table.createdAt),
]);

export const insertVideoPovRequestSchema = createInsertSchema(videoPovRequests).omit({
  id: true,
  userId: true,
  sessionId: true,
  amountCents: true,
  status: true,
  previewAnalysisImageUrl: true,
  previewAnalysisStatus: true,
  previewAnalysisProvider: true,
  previewAnalysisError: true,
  previewVisualTone: true,
  previewBodyType: true,
  previewVideoKey: true,
  previewResolvedAt: true,
  createdAt: true,
  updatedAt: true,
});

export type VideoPovRequest = typeof videoPovRequests.$inferSelect;
export type InsertVideoPovRequest = z.infer<typeof insertVideoPovRequestSchema>;

// PIX payments are created and reconciled through the Cloudflare worker.
export const pixPaymentStatusEnum = pgEnum("pix_payment_status", [
  "pending",
  "paid",
  "expired",
  "failed",
  "cancelled",
  "refunded",
  "chargedback",
]);

export const pixPayments = pgTable("pix_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  externalId: serial("external_id").notNull(),
  userId: varchar("user_id").notNull(),
  // Set when the charge is created via /api/pix/create so Worker callbacks
  // can attribute the payment back to the originating funnel session.
  sessionId: varchar("session_id"),
  abacatePayId: varchar("abacate_pay_id").notNull(),
  externalReference: text("external_reference"),
  abAssignments: json("ab_assignments").$type<Record<string, string>>(),
  creditAmount: integer("credit_amount").notNull(),
  amountCents: integer("amount_cents").notNull(),
  brCode: text("br_code"),
  brCodeBase64: text("br_code_base64"),
  status: pixPaymentStatusEnum("status").notNull().default("pending"),
  expiresAt: timestamp("expires_at"),
  paidAt: timestamp("paid_at"),
  refundedAt: timestamp("refunded_at"),
  lastEvent: text("last_event"),
  lastEventAt: timestamp("last_event_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_pix_payments_abacate_pay_id").on(table.abacatePayId),
  uniqueIndex("idx_pix_payments_abacate_pay_id_unique")
    .on(table.abacatePayId)
    .where(sql`${table.abacatePayId} NOT LIKE 'pending:%' AND ${table.abacatePayId} <> 'unknown'`),
  index("idx_pix_payments_session_id").on(table.sessionId),
  index("idx_pix_payments_external_reference").on(table.externalReference),
  index("idx_pix_payments_status_paid_at").on(table.status, table.paidAt),
  index("idx_pix_payments_status_refunded_at").on(table.status, table.refundedAt),
]);

export type PixPayment = typeof pixPayments.$inferSelect;
export type InsertPixPayment = typeof pixPayments.$inferInsert;

// Funnel tracking (landing -> offer -> PIX)
export const funnelStepEnum = pgEnum("funnel_step", [
  "visitor_entered",
  "photo_uploaded",
  "generated_photo_viewed",
  "offer_viewed",
  "offer_responded",
  "video_loading_screen",
  "video_loaded",
  "pix_generated",
  "pix_paid",
]);

export const funnelSessions = pgTable("funnel_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().unique(),
  userId: varchar("user_id"),
  currentStep: funnelStepEnum("current_step").notNull().default("visitor_entered"),
  maxStepReached: funnelStepEnum("max_step_reached").notNull().default("visitor_entered"),
  visitorFirstSeenAt: timestamp("visitor_first_seen_at").defaultNow(),
  visitorLastSeenAt: timestamp("visitor_last_seen_at").defaultNow(),
  isPaid: boolean("is_paid").notNull().default(false),
  paidAt: timestamp("paid_at"),
  saleAmountCents: integer("sale_amount_cents"),
  saleTransactionId: text("sale_transaction_id"),
  saleProvider: text("sale_provider"),
  saleEvent: text("sale_event"),
  customerName: text("customer_name"),
  customerEmail: text("customer_email"),
  uploadedPhotoUrl: text("uploaded_photo_url"),
  generatedPhotoUrl: text("generated_photo_url"),
  utmSource: text("utm_source"),
  utmMedium: text("utm_medium"),
  utmCampaign: text("utm_campaign"),
  utmContent: text("utm_content"),
  utmTerm: text("utm_term"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const funnelEvents = pgTable("funnel_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull(),
  userId: varchar("user_id"),
  step: funnelStepEnum("step").notNull(),
  eventName: text("event_name").notNull(),
  idempotencyKey: varchar("idempotency_key"),
  metadata: json("metadata").$type<Record<string, unknown>>(),
  occurredAt: timestamp("occurred_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_funnel_events_session_event_name").on(table.sessionId, table.eventName),
  index("idx_funnel_events_session_step").on(table.sessionId, table.step),
  index("idx_funnel_events_occurred_session_created").on(table.occurredAt, table.sessionId, table.createdAt),
  uniqueIndex("idx_funnel_events_session_idempotency_key")
    .on(table.sessionId, table.idempotencyKey)
    .where(sql`${table.idempotencyKey} IS NOT NULL`),
]);

export const blackcatWebhookLogs = pgTable("blackcat_webhook_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  transactionId: varchar("transaction_id"),
  event: text("event"),
  idempotencyKey: varchar("idempotency_key").notNull().unique(),
  payload: json("payload").$type<Record<string, unknown>>(),
  headers: json("headers").$type<Record<string, string>>(),
  status: text("status").notNull().default("received"),
  errorMessage: text("error_message"),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type FunnelStep = typeof funnelStepEnum.enumValues[number];
export type FunnelSession = typeof funnelSessions.$inferSelect;
export type InsertFunnelSession = typeof funnelSessions.$inferInsert;
export type FunnelEvent = typeof funnelEvents.$inferSelect;
export type InsertFunnelEvent = typeof funnelEvents.$inferInsert;
export type BlackcatWebhookLog = typeof blackcatWebhookLogs.$inferSelect;
export type InsertBlackcatWebhookLog = typeof blackcatWebhookLogs.$inferInsert;

export const paymentWebhookLogs = pgTable("payment_webhook_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  source: text("source").notNull().default("pix-worker"),
  transactionId: varchar("transaction_id"),
  appPaymentId: varchar("app_payment_id"),
  externalReference: text("external_reference"),
  event: text("event").notNull(),
  status: text("status").notNull().default("received"),
  idempotencyKey: varchar("idempotency_key").notNull().unique(),
  payload: json("payload").$type<Record<string, unknown>>(),
  headers: json("headers").$type<Record<string, string>>(),
  errorMessage: text("error_message"),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_payment_webhook_logs_transaction").on(table.transactionId),
  index("idx_payment_webhook_logs_app_payment").on(table.appPaymentId),
  index("idx_payment_webhook_logs_created_at").on(table.createdAt),
]);

export type PaymentWebhookLog = typeof paymentWebhookLogs.$inferSelect;
export type InsertPaymentWebhookLog = typeof paymentWebhookLogs.$inferInsert;

// ── Payment gateway orchestration ─────────────────────────────────────
export const paymentGatewayProviderEnum = pgEnum("payment_gateway_provider", ["blackcat", "woovi", "custom"]);
export const paymentGatewayStatusEnum = pgEnum("payment_gateway_status", ["active", "paused"]);
export const paymentGatewayTestStatusEnum = pgEnum("payment_gateway_test_status", ["active", "paused", "ended"]);
export const paymentGatewayTransactionStatusEnum = pgEnum("payment_gateway_transaction_status", [
  "pending",
  "paid",
  "failed",
  "expired",
  "cancelled",
  "refunded",
  "chargedback",
]);

export const paymentGateways = pgTable("payment_gateways", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  provider: paymentGatewayProviderEnum("provider").notNull().default("custom"),
  status: paymentGatewayStatusEnum("status").notNull().default("active"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_payment_gateways_status").on(table.status),
]);

export const paymentGatewayTests = pgTable("payment_gateway_tests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  status: paymentGatewayTestStatusEnum("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_payment_gateway_tests_status").on(table.status),
]);

export const paymentGatewayTestVariants = pgTable("payment_gateway_test_variants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  testId: varchar("test_id").notNull().references(() => paymentGatewayTests.id, { onDelete: "cascade" }),
  gatewayId: varchar("gateway_id").notNull().references(() => paymentGateways.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  weight: real("weight").notNull().default(50),
  visits: integer("visits").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_payment_gateway_test_variants_test").on(table.testId),
  index("idx_payment_gateway_test_variants_gateway").on(table.gatewayId),
]);

export const paymentGatewayTransactions = pgTable("payment_gateway_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pixPaymentId: varchar("pix_payment_id").notNull().references(() => pixPayments.id, { onDelete: "cascade" }),
  gatewayId: varchar("gateway_id").references(() => paymentGateways.id, { onDelete: "set null" }),
  testId: varchar("test_id").references(() => paymentGatewayTests.id, { onDelete: "set null" }),
  variantId: varchar("variant_id").references(() => paymentGatewayTestVariants.id, { onDelete: "set null" }),
  provider: text("provider").notNull(),
  providerTransactionId: text("provider_transaction_id"),
  externalReference: text("external_reference").notNull(),
  status: paymentGatewayTransactionStatusEnum("status").notNull().default("pending"),
  amountCents: integer("amount_cents").notNull(),
  planId: text("plan_id"),
  journeyNode: text("journey_node"),
  utm: json("utm").$type<Record<string, string | null>>(),
  requestPayload: json("request_payload").$type<Record<string, unknown>>(),
  responsePayload: json("response_payload").$type<Record<string, unknown>>(),
  lastEvent: text("last_event"),
  errorMessage: text("error_message"),
  paidAt: timestamp("paid_at"),
  refundedAt: timestamp("refunded_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_payment_gateway_transactions_pix").on(table.pixPaymentId),
  index("idx_payment_gateway_transactions_provider_tx").on(table.providerTransactionId),
  uniqueIndex("idx_payment_gateway_transactions_provider_tx_unique")
    .on(table.provider, table.providerTransactionId)
    .where(sql`${table.providerTransactionId} IS NOT NULL AND ${table.providerTransactionId} <> 'unknown' AND ${table.providerTransactionId} NOT LIKE 'pending:%'`),
  index("idx_payment_gateway_transactions_gateway_status").on(table.gatewayId, table.status),
  index("idx_payment_gateway_transactions_created_at").on(table.createdAt),
  index("idx_payment_gateway_transactions_paid_at").on(table.paidAt),
  index("idx_payment_gateway_transactions_refunded_at").on(table.refundedAt),
]);

export type PaymentGateway = typeof paymentGateways.$inferSelect;
export type InsertPaymentGateway = typeof paymentGateways.$inferInsert;
export type PaymentGatewayTest = typeof paymentGatewayTests.$inferSelect;
export type InsertPaymentGatewayTest = typeof paymentGatewayTests.$inferInsert;
export type PaymentGatewayTestVariant = typeof paymentGatewayTestVariants.$inferSelect;
export type InsertPaymentGatewayTestVariant = typeof paymentGatewayTestVariants.$inferInsert;
export type PaymentGatewayTransaction = typeof paymentGatewayTransactions.$inferSelect;
export type InsertPaymentGatewayTransaction = typeof paymentGatewayTransactions.$inferInsert;

// ── A/B testing ──────────────────────────────────────────────────
export const abTestStatusEnum = pgEnum("ab_test_status", ["active", "paused", "ended"]);

export const abTests = pgTable("ab_tests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  publicPath: text("public_path").notNull(),
  status: abTestStatusEnum("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_ab_tests_status_path").on(table.status, table.publicPath),
  uniqueIndex("idx_ab_tests_active_public_path")
    .on(table.publicPath)
    .where(sql`${table.status} = 'active'`),
]);

export const abVariants = pgTable("ab_variants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  testId: varchar("test_id").notNull().references(() => abTests.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  weight: real("weight").notNull().default(50),
  componentKey: text("component_key").notNull(),
  visits: integer("visits").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_ab_variants_test_id").on(table.testId),
]);

export const abConversions = pgTable("ab_conversions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  variantId: varchar("variant_id").notNull().references(() => abVariants.id, { onDelete: "cascade" }),
  transactionId: text("transaction_id").notNull(),
  amountCents: integer("amount_cents").notNull(),
  externalReference: text("external_reference"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  uniqueIndex("idx_ab_conversions_variant_transaction").on(table.variantId, table.transactionId),
  index("idx_ab_conversions_transaction_id").on(table.transactionId),
]);

export type AbTest = typeof abTests.$inferSelect;
export type InsertAbTest = typeof abTests.$inferInsert;
export type AbVariant = typeof abVariants.$inferSelect;
export type InsertAbVariant = typeof abVariants.$inferInsert;
export type AbConversion = typeof abConversions.$inferSelect;
export type InsertAbConversion = typeof abConversions.$inferInsert;
