import { sql } from "drizzle-orm";
import { index, jsonb, pgTable, timestamp, varchar, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// User storage table with custom auth fields.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  username: varchar("username").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  passwordHash: varchar("password_hash"),
  emailVerified: boolean("email_verified").default(false),
  role: varchar("role").default("user"),
  registrationIp: varchar("registration_ip"),
  deviceId: varchar("device_id"),

  // WhatsApp contact
  whatsappCountryCode: varchar("whatsapp_country_code"),
  whatsappNumber: varchar("whatsapp_number"),

  // Free Credits System fields
  cardValidated: boolean("card_validated").default(false),
  freeCreditsClaimed: boolean("free_credits_claimed").default(false),
  referredByAffiliateId: varchar("referred_by_affiliate_id"),

  // UTM Tracking
  utmSource: varchar("utm_source"),
  utmMedium: varchar("utm_medium"),
  utmCampaign: varchar("utm_campaign"),

  // Tracking for username changes (max 2 per 14 days)
  usernameChangeHistory: jsonb("username_change_history").default([]),

  // PIX payment tax ID (CPF/CNPJ)
  taxId: varchar("tax_id"),

  // Dashboard preference: hide recent media section (default hidden)
  recentMediaHidden: boolean("recent_media_hidden").default(true),

  // Panel layout preference: "dev" = frozen Dev Mode generate, "free" = evolving Estilo Livre
  panelLayout: varchar("panel_layout").default("free"),

  // Soft delete: account is deactivated (user can't login)
  isDeactivated: boolean("is_deactivated").default(false),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastLogin: timestamp("last_login"),
});

// Password reset tokens table
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  token: varchar("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Email verification tokens table
export const emailVerificationTokens = pgTable("email_verification_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  token: varchar("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Password validation schema with strong requirements
const passwordSchema = z.string()
  .min(6, "Senha deve ter pelo menos 6 caracteres")
  .regex(/[A-Z]/, "Senha deve ter pelo menos 1 letra maiúscula")
  .regex(/[a-z]/, "Senha deve ter pelo menos 1 letra minúscula")
  .regex(/[0-9]/, "Senha deve ter pelo menos 1 número")
  .regex(/[!@#$%^&*]/, "Senha deve ter pelo menos 1 símbolo especial (!@#$%^&*)");

export const registerSchema = z.object({
  email: z.string().email("Email inválido"),
  password: passwordSchema,
  username: z.string()
    .min(3, "Username deve ter pelo menos 3 caracteres")
    .max(20, "Username deve ter no máximo 20 caracteres")
    .regex(/^[a-zA-Z0-9._]+$/, "Username pode conter apenas letras, números, pontos e underscores"),
  whatsappCountryCode: z.string().min(1, "Informe o código do país (Brasil +55)"),
  whatsappNumber: z.string().min(1, "Informe um número brasileiro válido (DDD + número, 10 ou 11 dígitos)"),
  deviceId: z.string().optional(),
  utmSource: z.string().optional(),
  utmMedium: z.string().optional(),
  utmCampaign: z.string().optional(),
}).refine(
  (data) => {
    const code = (data.whatsappCountryCode || "").trim();
    const num = (data.whatsappNumber || "").replace(/\D/g, "");
    return code === "+55" && /^[1-9][1-9](9\d{8}|\d{8})$/.test(num);
  },
  { message: "Informe um número brasileiro válido (DDD + número, 10 ou 11 dígitos)" }
);

export const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(1, "Senha é obrigatória"),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("Email inválido"),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, "Token é obrigatório"),
  password: passwordSchema,
});

// Funnel registration: username + password (min 6, max 40)
export const registerFunnelSchema = z.object({
  username: z.string()
    .min(3, "Username deve ter pelo menos 3 caracteres")
    .max(20, "Username deve ter no máximo 20 caracteres")
    .regex(/^[a-zA-Z0-9._]+$/, "Username pode conter apenas letras, números, pontos e underscores"),
  password: z.string()
    .min(6, "Senha deve ter pelo menos 6 caracteres")
    .max(40, "Senha não deve ter mais de 40 caracteres"),
  confirmPassword: z.string(),
  visitorId: z.string().optional(),
  source: z.enum(["landing_embedded_login", "login_page"]).optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"],
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterFunnelInput = z.infer<typeof registerFunnelSchema>;

// Login via username + password (for the /login page)
export const loginFunnelSchema = z.object({
  username: z.string().min(1, "Username é obrigatório"),
  password: z.string().min(1, "Senha é obrigatória"),
});
export type LoginFunnelInput = z.infer<typeof loginFunnelSchema>;
