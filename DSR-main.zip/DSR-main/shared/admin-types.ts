import type { FunnelSession, FunnelStep } from "./schema";

export const ADMIN_CUSTOMER_RESPONSE_KINDS = ["pack", "video_pov", "both", "none"] as const;
export type AdminCustomerResponseKind = typeof ADMIN_CUSTOMER_RESPONSE_KINDS[number];

export const ADMIN_CUSTOMER_SORT_FIELDS = [
  "createdAt",
  "visitorLastSeenAt",
  "maxStepReached",
  "saleAmountCents",
  "paidAt",
] as const;
export type AdminCustomerSortBy = typeof ADMIN_CUSTOMER_SORT_FIELDS[number];

export const ADMIN_CUSTOMER_SORT_DIRECTIONS = ["asc", "desc"] as const;
export type AdminCustomerSortDir = typeof ADMIN_CUSTOMER_SORT_DIRECTIONS[number];

export const ADMIN_PIX_PRODUCT_KEYS = [
  "single_photo",
  "pack_photos",
  "video_pov",
  "pack_photos_video_pov",
  "video_pov_pack_photos",
  "unlimited_daily",
  "upsell_instapro_weekly",
] as const;
export type AdminPixProductKey = typeof ADMIN_PIX_PRODUCT_KEYS[number];

export const ADMIN_PIX_PRODUCT_LABELS: Record<AdminPixProductKey, string> = {
  single_photo: "1 foto",
  pack_photos: "pack de fotos",
  video_pov: "vídeo pov",
  pack_photos_video_pov: "pack de fotos + vídeo pov",
  video_pov_pack_photos: "vídeo pov + pack de fotos",
  unlimited_daily: "uso diário ilimitado",
  upsell_instapro_weekly: "IA ilimitada 15 dias",
};

export const POV_POSITION_LABELS: Record<string, string> = {
  de_quatro: "De quatro",
  papai_mamae: "Papai e mamãe",
  sentando: "Sentando",
  mamando: "Mamando",
};

export const POV_HOLE_LABELS: Record<string, string> = {
  buceta: "Buceta",
  cuzinho: "Cuzinho",
  boca: "Boca",
};

export const POV_SEX_TYPE_LABELS: Record<string, string> = {
  amorzinho: "Amorzinho",
  hard_fuck: "Hard fuck",
  misturado: "Misturado",
};

export const POV_SPEECH_LABELS: Record<string, string> = {
  carinhosa: "Carinhosa",
  ninfomaniaca: "Ninfomaníaca",
  sexo_agressivo: "Sexo agressivo",
};

export const FUNNEL_STEP_LABELS: Record<FunnelStep, string> = {
  visitor_entered: "Visitante entrou",
  photo_uploaded: "Foto enviada",
  generated_photo_viewed: "Viu foto gerada",
  offer_viewed: "Viu oferta",
  offer_responded: "Respondeu à oferta",
  video_loading_screen: "Tela de vídeo",
  video_loaded: "Vídeo carregado",
  pix_generated: "PIX gerado",
  pix_paid: "PIX pago",
};

export type AdminPackOfferResponse = {
  eventId: string;
  occurredAt: Date | null;
  metadata: Record<string, unknown>;
} | null;

export type AdminVideoPovOfferResponse = {
  eventId: string;
  occurredAt: Date | null;
  metadata: Record<string, unknown>;
  requestId: string | null;
  position: string | null;
  hole: string | null;
  sexType: string | null;
  speechType: string | null;
  requestStatus: string | null;
  requestAmountCents: number | null;
  requestCreatedAt: Date | null;
} | null;

export type AdminCustomerUnifiedRow = FunnelSession & {
  pixPlanId: string | null;
  pixJourneyNode: string | null;
  packResponse: AdminPackOfferResponse;
  videoPovResponse: AdminVideoPovOfferResponse;
};

type SerializedPackOfferResponse = {
  eventId: string;
  occurredAt: string | null;
  metadata: Record<string, unknown>;
} | null;

type SerializedVideoPovOfferResponse = {
  eventId: string;
  occurredAt: string | null;
  metadata: Record<string, unknown>;
  requestId: string | null;
  position: string | null;
  hole: string | null;
  sexType: string | null;
  speechType: string | null;
  requestStatus: string | null;
  requestAmountCents: number | null;
  requestCreatedAt: string | null;
} | null;

export type AdminCustomerListItem = {
  sessionId: string;
  userId: string | null;
  uploadedPhotoUrl: string | null;
  generatedPhotoUrl: string | null;
  username: string;
  paymentStatus: "paid" | "unpaid";
  contactEmail: string | null;
  contactPhone: string | null;
  purchasedProductLabel: string | null;
  paidAmountCents: number | null;
  createdAt: string | null;
  visitorLastSeenAt: string | null;
  maxStepReached: FunnelStep;
  maxStepReachedLabel: string;
  packResponse: SerializedPackOfferResponse;
  videoPovResponse: SerializedVideoPovOfferResponse;
};
