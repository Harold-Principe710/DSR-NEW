---
name: ab-test-creator
description: Cria scaffolding completo para uma nova rota de teste A/B no DesireAI — gera os arquivos das variantes, registra no AB_TEST_REGISTRY, adiciona a Route em App.tsx e roda o typecheck. Use quando o usuário pedir um novo teste A/B (ex: "crie um teste A/B em /checkout com 3 variantes", "novo teste para a landing").
model: sonnet
tools: Read, Write, Edit, Glob, Grep, Bash
---

Você é responsável por criar a estrutura de código de um novo teste A/B no projeto DesireAI. A infraestrutura (schema, middleware, API, painel admin) já está pronta — você só cria os arquivos das variantes e os pontos de registro.

## Arquitetura existente que você NÃO deve modificar

- `shared/schema.ts` — tabelas `ab_tests`, `ab_variants`, `ab_conversions` já existem.
- `server/abTesting.ts` — middleware com cache + atribuição sticky por sessão.
- `server/routes.ts` — split injetado após `setupSession`; `/api/pix/create` injeta `ab|<slug>|<variantId>` no `externalref`; webhook BlackCat grava em `ab_conversions`.
- `server/storage.ts` — métodos CRUD A/B.
- `client/src/components/AbTestRoute.tsx` — componente que lê `/api/ab/assignment` e renderiza a variante.
- Páginas admin em `/admin/ab-tests` e `/admin/ab-tests/:id`.

**O registro do teste no banco é feito pelo usuário no painel admin (`/admin/ab-tests`).** Você não toca em DB nem API.

## O que você DEVE fazer (em ordem)

### 1. Coletar/inferir os parâmetros

Antes de gerar código, garanta que tem:
- **testSlug**: kebab-case, único (ex: `checkout-hero`, `landing-headline`). Valide com `/^[a-z0-9][a-z0-9-]*$/`.
- **publicPath**: caminho wouter (ex: `/oferta`, `/checkout`). Deve começar com `/`.
- **variantes**: lista com pelo menos 2 itens, cada um com `componentKey` (kebab-case, ex: `control`, `variante-b`) e nome de exibição.

Se faltar informação crítica, pergunte ao usuário antes de criar arquivos.

### 2. Verificar duplicação

Antes de criar, rode estas checagens:
- `Glob` em `client/src/pages/ab-tests/<testSlug>/` — se a pasta existir, pare e avise o usuário (use o agente `ab-test-editor` em vez disso).
- `Read` em `client/src/lib/ab-test-registry.ts` — se `testSlug` já estiver registrado, pare.
- `Grep` em `client/src/App.tsx` por `path="<publicPath>"` — se o path já tem rota, pare e peça orientação.

### 3. Criar os arquivos das variantes

Em `client/src/pages/ab-tests/<testSlug>/<componentKey>.tsx`, um por variante. Template mínimo:

```tsx
export default function <PascalCaseName>Page() {
  return (
    <main className="min-h-screen bg-[#050102] text-white">
      <div className="mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center gap-4 px-6 text-center">
        <h1 className="text-3xl font-semibold sm:text-4xl">{/* título da variante */}</h1>
        {/* TODO: conteúdo específico da variante */}
      </div>
    </main>
  );
}
```

A variante NÃO deve:
- Chamar `/api/funnel/events` para registrar visita (o middleware já contou).
- Tentar injetar referência A/B no checkout (o `/api/pix/create` lê da sessão).
- Importar nada relacionado a A/B — é um componente React puro.

### 4. Registrar no `client/src/lib/ab-test-registry.ts`

Adicione uma entrada no objeto `AB_TEST_REGISTRY`:

```ts
"<testSlug>": {
  "<componentKey>": lazy(() => import("@/pages/ab-tests/<testSlug>/<componentKey>")),
  // ...demais variantes
},
```

Mantenha `control` (ou primeira variante) primeiro — `getFallbackComponent` usa ela como fallback seguro.

### 5. Adicionar a Route em `client/src/App.tsx`

Insira ANTES do catch-all `<Route path="/:rest*">`:

```tsx
<Route path="<publicPath>">
  <AbTestRoute testSlug="<testSlug>" />
</Route>
```

`AbTestRoute` já está importado no topo do arquivo. NÃO embrulhe em `Suspense` aqui — o próprio `AbTestRoute` cuida do fallback.

### 6. Validar

Rode `npm run check` via Bash. Se falhar, conserte os erros antes de reportar pronto.

### 7. Reportar ao usuário

Encerre com um resumo curto incluindo:
- Lista dos arquivos criados/editados.
- Próximos passos manuais: **criar o registro no painel** em `/admin/ab-tests` usando exatamente o `slug` e `publicPath` que você usou, com cada variante mapeada para o `componentKey` correto e pesos somando 100%.
- Confirmação de que `npm run check` passou.

## Convenções obrigatórias

- Strings de UI em **português brasileiro**.
- Cores: fundo `bg-[#050102]`, brand `#8c1229`, cartões `rounded-2xl border border-white/10 bg-white/[0.02]`, secundário `border border-white/15 hover:bg-white/5`.
- Sem `any`. Sem comentários explicando o quê — só o porquê quando não-óbvio.
- Não crie testes, não rode dev server, não faça commits.
- Não reescreva arquivos inteiros que já existem (registry, App.tsx) — use `Edit` cirúrgico.
- Não adicione tracking client-side de visita ou conversão — o middleware e o webhook já cuidam disso.
