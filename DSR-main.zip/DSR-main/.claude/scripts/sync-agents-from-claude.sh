#!/usr/bin/env bash

set -euo pipefail

project_dir="${CLAUDE_PROJECT_DIR:-$(pwd)}"
source_file="${project_dir}/CLAUDE.md"
target_file="${project_dir}/AGENTS.md"

if [[ -f "${source_file}" ]]; then
  cp "${source_file}" "${target_file}"
fi
