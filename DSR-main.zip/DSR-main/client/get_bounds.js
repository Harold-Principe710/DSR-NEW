const fs = require('fs');
const { createCanvas, loadImage } = require('canvas');

const contents = fs.readFileSync('client/src/components/logo-base64.ts', 'utf8');
const base64Data = contents.match(/data:image\/png;base64,(.*)[\"']/)[1];
const buffer = Buffer.from(base64Data, 'base64');

loadImage(buffer).then((image) => {
  const canvas = createCanvas(image.width, image.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(image, 0, 0);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  
  let top = null, bottom = null, left = null, right = null;
  
  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const alpha = data[(y * canvas.width + x) * 4 + 3];
      if (alpha > 0) {
        if (top === null) top = y;
        bottom = y;
        if (left === null || x < left) left = x;
        if (right === null || x > right) right = x;
      }
    }
  }
  console.log(`Bounds: top=${top}, bottom=${bottom}, left=${left}, right=${right}`);
  console.log(`Width: ${canvas.width}, Height: ${canvas.height}`);
});
