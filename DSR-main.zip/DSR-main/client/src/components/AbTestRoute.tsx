import { useQuery } from "@tanstack/react-query";
import { Suspense } from "react";
import { fetchWithTimeout } from "@/lib/queryClient";
import { resolveVariantComponent, getFallbackComponent } from "@/lib/ab-test-registry";

type AssignmentResponse = {
  componentKey: string | null;
  variantId?: string;
  testSlug?: string;
};

function RouteLoader({ label = "Carregando" }: { label?: string }) {
  return (
    <div className="flex h-screen flex-col items-center justify-center bg-[#0a0a0a]">
      <div className="w-6 h-6 border-2 border-[#8c1229] border-t-transparent rounded-full animate-spin" />
      <p className="mt-3 text-sm text-white/70">{label}</p>
    </div>
  );
}

/**
 * Renders the variant assigned to this session for the given A/B test.
 * The server middleware already assigned a variant when the visitor first hit
 * the public path; this query reads the assignment back and falls through to
 * the control variant if anything goes wrong.
 */
export function AbTestRoute({ testSlug }: { testSlug: string }) {
  const { data, isLoading, isError } = useQuery<AssignmentResponse>({
    queryKey: ["/api/ab/assignment", testSlug],
    queryFn: async () => {
      const res = await fetchWithTimeout(
        `/api/ab/assignment?testSlug=${encodeURIComponent(testSlug)}`,
        { credentials: "include" },
      );
      if (!res.ok) throw new Error(`Falha ao buscar variante (${res.status})`);
      return (await res.json()) as AssignmentResponse;
    },
    staleTime: Infinity,
    retry: false,
  });

  if (isLoading) return <RouteLoader />;

  const componentKey = data?.componentKey ?? null;
  const Component = componentKey ? resolveVariantComponent(testSlug, componentKey) : null;

  if (Component) {
    return (
      <Suspense fallback={<RouteLoader />}>
        <Component />
      </Suspense>
    );
  }

  // Fallbacks: assignment missing (test inactive) or component not registered.
  // Render the control variant so the page never goes blank.
  if (isError || !componentKey) {
    const Fallback = getFallbackComponent(testSlug);
    if (Fallback) {
      return (
        <Suspense fallback={<RouteLoader />}>
          <Fallback />
        </Suspense>
      );
    }
  }

  return (
    <div className="flex h-screen items-center justify-center bg-[#0a0a0a] px-6 text-center text-white/70">
      <p className="text-sm">Variante não encontrada para o teste &quot;{testSlug}&quot;.</p>
    </div>
  );
}
