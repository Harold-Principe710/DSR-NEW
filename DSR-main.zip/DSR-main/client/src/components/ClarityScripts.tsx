import { useEffect } from "react";
import { useLocation } from "wouter";

const CLARITY_SCRIPT_ID = "microsoft-clarity-inline";

function isExcludedRoute(path: string) {
  return (
    path === "/admin" || path.startsWith("/admin/") ||
    path === "/caller-92192" || path.startsWith("/caller-92192/")
  );
}

function removeClarityFromHead() {
  document.getElementById(CLARITY_SCRIPT_ID)?.remove();
}

function ensureClarityInHead() {
  if (document.getElementById(CLARITY_SCRIPT_ID)) return;

  const script = document.createElement("script");
  script.id = CLARITY_SCRIPT_ID;
  script.type = "text/javascript";
  script.text = `
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "wg9kphfc3l");
  `;

  document.head.appendChild(script);
}

export function ClarityScripts() {
  const [location] = useLocation();

  useEffect(() => {
    if (typeof document === "undefined") return;

    if (isExcludedRoute(location)) {
      removeClarityFromHead();
      return;
    }

    const idle = (window as any).requestIdleCallback as
      | ((cb: () => void, opts?: { timeout: number }) => number)
      | undefined;

    if (idle) {
      const idleId = idle(ensureClarityInHead, { timeout: 3500 });
      return () => {
        (window as any).cancelIdleCallback?.(idleId);
      };
    }

    const timeoutId = window.setTimeout(ensureClarityInHead, 1500);
    return () => window.clearTimeout(timeoutId);
  }, [location]);

  return null;
}
