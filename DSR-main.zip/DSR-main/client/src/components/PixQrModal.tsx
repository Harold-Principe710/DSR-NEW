import { useEffect, useRef, useState, useCallback } from "react";
import { X, Copy, CheckCircle2, Loader2, AlertCircle, RefreshCw, Smartphone, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";
import QRCode from "qrcode";
import { useBodyScrollLock } from "@/hooks/use-body-scroll-lock";
import { getBestAvailableUtms } from "@/lib/utm";
import { trackFunnelEvent, getJourneyContext, getTrackingSessionKey } from "@/lib/funnel";

// ── Plan configuration ────────────────────────────────────────────────
export interface PlanInfo {
    id: string;
    title: string;
    price: string;
    amountCents: number;
}

export const PLANS: Record<string, PlanInfo> = {
    "pix-tester-1000": { id: "pix-tester-1000", title: "PIX de teste", price: "R$ 10,00", amountCents: 1000 },
    "1-foto": { id: "1-foto", title: "1 foto", price: "R$ 9,90", amountCents: 990 },
    "video-pov-990": { id: "video-pov-990", title: "Vídeo POV promocional", price: "R$ 9,90", amountCents: 990 },
    "video-pov-1990": { id: "video-pov-1990", title: "Vídeo POV personalizado", price: "R$ 19,90", amountCents: 1990 },
    "video-pov-pack-2990": { id: "video-pov-pack-2990", title: "Vídeo POV + Pack de fotos", price: "R$ 29,90", amountCents: 2990 },
    "pack-fotos-1990": { id: "pack-fotos-1990", title: "Pack de fotos", price: "R$ 19,90", amountCents: 1990 },
    "10-fotos": { id: "10-fotos", title: "10 fotos", price: "R$ 49,90", amountCents: 4990 },
    "10-fotos-1-video": { id: "10-fotos-1-video", title: "10 fotos + 1 vídeo", price: "R$ 69,90", amountCents: 6990 },
    "ilimitado": { id: "ilimitado", title: "Uso diário ilimitado", price: "R$ 49,90", amountCents: 4990 },
    "ilimitado-pack-fotos-4490": { id: "ilimitado-pack-fotos-4490", title: "Uso diário ilimitado", price: "R$ 44,90", amountCents: 4490 },
    "upsell-instapro-semanal": {
        id: "upsell-instapro-semanal",
        title: "IA Ilimitada 15 dias",
        price: "R$ 59,90",
        amountCents: 5990,
    },
    // ── A/B "landing-pricing" variant B (todos os preços +R$10) ──
    "1-foto-1990": { id: "1-foto-1990", title: "1 foto", price: "R$ 19,90", amountCents: 1990 },
    "pack-fotos-2990": { id: "pack-fotos-2990", title: "Pack de fotos", price: "R$ 29,90", amountCents: 2990 },
    "video-pov-promo-1990": { id: "video-pov-promo-1990", title: "Vídeo POV promocional", price: "R$ 19,90", amountCents: 1990 },
    "video-pov-2990": { id: "video-pov-2990", title: "Vídeo POV personalizado", price: "R$ 29,90", amountCents: 2990 },
    "video-pov-pack-3990": { id: "video-pov-pack-3990", title: "Vídeo POV + Pack de fotos", price: "R$ 39,90", amountCents: 3990 },
    "10-fotos-5990": { id: "10-fotos-5990", title: "10 fotos", price: "R$ 59,90", amountCents: 5990 },
    "10-fotos-1-video-7990": { id: "10-fotos-1-video-7990", title: "10 fotos + 1 vídeo", price: "R$ 79,90", amountCents: 7990 },
};

type PixState = "idle" | "loading" | "ready" | "paid" | "error";

// Default post-payment route. Every paying user lands on the InstaPro upsell
// unless the caller explicitly opts out (`redirectAfterPaymentTo={null}`).
const DEFAULT_POST_PAYMENT_REDIRECT = "/upsell/instapro";
const UPSELL_PLAN_ID = "upsell-instapro-semanal";
const PIX_CREATE_POLL_INTERVAL_MS = 1500;
const PIX_CREATE_POLL_TIMEOUT_MS = 45000;
const PIX_CREATE_ATTEMPT_WINDOWS_MS = [6000, 12000, 12000];

interface PixQrModalProps {
    open: boolean;
    onClose: () => void;
    planId: string;
    onPaymentSuccess?: (paymentData: any) => void;
    /**
     * Where to navigate after the 5-second success screen.
     * - `undefined` → default to {@link DEFAULT_POST_PAYMENT_REDIRECT}
     * - `null` → stay put (used by the upsell page itself)
     * - internal path (`/foo`) → navigate there
     */
    redirectAfterPaymentTo?: string | null;
}

function readPixCodeFromCreateResponse(data: any): string | undefined {
    return data?.pix?.qrcode
        ?? data?.pix?.copyPaste
        ?? data?.pix?.brCode
        ?? data?.qrcode
        ?? data?.copyPaste
        ?? data?.brCode
        ?? data?.pixCode
        ?? data?.code;
}

function parseJsonText(text: string) {
    try {
        return text.trim() ? JSON.parse(text) : {};
    } catch {
        return { raw: text };
    }
}

function wait(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

function createPixPendingTimeoutError(message: string) {
    return Object.assign(new Error(message), { code: "pix_create_pending_timeout" });
}

export default function PixQrModal({ open, onClose, planId, onPaymentSuccess, redirectAfterPaymentTo }: PixQrModalProps) {
    useBodyScrollLock(open);
    const [, setLocation] = useLocation();
    const [pixState, setPixState] = useState<PixState>("idle");
    const [pixCode, setPixCode] = useState<string>("");
    const [qrDataUrl, setQrDataUrl] = useState<string>("");
    const [errorMessage, setErrorMessage] = useState<string>("");
    const [copied, setCopied] = useState(false);
    const [saleId, setSaleId] = useState<string>("");
    const [appPaymentId, setAppPaymentId] = useState<string>("");
    const [countdown, setCountdown] = useState(5);
    const prevPlanId = useRef<string>("");
    const prevOpen = useRef(false);
    const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);
    const autoCloseTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);
    const paymentHandledRef = useRef(false);
    const pixRequestInFlightRef = useRef(false);
    const pixRequestRunRef = useRef(0);

    const plan = PLANS[planId] ?? PLANS["1-foto"];

    // ── Generate QR from pix copia-e-cola ───────────────────────────────
    const generateQrImage = useCallback(async (code: string) => {
        try {
            const clean = code.replace(/[\r\n]/g, "");
            const dataUrl = await QRCode.toDataURL(clean, {
                width: 260,
                margin: 1,
                color: { dark: "#000000", light: "#ffffff" },
                errorCorrectionLevel: "M",
            });
            setQrDataUrl(dataUrl);
        } catch (err) {
            console.error("[PixQr] QR generation failed:", err);
        }
    }, []);

    const waitForPixCreation = useCallback(async (paymentId: string, timeoutMs = PIX_CREATE_POLL_TIMEOUT_MS) => {
        const startedAt = Date.now();
        let lastMessage = "O pagamento demorou demais para responder. Tente novamente.";

        while (Date.now() - startedAt < timeoutMs) {
            await wait(Math.min(PIX_CREATE_POLL_INTERVAL_MS, Math.max(250, timeoutMs - (Date.now() - startedAt))));

            let response: Response;
            try {
                response = await fetch(`/api/pix/create-status/${encodeURIComponent(paymentId)}`, {
                    credentials: "include",
                });
            } catch {
                continue;
            }

            const text = await response.text();
            const data = parseJsonText(text);
            if (typeof data?.message === "string" && data.message.trim()) {
                lastMessage = data.message;
            }

            if (response.status === 202 || data?.status === "creating") {
                continue;
            }

            if (!response.ok) {
                if (response.status >= 500) continue;
                throw new Error(data?.message || `Erro ${response.status}`);
            }

            if (readPixCodeFromCreateResponse(data)) {
                return data;
            }
        }

        throw createPixPendingTimeoutError(lastMessage);
    }, []);

    // ── Handle successful payment ────────────────────────────────────
    const handlePaymentConfirmed = useCallback((paymentData?: any) => {
        if (paymentHandledRef.current) return;
        paymentHandledRef.current = true;

        // Stop polling
        if (pollIntervalRef.current) {
            clearInterval(pollIntervalRef.current);
            pollIntervalRef.current = null;
        }

        setPixState("paid");
        setCountdown(5);
        const paymentTrackingId = appPaymentId || saleId;
        const paidIdempotencyKey = paymentTrackingId
            ? `pix_modal:paid:${paymentTrackingId}`
            : `pix_modal:paid:session:${getTrackingSessionKey()}`;
        trackFunnelEvent({
            step: "pix_paid",
            eventName: "pix.modal_paid",
            idempotencyKey: paidIdempotencyKey,
            metadata: {
                ...(paymentData || {}),
                appPaymentId: appPaymentId || null,
                saleId: saleId || null,
            },
        });

        // Countdown timer
        let remaining = 5;
        countdownIntervalRef.current = setInterval(() => {
            remaining--;
            setCountdown(remaining);
            if (remaining <= 0) {
                if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
            }
        }, 1000);

        // Resolve redirect target:
        // 1. Never redirect from the upsell to itself (loop guard).
        // 2. Explicit `null` → opt-out.
        // 3. Undefined → default to the upsell page.
        // 4. Any string → must be an internal, same-origin path (`/foo`).
        let targetPath: string | null = null;
        if (planId !== UPSELL_PLAN_ID && redirectAfterPaymentTo !== null) {
            const candidate = redirectAfterPaymentTo ?? DEFAULT_POST_PAYMENT_REDIRECT;
            if (/^\/(?!\/)/.test(candidate)) {
                targetPath = candidate;
            }
        }

        // Auto-close after 5 seconds
        autoCloseTimeoutRef.current = setTimeout(() => {
            onPaymentSuccess?.(paymentData);
            if (targetPath) {
                setLocation(targetPath);
            }
            onClose();
        }, 5000);
    }, [onClose, onPaymentSuccess, appPaymentId, saleId, redirectAfterPaymentTo, setLocation, planId]);

    // ── Poll PIX status ──────────────────────────────────────────────
    useEffect(() => {
        const paymentTrackingId = appPaymentId || saleId;
        if (pixState !== "ready" || !paymentTrackingId || !open) return;

        const poll = async () => {
            try {
                const res = await fetch(`/api/pix/status/${paymentTrackingId}`, { credentials: "include" });
                if (res.ok) {
                    const data = await res.json();
                    if (data.status === "paid") {
                        handlePaymentConfirmed(data);
                    }
                }
            } catch {
                // ignore poll errors
            }
        };

        // Start polling every 3 seconds
        pollIntervalRef.current = setInterval(poll, 3000);

        return () => {
            if (pollIntervalRef.current) {
                clearInterval(pollIntervalRef.current);
                pollIntervalRef.current = null;
            }
        };
    }, [pixState, appPaymentId, saleId, open, handlePaymentConfirmed]);

    // ── Listen for WebSocket pix_paid event ──────────────────────────
    useEffect(() => {
        if (!open || pixState === "paid") return;

        const handleWsMessage = (event: MessageEvent) => {
            try {
                const message = JSON.parse(event.data);
                if (message.type === "pix_paid") {
                    handlePaymentConfirmed(message.data);
                }
            } catch {
                // ignore parse errors
            }
        };

        // Try to find an existing open connection or create a temporary listener
        // We use a BroadcastChannel approach — listen on a custom event
        const onPixPaid = (e: CustomEvent) => {
            handlePaymentConfirmed(e.detail);
        };
        window.addEventListener("pix_paid" as any, onPixPaid);

        return () => {
            window.removeEventListener("pix_paid" as any, onPixPaid);
        };
    }, [open, pixState, handlePaymentConfirmed]);

    // ── Call backend PIX proxy ────────────────────────────────────────
    const requestPix = useCallback(async (amountCents: number) => {
        if (pixRequestInFlightRef.current) return;
        pixRequestInFlightRef.current = true;
        const requestRun = pixRequestRunRef.current + 1;
        pixRequestRunRef.current = requestRun;
        const isCurrentRequest = () => pixRequestRunRef.current === requestRun;
        setPixState("loading");
        setErrorMessage("");
        setPixCode("");
        setQrDataUrl("");
        setSaleId("");
        setAppPaymentId("");
        paymentHandledRef.current = false;

        try {
            const utms = getBestAvailableUtms();
            const { journeyNode, journeyPath } = getJourneyContext();
            const trackingSessionKey = getTrackingSessionKey();

            let data: any = null;
            let pendingPaymentId = "";
            let lastError: any = null;

            for (let attemptIndex = 0; attemptIndex < PIX_CREATE_ATTEMPT_WINDOWS_MS.length; attemptIndex += 1) {
                const attemptStartedAt = Date.now();
                const attemptWindowMs = PIX_CREATE_ATTEMPT_WINDOWS_MS[attemptIndex];

                try {
                    if (pendingPaymentId) {
                        data = await waitForPixCreation(pendingPaymentId, attemptWindowMs);
                    } else {
                        const response = await fetch("/api/pix/create", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            credentials: "include",
                            body: JSON.stringify({
                                amount: amountCents,
                                planId,
                                journeyNode,
                                journeyPath,
                                ...utms,
                            }),
                        });

                        const text = await response.text();
                        if (!text?.trim()) throw new Error("Servidor não retornou dados");

                        data = parseJsonText(text);

                        if (response.status === 202 || data?.status === "creating") {
                            if (!data?.appPaymentId || typeof data.appPaymentId !== "string") {
                                throw new Error("Servidor não retornou o identificador da cobrança PIX");
                            }
                            pendingPaymentId = data.appPaymentId;
                            setAppPaymentId(data.appPaymentId);
                            const elapsedMs = Date.now() - attemptStartedAt;
                            data = await waitForPixCreation(data.appPaymentId, Math.max(0, attemptWindowMs - elapsedMs));
                        } else if (!response.ok) {
                            const fallbackMessage =
                                response.status === 504
                                    ? "O pagamento demorou demais para responder. Tente novamente."
                                    : `Erro ${response.status}`;
                            throw new Error(data?.message || fallbackMessage);
                        }
                    }

                    if (!isCurrentRequest()) return;
                    if (!readPixCodeFromCreateResponse(data)) {
                        throw new Error("PIX não encontrado na resposta do servidor");
                    }
                    lastError = null;
                    break;
                } catch (err: any) {
                    if (!isCurrentRequest()) return;
                    lastError = err;

                    if (pendingPaymentId && err?.code !== "pix_create_pending_timeout") {
                        pendingPaymentId = "";
                    }

                    const elapsedMs = Date.now() - attemptStartedAt;
                    const remainingMs = Math.max(0, attemptWindowMs - elapsedMs);
                    if (remainingMs > 0) await wait(remainingMs);
                    if (!isCurrentRequest()) return;

                    if (attemptIndex === PIX_CREATE_ATTEMPT_WINDOWS_MS.length - 1) {
                        throw lastError;
                    }
                }
            }

            if (!data && lastError) throw lastError;

            // Backend normalizes to pix.qrcode, but accepts legacy aliases too.
            const raw = readPixCodeFromCreateResponse(data);

            if (!raw || typeof raw !== "string") {
                throw new Error("PIX não encontrado na resposta do servidor");
            }

            const clean = raw.replace(/[\r\n]/g, "");
            setPixCode(clean);
            setSaleId(data?.saleId ?? "");
            setAppPaymentId(data?.appPaymentId ?? "");
            setPixState("ready");
            const paymentTrackingId = data?.appPaymentId || data?.saleId;
            const generatedIdempotencyKey = paymentTrackingId
                ? `pix_modal:generated:${paymentTrackingId}`
                : `pix_modal:generated:session:${trackingSessionKey}:${amountCents}`;
            trackFunnelEvent({
                step: "pix_generated",
                eventName: "pix.modal_ready",
                idempotencyKey: generatedIdempotencyKey,
                metadata: {
                    planId,
                    amountCents,
                    appPaymentId: data?.appPaymentId ?? null,
                    saleId: data?.saleId ?? null,
                },
            });
            await generateQrImage(clean);
        } catch (err: any) {
            if (!isCurrentRequest()) return;
            console.error("[PixQr] Error:", err);
            setPixState("error");
            setErrorMessage(err?.message || "Não foi possível gerar o PIX. Tente novamente.");
        } finally {
            if (isCurrentRequest()) pixRequestInFlightRef.current = false;
        }
    }, [generateQrImage, planId, waitForPixCreation]);

    // ── Trigger on open or planId change ────────────────────────────────
    useEffect(() => {
        const planChanged = planId !== prevPlanId.current;
        const justOpened = open && !prevOpen.current;

        if (open && (justOpened || planChanged)) {
            prevPlanId.current = planId;
            requestPix(PLANS[planId]?.amountCents ?? 990);
        }

        if (!open) {
            // Reset state when closed
            setPixState("idle");
            setPixCode("");
            setQrDataUrl("");
            setCopied(false);
            setErrorMessage("");
            setSaleId("");
            setAppPaymentId("");
            setCountdown(5);
            paymentHandledRef.current = false;
            pixRequestInFlightRef.current = false;
            pixRequestRunRef.current += 1;

            // Clear all timers
            if (pollIntervalRef.current) {
                clearInterval(pollIntervalRef.current);
                pollIntervalRef.current = null;
            }
            if (autoCloseTimeoutRef.current) {
                clearTimeout(autoCloseTimeoutRef.current);
                autoCloseTimeoutRef.current = null;
            }
            if (countdownIntervalRef.current) {
                clearInterval(countdownIntervalRef.current);
                countdownIntervalRef.current = null;
            }
        }

        prevOpen.current = open;
    }, [open, planId, requestPix]);

    // ── Cleanup on unmount ──────────────────────────────────────────
    useEffect(() => {
        return () => {
            pixRequestInFlightRef.current = false;
            if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
            if (autoCloseTimeoutRef.current) clearTimeout(autoCloseTimeoutRef.current);
            if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
        };
    }, []);

    // ── Copy pix code ────────────────────────────────────────────────────
    const handleCopy = async () => {
        if (!pixCode) return;
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
        try {
            await navigator.clipboard.writeText(pixCode);
        } catch {
            const el = document.createElement("textarea");
            el.value = pixCode;
            Object.assign(el.style, { position: "fixed", opacity: "0" });
            document.body.appendChild(el);
            el.select();
            document.execCommand("copy");
            document.body.removeChild(el);
        }
    };

    if (!open) return null;

    return (
        <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center sm:px-4">
            {/* Backdrop */}
            <div
                className="absolute inset-0 bg-black/80 backdrop-blur-sm"
                onClick={pixState === "paid" ? undefined : onClose}
            />

            {/* Modal */}
            <div
                className={`relative w-full sm:max-w-sm
          bg-gradient-to-b from-[#160b12] via-[#110609] to-[#0a0204]
          border-t sm:border ${pixState === "paid" ? "border-emerald-500/30" : "border-[#8c1229]/25"}
          rounded-t-3xl sm:rounded-2xl
          shadow-[0_-20px_80px_rgba(140,18,41,0.3)] sm:shadow-[0_0_80px_rgba(140,18,41,0.2)]
          animate-in slide-in-from-bottom sm:fade-in sm:zoom-in-95 duration-300
          max-h-[92svh] overflow-y-auto transition-all`}
                style={{
                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                    overscrollBehavior: "contain",
                    WebkitOverflowScrolling: "touch",
                }}
            >
                {/* Mobile drag handle */}
                <div className="sm:hidden flex justify-center pt-3 pb-1">
                    <div className="w-10 h-1 rounded-full bg-white/15" />
                </div>

                {/* Close (hidden during paid state) */}
                {pixState !== "paid" && (
                    <button
                        type="button"
                        onClick={onClose}
                        className="absolute top-4 right-4 z-10 p-1.5 text-white/30 hover:text-white/70 transition-colors rounded-full hover:bg-white/5"
                    >
                        <X className="w-5 h-5" />
                    </button>
                )}

                {/* ── PAID STATE ─────────────────────────────────────────── */}
                {pixState === "paid" && (
                    <div className="px-6 pt-10 pb-10 flex flex-col items-center gap-5 animate-in zoom-in-75 fade-in duration-500">
                        {/* Success icon with pulse ring */}
                        <div className="relative">
                            <div className="absolute inset-0 w-20 h-20 rounded-full bg-emerald-500/20 animate-ping" />
                            <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center shadow-[0_0_40px_rgba(52,211,153,0.35)]">
                                <CheckCircle2 className="w-10 h-10 text-white animate-in zoom-in-50 duration-300" />
                            </div>
                        </div>

                        <div className="text-center">
                            <h3 className="text-xl font-bold text-white/95 tracking-tight">
                                Pagamento confirmado!
                            </h3>
                            <p className="text-sm text-emerald-400/80 mt-2 font-medium">
                                Seus créditos já foram adicionados
                            </p>
                            <p className="text-xs text-white/30 mt-3 font-light">
                                Fechando em {countdown}s...
                            </p>
                        </div>

                        {/* Progress bar */}
                        <div className="w-full max-w-[200px] h-1 bg-white/[0.06] rounded-full overflow-hidden mt-1">
                            <div
                                className="h-full bg-gradient-to-r from-emerald-400 to-emerald-600 rounded-full transition-all duration-1000 ease-linear"
                                style={{ width: `${(countdown / 5) * 100}%` }}
                            />
                        </div>
                    </div>
                )}

                {/* ── Non-paid states ──────────────────────────────────────── */}
                {pixState !== "paid" && (
                    <>
                        {/* ── Header ────────────────────────────────────────────── */}
                        <div className="px-6 pt-5 pb-4 text-center sm:pt-6 sm:pb-5">
                            <div className="mb-2.5 inline-flex h-12 w-12 items-center justify-center rounded-full border border-[#8c1229]/25 bg-[#8c1229]/15 sm:mb-3">
                                <Smartphone className="w-5 h-5 text-[#ff3b5c]/60" />
                            </div>
                            <h3 className="text-[18px] font-semibold text-white/95 tracking-tight">
                                Pagamento via PIX
                            </h3>
                            <div className="flex items-center justify-center gap-2 mt-1.5">
                                <span className="text-sm text-white/30 font-light">{plan.title}</span>
                                <span className="text-white/15">·</span>
                                <span className="text-xl font-bold text-[#ff3b5c]">{plan.price}</span>
                            </div>
                        </div>

                        {/* Thin divider */}
                        <div className="mx-6 mb-4 h-px bg-gradient-to-r from-transparent via-[#8c1229]/20 to-transparent sm:mb-5" />

                        {/* ── Content ───────────────────────────────────────────── */}
                        <div className="flex flex-col items-center gap-4 px-6 pb-5 sm:gap-5 sm:pb-6">

                            {/* LOADING */}
                            {pixState === "loading" && (
                                <div className="flex flex-col items-center gap-5 py-10 w-full">
                                    {/* Animated rings */}
                                    <div className="relative w-16 h-16">
                                        <div className="absolute inset-0 rounded-full border-2 border-[#8c1229]/15 border-t-[#8c1229] animate-[spin_1.4s_linear_infinite]" />
                                        <div className="absolute inset-[5px] rounded-full border border-transparent border-b-[#c9a227]/30 animate-[spin_2s_reverse_linear_infinite]" />
                                        <div className="absolute inset-0 flex items-center justify-center">
                                            <div className="w-2 h-2 rounded-full bg-[#8c1229]/40 animate-pulse" />
                                        </div>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-sm text-white/50 font-medium">Gerando cobrança PIX...</p>
                                        <p className="text-xs text-white/25 mt-1 font-light">Aguarde alguns segundos</p>
                                    </div>
                                </div>
                            )}

                            {/* ERROR */}
                            {pixState === "error" && (
                                <div className="flex flex-col items-center gap-4 py-8 text-center w-full">
                                    <div className="w-14 h-14 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                                        <AlertCircle className="w-6 h-6 text-red-400/60" />
                                    </div>
                                    <div>
                                        <p className="text-sm text-white/60 font-medium">Erro ao gerar PIX</p>
                                        <p className="text-xs text-white/30 mt-1.5 font-light max-w-[230px] leading-relaxed">
                                            {errorMessage}
                                        </p>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={() => requestPix(plan.amountCents)}
                                        className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium
                  bg-white/[0.04] border border-white/[0.08] text-white/60
                  hover:bg-white/[0.07] hover:text-white/80 hover:border-white/[0.14]
                  transition-all duration-200 active:scale-[0.97]"
                                    >
                                        <RefreshCw className="w-3.5 h-3.5" />
                                        Tentar novamente
                                    </button>
                                </div>
                            )}

                            {/* READY */}
                            {pixState === "ready" && (
                                <>
                                    {/* QR Code box */}
                                    <div className="relative flex-shrink-0">
                                        {/* Outer glow frame */}
                                        <div className="absolute -inset-3 rounded-2xl bg-[#8c1229]/10 blur-lg" />
                                        {/* QR white card */}
                                        <div className="relative h-52 w-52 overflow-hidden rounded-xl bg-white p-2.5 shadow-xl sm:h-56 sm:w-56">
                                            {qrDataUrl ? (
                                                <img
                                                    src={qrDataUrl}
                                                    alt="QR Code PIX"
                                                    width={260}
                                                    height={260}
                                                    decoding="async"
                                                    className="w-full h-full object-contain"
                                                    draggable={false}
                                                />
                                            ) : (
                                                <div className="w-full h-full flex items-center justify-center">
                                                    <Loader2 className="w-8 h-8 text-gray-300 animate-spin" />
                                                </div>
                                            )}
                                        </div>
                                        {/* Corner accent brackets */}
                                        <div className="absolute -top-0.5 -left-0.5 w-5 h-5 rounded-tl-xl border-t-2 border-l-2 border-[#8c1229]/50" />
                                        <div className="absolute -top-0.5 -right-0.5 w-5 h-5 rounded-tr-xl border-t-2 border-r-2 border-[#8c1229]/50" />
                                        <div className="absolute -bottom-0.5 -left-0.5 w-5 h-5 rounded-bl-xl border-b-2 border-l-2 border-[#8c1229]/50" />
                                        <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-br-xl border-b-2 border-r-2 border-[#8c1229]/50" />
                                    </div>

                                    {/* Instruction */}
                                    <div className="text-center">
                                        <p className="text-[13px] text-white/55 font-light">
                                            Escaneie com o app do seu banco
                                        </p>
                                        <p className="text-[11px] text-white/25 mt-0.5">ou use o código copia e cola abaixo</p>
                                    </div>

                                    {/* OR separator */}
                                    <div className="w-full flex items-center gap-3">
                                        <div className="flex-1 h-px bg-white/[0.06]" />
                                        <span className="text-[10px] text-white/20 uppercase tracking-[0.15em] font-medium">ou</span>
                                        <div className="flex-1 h-px bg-white/[0.06]" />
                                    </div>

                                    {/* Pix copia e cola */}
                                    <div className="w-full">
                                        <p className="text-[10px] text-white/25 uppercase tracking-wider font-medium mb-2">
                                            Pix copia e cola
                                        </p>
                                        <button
                                            type="button"
                                            onClick={handleCopy}
                                            className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border transition-all duration-300 text-left group
                    ${copied
                                                    ? "bg-emerald-500/[0.08] border-emerald-500/25 shadow-[0_0_16px_rgba(52,211,153,0.08)]"
                                                    : "bg-white/[0.03] border-white/[0.07] hover:bg-white/[0.05] hover:border-[#8c1229]/25"
                                                }`}
                                        >
                                            {/* Truncated code */}
                                            <span className="flex-1 text-[11px] text-white/30 font-mono truncate select-none leading-relaxed">
                                                {pixCode.slice(0, 44)}...
                                            </span>
                                            {/* Icon */}
                                            <span className="shrink-0 transition-transform duration-200">
                                                {copied ? (
                                                    <CheckCircle2 className="w-4 h-4 text-emerald-400 animate-in zoom-in-75 duration-200" />
                                                ) : (
                                                    <Copy className="w-4 h-4 text-white/20 group-hover:text-white/45 transition-colors" />
                                                )}
                                            </span>
                                        </button>

                                        {/* Copy feedback */}
                                        <div className={`overflow-hidden transition-all duration-300 ${copied ? "max-h-8 opacity-100 mt-2" : "max-h-0 opacity-0"}`}>
                                            <p className="text-[11px] text-emerald-400/80 text-center font-medium">
                                                ✓ Código copiado para a área de transferência
                                            </p>
                                        </div>
                                    </div>

                                    {/* Waiting indicator */}
                                    <div className="flex items-center gap-2 mt-1">
                                        <div className="w-1.5 h-1.5 rounded-full bg-[#c9a227]/60 animate-pulse" />
                                        <p className="text-[11px] text-white/25 font-light">
                                            Aguardando pagamento...
                                        </p>
                                    </div>
                                </>
                            )}
                        </div>

                        {/* ── Footer ────────────────────────────────────────────── */}
                        {pixState === "ready" && (
                            <div className="px-6 pb-4 pt-0 sm:pb-5">
                                <div className="mb-2.5 h-px w-full bg-white/[0.04] sm:mb-3" />

                                <div className="flex items-start gap-3 rounded-xl border border-emerald-400/15 bg-emerald-400/[0.04] px-3 py-2.5 text-left sm:px-3.5 sm:py-3">
                                    <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-400/10">
                                        <ShieldCheck className="h-3.5 w-3.5 text-emerald-300/80" />
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-[11px] font-semibold text-white/75">
                                            Garantia DesireAI
                                        </p>
                                        <p className="mt-0.5 text-[10px] font-light leading-relaxed text-white/45">
                                            Se você ficar insatisfeito, reembolsamos seu dinheiro. A DesireAI garante qualidade de alto nível.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </>
                )}
            </div>
        </div>
    );
}
