import { useCallback, useEffect, useRef, useState } from "react";
import { X, ImageIcon, ImageOff, Check, ChevronLeft, ChevronRight } from "lucide-react";
import { useBodyScrollLock } from "@/hooks/use-body-scroll-lock";
import { PACK_PREVIEW_IMAGES, PACK_PREVIEW_IMAGE_SIZES } from "@/lib/pack-preview-images";

interface PackPhotosModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: () => void | Promise<void>;
  isSubmitting: boolean;
}

const PACK_ITEMS = [
  "De quatro",
  "Com as pernas abertas",
  "Só ela peladinha",
  "Sentando",
  "Fudendo no cuzinho",
  "Fudendo na bucetinha",
  "Mamando",
  "+ Gif de brinde",
];

export default function PackPhotosModal({
  open,
  onClose,
  onSubmit,
  isSubmitting,
}: PackPhotosModalProps) {
  useBodyScrollLock(open);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isBounceActive, setIsBounceActive] = useState(false);
  const [failedPreviewIds, setFailedPreviewIds] = useState<string[]>([]);
  const carouselRef = useRef<HTMLDivElement | null>(null);
  const submitStartedRef = useRef(false);

  const scrollToIndex = useCallback((index: number) => {
    const el = carouselRef.current;
    if (!el) return;
    const bounded = Math.max(0, Math.min(PACK_PREVIEW_IMAGES.length - 1, index));
    el.scrollTo({ left: bounded * el.clientWidth, behavior: "smooth" });
    setActiveIndex(bounded);
  }, []);

  useEffect(() => {
    if (!open) return;
    setActiveIndex(0);
    setIsBounceActive(false);
    setFailedPreviewIds([]);
    submitStartedRef.current = false;
    requestAnimationFrame(() => {
      const el = carouselRef.current;
      if (!el) return;
      el.scrollTo({ left: 0, behavior: "auto" });
      requestAnimationFrame(() => {
        setIsBounceActive(true);
        window.setTimeout(() => setIsBounceActive(false), 420);
      });
    });
  }, [open]);

  const handleCarouselScroll = useCallback(() => {
    const el = carouselRef.current;
    if (!el) return;
    const next = Math.round(el.scrollLeft / Math.max(el.clientWidth, 1));
    if (next !== activeIndex) setActiveIndex(next);
  }, [activeIndex]);

  useEffect(() => {
    if (!isSubmitting) submitStartedRef.current = false;
  }, [isSubmitting]);

  const handleSubmit = useCallback(async () => {
    if (isSubmitting || submitStartedRef.current) return;
    submitStartedRef.current = true;
    try {
      await onSubmit();
    } finally {
      submitStartedRef.current = false;
    }
  }, [isSubmitting, onSubmit]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center sm:px-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={isSubmitting ? undefined : onClose} />

      <div
        className="relative w-full sm:max-w-md bg-gradient-to-b from-[#160b12] via-[#110609] to-[#0a0204]
        border-t sm:border border-[#8c1229]/25 rounded-t-3xl sm:rounded-2xl
        shadow-[0_-20px_80px_rgba(140,18,41,0.3)] sm:shadow-[0_0_80px_rgba(140,18,41,0.2)]
        max-h-[92svh] overflow-y-auto animate-in slide-in-from-bottom sm:fade-in sm:zoom-in-95 duration-300"
        style={{
          fontFamily: "'Plus Jakarta Sans', sans-serif",
          overscrollBehavior: "contain",
          WebkitOverflowScrolling: "touch",
        }}
      >
        <div className="sm:hidden flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-white/15" />
        </div>

        <button
          type="button"
          onClick={onClose}
          disabled={isSubmitting}
          className="absolute top-4 right-4 z-10 p-1.5 text-white/30 hover:text-white/70 transition-colors rounded-full hover:bg-white/5 disabled:opacity-30"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="px-6 pt-6 pb-4 text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#8c1229]/15 border border-[#8c1229]/25 mb-3">
            <ImageIcon className="w-5 h-5 text-[#ff3b5c]/75" />
          </div>
          <h3 className="text-[22px] font-semibold text-white/95 tracking-tight">Pack de Fotos Premium</h3>
          <p className="text-sm text-white/45 mt-2 font-light">
            Veja exemplos anteriores e gere seu pack completo em segundos.
          </p>
          <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-[#8c1229]/30 bg-[#8c1229]/10 px-3 py-1.5 text-[11px] text-white/75">
            <span className="h-1.5 w-1.5 rounded-full bg-[#ff3b5c]" />
            Conteúdo exclusivo com entrega instantânea
          </div>
        </div>

        <div className="mx-6 h-px bg-gradient-to-r from-transparent via-[#8c1229]/20 to-transparent" />

        <div className="px-6 py-5 space-y-5">
          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-3">
            <div className="mb-3 flex items-center justify-between px-1">
              <p className="text-[12px] uppercase tracking-wider text-white/45">Gerações anteriores</p>
              {activeIndex === 0 ? (
                <span className="inline-flex items-center rounded-full border border-[#8c1229]/35 bg-[#8c1229]/15 px-2.5 py-1 text-[11px] text-white/80">
                  Foto original
                </span>
              ) : (
                <p className="text-[12px] text-white/40">{activeIndex + 1}/{PACK_PREVIEW_IMAGES.length}</p>
              )}
            </div>

            <div
              className="relative"
              style={{
                transform: isBounceActive ? "translateX(10px)" : "translateX(0px)",
                transition: "transform 280ms cubic-bezier(0.22, 1, 0.36, 1)",
              }}
            >
              <div
                ref={carouselRef}
                onScroll={handleCarouselScroll}
                className="flex snap-x snap-mandatory overflow-x-auto rounded-xl scroll-smooth"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              >
                {PACK_PREVIEW_IMAGES.map((image, index) => (
                  <div key={image.id} className="w-full shrink-0 snap-center">
                    <div className="aspect-[4/5] overflow-hidden rounded-xl bg-black/30">
                      {failedPreviewIds.includes(image.id) ? (
                        <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-white/[0.03] text-white/45">
                          <ImageOff className="h-6 w-6" />
                          <p className="text-[12px]">Prévia temporariamente indisponível</p>
                        </div>
                      ) : (
                        <img
                          src={image.src}
                          srcSet={image.srcSet}
                          sizes={PACK_PREVIEW_IMAGE_SIZES}
                          width={image.width}
                          height={image.height}
                          alt={`Preview do pack ${index + 1}`}
                          className="h-full w-full object-cover"
                          loading={index === 0 ? "eager" : "lazy"}
                          decoding="async"
                          fetchPriority={index === 0 ? "high" : "low"}
                          onError={() => {
                            setFailedPreviewIds((current) => (
                              current.includes(image.id) ? current : [...current, image.id]
                            ));
                          }}
                        />
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={() => scrollToIndex(activeIndex - 1)}
                className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/55 border border-white/15 p-1.5 text-white/70 hover:text-white hover:bg-black/70 transition-colors disabled:opacity-30"
                disabled={activeIndex === 0}
                aria-label="Imagem anterior"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => scrollToIndex(activeIndex + 1)}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/55 border border-white/15 p-1.5 text-white/70 hover:text-white hover:bg-black/70 transition-colors disabled:opacity-30"
                disabled={activeIndex === PACK_PREVIEW_IMAGES.length - 1}
                aria-label="Próxima imagem"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-3 flex items-center justify-between gap-3 px-1">
              <div className="inline-flex items-center gap-1.5 text-[11px] text-white/45">
                <span className="inline-flex items-center">
                  <ChevronRight className="w-3 h-3 -mr-1 opacity-70" />
                  <ChevronRight className="w-3 h-3 opacity-40" />
                </span>
                <span>Arraste para o lado</span>
              </div>
              <div className="flex items-center justify-center gap-1.5">
              {PACK_PREVIEW_IMAGES.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => scrollToIndex(index)}
                  className={`h-1.5 rounded-full transition-all duration-200 ${
                    index === activeIndex ? "w-6 bg-[#ff3b5c]" : "w-2 bg-white/25 hover:bg-white/40"
                  }`}
                  aria-label={`Ir para imagem ${index + 1}`}
                />
              ))}
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4 sm:p-5">
            <p className="text-[12px] uppercase tracking-wider text-white/45 mb-3">Você recebe no pack</p>
            <ul className="space-y-2.5">
              {PACK_ITEMS.map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <span className="mt-0.5 inline-flex h-4 w-4 items-center justify-center rounded-full bg-[#8c1229]/30 border border-[#8c1229]/40 shrink-0">
                    <Check className="w-2.5 h-2.5 text-[#ff3b5c]" />
                  </span>
                  <span className="text-[14px] text-white/85 leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="sticky bottom-0 left-0 right-0 px-6 pt-3 pb-6 bg-gradient-to-t from-[#0a0204] via-[#0a0204]/95 to-transparent">
          <button
            type="button"
            onClick={handleSubmit}
            disabled={isSubmitting}
            className={`w-full py-4 rounded-xl text-[15px] font-semibold tracking-wide transition-all duration-300
              ${isSubmitting
                ? "bg-white/[0.04] text-white/25 border border-white/[0.06] cursor-not-allowed"
                : "bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white hover:from-[#a61530] hover:to-[#6b0d1e] shadow-[0_0_24px_rgba(140,18,41,0.28)] border border-[#ff3b5c]/20"
              }`}
          >
            {isSubmitting ? "Carregando..." : "Gerar agora - 19,90"}
          </button>
          <p className="text-[10px] text-white/20 font-light tracking-wide text-center mt-3">
            Pagamento seguro via PIX e aprovação instantânea
          </p>
        </div>
      </div>
    </div>
  );
}
