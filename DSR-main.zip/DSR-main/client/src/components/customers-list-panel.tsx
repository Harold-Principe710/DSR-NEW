import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  RefreshCw,
  Search,
  X,
} from "lucide-react";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { formatDateTimeInAppTimeZone } from "@/lib/timezone";
import { cn } from "@/lib/utils";

type PaymentStatus = "paid" | "unpaid";
type LeadStage = "all" | "photo_generated" | "generation_error" | "first_screen";
type ResponseKindFilter = "all" | "pack" | "video_pov" | "both" | "none";
type PixProductKey =
  | "single_photo"
  | "pack_photos"
  | "video_pov"
  | "pack_photos_video_pov"
  | "video_pov_pack_photos"
  | "unlimited_daily"
  | "upsell_instapro_weekly";
type PixProductFilter = "all" | PixProductKey;
type SortBy = "createdAt" | "visitorLastSeenAt" | "maxStepReached" | "saleAmountCents" | "paidAt";
type SortDir = "asc" | "desc";

type CustomerOfferResponse = {
  eventId: string;
  occurredAt: string | null;
  metadata: Record<string, unknown> | null;
};

type CustomerVideoPovResponse = CustomerOfferResponse & {
  requestId?: string | null;
  position?: string | null;
  hole?: string | null;
  sexType?: string | null;
  speechType?: string | null;
  requestStatus?: string | null;
  requestAmountCents?: number | null;
  requestCreatedAt?: string | null;
};

type CustomerRow = {
  sessionId: string;
  uploadedPhotoUrl: string | null;
  generatedPhotoUrl: string | null;
  username: string;
  paymentStatus: PaymentStatus;
  contactEmail: string | null;
  contactPhone: string | null;
  purchasedProductLabel?: string | null;
  paidAmountCents?: number | null;
  createdAt: string;
  maxStepReached?: string | null;
  visitorLastSeenAt?: string | null;
  paidAt?: string | null;
  saleAmountCents?: number | null;
  pixProduct?: string | null;
  pixPlanId?: string | null;
  pixJourneyNode?: string | null;
  packResponse?: CustomerOfferResponse | null;
  videoPovResponse?: CustomerVideoPovResponse | null;
};

type CustomersResponse = {
  page: number;
  pageSize: number;
  total: number;
  rows: CustomerRow[];
};

function getCloudinaryThumbnailUrl(url: string | null, size = 96) {
  if (!url) return null;

  const uploadSegment = "/image/upload/";
  const uploadIndex = url.indexOf(uploadSegment);
  if (uploadIndex === -1) return url;

  const prefix = url.slice(0, uploadIndex + uploadSegment.length);
  const suffix = url.slice(uploadIndex + uploadSegment.length);
  const transforms = `f_auto,q_auto:eco,c_fill,g_auto,w_${size},h_${size}`;

  return `${prefix}${transforms}/${suffix}`;
}

type CustomerDetailsSession = {
  sessionId: string;
  userId: string | null;
  customerName: string | null;
  customerEmail: string | null;
  uploadedPhotoUrl: string | null;
  generatedPhotoUrl: string | null;
  isPaid: boolean | null;
  paidAt: string | null;
  saleAmountCents: number | null;
  saleProvider: string | null;
  saleEvent: string | null;
  visitorFirstSeenAt: string | null;
  visitorLastSeenAt: string | null;
  currentStep: string | null;
  maxStepReached: string | null;
  utmSource: string | null;
  utmMedium: string | null;
  utmCampaign: string | null;
  utmContent: string | null;
  utmTerm: string | null;
};

type CustomerDetailsEvent = {
  id: string;
  step: string;
  eventName: string;
  occurredAt: string | null;
  metadata: Record<string, unknown> | null;
};

type CustomerDetailsResponse = {
  session: CustomerDetailsSession;
  events: CustomerDetailsEvent[];
  images: Array<Record<string, unknown>>;
  loginData: {
    userId: string;
    username: string | null;
    email: string | null;
  } | null;
};

export type CustomerListScope = "admin" | "caller";

interface CustomersListPanelProps {
  preset?: string;
  dateFrom?: string;
  dateTo?: string;
  scope?: CustomerListScope;
}

const REFETCH_INTERVAL_MS = 15_000;
const DEFAULT_PAGE_SIZE = 20;

const RESPONSE_KIND_OPTIONS: Array<{ value: ResponseKindFilter; label: string }> = [
  { value: "all", label: "Todas as respostas" },
  { value: "pack", label: "Com pack" },
  { value: "video_pov", label: "Com POV" },
  { value: "both", label: "Com ambos" },
  { value: "none", label: "Sem resposta" },
];

const PIX_PRODUCT_OPTIONS: Array<{ value: PixProductFilter; label: string }> = [
  { value: "all", label: "Todos os produtos PIX" },
  { value: "single_photo", label: "1 foto" },
  { value: "pack_photos", label: "pack de fotos" },
  { value: "video_pov", label: "vídeo pov" },
  { value: "pack_photos_video_pov", label: "pack de fotos + vídeo pov" },
  { value: "video_pov_pack_photos", label: "vídeo pov + pack de fotos" },
  { value: "unlimited_daily", label: "uso diário ilimitado" },
  { value: "upsell_instapro_weekly", label: "IA ilimitada 15 dias" },
];

const PIX_PRODUCT_LABELS: Record<PixProductKey, string> = {
  single_photo: "1 foto",
  pack_photos: "pack de fotos",
  video_pov: "vídeo pov",
  pack_photos_video_pov: "pack de fotos + vídeo pov",
  video_pov_pack_photos: "vídeo pov + pack de fotos",
  unlimited_daily: "uso diário ilimitado",
  upsell_instapro_weekly: "IA ilimitada 15 dias",
};

const FUNNEL_STEP_LABELS: Record<string, string> = {
  visitor_entered: "Visitou",
  photo_uploaded: "Foto enviada",
  generated_photo_viewed: "Foto gerada",
  offer_viewed: "Oferta vista",
  offer_responded: "Oferta respondida",
  video_loading_screen: "Vídeo carregando",
  video_loaded: "Vídeo liberado",
  pix_generated: "PIX gerado",
  pix_paid: "PIX pago",
};

const FUNNEL_STEP_BADGE_CLASSNAMES: Record<string, string> = {
  visitor_entered: "border-white/10 bg-white/5 text-white/70",
  photo_uploaded: "border-sky-500/25 bg-sky-500/15 text-sky-50",
  generated_photo_viewed: "border-fuchsia-500/25 bg-fuchsia-500/15 text-fuchsia-50",
  offer_viewed: "border-amber-500/25 bg-amber-500/15 text-amber-50",
  offer_responded: "border-orange-500/25 bg-orange-500/15 text-orange-50",
  video_loading_screen: "border-violet-500/25 bg-violet-500/15 text-violet-50",
  video_loaded: "border-purple-500/25 bg-purple-500/15 text-purple-50",
  pix_generated: "border-cyan-500/25 bg-cyan-500/15 text-cyan-50",
  pix_paid: "border-emerald-500/25 bg-emerald-500/15 text-emerald-50",
};

const POV_POSITION_LABELS: Record<string, string> = {
  de_quatro: "De quatro",
  papai_mamae: "Papai e mamãe",
  sentando: "Sentando",
  mamando: "Mamando",
};

const POV_HOLE_LABELS: Record<string, string> = {
  buceta: "Buceta",
  cuzinho: "Cuzinho",
  boca: "Boca",
};

const POV_SEX_TYPE_LABELS: Record<string, string> = {
  amorzinho: "Amorzinho",
  hard_fuck: "Hard fuck",
  misturado: "Misturado",
};

const POV_SPEECH_LABELS: Record<string, string> = {
  carinhosa: "Carinhosa",
  ninfomaniaca: "Ninfomaníaca",
  sexo_agressivo: "Sexo agressivo",
};

function formatMoney(amountCents: number) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(amountCents / 100);
}

function formatDateTime(value?: string | null) {
  return formatDateTimeInAppTimeZone(value);
}

function formatRelativeDate(value?: string | null) {
  if (!value) return "sem data";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "sem data";

  const diffMs = date.getTime() - Date.now();
  const absMs = Math.abs(diffMs);
  const rtf = new Intl.RelativeTimeFormat("pt-BR", { numeric: "auto" });

  if (absMs < 60_000) {
    return rtf.format(Math.round(diffMs / 1_000), "second");
  }
  if (absMs < 3_600_000) {
    return rtf.format(Math.round(diffMs / 60_000), "minute");
  }
  if (absMs < 86_400_000) {
    return rtf.format(Math.round(diffMs / 3_600_000), "hour");
  }

  return rtf.format(Math.round(diffMs / 86_400_000), "day");
}

function formatPovLabel(value: string | null | undefined, labels: Record<string, string>) {
  if (!value) return null;
  return labels[value] || value;
}

function getPurchasedProductLabel(row: CustomerRow) {
  if (row.purchasedProductLabel) return row.purchasedProductLabel;

  const productKey = row.pixProduct as PixProductKey | null | undefined;
  if (productKey && productKey in PIX_PRODUCT_LABELS) {
    return PIX_PRODUCT_LABELS[productKey];
  }

  return null;
}

function getPaidAmountCents(row: CustomerRow) {
  return row.paidAmountCents ?? row.saleAmountCents ?? null;
}

function getPaymentState(row: CustomerRow): "paid" | "pending" | "none" {
  if (row.paymentStatus === "paid") return "paid";

  if (
    row.paidAt
    || getPaidAmountCents(row) !== null
    || getPurchasedProductLabel(row)
    || row.pixPlanId
    || row.pixProduct
  ) {
    return "pending";
  }

  return "none";
}

function getPaymentLabel(row: CustomerRow) {
  const paymentState = getPaymentState(row);

  if (paymentState === "paid") return "Pago";
  if (paymentState === "pending") return "Pendente";
  return "—";
}

function getPaymentBadgeClassName(row: CustomerRow) {
  const paymentState = getPaymentState(row);

  if (paymentState === "paid") {
    return "border-emerald-500/40 bg-emerald-500/20 text-emerald-100";
  }
  if (paymentState === "pending") {
    return "border-amber-500/40 bg-amber-500/20 text-amber-100";
  }
  return "border-white/10 bg-white/5 text-white/60";
}

function getCurrentStepLabel(step?: string | null) {
  if (!step) return "—";
  return FUNNEL_STEP_LABELS[step] || step.replaceAll("_", " ");
}

function getCurrentStepBadgeClassName(step?: string | null) {
  if (!step) return "border-white/10 bg-white/5 text-white/60";
  return FUNNEL_STEP_BADGE_CLASSNAMES[step] || "border-white/10 bg-white/5 text-white/80";
}

function getCompactPovPreferences(response?: CustomerVideoPovResponse | null) {
  if (!response) return null;

  const values = [
    formatPovLabel(response.position, POV_POSITION_LABELS),
    formatPovLabel(response.hole, POV_HOLE_LABELS),
    formatPovLabel(response.sexType, POV_SEX_TYPE_LABELS),
    formatPovLabel(response.speechType, POV_SPEECH_LABELS),
  ].filter(Boolean) as string[];

  if (!values.length) return "Sem preferência detalhada";
  return values.join(" · ");
}

function SortableHeader({
  label,
  sortKey,
  activeSortBy,
  activeSortDir,
  onToggle,
}: {
  label: string;
  sortKey: SortBy;
  activeSortBy: SortBy;
  activeSortDir: SortDir;
  onToggle: (sortKey: SortBy) => void;
}) {
  const isActive = activeSortBy === sortKey;
  const Icon = !isActive ? ArrowUpDown : activeSortDir === "asc" ? ArrowUp : ArrowDown;

  return (
    <button
      type="button"
      onClick={() => onToggle(sortKey)}
      className={cn(
        "inline-flex items-center gap-1 transition-colors hover:text-white",
        isActive ? "text-white" : "text-white/70",
      )}
    >
      <span>{label}</span>
      <Icon className="h-3.5 w-3.5" />
    </button>
  );
}

function ResponseBadges({
  pack,
  pov,
}: {
  pack?: CustomerOfferResponse | null;
  pov?: CustomerVideoPovResponse | null;
}) {
  if (!pack && !pov) {
    return <span className="text-white/30">—</span>;
  }

  const badges = [
    pack
      ? {
        key: "pack",
        label: "pack",
        variant: "secondary" as const,
        occurredAt: pack.occurredAt,
      }
      : null,
    pov
      ? {
        key: "pov",
        label: "POV",
        variant: "outline" as const,
        occurredAt: pov.occurredAt,
      }
      : null,
  ].filter(Boolean) as Array<{
    key: string;
    label: string;
    variant: "secondary" | "outline";
    occurredAt: string | null | undefined;
  }>;

  return (
    <div className="flex flex-wrap gap-1.5">
      {badges.map((badge) => (
        <Tooltip key={badge.key}>
          <TooltipTrigger asChild>
            <span>
              <Badge
                variant={badge.variant}
                className={cn(
                  "border-white/10 bg-white/10 text-white",
                  badge.variant === "secondary" && "bg-[#8c1229]/20 text-[#ffdbe2] border-[#8c1229]/30",
                  badge.variant === "outline" && "bg-transparent text-white/90 [--badge-outline:rgba(255,255,255,0.18)]",
                )}
              >
                {badge.label}
              </Badge>
            </span>
          </TooltipTrigger>
          <TooltipContent className="border-white/20 bg-[#0d0810] text-white">
            <p className="text-xs">{formatRelativeDate(badge.occurredAt)}</p>
            <p className="text-[11px] text-white/65">{formatDateTime(badge.occurredAt)}</p>
          </TooltipContent>
        </Tooltip>
      ))}
    </div>
  );
}

function AdminTableRow({
  row,
  onPreviewImage,
  onOpenDetails,
}: {
  row: CustomerRow;
  onPreviewImage: (payload: { url: string; label: string }) => void;
  onOpenDetails: (sessionId: string) => void;
}) {
  const purchasedProductLabel = getPurchasedProductLabel(row);
  const paidAmountCents = getPaidAmountCents(row);
  const compactPovPreferences = getCompactPovPreferences(row.videoPovResponse);
  const uploadedPhotoThumbnailUrl = getCloudinaryThumbnailUrl(row.uploadedPhotoUrl);

  return (
    <TableRow className="border-white/[0.06] hover:bg-white/[0.025]">
      <TableCell className="py-3">
        {row.uploadedPhotoUrl ? (
          <button
            type="button"
            onClick={() => onPreviewImage({ url: row.uploadedPhotoUrl!, label: "Foto upada" })}
            className="rounded focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8c1229]"
          >
            <img
              src={uploadedPhotoThumbnailUrl || row.uploadedPhotoUrl}
              alt="Foto upada do usuário"
              className="h-12 w-12 rounded object-cover cursor-zoom-in"
              loading="lazy"
              decoding="async"
            />
          </button>
        ) : (
          <span className="text-white/30">—</span>
        )}
      </TableCell>
      <TableCell className="py-3">
        {row.generatedPhotoUrl ? (
          <button
            type="button"
            onClick={() => onPreviewImage({ url: row.generatedPhotoUrl!, label: "Foto gerada" })}
            className="rounded focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8c1229]"
          >
            <img
              src={row.generatedPhotoUrl}
              alt="Foto gerada do usuário"
              className="h-12 w-12 rounded object-cover cursor-zoom-in"
              loading="lazy"
              decoding="async"
            />
          </button>
        ) : (
          <span className="text-white/30">—</span>
        )}
      </TableCell>
      <TableCell className="min-w-[180px] py-3">
        <div className="space-y-0.5">
          <p className="font-medium text-white/95">{row.username}</p>
          <p className="text-xs text-white/45">Sessão: {row.sessionId}</p>
        </div>
      </TableCell>
      <TableCell className="min-w-[150px] py-3">
        <Badge variant="outline" className={cn("font-medium [--badge-outline:rgba(255,255,255,0.1)]", getCurrentStepBadgeClassName(row.maxStepReached))}>
          {getCurrentStepLabel(row.maxStepReached)}
        </Badge>
      </TableCell>
      <TableCell className="min-w-[130px] py-3">
        <div className="space-y-1">
          <span className={cn("inline-flex rounded-full border px-2.5 py-1 text-xs font-medium", getPaymentBadgeClassName(row))}>
            {getPaymentLabel(row)}
          </span>
          {row.paidAt ? <p className="text-[11px] text-white/45">{formatDateTime(row.paidAt)}</p> : null}
        </div>
      </TableCell>
      <TableCell className="min-w-[180px] py-3">
        {purchasedProductLabel || paidAmountCents !== null ? (
          <div className="space-y-0.5">
            <p>{purchasedProductLabel || "Produto identificado"}</p>
            {paidAmountCents !== null ? <p className="text-white/60">{formatMoney(paidAmountCents)}</p> : null}
          </div>
        ) : (
          <span className="text-white/30">—</span>
        )}
      </TableCell>
      <TableCell className="min-w-[120px] py-3">
        <ResponseBadges pack={row.packResponse} pov={row.videoPovResponse} />
      </TableCell>
      <TableCell className="min-w-[230px] py-3">
        {compactPovPreferences ? (
          <div className="space-y-1">
            <p className="text-xs leading-5 text-white/90">{compactPovPreferences}</p>
            {row.videoPovResponse?.requestStatus ? (
              <p className="text-[11px] text-white/45">Solicitação: {row.videoPovResponse.requestStatus}</p>
            ) : null}
          </div>
        ) : (
          <span className="text-white/30">—</span>
        )}
      </TableCell>
      <TableCell className="min-w-[200px] py-3">
        <div className="space-y-0.5">
          <p>{row.contactEmail || "E-mail não preenchido"}</p>
          <p className="text-white/60">{row.contactPhone || "Telefone não preenchido"}</p>
        </div>
      </TableCell>
      <TableCell className="min-w-[170px] py-3">
        <div className="space-y-0.5">
          <p>{formatDateTime(row.createdAt)}</p>
          {row.visitorLastSeenAt ? (
            <p className="text-[11px] text-white/45">Última atividade: {formatDateTime(row.visitorLastSeenAt)}</p>
          ) : null}
        </div>
      </TableCell>
      <TableCell className="py-3">
        <button
          type="button"
          onClick={() => onOpenDetails(row.sessionId)}
          className="inline-flex min-h-8 items-center gap-1.5 rounded-md border border-white/[0.15] px-2.5 text-xs font-medium text-white/75 transition-colors hover:bg-white/[0.06] hover:text-white"
        >
          <Eye className="h-3.5 w-3.5" />
          Ver detalhes
        </button>
      </TableCell>
    </TableRow>
  );
}

function CallerTableRow({
  row,
  onPreviewImage,
}: {
  row: CustomerRow;
  onPreviewImage: (payload: { url: string; label: string }) => void;
}) {
  const uploadedPhotoThumbnailUrl = getCloudinaryThumbnailUrl(row.uploadedPhotoUrl);

  return (
    <TableRow className="border-white/[0.06] hover:bg-white/[0.025]">
      <TableCell className="py-3">
        {row.uploadedPhotoUrl ? (
          <button
            type="button"
            onClick={() => onPreviewImage({ url: row.uploadedPhotoUrl!, label: "Foto upada" })}
            className="rounded focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8c1229]"
          >
            <img
              src={uploadedPhotoThumbnailUrl || row.uploadedPhotoUrl}
              alt="Foto upada do usuário"
              className="h-12 w-12 rounded object-cover cursor-zoom-in"
              loading="lazy"
              decoding="async"
            />
          </button>
        ) : (
          <span className="text-white/30">-</span>
        )}
      </TableCell>
      <TableCell className="py-3">
        {row.generatedPhotoUrl ? (
          <button
            type="button"
            onClick={() => onPreviewImage({ url: row.generatedPhotoUrl!, label: "Foto gerada" })}
            className="rounded focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8c1229]"
          >
            <img
              src={row.generatedPhotoUrl}
              alt="Foto gerada do usuário"
              className="h-12 w-12 rounded object-cover cursor-zoom-in"
              loading="lazy"
              decoding="async"
            />
          </button>
        ) : (
          <span className="text-white/30">-</span>
        )}
      </TableCell>
      <TableCell className="py-3">{row.username}</TableCell>
      <TableCell className="py-3">{row.paymentStatus === "paid" ? "Pago" : "Não pago"}</TableCell>
      <TableCell className="py-3">
        <div className="space-y-0.5">
          <p>{row.contactEmail || "E-mail não preenchido"}</p>
          <p className="text-white/60">{row.contactPhone || "Telefone não preenchido"}</p>
        </div>
      </TableCell>
      <TableCell className="py-3">{formatDateTime(row.createdAt)}</TableCell>
    </TableRow>
  );
}

export function CustomersListPanel({
  preset = "7d",
  dateFrom = "",
  dateTo = "",
  scope = "admin",
}: CustomersListPanelProps) {
  const [, setLocation] = useLocation();
  const isAdmin = scope === "admin";
  const [search, setSearch] = useState("");
  const [paymentStatus, setPaymentStatus] = useState<"all" | PaymentStatus>("all");
  const [leadStage, setLeadStage] = useState<LeadStage>("all");
  const [responseKind, setResponseKind] = useState<ResponseKindFilter>("all");
  const [pixProduct, setPixProduct] = useState<PixProductFilter>("all");
  const [sortBy, setSortBy] = useState<SortBy>("createdAt");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [page, setPage] = useState(1);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<{ url: string; label: string } | null>(null);

  const loginRedirect = isAdmin ? "/admin/login" : "/caller-92192/login";
  const customersEndpoint = isAdmin ? "/api/admin/customers" : "/api/caller/customers";
  const detailsEndpoint = isAdmin && selectedSessionId ? `/api/admin/customers/${selectedSessionId}` : null;

  const queryString = useMemo(() => {
    const params = new URLSearchParams();
    params.set("preset", preset);

    if (preset === "custom") {
      if (dateFrom) params.set("dateFrom", dateFrom);
      if (dateTo) params.set("dateTo", dateTo);
    }

    params.set("search", search);
    params.set("paymentStatus", paymentStatus);
    params.set("leadStage", leadStage);
    params.set("page", String(page));
    params.set("pageSize", String(DEFAULT_PAGE_SIZE));

    if (isAdmin) {
      if (responseKind !== "all") params.set("responseKind", responseKind);
      if (pixProduct !== "all") params.set("pixProduct", pixProduct);
      params.set("sortBy", sortBy);
      params.set("sortDir", sortDir);
    }

    return params.toString();
  }, [
    dateFrom,
    dateTo,
    isAdmin,
    leadStage,
    page,
    paymentStatus,
    pixProduct,
    preset,
    responseKind,
    search,
    sortBy,
    sortDir,
  ]);

  const customersQuery = useQuery<CustomersResponse>({
    queryKey: [customersEndpoint, queryString],
    queryFn: async () => {
      const res = await fetch(`${customersEndpoint}?${queryString}`, { credentials: "include" });
      if (res.status === 401) {
        setLocation(loginRedirect);
        throw new Error("unauthorized");
      }
      if (!res.ok) throw new Error("Erro ao carregar clientes");
      return res.json();
    },
    refetchInterval: REFETCH_INTERVAL_MS,
    refetchIntervalInBackground: false,
  });

  const detailsQuery = useQuery<CustomerDetailsResponse>({
    queryKey: ["/api/admin/customers/details", selectedSessionId],
    enabled: !!selectedSessionId && isAdmin && !!detailsEndpoint,
    queryFn: async () => {
      const res = await fetch(detailsEndpoint!, { credentials: "include" });
      if (res.status === 401) {
        setLocation(loginRedirect);
        throw new Error("unauthorized");
      }
      if (!res.ok) throw new Error("Erro ao carregar detalhes");
      return res.json();
    },
  });

  const rows = customersQuery.data?.rows || [];
  const total = customersQuery.data?.total || 0;
  const hasNextPage = page * DEFAULT_PAGE_SIZE < total;

  function toggleSort(nextSortBy: SortBy) {
    setPage(1);

    if (sortBy === nextSortBy) {
      setSortDir((current) => (current === "asc" ? "desc" : "asc"));
      return;
    }

    setSortBy(nextSortBy);
    setSortDir("desc");
  }

  return (
    <TooltipProvider delayDuration={120}>
      <section className="space-y-4 rounded-md border border-white/10 bg-[#0d0a0c] p-4 shadow-[0_18px_50px_rgba(0,0,0,0.16)]">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-xs font-medium uppercase text-white/[0.42]">
              {isAdmin ? "Clientes e sessões" : "Usuários"}
            </p>
            <h2 className="mt-1 text-lg font-semibold tracking-normal text-white">
              {isAdmin ? "Inteligência de clientes" : "Lista operacional"}
            </h2>
            <p className="mt-1 text-sm text-white/50">
              {isAdmin
                ? "Busca, status de pagamento, respostas comerciais e eventos da sessão."
                : "Lista para contato, com atualização automática a cada 15 segundos."}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-white/50">
            <span className="rounded-md border border-white/10 bg-black/25 px-2.5 py-1.5">
              Total: <span className="font-semibold text-white tabular-nums">{total.toLocaleString("pt-BR")}</span>
            </span>
            {customersQuery.isFetching ? (
              <span className="inline-flex items-center gap-1.5 rounded-md border border-[#8c1229]/30 bg-[#8c1229]/[0.14] px-2.5 py-1.5 text-[#ffdbe2]">
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                Atualizando
              </span>
            ) : null}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-2 md:grid-cols-2 xl:flex xl:flex-wrap">
          <div className="relative min-w-[260px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/[0.38]" />
            <Input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Buscar sessão, nome, email, UTM..."
              className="border-white/10 bg-black/25 pl-9 text-white placeholder:text-white/[0.35]"
            />
          </div>

          <Select
            value={paymentStatus}
            onValueChange={(value) => {
              setPaymentStatus(value as "all" | PaymentStatus);
              setPage(1);
            }}
          >
            <SelectTrigger className="border-white/10 bg-black/25 text-white md:w-full xl:w-[180px]">
              <SelectValue placeholder="Pagamento" />
            </SelectTrigger>
            <SelectContent className="border-white/10 bg-[#12080d] text-white">
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="paid">Pago</SelectItem>
              <SelectItem value="unpaid">Não pago</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={leadStage}
            onValueChange={(value) => {
              setLeadStage(value as LeadStage);
              setPage(1);
            }}
          >
            <SelectTrigger className="border-white/10 bg-black/25 text-white md:w-full xl:w-[210px]">
              <SelectValue placeholder="Etapa" />
            </SelectTrigger>
            <SelectContent className="border-white/10 bg-[#12080d] text-white">
              <SelectItem value="all">Todas as etapas</SelectItem>
              <SelectItem value="photo_generated">Foto gerada</SelectItem>
              <SelectItem value="generation_error">Erro na geração</SelectItem>
              <SelectItem value="first_screen">Visualização da primeira tela</SelectItem>
            </SelectContent>
          </Select>

          {isAdmin ? (
            <>
              <Select
                value={responseKind}
                onValueChange={(value) => {
                  setResponseKind(value as ResponseKindFilter);
                  setPage(1);
                }}
              >
                <SelectTrigger className="border-white/10 bg-black/25 text-white md:w-full xl:w-[210px]">
                  <SelectValue placeholder="Tipo de resposta" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#12080d] text-white">
                  {RESPONSE_KIND_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={pixProduct}
                onValueChange={(value) => {
                  setPixProduct(value as PixProductFilter);
                  setPage(1);
                }}
              >
                <SelectTrigger className="border-white/10 bg-black/25 text-white md:w-full xl:w-[230px]">
                  <SelectValue placeholder="Produto PIX" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#12080d] text-white">
                  {PIX_PRODUCT_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </>
          ) : null}
        </div>

        {customersQuery.isError && (
          <div className="rounded-md border border-red-500/20 bg-red-500/10 px-3 py-2 text-sm text-red-100">
            Não foi possível carregar a lista de clientes com os filtros atuais.
          </div>
        )}

        <div className="overflow-hidden rounded-md border border-white/[0.08] bg-black/20">
          <div className="overflow-auto">
          <Table className={isAdmin ? "min-w-[1440px]" : "min-w-[760px]"}>
            <TableHeader>
              <TableRow className="border-white/10 bg-white/[0.025] text-white/60 hover:bg-white/[0.025]">
                <TableHead className="py-2 text-left">Foto upada</TableHead>
                <TableHead className="py-2 text-left">Foto gerada</TableHead>
                <TableHead className="py-2 text-left">Username</TableHead>
                {isAdmin ? (
                  <>
                    <TableHead className="py-2 text-left">
                      <SortableHeader
                        label="Maior passo"
                        sortKey="maxStepReached"
                        activeSortBy={sortBy}
                        activeSortDir={sortDir}
                        onToggle={toggleSort}
                      />
                    </TableHead>
                    <TableHead className="py-2 text-left">
                      <SortableHeader
                        label="Pagamento"
                        sortKey="paidAt"
                        activeSortBy={sortBy}
                        activeSortDir={sortDir}
                        onToggle={toggleSort}
                      />
                    </TableHead>
                    <TableHead className="py-2 text-left">
                      <SortableHeader
                        label="Produto pago"
                        sortKey="saleAmountCents"
                        activeSortBy={sortBy}
                        activeSortDir={sortDir}
                        onToggle={toggleSort}
                      />
                    </TableHead>
                    <TableHead className="py-2 text-left">Respostas</TableHead>
                    <TableHead className="py-2 text-left">Preferências POV</TableHead>
                  </>
                ) : (
                  <TableHead className="py-2 text-left">Pagamento</TableHead>
                )}
                <TableHead className="py-2 text-left">E-mail/telefone</TableHead>
                <TableHead className="py-2 text-left">
                  {isAdmin ? (
                    <SortableHeader
                      label="Data"
                      sortKey="createdAt"
                      activeSortBy={sortBy}
                      activeSortDir={sortDir}
                      onToggle={toggleSort}
                    />
                  ) : (
                    "Data/hora"
                  )}
                </TableHead>
                {isAdmin ? <TableHead className="py-2 text-left">Ações</TableHead> : null}
              </TableRow>
            </TableHeader>
            <TableBody>
              {customersQuery.isLoading ? (
                <TableRow className="border-white/5">
                  <TableCell colSpan={isAdmin ? 11 : 6} className="py-6 text-center text-white/45">
                    Carregando clientes...
                  </TableCell>
                </TableRow>
              ) : rows.length ? (
                rows.map((row) => (
                  isAdmin ? (
                    <AdminTableRow
                      key={row.sessionId}
                      row={row}
                      onPreviewImage={setImagePreview}
                      onOpenDetails={setSelectedSessionId}
                    />
                  ) : (
                    <CallerTableRow
                      key={row.sessionId}
                      row={row}
                      onPreviewImage={setImagePreview}
                    />
                  )
                ))
              ) : (
                <TableRow className="border-white/5">
                  <TableCell colSpan={isAdmin ? 11 : 6} className="py-6 text-center text-white/45">
                    Nenhum cliente encontrado para os filtros selecionados.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          </div>
        </div>

        <div className="flex flex-col gap-3 text-sm text-white/60 sm:flex-row sm:items-center sm:justify-between">
          <p>
            Página <span className="font-semibold text-white tabular-nums">{page}</span> ·{" "}
            <span className="font-semibold text-white tabular-nums">{total.toLocaleString("pt-BR")}</span> registros
          </p>
          <div className="flex gap-2">
            <Button
              type="button"
              onClick={() => setPage((current) => Math.max(1, current - 1))}
              variant="outline"
              size="sm"
              className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
              disabled={page <= 1}
            >
              <ChevronLeft className="h-4 w-4" />
              Anterior
            </Button>
            <Button
              type="button"
              onClick={() => setPage((current) => current + 1)}
              variant="outline"
              size="sm"
              className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
              disabled={!hasNextPage}
            >
              Próxima
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {selectedSessionId && isAdmin ? (
          <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
            <div className="w-full max-w-2xl max-h-[85vh] overflow-auto rounded-md border border-white/[0.15] bg-[#0b0609] p-4 shadow-[0_24px_80px_rgba(0,0,0,0.45)]">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-lg font-medium">Detalhes da sessão</h3>
                <button
                  type="button"
                  onClick={() => setSelectedSessionId(null)}
                  className="inline-flex h-8 w-8 items-center justify-center rounded-md text-white/60 transition-colors hover:bg-white/[0.06] hover:text-white"
                  aria-label="Fechar detalhes"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              {detailsQuery.isLoading ? (
                <p className="text-white/45">Carregando...</p>
              ) : detailsQuery.data ? (
                <div className="space-y-3 text-sm">
                  <div className="rounded-md border border-white/10 bg-black/30 p-3 space-y-2">
                    <h4 className="font-medium text-white">Nome / dado preenchido</h4>
                    <p className="text-white/80">
                      {detailsQuery.data.session.customerName
                        || detailsQuery.data.session.customerEmail
                        || detailsQuery.data.loginData?.username
                        || detailsQuery.data.loginData?.email
                        || detailsQuery.data.session.userId
                        || detailsQuery.data.session.sessionId}
                    </p>
                  </div>

                  <div className="rounded-md border border-white/10 bg-black/30 p-3 space-y-2">
                    <h4 className="font-medium text-white">Dados de login preenchidos</h4>
                    <p className="text-white/80">
                      <span className="text-white/50">Usuário: </span>
                      {detailsQuery.data.loginData?.username || "Não preenchido"}
                    </p>
                    <p className="text-white/80">
                      <span className="text-white/50">E-mail: </span>
                      {detailsQuery.data.loginData?.email || detailsQuery.data.session.customerEmail || "Não preenchido"}
                    </p>
                    <p className="text-white/80">
                      <span className="text-white/50">Senha: </span>
                      Não exibida por segurança
                    </p>
                  </div>

                  <SessionDetailsBlock session={detailsQuery.data.session} />
                  <EventsTimelineBlock events={detailsQuery.data.events} />
                </div>
              ) : (
                <p className="text-white/45">Sem dados.</p>
              )}
            </div>
          </div>
        ) : null}

        {imagePreview ? (
          <div
            className="fixed inset-0 z-[60] bg-black/80 flex items-center justify-center p-4"
            onClick={() => setImagePreview(null)}
          >
            <div
              className="w-full max-w-4xl rounded-md border border-white/[0.15] bg-[#0b0609] p-4 shadow-[0_24px_80px_rgba(0,0,0,0.45)]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-lg font-medium">{imagePreview.label}</h3>
                <button
                  type="button"
                  onClick={() => setImagePreview(null)}
                  className="inline-flex h-8 w-8 items-center justify-center rounded-md text-white/60 transition-colors hover:bg-white/[0.06] hover:text-white"
                  aria-label="Fechar imagem"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="flex max-h-[75vh] items-center justify-center overflow-auto rounded-md border border-white/10 bg-black/30 p-2">
                <img
                  src={imagePreview.url}
                  alt={imagePreview.label}
                  className="max-h-[70vh] max-w-full rounded-md object-contain"
                  decoding="async"
                />
              </div>
            </div>
          </div>
        ) : null}
      </section>
    </TooltipProvider>
  );
}

// Whitelist of session fields rendered in the details modal. Anything not
// listed here stays out of the admin UI to avoid accidental PII exposure as
// the schema evolves (e.g. if a new sensitive column is added later).
const SESSION_FIELD_LABELS: Array<[keyof CustomerDetailsSession, string]> = [
  ["sessionId", "Session ID"],
  ["userId", "User ID"],
  ["customerName", "Nome"],
  ["customerEmail", "E-mail"],
  ["isPaid", "Pagou?"],
  ["paidAt", "Pago em"],
  ["saleAmountCents", "Valor (centavos)"],
  ["saleProvider", "Provedor PIX"],
  ["saleEvent", "Evento PIX"],
  ["currentStep", "Etapa atual"],
  ["maxStepReached", "Etapa máx."],
  ["visitorFirstSeenAt", "Primeira visita"],
  ["visitorLastSeenAt", "Última visita"],
  ["utmSource", "UTM source"],
  ["utmMedium", "UTM medium"],
  ["utmCampaign", "UTM campaign"],
  ["utmContent", "UTM content"],
  ["utmTerm", "UTM term"],
];

function formatSessionFieldValue(value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "boolean") return value ? "Sim" : "Não";
  return String(value);
}

function SessionDetailsBlock({ session }: { session: CustomerDetailsSession }) {
  return (
    <div className="rounded-md border border-white/10 bg-black/30 p-3 space-y-2">
      <h4 className="font-medium text-white">Sessão</h4>
      <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-[12.5px]">
        {SESSION_FIELD_LABELS.map(([field, label]) => (
          <div key={String(field)} className="flex flex-col">
            <dt className="text-white/45">{label}</dt>
            <dd className="text-white/85 break-words">{formatSessionFieldValue(session[field])}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

function EventsTimelineBlock({ events }: { events: CustomerDetailsEvent[] }) {
  if (!events.length) {
    return (
      <div className="rounded-md border border-white/10 bg-black/30 p-3">
        <h4 className="font-medium text-white mb-1">Eventos</h4>
        <p className="text-white/45 text-sm">Nenhum evento registrado.</p>
      </div>
    );
  }
  return (
    <div className="rounded-md border border-white/10 bg-black/30 p-3 space-y-2">
      <h4 className="font-medium text-white">Eventos ({events.length})</h4>
      <ul className="flex flex-col gap-2">
        {events.map((event) => {
          const stepLabel = FUNNEL_STEP_LABELS[event.step] || event.step;
          const metaEntries = event.metadata
            ? Object.entries(event.metadata).filter(([, v]) => v !== null && v !== undefined && v !== "")
            : [];
          return (
            <li key={event.id} className="rounded border border-white/10 bg-black/20 p-2">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10.5px] uppercase tracking-wide text-white/70">
                    {stepLabel}
                  </span>
                  <span className="text-[12px] text-white/85 font-medium">{event.eventName}</span>
                </div>
                <span className="text-[11px] text-white/45 tabular-nums">
                  {formatDateTimeInAppTimeZone(event.occurredAt)}
                </span>
              </div>
              {metaEntries.length > 0 && (
                <dl className="mt-1.5 grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11.5px]">
                  {metaEntries.slice(0, 8).map(([key, value]) => (
                    <div key={key} className="flex gap-1.5">
                      <dt className="text-white/45 shrink-0">{key}:</dt>
                      <dd className="text-white/80 truncate" title={String(value)}>{String(value)}</dd>
                    </div>
                  ))}
                </dl>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
