import { useState } from "react";
import { Mail, ShieldX } from "lucide-react";

interface Props {
    reason?: string;
}

export default function EmailVerificationGate({ reason }: Props) {
    const [email, setEmail] = useState("");
    const [sent, setSent] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async () => {
        setError("");
        if (!email || !email.includes("@")) {
            setError("Insira um e-mail válido.");
            return;
        }
        setLoading(true);
        try {
            const res = await fetch("/api/auth/send-verification", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email }),
                credentials: "include",
            });
            if (res.ok) {
                setSent(true);
            } else {
                const data = await res.json().catch(() => ({}));
                setError(data.message || "Erro ao enviar. Tente novamente.");
            }
        } catch {
            setError("Erro de conexão. Tente novamente.");
        } finally {
            setLoading(false);
        }
    };

    return (
        /* Full-screen persistent overlay — cannot be closed */
        <div className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-md flex items-center justify-center p-5">
            <div className="w-full max-w-sm rounded-2xl bg-[#0a0204] border border-[#8c1229]/30 shadow-[0_20px_80px_rgba(140,18,41,0.4)] p-8 flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-500">

                {/* Icon */}
                <div className="flex flex-col items-center gap-3 text-center">
                    <div className="w-12 h-12 rounded-full bg-[#8c1229]/20 border border-[#8c1229]/30 flex items-center justify-center">
                        <ShieldX className="w-6 h-6 text-[#ff3b5c]" />
                    </div>
                    <h2 className="text-white text-lg font-semibold">Verificação necessária</h2>
                    <p className="text-white/40 text-sm leading-relaxed">
                        Detectamos uma conexão incomum. Para continuar, é necessário verificar seu e-mail.
                    </p>
                </div>

                {!sent ? (
                    <>
                        {/* Email input */}
                        <div className="flex flex-col gap-2">
                            <label className="text-white/60 text-[13px] font-medium">
                                Insira um email para receber código de verificação
                            </label>
                            <div className="relative">
                                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                                <input
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                                    placeholder="seuemail@exemplo.com"
                                    className="w-full pl-9 pr-4 py-3 rounded-xl bg-white/[0.05] border border-white/10 text-white placeholder-white/25 text-[14px] focus:outline-none focus:border-[#8c1229]/60 focus:bg-white/[0.07] transition-all"
                                />
                            </div>
                            {error && (
                                <p className="text-[#ff3b5c] text-xs mt-1">{error}</p>
                            )}
                        </div>

                        {/* Submit button */}
                        <button
                            onClick={handleSubmit}
                            disabled={loading}
                            className="w-full py-3.5 rounded-[14px] bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white text-[14px] font-semibold tracking-wide hover:from-[#a61530] hover:to-[#6b0d1e] active:scale-[0.98] transition-all shadow-[0_0_30px_rgba(140,18,41,0.25)] disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {loading ? "Enviando..." : "Confirmar"}
                        </button>
                    </>
                ) : (
                    /* Sent state */
                    <div className="flex flex-col items-center gap-3 text-center py-4">
                        <div className="w-12 h-12 rounded-full bg-[#1a4a1a]/40 border border-green-700/30 flex items-center justify-center">
                            <Mail className="w-6 h-6 text-green-400" />
                        </div>
                        <p className="text-white/80 text-[15px] font-medium leading-relaxed">
                            Clique no link enviado ao seu e-mail para verificar e acessar sua conta.
                        </p>
                        <p className="text-white/30 text-xs">
                            Não recebeu? Verifique a caixa de spam.
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
}
