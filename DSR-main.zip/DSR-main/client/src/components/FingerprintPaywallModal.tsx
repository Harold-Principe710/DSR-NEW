import { useMemo, useState } from "react";
import { ShieldAlert, Film, Images, Infinity, Sparkles } from "lucide-react";
import { PLANS } from "./PixQrModal";
import PixQrModal from "./PixQrModal";
import { useBodyScrollLock } from "@/hooks/use-body-scroll-lock";
import { useResolvePlanId } from "@/lib/ab-pricing";

interface FingerprintPaywallModalProps {
    open: boolean;
    onPaymentSuccess: (paymentData: any) => void;
}

const PAYWALL_PLANS = [
    {
        planId: "video-pov-2990",
        label: "Vídeo POV",
        description: "Acesso ao vídeo POV",
        icon: Film,
        highlight: false,
    },
    {
        planId: "pack-fotos-2990",
        label: "Pack de fotos",
        description: "Pacote completo de fotos",
        icon: Images,
        highlight: false,
    },
    {
        planId: "ilimitado",
        label: "Uso diário ilimitado",
        description: "Acesso irrestrito por 1 dia",
        icon: Infinity,
        highlight: true,
    },
];

export default function FingerprintPaywallModal({ open, onPaymentSuccess }: FingerprintPaywallModalProps) {
    useBodyScrollLock(open);
    const resolvePlanId = useResolvePlanId("landing-pricing");
    const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);

    const resolvedPaywallPlans = useMemo(
        () => PAYWALL_PLANS.map((plan) => ({ ...plan, planId: resolvePlanId(plan.planId) })),
        [resolvePlanId],
    );

    if (!open) return null;

    // If a plan is selected, show PixQrModal on top
    if (selectedPlanId) {
        return (
            <>
                {/* Keep paywall backdrop visible behind PixQrModal */}
                <div className="fixed inset-0 z-[9998] bg-black/95 backdrop-blur-md" />
                <PixQrModal
                    open={true}
                    onClose={() => setSelectedPlanId(null)}
                    planId={selectedPlanId}
                    onPaymentSuccess={(data) => {
                        setSelectedPlanId(null);
                        onPaymentSuccess(data);
                    }}
                />
            </>
        );
    }

    return (
        <div className="fixed inset-0 z-[9999] bg-black/95 backdrop-blur-md flex items-center justify-center p-5">
            <div
                className="w-full max-w-sm rounded-2xl bg-gradient-to-b from-[#160b12] via-[#110609] to-[#0a0204] border border-[#8c1229]/30 shadow-[0_20px_80px_rgba(140,18,41,0.4)] p-8 flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-500"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
                {/* Icon + Header */}
                <div className="flex flex-col items-center gap-3 text-center">
                    <div className="w-14 h-14 rounded-full bg-[#8c1229]/20 border border-[#8c1229]/30 flex items-center justify-center">
                        <ShieldAlert className="w-7 h-7 text-[#ff3b5c]" />
                    </div>
                    <h2 className="text-[20px] font-semibold text-white/95 tracking-tight">
                        Acesso requer pagamento
                    </h2>
                    <p className="text-sm text-white/40 leading-relaxed max-w-[280px]">
                        Detectamos que você já utilizou este serviço. Escolha um plano para continuar.
                    </p>
                </div>

                {/* Plan options */}
                <div className="flex flex-col gap-3">
                    {resolvedPaywallPlans.map((plan) => {
                        const planInfo = PLANS[plan.planId];
                        if (!planInfo) return null;
                        const Icon = plan.icon;

                        return (
                            <button
                                key={plan.planId}
                                type="button"
                                onClick={() => setSelectedPlanId(plan.planId)}
                                className={`relative w-full flex items-center gap-4 px-5 py-4 rounded-xl border transition-all duration-200 group text-left active:scale-[0.98]
                  ${plan.highlight
                                        ? "bg-gradient-to-r from-[#8c1229]/20 to-[#520a17]/10 border-[#8c1229]/40 hover:border-[#ff3b5c]/50 hover:from-[#8c1229]/25 hover:to-[#520a17]/15"
                                        : "bg-white/[0.02] border-white/[0.08] hover:border-white/[0.15] hover:bg-white/[0.04]"
                                    }`}
                            >
                                <div
                                    className={`flex items-center justify-center w-10 h-10 rounded-lg shrink-0
                    ${plan.highlight
                                            ? "bg-[#8c1229]/30 text-[#ff3b5c]/80"
                                            : "bg-white/[0.05] text-white/40"
                                        }`}
                                >
                                    <Icon className="w-5 h-5" />
                                </div>

                                <div className="flex-1 min-w-0">
                                    <span
                                        className={`text-[15px] font-medium block ${plan.highlight ? "text-white/95" : "text-white/80"
                                            }`}
                                    >
                                        {plan.label}
                                    </span>
                                    <span className="text-[12px] text-white/35 block mt-0.5">
                                        {plan.description}
                                    </span>
                                </div>

                                <span
                                    className={`text-[15px] font-semibold shrink-0 ${plan.highlight ? "text-[#ff3b5c]" : "text-white/60"
                                        }`}
                                >
                                    {planInfo.price}
                                </span>

                                {plan.highlight && (
                                    <div className="absolute -top-2.5 right-4 px-2.5 py-0.5 bg-gradient-to-r from-[#8c1229] to-[#ff3b5c] rounded-full flex items-center gap-1">
                                        <Sparkles className="w-3 h-3 text-white" />
                                        <span className="text-[10px] font-semibold text-white tracking-wide uppercase">
                                            Popular
                                        </span>
                                    </div>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* Footer */}
                <div className="text-center">
                    <p className="text-[11px] text-white/20 font-light tracking-wide">
                        * Compra 100% sigilosa, pago via PIX · Aprovação instantânea
                    </p>
                </div>
            </div>
        </div>
    );
}
