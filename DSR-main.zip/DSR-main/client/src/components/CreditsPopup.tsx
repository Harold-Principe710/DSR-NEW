import { useState } from "react";
import { X, Info, Sparkles, ImageIcon, Film, Infinity } from "lucide-react";
import { PLANS } from "./PixQrModal";
import { useBodyScrollLock } from "@/hooks/use-body-scroll-lock";

interface CreditsPopupProps {
    open: boolean;
    onClose: () => void;
    onSelectPlan: (planId: string) => void;
    customTitle?: string;
    customSubtitle?: string;
    customItems?: CreditsPopupItem[];
}

export interface CreditsPopupItem {
    planId: string;
    title?: string;
    subtitle?: string;
    price?: string;
    onClick?: () => void;
}

// Map plan IDs → icon & optional tooltip
const planMeta: Record<string, { icon: React.ReactNode; highlight?: boolean; tooltip?: string }> = {
    "1-foto": {
        icon: <ImageIcon className="w-5 h-5" />,
    },
    "10-fotos": {
        icon: <Sparkles className="w-5 h-5" />,
    },
    "10-fotos-1-video": {
        icon: <Film className="w-5 h-5" />,
    },
    "ilimitado": {
        icon: <Infinity className="w-5 h-5" />,
        highlight: true,
        tooltip: "Use todas as funções da ferramenta ilimitado hoje (oferta válida por 5 minutos)",
    },
};

const planOrder = ["10-fotos", "10-fotos-1-video", "ilimitado"];

export default function CreditsPopup({
    open,
    onClose,
    onSelectPlan,
    customTitle,
    customSubtitle,
    customItems,
}: CreditsPopupProps) {
    useBodyScrollLock(open);
    const [hoveredTooltip, setHoveredTooltip] = useState<string | null>(null);

    const popupItems: CreditsPopupItem[] = customItems ?? planOrder.map((planId) => ({ planId }));

    if (!open) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:px-4">
            {/* Backdrop */}
            <div
                className="absolute inset-0 bg-black/70 backdrop-blur-sm"
                onClick={onClose}
            />

            {/* Modal — bottom sheet on mobile, centered card on desktop */}
            <div
                className="relative w-full sm:max-w-md
          bg-gradient-to-b from-[#160b12] via-[#110609] to-[#0a0204]
          border-t sm:border border-[#8c1229]/25
          rounded-t-3xl sm:rounded-2xl
          shadow-[0_-20px_80px_rgba(140,18,41,0.25)] sm:shadow-[0_0_80px_rgba(140,18,41,0.2)]
          max-h-[92svh] overflow-y-auto animate-in slide-in-from-bottom sm:fade-in sm:zoom-in-95 duration-300"
                style={{
                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                    overscrollBehavior: "contain",
                    WebkitOverflowScrolling: "touch",
                }}
            >
                {/* Drag handle (mobile) */}
                <div className="sm:hidden flex justify-center pt-3 pb-1">
                    <div className="w-10 h-1 rounded-full bg-white/20" />
                </div>

                {/* Close button */}
                <button
                    type="button"
                    onClick={onClose}
                    className="absolute top-4 right-4 p-1.5 text-white/30 hover:text-white/60 transition-colors rounded-full hover:bg-white/5"
                >
                    <X className="w-5 h-5" />
                </button>

                {/* Header */}
                <div className="px-6 pt-6 pb-2 text-center">
                    <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#8c1229]/20 border border-[#8c1229]/30 mb-4">
                        <Sparkles className="w-6 h-6 text-[#ff3b5c]/70" />
                    </div>
                    <h2
                        className="text-[22px] font-semibold text-white/95 tracking-tight"
                    >
                        {customTitle || "Ops... Acabou seus créditos"}
                    </h2>
                    <p className="text-sm text-white/35 mt-2 font-light">
                        {customSubtitle || "Escolha um plano para continuar via PIX"}
                    </p>
                </div>

                {/* Plans */}
                <div className="px-6 py-5 flex flex-col gap-3">
                    {popupItems.map((item) => {
                        const planId = item.planId;
                        const plan = PLANS[planId];
                        const meta = planMeta[planId];
                        if (!plan || !meta) return null;

                        return (
                            <button
                                key={planId}
                                type="button"
                                onClick={() => {
                                    if (item.onClick) {
                                        item.onClick();
                                        return;
                                    }
                                    onSelectPlan(planId);
                                }}
                                className={`relative w-full flex items-center gap-4 px-5 py-4 rounded-xl border transition-all duration-200 group text-left
                  ${meta.highlight
                                        ? "bg-gradient-to-r from-[#8c1229]/20 to-[#520a17]/10 border-[#8c1229]/40 hover:border-[#ff3b5c]/50 hover:from-[#8c1229]/25 hover:to-[#520a17]/15"
                                        : "bg-white/[0.02] border-white/[0.08] hover:border-white/[0.15] hover:bg-white/[0.04]"
                                    }`}
                            >
                                <div
                                    className={`flex items-center justify-center w-10 h-10 rounded-lg shrink-0
                    ${meta.highlight
                                            ? "bg-[#8c1229]/30 text-[#ff3b5c]/80"
                                            : "bg-white/[0.05] text-white/40"
                                        }`}
                                >
                                    {meta.icon}
                                </div>

                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                        <span
                                            className={`text-[15px] font-medium ${meta.highlight ? "text-white/95" : "text-white/80"
                                                }`}
                                        >
                                            {item.title || plan.title}
                                        </span>
                                        {meta.tooltip && (
                                            <div className="relative">
                                                <Info
                                                    className="w-3.5 h-3.5 text-white/25 cursor-help"
                                                    onMouseEnter={() => setHoveredTooltip(planId)}
                                                    onMouseLeave={() => setHoveredTooltip(null)}
                                                />
                                                {hoveredTooltip === planId && (
                                                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-60 p-3 bg-[#1a0a10] border border-[#8c1229]/30 rounded-lg text-xs text-white/60 font-light leading-relaxed shadow-xl z-10 pointer-events-none">
                                                        {meta.tooltip}
                                                        <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-px w-2 h-2 rotate-45 bg-[#1a0a10] border-r border-b border-[#8c1229]/30" />
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                    {item.subtitle && (
                                        <p className="text-[12px] text-white/40 mt-0.5 tracking-wide">
                                            {item.subtitle}
                                        </p>
                                    )}
                                </div>

                                <span
                                    className={`text-[15px] font-semibold shrink-0 ${meta.highlight ? "text-[#ff3b5c]" : "text-white/60"
                                        }`}
                                >
                                    {item.price || plan.price}
                                </span>
                            </button>
                        );
                    })}
                </div>

                {/* Footer */}
                <div className="px-6 pb-6 text-center">
                    <p className="text-[11px] text-white/20 font-light tracking-wide">
                        * Compra 100% sigilosa, pago via PIX · Aprovação instantânea
                    </p>
                </div>
            </div>
        </div>
    );
}
