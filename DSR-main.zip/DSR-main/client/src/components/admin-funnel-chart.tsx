import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import {
  ArrowDownRight,
  CircleHelp,
  CreditCard,
  GitBranch,
  TrendingUp,
} from "lucide-react";

// ── Types ────────────────────────────────────────────────────────────
export type JourneyMapNode = {
  id: string;
  label: string;
  position: { x: number; y: number };
  total: number;
  conversionVsPrevious: number;
  conversionVsTop: number;
  lowConversion: boolean;
};

export type JourneyMapEdge = {
  id: string;
  source: string;
  target: string;
  total: number;
  conversionVsSource: number;
};

export type FunnelStepData = {
  id: string;
  label: string;
  total: number;
  conversionVsPrevious: number;
  conversionVsTop: number;
};

type JourneyPixGroup = {
  label: string;
  parentNode: string;
  pixGenerated: number;
  pixPaid: number;
  pixConversionRate: number;
};

type AdminFunnelChartProps = {
  pixByPage: JourneyPixGroup[];
  funnelSteps?: FunnelStepData[];
};

const numberFormatter = new Intl.NumberFormat("pt-BR");

function formatNumber(value: number) {
  return numberFormatter.format(value);
}

// ── Step color helpers ──────────────────────────────────────────────
function getStepColor(conversionVsTop: number, idx: number): string {
  if (idx === 0) return "from-white/[0.24] to-white/[0.12]";
  const ratio = conversionVsTop / 100;
  if (ratio >= 0.5) return "from-emerald-400/[0.45] to-emerald-500/[0.18]";
  if (ratio >= 0.2) return "from-amber-400/[0.45] to-amber-500/[0.18]";
  if (ratio >= 0.05) return "from-orange-400/[0.45] to-orange-500/[0.18]";
  return "from-rose-400/[0.45] to-rose-500/[0.18]";
}

function getConversionBadgeClassName(percent: number): string {
  if (percent > 100) return "border-sky-500/[0.28] bg-sky-500/10 text-sky-100";
  if (percent >= 70) return "border-emerald-500/[0.24] bg-emerald-500/10 text-emerald-100";
  if (percent >= 40) return "border-amber-500/[0.24] bg-amber-500/10 text-amber-100";
  if (percent >= 15) return "border-orange-500/[0.24] bg-orange-500/10 text-orange-100";
  return "border-rose-500/[0.24] bg-rose-500/10 text-rose-100";
}

function getPixRateClassName(percent: number) {
  if (percent >= 50) return "text-emerald-200";
  if (percent >= 20) return "text-amber-200";
  if (percent > 0) return "text-orange-200";
  return "text-white/[0.32]";
}

const STEP_HELP_TEXT: Record<string, { title: string; description: string }> = {
  visitors: {
    title: "Visitantes",
    description: "Sessões que entraram na landing inicial (/), marcando o topo do funil.",
  },
  upload: {
    title: "Upload de foto",
    description: "Sessões que enviaram pelo menos uma foto na landing.",
  },
  generated: {
    title: "Foto gerada vista",
    description: "Sessões que visualizaram a foto já processada/gerada após o upload.",
  },
  offer: {
    title: "Oferta visualizada",
    description: "Sessões que chegaram na etapa de oferta exibida depois da foto gerada.",
  },
  offer_responded: {
    title: "Respondeu oferta",
    description: "Sessões que interagiram com a oferta (resposta/ação no card de oferta).",
  },
  pix_generated: {
    title: "PIX gerado",
    description: "Sessões que geraram cobrança PIX em qualquer origem.",
  },
  pix_paid: {
    title: "PIX pago",
    description: "Sessões com confirmação de pagamento PIX concluído.",
  },
};

function getStepHelp(step: FunnelStepData) {
  return STEP_HELP_TEXT[step.id] ?? {
    title: step.label,
    description: "Sessões que atingiram esta etapa do funil.",
  };
}

function FunnelStepBar({ step, idx, maxTotal }: { step: FunnelStepData; idx: number; maxTotal: number }) {
  const widthPercent = maxTotal > 0 ? Math.max(5, (step.total / maxTotal) * 100) : 5;
  const gradientClass = getStepColor(step.conversionVsTop, idx);
  const stepHelp = getStepHelp(step);
  const hasTemporalAnomaly = idx > 0 && step.conversionVsPrevious > 100;
  const dropPercent = idx > 0 ? Math.max(0, 100 - step.conversionVsPrevious) : 0;

  return (
    <div className="group rounded-md border border-white/[0.07] bg-white/[0.025] p-3 transition-colors hover:border-white/[0.12] hover:bg-white/[0.04]">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md border border-white/10 bg-black/25 text-[11px] font-semibold text-white/70 tabular-nums">
              {idx + 1}
            </span>
            <p className="truncate text-sm font-semibold text-white">{step.label}</p>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  className="inline-flex h-6 w-6 items-center justify-center rounded-md text-white/[0.42] transition-colors hover:bg-white/[0.06] hover:text-white"
                  aria-label={`Ajuda da etapa ${step.label}`}
                >
                  <CircleHelp className="h-3.5 w-3.5" />
                </button>
              </TooltipTrigger>
              <TooltipContent className="max-w-[280px] border-white/15 bg-[#0d0a0c] text-white">
                <div className="space-y-1 text-xs">
                  <p className="font-semibold">{stepHelp.title}</p>
                  <p className="text-white/75">{stepHelp.description}</p>
                </div>
              </TooltipContent>
            </Tooltip>
          </div>
          {idx > 0 ? (
            <p className={cn(
              "mt-1 flex items-center gap-1.5 text-xs",
              hasTemporalAnomaly ? "text-sky-100/70" : "text-white/[0.42]",
            )}>
              {hasTemporalAnomaly ? <TrendingUp className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
              {hasTemporalAnomaly
                ? `${(step.conversionVsPrevious - 100).toFixed(1)}% acima da etapa anterior`
                : `${dropPercent.toFixed(1)}% de perda desde a etapa anterior`}
            </p>
          ) : (
            <p className="mt-1 text-xs text-white/[0.42]">Ponto de entrada do funil selecionado</p>
          )}
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <span className="text-lg font-semibold text-white tabular-nums">{formatNumber(step.total)}</span>
          {idx > 0 ? (
            <span className={cn("rounded-md border px-2 py-1 text-xs font-semibold tabular-nums", getConversionBadgeClassName(step.conversionVsPrevious))}>
              {step.conversionVsPrevious.toFixed(1)}%
            </span>
          ) : null}
        </div>
      </div>

      <Tooltip>
        <TooltipTrigger asChild>
          <div className="mt-3">
            <div className="relative h-8 overflow-hidden rounded-md border border-white/[0.06] bg-black/30">
              <div
                className={cn(
                  "absolute inset-y-0 left-0 rounded-md bg-gradient-to-r transition-all duration-700 ease-out group-hover:brightness-110",
                  gradientClass,
                )}
                style={{ width: `${widthPercent}%` }}
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                <span className="text-[11px] font-medium text-white/[0.38] tabular-nums">
                  {step.conversionVsTop.toFixed(1)}% do topo
                </span>
              </div>
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent className="max-w-[240px] border-white/15 bg-[#0d0a0c] text-white">
          <div className="space-y-1 text-xs">
            <p className="font-semibold">{step.label}</p>
            <p>Total: {formatNumber(step.total)} sessões</p>
            {idx > 0 ? <p>vs etapa anterior: {step.conversionVsPrevious.toFixed(1)}%</p> : null}
            <p>vs topo do funil: {step.conversionVsTop.toFixed(1)}%</p>
          </div>
        </TooltipContent>
      </Tooltip>
    </div>
  );
}

function PixOriginCard({ item }: { item: JourneyPixGroup }) {
  const hasActivity = item.pixGenerated > 0 || item.pixPaid > 0;
  const paidShare = item.pixGenerated > 0 ? Math.min(100, item.pixConversionRate) : 0;

  return (
    <div
      className={cn(
        "rounded-md border p-3 transition-colors",
        hasActivity
          ? "border-white/10 bg-white/[0.025] hover:bg-white/[0.04]"
          : "border-white/[0.06] bg-white/[0.012] opacity-60",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-sm font-medium text-white">{item.label}</p>
          <p className="mt-1 text-xs text-white/[0.42]">{item.parentNode || "Origem do PIX"}</p>
        </div>
        <span className={cn("text-sm font-semibold tabular-nums", getPixRateClassName(item.pixConversionRate))}>
          {item.pixConversionRate.toFixed(1)}%
        </span>
      </div>

      <div className="mt-3 flex items-center justify-between gap-3 text-xs text-white/[0.52]">
        <span>
          <span className="font-semibold text-emerald-200">{formatNumber(item.pixPaid)}</span> pagos
        </span>
        <span>
          <span className="font-semibold text-amber-200">{formatNumber(item.pixGenerated)}</span> gerados
        </span>
      </div>

      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-black/[0.35]">
        <div
          className="h-full rounded-full bg-emerald-400/70 transition-all duration-500"
          style={{ width: `${paidShare}%` }}
        />
      </div>
    </div>
  );
}

export function AdminFunnelChart({
  pixByPage,
  funnelSteps = [],
}: AdminFunnelChartProps) {
  const hasData = funnelSteps.some((step) => step.total > 0) || pixByPage.some((item) => item.pixGenerated > 0 || item.pixPaid > 0);
  const maxTotal = funnelSteps.reduce((max, step) => Math.max(max, step.total), 0);
  const totalPixGenerated = pixByPage.reduce((sum, item) => sum + item.pixGenerated, 0);
  const totalPixPaid = pixByPage.reduce((sum, item) => sum + item.pixPaid, 0);
  const pixRate = totalPixGenerated > 0 ? (totalPixPaid / totalPixGenerated) * 100 : 0;

  if (!hasData) {
    return (
      <div className="rounded-md border border-white/10 bg-[#0d0a0c] p-6 text-sm text-white/[0.55]">
        Nenhum dado no período selecionado.
      </div>
    );
  }

  return (
    <TooltipProvider delayDuration={120}>
      <div className="space-y-4">
        <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-md border border-[#8c1229]/30 bg-[#8c1229]/[0.14] text-[#ffdbe2]">
                  <GitBranch className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-xs font-medium uppercase text-white/[0.42]">Conversão sequencial</p>
                  <h2 className="text-lg font-semibold tracking-normal text-white">Funil principal</h2>
                </div>
              </div>
              <p className="mt-2 max-w-2xl text-sm text-white/[0.48]">
                Volume por etapa, retenção em relação ao passo anterior e conversão acumulada desde o topo.
              </p>
            </div>
            <div className="rounded-md border border-white/10 bg-black/25 px-3 py-2">
              <p className="text-[11px] font-medium uppercase text-white/[0.38]">Maior volume</p>
              <p className="mt-0.5 text-sm font-semibold text-white tabular-nums">{formatNumber(maxTotal)} sessões</p>
            </div>
          </div>

          <div className="space-y-2.5">
            {funnelSteps.map((step, idx) => (
              <FunnelStepBar key={step.id} step={step} idx={idx} maxTotal={maxTotal} />
            ))}
          </div>
        </section>

        <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-md border border-emerald-500/[0.24] bg-emerald-500/10 text-emerald-100">
                  <CreditCard className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-xs font-medium uppercase text-white/[0.42]">Origem de pagamento</p>
                  <h2 className="text-lg font-semibold tracking-normal text-white">PIX por página</h2>
                </div>
              </div>
              <p className="mt-2 max-w-2xl text-sm text-white/[0.48]">
                Performance das telas que geraram cobrança, com pagos, criados e taxa de confirmação.
              </p>
            </div>
            <div className="rounded-md border border-white/10 bg-black/25 px-3 py-2">
              <p className="text-[11px] font-medium uppercase text-white/[0.38]">Taxa consolidada</p>
              <p className="mt-0.5 flex items-center gap-1.5 text-sm font-semibold text-white tabular-nums">
                <TrendingUp className="h-3.5 w-3.5 text-emerald-200" />
                {pixRate.toFixed(1)}%
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-2.5 md:grid-cols-2 2xl:grid-cols-3">
            {pixByPage.map((item) => (
              <PixOriginCard key={item.label} item={item} />
            ))}
          </div>
        </section>
      </div>
    </TooltipProvider>
  );
}
