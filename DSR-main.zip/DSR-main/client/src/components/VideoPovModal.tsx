import { useEffect, useMemo, useRef, useState } from "react";
import { X, Clapperboard, Check } from "lucide-react";
import { useBodyScrollLock } from "@/hooks/use-body-scroll-lock";

type Option = { value: string; label: string };

export interface VideoPovPreferences {
  position: string;
  hole: string;
  sexType: string;
  speechType: string;
}

interface VideoPovModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (preferences: VideoPovPreferences) => Promise<void>;
  isSubmitting: boolean;
}

const POSITION_OPTIONS: Option[] = [
  { value: "de_quatro", label: "De quatro" },
  { value: "papai_mamae", label: "Papai mamãe" },
];

const HOLE_OPTIONS: Option[] = [
  { value: "buceta", label: "Buceta" },
  { value: "cuzinho", label: "Cuzinho" },
];

const SEX_TYPE_OPTIONS: Option[] = [
  { value: "amorzinho", label: "Amorzinho" },
  { value: "hard_fuck", label: "Hard fuck" },
];

const SPEECH_TYPE_OPTIONS: Option[] = [
  { value: "carinhosa", label: "Carinhosa" },
  { value: "ninfomaniaca", label: "Ninfomaníaca" },
  { value: "sexo_agressivo", label: "Sexo agressivo" },
];

export default function VideoPovModal({
  open,
  onClose,
  onSubmit,
  isSubmitting,
}: VideoPovModalProps) {
  useBodyScrollLock(open);
  const headerVideoSrc = "/api/card-image/pov_modal_header?v=pov-modal-header-20260504";
  const headerPosterSrc = "/api/card-image/pov_modal_header/poster?v=pov-modal-header-20260504";
  const [position, setPosition] = useState<string>("");
  const [hole, setHole] = useState<string>("");
  const [sexType, setSexType] = useState<string>("");
  const [speechType, setSpeechType] = useState<string>("");
  const submitStartedRef = useRef(false);

  useEffect(() => {
    if (!open) return;
    setPosition("");
    setHole("");
    setSexType("");
    setSpeechType("");
    submitStartedRef.current = false;
  }, [open]);

  useEffect(() => {
    if (!isSubmitting) submitStartedRef.current = false;
  }, [isSubmitting]);

  const canSubmit = useMemo(() => {
    return Boolean(position && hole && sexType && speechType) && !isSubmitting;
  }, [position, hole, sexType, speechType, isSubmitting]);

  const handleSubmit = async () => {
    if (!canSubmit || submitStartedRef.current) return;
    submitStartedRef.current = true;
    try {
      await onSubmit({ position, hole, sexType, speechType });
    } finally {
      submitStartedRef.current = false;
    }
  };

  const renderOptionGroup = (
    title: string,
    options: Option[],
    selectedValue: string,
    onSelect: (value: string) => void,
  ) => (
    <div className="flex flex-col gap-2.5">
      <h4 className="text-sm font-semibold tracking-wide text-white/80 uppercase">{title}</h4>
      <div className="grid grid-cols-2 gap-2.5">
        {options.map((option) => {
          const selected = selectedValue === option.value;
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => onSelect(option.value)}
              className={`relative min-h-[52px] rounded-xl border px-3 py-3 text-left transition-all duration-200
                ${selected
                  ? "border-[#ff3b5c]/60 bg-[#8c1229]/20 text-white shadow-[0_0_18px_rgba(140,18,41,0.25)]"
                  : "border-white/[0.08] bg-white/[0.02] text-white/75 hover:border-[#8c1229]/45 hover:bg-[#8c1229]/[0.06]"
                }`}
            >
              <span className="block text-[13px] font-medium leading-snug">{option.label}</span>
              {selected && (
                <span className="absolute right-2.5 top-2.5 text-[#ff3b5c]">
                  <Check className="h-3.5 w-3.5" />
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center sm:px-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={isSubmitting ? undefined : onClose} />

      <div
        className="relative w-full sm:max-w-md bg-gradient-to-b from-[#160b12] via-[#110609] to-[#0a0204]
        border-t sm:border border-[#8c1229]/25 rounded-t-3xl sm:rounded-2xl
        shadow-[0_-20px_80px_rgba(140,18,41,0.3)] sm:shadow-[0_0_80px_rgba(140,18,41,0.2)]
        max-h-[92svh] overflow-y-auto animate-in slide-in-from-bottom sm:fade-in sm:zoom-in-95 duration-300"
        style={{
          fontFamily: "'Plus Jakarta Sans', sans-serif",
          overscrollBehavior: "contain",
          WebkitOverflowScrolling: "touch",
        }}
      >
        <div className="sm:hidden flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-white/15" />
        </div>

        <div className="sticky top-0 z-20 px-4 sm:px-5 pt-2 sm:pt-4 pb-3 bg-gradient-to-b from-[#110609] via-[#110609]/98 to-[#110609]/65 backdrop-blur-sm">
          <div className="relative overflow-hidden rounded-2xl border border-[#8c1229]/25 bg-black/40 shadow-[0_16px_50px_rgba(0,0,0,0.35)]">
            <div className="aspect-video relative">
              <video
                src={headerVideoSrc}
                poster={headerPosterSrc}
                className="absolute inset-0 w-full h-full object-cover"
                autoPlay
                muted
                loop
                playsInline
                preload="metadata"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/15 to-transparent pointer-events-none" />
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          disabled={isSubmitting}
          className="absolute top-4 right-4 z-30 p-1.5 text-white/30 hover:text-white/70 transition-colors rounded-full hover:bg-white/5 disabled:opacity-30"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="px-6 pt-2 pb-5 text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#8c1229]/15 border border-[#8c1229]/25 mb-3">
            <Clapperboard className="w-5 h-5 text-[#ff3b5c]/75" />
          </div>
          <h3 className="text-[20px] font-semibold text-white/95 tracking-tight">Vídeo POV personalizado</h3>
          <p className="text-sm text-white/35 mt-2 font-light">
            Escolha suas preferências para gerar seu vídeo com o máximo de realismo.
          </p>
        </div>

        <div className="mx-6 h-px bg-gradient-to-r from-transparent via-[#8c1229]/20 to-transparent" />

        <div className="px-6 py-5 flex flex-col gap-5">
          {renderOptionGroup("Posição", POSITION_OPTIONS, position, setPosition)}
          {renderOptionGroup("Buraco", HOLE_OPTIONS, hole, setHole)}
          {renderOptionGroup("Tipo de foda", SEX_TYPE_OPTIONS, sexType, setSexType)}
          {renderOptionGroup("Tipo de fala e gemidos", SPEECH_TYPE_OPTIONS, speechType, setSpeechType)}
        </div>

        <div className="sticky bottom-0 left-0 right-0 z-10 bg-[#0a0204] px-6 pt-3 pb-6">
          <div className="pointer-events-none absolute -top-6 left-0 right-0 h-6 bg-gradient-to-t from-[#0a0204] to-transparent" />
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!canSubmit}
            className={`relative w-full py-4 rounded-xl text-[15px] font-semibold tracking-wide transition-all duration-300
              ${canSubmit
                ? "bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white hover:from-[#a61530] hover:to-[#6b0d1e] shadow-[0_0_24px_rgba(140,18,41,0.28)] border border-[#ff3b5c]/20"
                : "bg-[#1a0a10] text-white/35 border border-white/[0.08] cursor-not-allowed"
              }`}
          >
            {isSubmitting ? "Salvando preferências..." : "Gerar"}
          </button>
          <p className="text-[10px] text-white/20 font-light tracking-wide text-center mt-3">
            Pagamento seguro via PIX e aprovação instantânea
          </p>
        </div>
      </div>
    </div>
  );
}
