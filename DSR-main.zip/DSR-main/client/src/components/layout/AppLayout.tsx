import { useLocation } from "wouter";
import { Grid, Settings, LayoutDashboard, Plus, LogOut } from "lucide-react";
import {
    Sidebar,
    SidebarContent,
    SidebarGroup,
    SidebarGroupContent,
    SidebarGroupLabel,
    SidebarHeader,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem,
    SidebarProvider,
    SidebarRail,
} from "@/components/ui/sidebar";
import { useState, useEffect, useCallback } from "react";
import CreditsPopup from "../CreditsPopup";
import PixQrModal from "../PixQrModal";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { CRITICAL_QUERY_OPTIONS } from "@/lib/queryClient";

interface AppLayoutProps {
    children: React.ReactNode;
    user: { id: string; username: string; email: string | null; hasPaidPix: boolean };
}

const navItems = [
    { label: "Painel", href: "/painel", icon: LayoutDashboard },
    { label: "Galeria", href: "/galeria", icon: Grid },
    { label: "Configurações", href: "/configuracoes", icon: Settings },
];

export function AppSidebar({ user }: { user: AppLayoutProps["user"] }) {
    const [location, setLocation] = useLocation();
    const [creditsOpen, setCreditsOpen] = useState(false);
    const [pixModalOpen, setPixModalOpen] = useState(false);
    const [selectedPlanId, setSelectedPlanId] = useState("");

    const { data: credits } = useQuery<{ balance: number }>({
        queryKey: ["/api/credits"],
        ...CRITICAL_QUERY_OPTIONS,
    });

    const queryClient = useQueryClient();
    const { toast } = useToast();
    const { subscribe, isConnected } = useWebSocket();

    // Relay pix_paid WebSocket events to a window CustomEvent so PixQrModal
    // (and any other listener) can react regardless of the current route.
    useEffect(() => {
        const unsub = subscribe("pix_paid", (data) => {
            window.dispatchEvent(new CustomEvent("pix_paid", { detail: data }));
        });
        return unsub;
    }, [subscribe]);

    useEffect(() => {
        if (!isConnected) return;
        queryClient.invalidateQueries({ queryKey: ["/api/credits"] });
        queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
    }, [isConnected, queryClient]);

    const handleSelectPlan = useCallback((planId: string) => {
        setSelectedPlanId(planId);
        setCreditsOpen(false);
        setPixModalOpen(true);
    }, []);

    const handlePixPaymentSuccess = useCallback((paymentData?: any) => {
        // Optimistic update: show new balance immediately
        const current = queryClient.getQueryData<{ balance: number }>(["/api/credits"]);
        const newBalance = (current?.balance ?? 0) + (paymentData?.creditAmount ?? 0);
        queryClient.setQueryData(["/api/credits"], { balance: newBalance });
        // Then reconcile with server
        queryClient.invalidateQueries({ queryKey: ["/api/credits"] });
        queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
        toast({
            title: "Pagamento confirmado!",
            description: "Seus créditos foram adicionados.",
        });
    }, [queryClient, toast]);

    const handleLogout = async () => {
        await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
        window.location.href = "/login";
    };

    return (
        <>
            <Sidebar>
                <SidebarHeader className="p-4 flex items-center justify-center border-b border-white/5">
                    <img
                        src="/uploads/logo.webp"
                        alt="DesireAI"
                        width={599}
                        height={171}
                        decoding="async"
                        fetchPriority="high"
                        className="h-8 object-contain"
                    />
                </SidebarHeader>

                <SidebarContent>
                    <SidebarGroup>
                        <SidebarGroupLabel>Menu Principal</SidebarGroupLabel>
                        <SidebarGroupContent>
                            <SidebarMenu>
                                {navItems.map((item) => (
                                    <SidebarMenuItem key={item.label}>
                                        <SidebarMenuButton
                                            isActive={location === item.href}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                setLocation(item.href);
                                            }}
                                            tooltip={item.label}
                                        >
                                            <item.icon />
                                            <span>{item.label}</span>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                ))}
                            </SidebarMenu>
                        </SidebarGroupContent>
                    </SidebarGroup>
                </SidebarContent>

                <div className="mt-auto border-t border-white/5">
                    {/* Credits */}
                    <div className="p-4 flex items-center justify-between bg-black/20">
                        <div className="flex flex-col">
                            <span className="text-xs text-white/50 uppercase font-semibold tracking-wider">Saldo</span>
                            <span className="text-xl font-bold text-white tracking-tight">
                                {credits?.balance ?? 0} <span className="text-sm font-medium text-white/70">créditos</span>
                            </span>
                        </div>
                        <button
                            onClick={() => setCreditsOpen(true)}
                            className="h-10 w-10 shrink-0 flex items-center justify-center rounded-full bg-[#ff3b5c] text-white hover:bg-[#ff3b5c]/90 transition-colors shadow-lg shadow-[#ff3b5c]/20"
                        >
                            <Plus className="h-5 w-5" />
                        </button>
                    </div>

                    {/* User Info + Logout */}
                    <div className="px-4 py-3 flex items-center justify-between border-t border-white/5 bg-black/10">
                        <span className="text-[13px] text-white/50 truncate max-w-[140px]">{user.username}</span>
                        <button
                            onClick={handleLogout}
                            className="text-white/30 hover:text-[#ff3b5c] transition-colors"
                            title="Sair"
                        >
                            <LogOut className="w-4 h-4" />
                        </button>
                    </div>
                </div>

                <SidebarRail />
            </Sidebar>

            <CreditsPopup
                open={creditsOpen}
                onClose={() => setCreditsOpen(false)}
                onSelectPlan={handleSelectPlan}
                customTitle="Quantos créditos você quer comprar?"
            />

            <PixQrModal
                open={pixModalOpen}
                onClose={() => setPixModalOpen(false)}
                planId={selectedPlanId}
                onPaymentSuccess={handlePixPaymentSuccess}
            />
        </>
    );
}

export default function AppLayout({ children, user }: AppLayoutProps) {
    return (
        <SidebarProvider>
            <div className="flex h-screen w-full bg-[#0a0a0a] overflow-hidden text-white">
                <AppSidebar user={user} />
                <main className="flex-1 flex flex-col min-h-0 w-full relative overflow-y-auto">
                    {children}
                </main>
            </div>
        </SidebarProvider>
    );
}
