import { Route, Switch, Redirect, useLocation } from "wouter";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Suspense, lazy, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, setGlobalToast, setGlobalAuthenticated, getQueryFn, CRITICAL_QUERY_OPTIONS } from "./lib/queryClient";
import { persistUtmsFromCurrentUrl } from "./lib/utm";
import { identify as posthogIdentify } from "./lib/posthog";
import DesireLandingPage from "@/pages/desire-landing";
import { ClarityScripts } from "@/components/ClarityScripts";
import { AbTestRoute } from "@/components/AbTestRoute";

const LazyToaster = lazy(() => import("@/components/ui/toaster").then((mod) => ({ default: mod.Toaster })));
const AppLayout = lazy(() => import("@/components/layout/AppLayout"));
const LoginPage = lazy(() => import("@/pages/login"));
const Dashboard = lazy(() => import("@/pages/dashboard"));
const Gallery = lazy(() => import("@/pages/gallery"));
const AppSettings = lazy(() => import("@/pages/settings"));
const VideoPovLoadingPage = lazy(() => import("@/pages/video-pov-loading"));
const PackPhotosLoadingPage = lazy(() => import("@/pages/pack-photos-loading"));
const AdminLoginPage = lazy(() => import("@/pages/admin-login"));
const AdminDashboardPage = lazy(() => import("@/pages/admin-dashboard"));
const AdminJourneyPage = lazy(() => import("@/pages/admin-journey"));
const AdminAbTestsListPage = lazy(() => import("@/pages/admin-ab-tests"));
const AdminAbTestDetailPage = lazy(() => import("@/pages/admin-ab-test-detail"));
const AdminPaymentGatewaysPage = lazy(() => import("@/pages/admin-payment-gateways"));
const CallerLoginPage = lazy(() => import("@/pages/caller-login"));
const CallerDashboardPage = lazy(() => import("@/pages/caller-dashboard"));
const UpsellInstaProPage = lazy(() => import("@/pages/upsell-instapro"));
const UpsellInstaPro2Page = lazy(() => import("@/pages/upsell-instapro-2"));
const PixTesterPage = lazy(() => import("@/pages/pix-tester"));

const preloadDashboard = () => import("@/pages/dashboard");
const preloadGallery = () => import("@/pages/gallery");
const preloadSettings = () => import("@/pages/settings");
const preloadLogin = () => import("@/pages/login");
const preloadVideoPovLoading = () => import("@/pages/video-pov-loading");
const preloadPackPhotosLoading = () => import("@/pages/pack-photos-loading");
const preloadAdminLogin = () => import("@/pages/admin-login");
const preloadAdminDashboard = () => import("@/pages/admin-dashboard");
const preloadAdminPaymentGateways = () => import("@/pages/admin-payment-gateways");
const preloadCallerLogin = () => import("@/pages/caller-login");
const preloadCallerDashboard = () => import("@/pages/caller-dashboard");
const preloadUpsellInstaPro = () => import("@/pages/upsell-instapro");

function scheduleBackgroundPreload(preloadFn: () => Promise<unknown>, delayMs = 0) {
  if (typeof window === "undefined") return;
  const runner = () => { void preloadFn(); };
  const idle = (window as any).requestIdleCallback as ((cb: () => void, opts?: { timeout: number }) => number) | undefined;
  if (idle) {
    idle(runner, { timeout: 2500 + delayMs });
    return;
  }
  window.setTimeout(runner, Math.max(300, delayMs));
}

function RouteLoader({ label = "Traduzindo para o seu idioma" }: { label?: string }) {
  return (
    <div className="flex h-screen flex-col items-center justify-center bg-[#0a0a0a]">
      <div className="w-6 h-6 border-2 border-[#8c1229] border-t-transparent rounded-full animate-spin" />
      <p className="mt-3 text-sm text-white/70">{label}</p>
    </div>
  );
}

function IdleToaster() {
  const [shouldRender, setShouldRender] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const showToaster = () => setShouldRender(true);
    const idle = (window as any).requestIdleCallback as
      | ((cb: () => void, opts?: { timeout: number }) => number)
      | undefined;

    if (idle) {
      const idleId = idle(showToaster, { timeout: 2000 });
      return () => {
        (window as any).cancelIdleCallback?.(idleId);
      };
    }

    const timeoutId = window.setTimeout(showToaster, 800);
    return () => window.clearTimeout(timeoutId);
  }, []);

  if (!shouldRender) return null;

  return (
    <Suspense fallback={null}>
      <LazyToaster />
    </Suspense>
  );
}

/** Hook to fetch current user. Returns null if not authenticated. */
function useUser() {
  const query = useQuery<{ id: string; username: string; email: string | null; hasPaidPix: boolean } | null>({
    queryKey: ["/api/user/me"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    retry: false,
    ...CRITICAL_QUERY_OPTIONS,
  });
  useEffect(() => {
    if (query.data?.id) {
      void posthogIdentify(String(query.data.id), {
        username: query.data.username,
        has_paid_pix: query.data.hasPaidPix,
      });
    }
  }, [query.data?.id, query.data?.username, query.data?.hasPaidPix]);
  return query;
}

/** Wrapper that requires auth + hasPaidPix. Redirects to /login if unauthenticated. */
function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { data: user, isLoading, isError, refetch } = useUser();
  const [loadingStalled, setLoadingStalled] = useState(false);

  useEffect(() => {
    setLoadingStalled(false);
    if (!isLoading) return;
    const timeoutId = setTimeout(() => setLoadingStalled(true), 15000);
    return () => clearTimeout(timeoutId);
  }, [isLoading]);

  if (isLoading && !loadingStalled) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-[#0a0a0a]">
        <div className="w-6 h-6 border-2 border-[#8c1229] border-t-transparent rounded-full animate-spin" />
        <p className="mt-3 text-sm text-white/70">Traduzindo para o seu idioma</p>
      </div>
    );
  }

  // Request failed (including timeout) -> show retry instead of infinite loading/redirect loop
  if (isError) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#0a0a0a] px-6">
        <div className="max-w-sm rounded-2xl border border-white/10 bg-black/40 p-6 text-center">
          <p className="text-sm text-white/80">Não foi possível validar sua sessão agora.</p>
          <button
            onClick={() => refetch()}
            className="mt-4 rounded-lg bg-[#8c1229] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#a61530]"
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  if (loadingStalled) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#0a0a0a] px-6">
        <div className="max-w-sm rounded-2xl border border-white/10 bg-black/40 p-6 text-center">
          <p className="text-sm text-white/80">A validação demorou mais do que o esperado.</p>
          <button
            onClick={() => refetch()}
            className="mt-4 rounded-lg bg-[#8c1229] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#a61530]"
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  // Not authenticated → login
  if (!user) {
    return <Redirect to="/login" />;
  }

  // Authenticated but hasn't paid PIX → redirect to landing
  if (!user.hasPaidPix) {
    return <Redirect to="/" />;
  }

  return (
    <AppLayout user={user}>
      <Component />
    </AppLayout>
  );
}

function useAdmin() {
  return useQuery<{ authenticated: boolean; username: string } | null>({
    queryKey: ["/api/admin/me"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    retry: false,
    staleTime: 0,
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });
}

function AdminProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { data, isLoading } = useAdmin();

  if (isLoading) return <RouteLoader />;
  if (!data?.authenticated) return <Redirect to="/admin/login" />;
  return <Component />;
}

function useCaller() {
  return useQuery<{ authenticated: boolean; username: string } | null>({
    queryKey: ["/api/caller/me"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    retry: false,
    staleTime: 0,
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });
}

function CallerProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { data, isLoading } = useCaller();

  if (isLoading) return <RouteLoader />;
  if (!data?.authenticated) return <Redirect to="/caller-92192/login" />;
  return <Component />;
}

function AppRoutes() {
  const { toast } = useToast();
  const [location] = useLocation();

  useEffect(() => {
    setGlobalToast(toast);
    setGlobalAuthenticated(true);
  }, [toast]);

  useEffect(() => {
    const revalidateCritical = () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/credits"] });
    };

    const onVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        revalidateCritical();
      }
    };

    window.addEventListener("online", revalidateCritical);
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      window.removeEventListener("online", revalidateCritical);
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, []);

  useEffect(() => {
    if (location === "/") return;

    if (location === "/video-pov-loading" || location === "/pack-photos-loading") {
      scheduleBackgroundPreload(preloadUpsellInstaPro, 1800);
      return;
    }

    if (location.startsWith("/admin")) {
      scheduleBackgroundPreload(preloadAdminLogin, 600);
      scheduleBackgroundPreload(preloadAdminDashboard, 1400);
      scheduleBackgroundPreload(preloadAdminPaymentGateways, 2200);
      return;
    }

    if (location.startsWith("/caller-92192")) {
      scheduleBackgroundPreload(preloadCallerLogin, 600);
      scheduleBackgroundPreload(preloadCallerDashboard, 1400);
      return;
    }

    if (location === "/painel" || location === "/galeria" || location === "/configuracoes") {
      scheduleBackgroundPreload(preloadDashboard, 600);
      scheduleBackgroundPreload(preloadGallery, 1200);
      scheduleBackgroundPreload(preloadSettings, 1800);
      scheduleBackgroundPreload(preloadUpsellInstaPro, 2400);
    }
  }, [location]);

  return (
    <Switch>
      <Route path="/login">
        <Suspense fallback={<RouteLoader />}>
          <LoginPage />
        </Suspense>
      </Route>
      <Route path="/painel">
        <Suspense fallback={<RouteLoader />}>
          <ProtectedRoute component={Dashboard} />
        </Suspense>
      </Route>
      <Route path="/galeria">
        <Suspense fallback={<RouteLoader />}>
          <ProtectedRoute component={Gallery} />
        </Suspense>
      </Route>
      <Route path="/configuracoes">
        <Suspense fallback={<RouteLoader />}>
          <ProtectedRoute component={AppSettings} />
        </Suspense>
      </Route>
      <Route path="/video-pov-loading">
        <Suspense fallback={<RouteLoader label="Gerando seu vídeo" />}>
          <VideoPovLoadingPage />
        </Suspense>
      </Route>
      <Route path="/pack-photos-loading">
        <Suspense fallback={<RouteLoader label="Gerando seu pack de imagens" />}>
          <PackPhotosLoadingPage />
        </Suspense>
      </Route>
      <Route path="/upsell/instapro-2">
        <Suspense fallback={<RouteLoader />}>
          <UpsellInstaPro2Page />
        </Suspense>
      </Route>
      <Route path="/upsell/instapro">
        <Suspense fallback={<RouteLoader />}>
          <UpsellInstaProPage />
        </Suspense>
      </Route>
      <Route path="/admin/login">
        <Suspense fallback={<RouteLoader />}>
          <AdminLoginPage />
        </Suspense>
      </Route>
      <Route path="/admin/journey">
        <Suspense fallback={<RouteLoader />}>
          <AdminProtectedRoute component={AdminJourneyPage} />
        </Suspense>
      </Route>
      <Route path="/admin/ab-tests/:id">
        <Suspense fallback={<RouteLoader />}>
          <AdminProtectedRoute component={AdminAbTestDetailPage} />
        </Suspense>
      </Route>
      <Route path="/admin/ab-tests">
        <Suspense fallback={<RouteLoader />}>
          <AdminProtectedRoute component={AdminAbTestsListPage} />
        </Suspense>
      </Route>
      <Route path="/admin/payment-gateways">
        <Suspense fallback={<RouteLoader />}>
          <AdminProtectedRoute component={AdminPaymentGatewaysPage} />
        </Suspense>
      </Route>
      <Route path="/admin">
        <Suspense fallback={<RouteLoader />}>
          <AdminProtectedRoute component={AdminDashboardPage} />
        </Suspense>
      </Route>
      <Route path="/oferta">
        <AbTestRoute testSlug="checkout-hero" />
      </Route>
      <Route path="/pix-tester999">
        <Suspense fallback={<RouteLoader label="Carregando PIX de teste" />}>
          <PixTesterPage />
        </Suspense>
      </Route>
      <Route path="/caller-92192/login">
        <Suspense fallback={<RouteLoader />}>
          <CallerLoginPage />
        </Suspense>
      </Route>
      <Route path="/caller-92192">
        <Suspense fallback={<RouteLoader />}>
          <CallerProtectedRoute component={CallerDashboardPage} />
        </Suspense>
      </Route>
      <Route path="/" component={DesireLandingPage} />
      <Route path="/:rest*">
        <Redirect to="/" />
      </Route>
    </Switch>
  );
}

function App() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    const persistCurrentUtms = () => {
      persistUtmsFromCurrentUrl();
    };

    persistCurrentUtms();

    const originalPushState = window.history.pushState.bind(window.history);
    const originalReplaceState = window.history.replaceState.bind(window.history);

    window.history.pushState = function (...args) {
      const result = originalPushState(...args);
      persistCurrentUtms();
      return result;
    };

    window.history.replaceState = function (...args) {
      const result = originalReplaceState(...args);
      persistCurrentUtms();
      return result;
    };

    window.addEventListener("popstate", persistCurrentUtms);
    window.addEventListener("hashchange", persistCurrentUtms);

    return () => {
      window.history.pushState = originalPushState;
      window.history.replaceState = originalReplaceState;
      window.removeEventListener("popstate", persistCurrentUtms);
      window.removeEventListener("hashchange", persistCurrentUtms);
    };
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <ClarityScripts />
      <IdleToaster />
      <AppRoutes />
    </QueryClientProvider>
  );
}

export default App;
