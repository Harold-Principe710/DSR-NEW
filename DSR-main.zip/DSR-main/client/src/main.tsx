import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { bootPosthog } from "./lib/posthog";

createRoot(document.getElementById("root")!).render(<App />);
bootPosthog();
