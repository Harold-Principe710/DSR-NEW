import { useEffect } from "react";
import { trackFunnelEvent, type FunnelStep } from "@/lib/funnel";
import { getDateStampInAppTimeZone } from "@/lib/timezone";

// Fires a single funnel event when a post-paid app page mounts so the admin
// journey map can count app_dashboard / app_gallery / app_settings as real
// parent nodes (instead of relying on the liftParentFromPix workaround).
//
// step is "offer_viewed" because these pages display the unlimited upsell
// card; this avoids inflating pix_paid / pix_generated aggregates in
// LINEAR_FUNNEL while still wiring up the journey-map node count.
export function useFunnelPageView(node: string, eventName: string, step: FunnelStep = "offer_viewed") {
  useEffect(() => {
    trackFunnelEvent({
      step,
      eventName,
      journeyNode: node,
      idempotencyKey: `app_view:${node}:${getDateStampInAppTimeZone()}`,
    });
  }, [node, eventName, step]);
}
