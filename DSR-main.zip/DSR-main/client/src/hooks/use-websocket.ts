import { useEffect, useRef, useCallback, useState } from "react";

type MessageHandler = (data: any) => void;

interface WebSocketHook {
  isConnected: boolean;
  subscribe: (event: string, handler: MessageHandler) => () => void;
}

export function useWebSocket(options: { enabled?: boolean } = {}): WebSocketHook {
  const enabled = options.enabled ?? true;
  const wsRef = useRef<WebSocket | null>(null);
  const handlersRef = useRef<Map<string, Set<MessageHandler>>>(new Map());
  const [isConnected, setIsConnected] = useState(false);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const connectingRef = useRef(false);
  const manuallyClosedRef = useRef(false);
  const enabledRef = useRef(enabled);
  const connectRef = useRef<() => void>(() => {});

  const scheduleReconnect = useCallback((closeCode: number) => {
    if (!enabledRef.current) return;
    if (manuallyClosedRef.current) return;

    const isAuthRace = closeCode === 4001;
    const maxAttempts = isAuthRace ? 6 : 10;
    if (reconnectAttemptsRef.current >= maxAttempts) {
      console.warn(`WebSocket reconnect stopped after ${reconnectAttemptsRef.current} attempts (code=${closeCode})`);
      return;
    }

    reconnectAttemptsRef.current += 1;
    const attempt = reconnectAttemptsRef.current;
    const delayMs = isAuthRace
      ? Math.min(1000 + (attempt - 1) * 500, 3500)
      : Math.min(1500 * attempt, 10000);

    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }

    reconnectTimeoutRef.current = setTimeout(() => {
      connectRef.current();
    }, delayMs);
  }, []);

  const connect = useCallback(() => {
    if (!enabledRef.current || typeof window === "undefined") {
      return;
    }
    if (connectingRef.current || wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    connectingRef.current = true;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      connectingRef.current = false;
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);

        if (message.type === "auth_success") {
          setIsConnected(true);
          reconnectAttemptsRef.current = 0;
          return;
        }

        if (message.type === "auth_failed") {
          setIsConnected(false);
          return;
        }

        const handlers = handlersRef.current.get(message.type);
        if (handlers) {
          handlers.forEach((handler) => handler(message.data));
        }
      } catch (error) {
        console.error("WebSocket message parse error:", error);
      }
    };

    ws.onclose = (event) => {
      setIsConnected(false);
      wsRef.current = null;
      connectingRef.current = false;
      scheduleReconnect(event.code);
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      connectingRef.current = false;
    };

    wsRef.current = ws;
  }, [scheduleReconnect]);

  connectRef.current = connect;

  useEffect(() => {
    enabledRef.current = enabled;

    if (!enabled) {
      manuallyClosedRef.current = true;
      setIsConnected(false);
      connectingRef.current = false;
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      return;
    }

    manuallyClosedRef.current = false;
    connect();

    return () => {
      manuallyClosedRef.current = true;
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect, enabled]);

  const subscribe = useCallback((event: string, handler: MessageHandler) => {
    if (!handlersRef.current.has(event)) {
      handlersRef.current.set(event, new Set());
    }
    handlersRef.current.get(event)!.add(handler);

    return () => {
      handlersRef.current.get(event)?.delete(handler);
    };
  }, []);

  return { isConnected, subscribe };
}
