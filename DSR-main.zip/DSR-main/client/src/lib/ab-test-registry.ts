import type { ComponentType, LazyExoticComponent } from "react";
import { lazy } from "react";

type AnyComponent = ComponentType<any>;
type LazyImporter = () => Promise<{ default: AnyComponent }>;

/**
 * Each testSlug maps componentKey → lazy-loaded variant component.
 * Add a new test by creating a folder under `client/src/pages/ab-tests/<test-slug>/`
 * and registering its components here.
 */
export const AB_TEST_REGISTRY: Record<string, Record<string, LazyExoticComponent<AnyComponent>>> = {
  "checkout-hero": {
    control: lazy(() => import("@/pages/ab-tests/checkout-hero/control")),
    "variante-b": lazy(() => import("@/pages/ab-tests/checkout-hero/variante-b")),
  },
  // "landing-pricing" é um teste de DADOS (preços), não de layout. A rota `/`
  // não passa por AbTestRoute — renderiza DesireLandingPage diretamente para
  // não adicionar roundtrip + lazy chunk no primeiro paint da landing. O
  // middleware Express atribui a variante quando o visitante acessa `/`, e o
  // hook `useResolvePlanId("landing-pricing")` aplica os overrides em tempo
  // de render. Ver client/src/lib/ab-pricing.ts.
};

export function resolveVariantComponent(
  testSlug: string,
  componentKey: string,
): LazyExoticComponent<AnyComponent> | null {
  const test = AB_TEST_REGISTRY[testSlug];
  if (!test) return null;
  return test[componentKey] ?? null;
}

export function getFallbackComponent(testSlug: string): LazyExoticComponent<AnyComponent> | null {
  const test = AB_TEST_REGISTRY[testSlug];
  if (!test) return null;
  // Prefer "control" as the safe fallback when assignment fetch fails.
  return test.control ?? Object.values(test)[0] ?? null;
}

// Used solely to silence the unused import warning in build outputs that strip types.
export type { LazyImporter };
