import { APP_LOCALE, APP_TIME_ZONE } from "@shared/timezone";

function getDateParts(date: Date) {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: APP_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
}

export function formatDateTimeInAppTimeZone(value?: string | null) {
  if (!value) return "—";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  return date.toLocaleString(APP_LOCALE, {
    timeZone: APP_TIME_ZONE,
  });
}

export function formatShortDateTimeInAppTimeZone(value?: string | null) {
  if (!value) return "—";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  return date.toLocaleString(APP_LOCALE, {
    timeZone: APP_TIME_ZONE,
    dateStyle: "short",
    timeStyle: "short",
  });
}

export function formatShortDateInAppTimeZone(value?: string | null) {
  if (!value) return "—";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  return date.toLocaleDateString(APP_LOCALE, {
    timeZone: APP_TIME_ZONE,
  });
}

export function getDateStampInAppTimeZone(date = new Date()) {
  const parts = getDateParts(date);
  const year = parts.find((part) => part.type === "year")?.value ?? "0000";
  const month = parts.find((part) => part.type === "month")?.value ?? "00";
  const day = parts.find((part) => part.type === "day")?.value ?? "00";

  return `${year}-${month}-${day}`;
}
