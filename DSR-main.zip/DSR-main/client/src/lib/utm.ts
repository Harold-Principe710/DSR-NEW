export const UTM_KEYS = [
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_content",
  "utm_term",
] as const;

type UtmKey = (typeof UTM_KEYS)[number];

export type UtmParams = Record<UtmKey, string>;

const UTM_STORAGE_KEY = "desireai:utm:v1";

const EMPTY_UTMS: UtmParams = {
  utm_source: "",
  utm_medium: "",
  utm_campaign: "",
  utm_content: "",
  utm_term: "",
};

function isBrowser() {
  return typeof window !== "undefined";
}

function sanitise(value: unknown): string {
  if (typeof value !== "string") return "";
  return value.trim();
}

function readUtmsFromSearchParams(params: URLSearchParams): UtmParams {
  return {
    utm_source: sanitise(params.get("utm_source")),
    utm_medium: sanitise(params.get("utm_medium")),
    utm_campaign: sanitise(params.get("utm_campaign")),
    utm_content: sanitise(params.get("utm_content")),
    utm_term: sanitise(params.get("utm_term")),
  };
}

function readStoredUtmsFromSession(): Partial<UtmParams> {
  if (!isBrowser()) return {};
  let raw: string | null = null;
  try {
    raw = window.sessionStorage.getItem(UTM_STORAGE_KEY);
  } catch {
    return {};
  }
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw) as Partial<UtmParams>;
    return {
      utm_source: sanitise(parsed.utm_source),
      utm_medium: sanitise(parsed.utm_medium),
      utm_campaign: sanitise(parsed.utm_campaign),
      utm_content: sanitise(parsed.utm_content),
      utm_term: sanitise(parsed.utm_term),
    };
  } catch {
    return {};
  }
}

function readStoredUtmsFromLocal(): Partial<UtmParams> {
  if (!isBrowser()) return {};
  let raw: string | null = null;
  try {
    raw = window.localStorage.getItem(UTM_STORAGE_KEY);
  } catch {
    return {};
  }
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw) as Partial<UtmParams>;
    return {
      utm_source: sanitise(parsed.utm_source),
      utm_medium: sanitise(parsed.utm_medium),
      utm_campaign: sanitise(parsed.utm_campaign),
      utm_content: sanitise(parsed.utm_content),
      utm_term: sanitise(parsed.utm_term),
    };
  } catch {
    return {};
  }
}

function mergeUtms(...sources: Array<Partial<UtmParams>>): UtmParams {
  const merged: UtmParams = { ...EMPTY_UTMS };
  for (const source of sources) {
    for (const key of UTM_KEYS) {
      const candidate = sanitise(source[key]);
      if (candidate) merged[key] = candidate;
    }
  }
  return merged;
}

export function persistUtmsFromCurrentUrl(): UtmParams {
  if (!isBrowser()) return { ...EMPTY_UTMS };

  const fromQuery = readUtmsFromSearchParams(new URLSearchParams(window.location.search));
  const fromSession = readStoredUtmsFromSession();
  const fromLocal = readStoredUtmsFromLocal();
  const merged = mergeUtms(fromLocal, fromSession, fromQuery);

  const serialised = JSON.stringify(merged);
  try {
    window.sessionStorage.setItem(UTM_STORAGE_KEY, serialised);
  } catch {
    // noop
  }
  try {
    window.localStorage.setItem(UTM_STORAGE_KEY, serialised);
  } catch {
    // noop
  }

  return merged;
}

export function getBestAvailableUtms(): UtmParams {
  if (!isBrowser()) return { ...EMPTY_UTMS };
  return persistUtmsFromCurrentUrl();
}
