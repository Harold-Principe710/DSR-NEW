export type FunnelStep =
  | "visitor_entered"
  | "photo_uploaded"
  | "generated_photo_viewed"
  | "offer_viewed"
  | "offer_responded"
  | "video_loading_screen"
  | "video_loaded"
  | "pix_generated"
  | "pix_paid";

const TRACKING_SESSION_KEY = "desireai:funnel_session_key";
let inMemoryTrackingSessionKey = "";

export const JOURNEY_NODES_BY_PATH: Record<string, string> = {
  "/": "landing_home",
  "/login": "login_page",
  "/video-pov-loading": "video_loading_page",
  "/pack-photos-loading": "pack_loading_page",
  "/pix-tester999": "pix_tester_page",
  "/painel": "app_dashboard",
  "/galeria": "app_gallery",
  "/configuracoes": "app_settings",
};

export function resolveJourneyNodeFromPath(pathname: string): string {
  return JOURNEY_NODES_BY_PATH[pathname] || "landing_home";
}

export function getJourneyContext() {
  if (typeof window === "undefined") {
    return {
      journeyPath: "/",
      journeyNode: "landing_home",
    };
  }
  const journeyPath = window.location.pathname || "/";
  return {
    journeyPath,
    journeyNode: resolveJourneyNodeFromPath(journeyPath),
  };
}

export function getTrackingSessionKey(): string {
  if (typeof window === "undefined") return "server";
  let existing: string | null = null;
  try {
    existing = window.sessionStorage.getItem(TRACKING_SESSION_KEY);
  } catch {
    existing = inMemoryTrackingSessionKey || null;
  }
  if (existing) return existing;
  const generated = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  inMemoryTrackingSessionKey = generated;
  try {
    window.sessionStorage.setItem(TRACKING_SESSION_KEY, generated);
  } catch {
    // Some browsers block storage; keep this page-view stable in memory.
  }
  return generated;
}

type TrackPayload = {
  step: FunnelStep;
  eventName?: string;
  idempotencyKey?: string;
  metadata?: Record<string, unknown>;
  journeyNode?: string;
  journeyPath?: string;
  customerName?: string;
  customerEmail?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_content?: string;
  utm_term?: string;
};


export async function trackFunnelEvent(payload: TrackPayload): Promise<void> {
  const context = getJourneyContext();
  const journeyNode = payload.journeyNode || context.journeyNode;
  const journeyPath = payload.journeyPath || context.journeyPath;
  const enrichedMetadata = {
    journeyNode,
    journeyPath,
    ...(payload.metadata || {}),
  };

  // Mirror to PostHog (best-effort, lazy-init, no-op when disabled).
  void import("./posthog")
    .then(({ capture }) =>
      capture(payload.eventName || payload.step, {
        funnel_step: payload.step,
        ...enrichedMetadata,
      }),
    )
    .catch(() => {});

  try {
    await fetch("/api/funnel/events", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...payload,
        metadata: enrichedMetadata,
      }),
    });
  } catch {
    // best-effort tracking
  }
}
