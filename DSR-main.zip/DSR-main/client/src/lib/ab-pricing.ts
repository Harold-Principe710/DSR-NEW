import { useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchWithTimeout } from "@/lib/queryClient";

/**
 * Per-test, per-variant planId overrides. The hook below reads the visitor's
 * current assignment from `/api/ab/assignment` and applies the matching map.
 *
 * Keep this in sync with `PLANS` (PixQrModal.tsx) and `PLAN_PRICES`
 * (server/routes.ts). Every override here MUST exist as a real planId on
 * both sides — the backend rejects unknown planIds.
 */
const PLAN_ID_OVERRIDES: Record<string, Record<string, Record<string, string>>> = {
  "landing-pricing": {
    // componentKey "control" leaves planIds untouched.
    "variante-b": {
      "1-foto": "1-foto-1990",
      "pack-fotos-1990": "pack-fotos-2990",
      "video-pov-990": "video-pov-promo-1990",
      "video-pov-1990": "video-pov-2990",
      "video-pov-pack-2990": "video-pov-pack-3990",
      "10-fotos": "10-fotos-5990",
      "10-fotos-1-video": "10-fotos-1-video-7990",
      // "ilimitado" intentionally omitted — preço mantido.
    },
  },
};

type AssignmentResponse = {
  componentKey: string | null;
};

function useAssignment(testSlug: string, enabled = true) {
  return useQuery<AssignmentResponse>({
    queryKey: ["/api/ab/assignment", testSlug],
    queryFn: async () => {
      const res = await fetchWithTimeout(
        `/api/ab/assignment?testSlug=${encodeURIComponent(testSlug)}`,
        { credentials: "include" },
      );
      if (!res.ok) throw new Error(`Falha ao buscar variante (${res.status})`);
      return (await res.json()) as AssignmentResponse;
    },
    enabled,
    staleTime: Infinity,
    retry: false,
  });
}

/**
 * Returns a function that maps an original planId to the variant-specific
 * planId, or returns the original when the visitor isn't in this test (or is
 * in a variant without overrides). Safe to call from any component — the
 * underlying query is shared via React Query cache.
 */
export function useResolvePlanId(
  testSlug: string,
  options: { enabled?: boolean } = {},
): (planId: string) => string {
  const { data } = useAssignment(testSlug, options.enabled ?? true);
  const componentKey = data?.componentKey ?? null;
  return useCallback(
    (planId: string) => {
      if (!componentKey) return planId;
      const overrides = PLAN_ID_OVERRIDES[testSlug]?.[componentKey];
      return overrides?.[planId] ?? planId;
    },
    [testSlug, componentKey],
  );
}
