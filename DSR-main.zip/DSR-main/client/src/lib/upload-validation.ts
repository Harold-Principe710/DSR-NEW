const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;

const SUPPORTED_UPLOAD_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/heic",
  "image/heif",
  "image/heic-sequence",
  "image/heif-sequence",
]);

const SUPPORTED_UPLOAD_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif"];
const HEIC_EXTENSIONS = [".heic", ".heif"];

function hasKnownExtension(fileName: string, extensions: string[]) {
  const lowerName = fileName.toLowerCase();
  return extensions.some((extension) => lowerName.endsWith(extension));
}

export function getUploadValidationMessage(file: File): string | null {
  const mimeType = (file.type || "").toLowerCase();

  if (file.size > MAX_UPLOAD_BYTES) {
    return "A imagem excede o limite de 10 MB.";
  }

  if (!mimeType) {
    return hasKnownExtension(file.name, SUPPORTED_UPLOAD_EXTENSIONS)
      ? null
      : "Formato não suportado. Use JPEG, PNG, WebP, HEIC ou HEIF.";
  }

  if (!mimeType.startsWith("image/")) {
    return "Envie uma imagem JPEG, PNG, WebP, HEIC ou HEIF.";
  }

  if (!SUPPORTED_UPLOAD_MIME_TYPES.has(mimeType)) {
    return hasKnownExtension(file.name, HEIC_EXTENSIONS)
      ? null
      : "Formato não suportado. Use JPEG, PNG, WebP, HEIC ou HEIF.";
  }

  return null;
}

export async function getUploadErrorMessage(res: Response, fallbackMessage: string) {
  const text = (await res.text()).trim();
  if (!text) return fallbackMessage;

  try {
    const parsed = JSON.parse(text) as { message?: string };
    if (typeof parsed?.message === "string" && parsed.message.trim()) {
      return parsed.message;
    }
  } catch {
    // Keep the raw response body if it is not JSON.
  }

  return text || fallbackMessage;
}
