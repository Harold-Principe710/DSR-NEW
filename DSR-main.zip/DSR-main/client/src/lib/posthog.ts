/**
 * Browser-side PostHog wrapper. Public functions no-op when the SDK is not
 * initialized (missing key, bot user-agent, SSR build). All `init` is lazy
 * to keep the landing path off the critical render: we trigger it on
 * requestIdleCallback so the script never delays first paint.
 */
import type { PostHog } from "posthog-js";

const apiKey = (import.meta.env.VITE_POSTHOG_API_KEY as string | undefined)?.trim() || "";
const apiHost = (import.meta.env.VITE_POSTHOG_HOST as string | undefined)?.trim() || "https://us.i.posthog.com";

// Mirror server botDetection.ts so client-side capture stays consistent.
const BOT_PATTERN =
  /bot\b|crawler|spider|crawling|slurp|baiduspider|yandex|sogou|exabot|facebookexternalhit|twitterbot|linkedinbot|embedly|whatsapp|telegrambot|discordbot|applebot|chrome-lighthouse|headlesschrome|phantomjs|puppeteer|playwright|http\.rb|axios\/|python-requests|curl\/|wget\/|node-fetch|go-http-client|okhttp|java\/|gptbot|ccbot|claudebot|anthropic-ai/i;

function isBotBrowser(): boolean {
  if (typeof navigator === "undefined") return true;
  const ua = (navigator.userAgent || "").trim();
  if (!ua || ua.length < 12) return true;
  return BOT_PATTERN.test(ua);
}

let client: PostHog | null = null;
let initPromise: Promise<PostHog | null> | null = null;

async function ensureInitialized(): Promise<PostHog | null> {
  if (client) return client;
  if (initPromise) return initPromise;
  if (typeof window === "undefined") return null;
  if (!apiKey) return null;
  if (isBotBrowser()) return null;

  initPromise = (async () => {
    const mod = await import("posthog-js");
    const ph = mod.default ?? (mod as unknown as PostHog);
    ph.init(apiKey, {
      api_host: apiHost,
      person_profiles: "identified_only",
      capture_pageview: true,
      capture_pageleave: true,
      autocapture: true,
      respect_dnt: true,
    });
    client = ph;
    return ph;
  })();

  return initPromise;
}

/** Bootstraps PostHog after first paint; safe to call multiple times. */
export function bootPosthog() {
  if (typeof window === "undefined") return;
  const start = () => {
    void ensureInitialized();
  };
  const idle = (window as any).requestIdleCallback as
    | ((cb: () => void, opts?: { timeout: number }) => number)
    | undefined;
  if (idle) idle(start, { timeout: 3000 });
  else window.setTimeout(start, 1000);
}

export async function capture(eventName: string, properties?: Record<string, unknown>) {
  const ph = await ensureInitialized();
  if (!ph) return;
  ph.capture(eventName, properties);
}

export async function identify(userId: string, properties?: Record<string, unknown>) {
  const ph = await ensureInitialized();
  if (!ph || !userId) return;
  ph.identify(userId, properties);
}

export async function reset() {
  const ph = await ensureInitialized();
  if (!ph) return;
  ph.reset();
}

/** Set super-properties attached to every subsequent event. */
export async function registerSuperProps(props: Record<string, unknown>) {
  const ph = await ensureInitialized();
  if (!ph) return;
  ph.register(props);
}
