const CLOUDINARY_UPLOAD_BASE = "https://res.cloudinary.com/dhu74rdsj/image/upload";
const PACK_PREVIEW_IMAGE_PATHS = [
  "v1775705437/gjnuhfthieckk5due8tx.webp",
  "v1775705399/1774652887769-p9v9m8yjicj_fdsb8h.webp",
  "v1775705400/1774654543435-cv6b0ucfhd_dupayj.webp",
  "v1775705399/1774655740182-krzl5dglef_wohuvu.webp",
  "v1775705430/1774654997133-30kbuv71aih_mqhnrp.webp",
] as const;

const PACK_PREVIEW_WIDTHS = [360, 540, 720, 900] as const;
const DEFAULT_PACK_PREVIEW_WIDTH = 720;
const PACK_PREVIEW_TRANSFORMS = "f_auto,q_auto:eco,dpr_auto,c_fill,g_auto,ar_4:5";

function buildPackPreviewUrl(path: string, width: number) {
  return `${CLOUDINARY_UPLOAD_BASE}/${PACK_PREVIEW_TRANSFORMS},w_${width}/${path}`;
}

export const PACK_PREVIEW_IMAGE_SIZES = "(max-width: 640px) calc(100vw - 88px), 360px";

export const PACK_PREVIEW_IMAGES = PACK_PREVIEW_IMAGE_PATHS.map((path, index) => ({
  id: `pack-preview-${index + 1}`,
  src: buildPackPreviewUrl(path, DEFAULT_PACK_PREVIEW_WIDTH),
  srcSet: PACK_PREVIEW_WIDTHS.map((width) => `${buildPackPreviewUrl(path, width)} ${width}w`).join(", "),
  width: DEFAULT_PACK_PREVIEW_WIDTH,
  height: 900,
}));
