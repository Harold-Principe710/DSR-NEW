import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

// ── Global auth state ──────────────────────────────────────────────
let _isAuthenticated = false;

export function setGlobalAuthenticated(value: boolean) {
  _isAuthenticated = value;
}

export function getIsAuthenticated(): boolean {
  return _isAuthenticated;
}

// ── Toast helper (works outside React components) ──────────────────
let _toastFn: ReturnType<typeof useToast>["toast"] | null = null;

export function setGlobalToast(toastFn: ReturnType<typeof useToast>["toast"]) {
  _toastFn = toastFn;
}

// ── Shared response error handler ──────────────────────────────────
async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    let message = `${res.status}: ${text}`;
    try {
      const parsed = JSON.parse(text) as { message?: string };
      if (typeof parsed?.message === "string" && parsed.message.trim()) {
        message = parsed.message;
      }
    } catch {
      // keep default message
    }
    throw new Error(message);
  }
}

const QUERY_TIMEOUT_MS = 12000;

export async function fetchWithTimeout(
  input: RequestInfo | URL,
  init: RequestInit = {},
  timeoutMs = QUERY_TIMEOUT_MS,
): Promise<Response> {
  if (typeof AbortController === "undefined") {
    return fetch(input, init);
  }

  const timeoutController = new AbortController();
  let didTimeout = false;
  const timeoutId = setTimeout(() => {
    didTimeout = true;
    timeoutController.abort();
  }, timeoutMs);

  const upstreamSignal = init.signal;
  const relayAbort = () => timeoutController.abort();
  if (upstreamSignal) {
    if (upstreamSignal.aborted) {
      relayAbort();
    } else {
      upstreamSignal.addEventListener("abort", relayAbort, { once: true });
    }
  }

  try {
    return await fetch(input, {
      ...init,
      signal: timeoutController.signal,
    });
  } catch (error) {
    if (didTimeout) {
      throw new Error("Tempo limite ao carregar dados. Tente novamente.");
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
    upstreamSignal?.removeEventListener("abort", relayAbort);
  }
}

// ── Main API request function ──────────────────────────────────────
export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const res = await fetchWithTimeout(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
    async ({ queryKey, signal }) => {
      const res = await fetchWithTimeout(queryKey.join("/") as string, {
        credentials: "include",
        signal,
      });

      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        return null;
      }

      await throwIfResNotOk(res);
      return await res.json();
    };

export const CRITICAL_QUERY_OPTIONS = {
  staleTime: 30000,
  refetchOnWindowFocus: true,
  refetchOnReconnect: true,
} as const;

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
