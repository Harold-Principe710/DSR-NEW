import { useState } from "react";
import { CheckCircle2, FlaskConical, QrCode, RefreshCw, ShieldCheck } from "lucide-react";
import PixQrModal, { PLANS } from "@/components/PixQrModal";

const TEST_PLAN_ID = "pix-tester-1000";

export default function PixTesterPage() {
  const [pixOpen, setPixOpen] = useState(false);
  const [paid, setPaid] = useState(false);
  const plan = PLANS[TEST_PLAN_ID];

  const openPix = () => {
    setPaid(false);
    setPixOpen(true);
  };

  return (
    <main className="min-h-[100svh] bg-[#08080a] px-5 py-8 text-white">
      <section className="mx-auto flex min-h-[calc(100svh-4rem)] w-full max-w-lg flex-col justify-center">
        <div className="mb-5 inline-flex h-11 w-11 items-center justify-center rounded-lg border border-[#8c1229]/35 bg-[#8c1229]/15">
          <FlaskConical className="h-5 w-5 text-[#ff4d6d]" />
        </div>

        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#ff4d6d]/80">
          Pix tester
        </p>
        <h1 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          PIX de teste
        </h1>
        <p className="mt-3 max-w-md text-sm leading-6 text-white/55">
          Cobrança real de R$ 10,00 para validar gateway, webhook e conciliação sem liberar créditos de produto.
        </p>

        <div className="mt-8 rounded-lg border border-white/10 bg-white/[0.035] p-4 shadow-[0_18px_60px_rgba(0,0,0,0.28)]">
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-xs uppercase tracking-[0.12em] text-white/35">Valor</dt>
              <dd className="mt-1 font-semibold text-white">{plan.price}</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-[0.12em] text-white/35">Créditos</dt>
              <dd className="mt-1 font-semibold text-white">0</dd>
            </div>
            <div className="col-span-2">
              <dt className="text-xs uppercase tracking-[0.12em] text-white/35">Origem</dt>
              <dd className="mt-1 break-all font-mono text-xs text-white/70">/pix-tester999</dd>
            </div>
          </dl>
        </div>

        {paid && (
          <div className="mt-4 flex items-center gap-3 rounded-lg border border-emerald-400/20 bg-emerald-400/[0.06] px-4 py-3 text-sm text-emerald-100">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-300" />
            Pagamento de teste confirmado.
          </div>
        )}

        <button
          type="button"
          onClick={openPix}
          className="mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-[#8c1229] px-5 text-sm font-semibold text-white transition hover:bg-[#a41733] active:scale-[0.99]"
        >
          {paid ? <RefreshCw className="h-4 w-4" /> : <QrCode className="h-4 w-4" />}
          {paid ? "Gerar outro PIX" : "Gerar PIX de R$ 10,00"}
        </button>

        <div className="mt-4 flex items-start gap-2 text-xs leading-5 text-white/40">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-white/30" />
          Usa o mesmo endpoint de produção e fica separado nos nós de teste da jornada.
        </div>
      </section>

      <PixQrModal
        open={pixOpen}
        onClose={() => setPixOpen(false)}
        planId={TEST_PLAN_ID}
        redirectAfterPaymentTo={null}
        onPaymentSuccess={() => setPaid(true)}
      />
    </main>
  );
}
