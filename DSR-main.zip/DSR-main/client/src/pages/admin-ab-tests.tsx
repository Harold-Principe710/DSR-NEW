import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AB_TEST_REGISTRY } from "@/lib/ab-test-registry";
import { formatShortDateInAppTimeZone } from "@/lib/timezone";

const REGISTERED_TEMPLATES = Object.keys(AB_TEST_REGISTRY).sort();
const CUSTOM_TEMPLATE = "__custom__";

function defaultVariantsForTemplate(templateSlug: string): DraftVariant[] {
  const componentKeys =
    templateSlug !== CUSTOM_TEMPLATE && AB_TEST_REGISTRY[templateSlug]
      ? Object.keys(AB_TEST_REGISTRY[templateSlug])
      : [];
  if (componentKeys.length === 0) {
    return [
      { name: "Control", slug: "control", componentKey: "control", weight: 50 },
      { name: "Variante B", slug: "variante-b", componentKey: "variante-b", weight: 50 },
    ];
  }
  const each = Math.floor(10000 / componentKeys.length) / 100;
  const remainder = 100 - each * componentKeys.length;
  return componentKeys.map((key, i) => ({
    name: key === "control" ? "Control" : key.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
    slug: key,
    componentKey: key,
    weight: i === componentKeys.length - 1 ? Math.round((each + remainder) * 100) / 100 : each,
  }));
}

type AbVariantRow = {
  id: string;
  testId: string;
  name: string;
  slug: string;
  componentKey: string;
  weight: number;
  visits: number;
  createdAt: string;
};
type AbTestRow = {
  id: string;
  name: string;
  slug: string;
  publicPath: string;
  status: "active" | "paused" | "ended";
  createdAt: string;
  variants: AbVariantRow[];
};
type ListResponse = { tests: AbTestRow[] };

const STATUS_LABEL: Record<AbTestRow["status"], string> = {
  active: "Ativo",
  paused: "Pausado",
  ended: "Encerrado",
};
const STATUS_CLASS: Record<AbTestRow["status"], string> = {
  active: "border-emerald-500/40 bg-emerald-500/15 text-emerald-300",
  paused: "border-amber-400/40 bg-amber-400/15 text-amber-200",
  ended: "border-white/15 bg-white/5 text-white/50",
};

function StatusBadge({ status }: { status: AbTestRow["status"] }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs ${STATUS_CLASS[status]}`}>
      {STATUS_LABEL[status]}
    </span>
  );
}

type DraftVariant = { name: string; slug: string; componentKey: string; weight: number };

function CreateTestModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [templateSlug, setTemplateSlug] = useState<string>(CUSTOM_TEMPLATE);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [publicPath, setPublicPath] = useState("/");
  const [variants, setVariants] = useState<DraftVariant[]>(() => defaultVariantsForTemplate(CUSTOM_TEMPLATE));

  const usingTemplate = templateSlug !== CUSTOM_TEMPLATE && Boolean(AB_TEST_REGISTRY[templateSlug]);
  const availableComponentKeys = usingTemplate ? Object.keys(AB_TEST_REGISTRY[templateSlug]) : [];
  const usedComponentKeys = new Set(variants.map((v) => v.componentKey));
  const unusedComponentKeys = usingTemplate
    ? availableComponentKeys.filter((k) => !usedComponentKeys.has(k))
    : [];

  const handleTemplateChange = (next: string) => {
    setTemplateSlug(next);
    if (next === CUSTOM_TEMPLATE) {
      setSlug("");
    } else {
      setSlug(next);
    }
    setVariants(defaultVariantsForTemplate(next));
  };

  const totalWeight = useMemo(
    () => Math.round(variants.reduce((s, v) => s + (Number.isFinite(v.weight) ? v.weight : 0), 0) * 100) / 100,
    [variants],
  );
  const weightOk = Math.abs(totalWeight - 100) < 0.01;

  const createMut = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/ab-tests", {
        name,
        slug,
        publicPath,
        variants,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Teste criado", description: `Variantes ativas em ${publicPath}` });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ab-tests"] });
      onClose();
      setTemplateSlug(CUSTOM_TEMPLATE);
      setName("");
      setSlug("");
      setPublicPath("/");
      setVariants(defaultVariantsForTemplate(CUSTOM_TEMPLATE));
    },
    onError: (err: Error) => {
      toast({ title: "Erro ao criar teste", description: err.message, variant: "destructive" });
    },
  });

  if (!open) return null;

  const updateVariant = (idx: number, patch: Partial<DraftVariant>) => {
    setVariants((prev) => prev.map((v, i) => (i === idx ? { ...v, ...patch } : v)));
  };

  const addVariant = () => {
    if (usingTemplate) {
      if (unusedComponentKeys.length === 0) return;
      const nextKey = unusedComponentKeys[0];
      setVariants((prev) => [
        ...prev,
        {
          name: nextKey === "control" ? "Control" : nextKey.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
          slug: nextKey,
          componentKey: nextKey,
          weight: 0,
        },
      ]);
      return;
    }
    setVariants((prev) => [
      ...prev,
      { name: `Variante ${String.fromCharCode(65 + prev.length)}`, slug: `variante-${prev.length + 1}`, componentKey: "control", weight: 0 },
    ]);
  };

  const removeVariant = (idx: number) => {
    setVariants((prev) => (prev.length <= 2 ? prev : prev.filter((_, i) => i !== idx)));
  };

  const distributeEvenly = () => {
    const each = Math.floor(10000 / variants.length) / 100;
    const remainder = 100 - each * variants.length;
    setVariants((prev) =>
      prev.map((v, i) => ({ ...v, weight: i === prev.length - 1 ? Math.round((each + remainder) * 100) / 100 : each })),
    );
  };

  const formValid =
    name.trim().length > 0 &&
    /^[a-z0-9][a-z0-9-]*$/.test(slug) &&
    publicPath.startsWith("/") &&
    variants.length >= 2 &&
    variants.every((v) => v.name.trim() && /^[a-z0-9][a-z0-9-]*$/.test(v.slug) && /^[a-z0-9][a-z0-9-]*$/.test(v.componentKey)) &&
    weightOk;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4 py-6">
      <div className="w-full max-w-2xl overflow-hidden rounded-2xl border border-white/10 bg-[#0a0407] shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <h2 className="text-lg font-semibold text-white">Novo teste A/B</h2>
          <button onClick={onClose} className="rounded-lg border border-white/15 px-3 py-1.5 text-xs text-white/70 hover:bg-white/5">
            Fechar
          </button>
        </div>
        <div className="max-h-[70vh] overflow-y-auto px-5 py-4 space-y-5 text-white">
          <label className="block space-y-1 text-sm">
            <span className="text-white/60">Template (do registry)</span>
            <select
              value={templateSlug}
              onChange={(e) => handleTemplateChange(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm focus:border-[#8c1229] focus:outline-none"
            >
              <option value={CUSTOM_TEMPLATE}>Custom (sem template — teste de dados)</option>
              {REGISTERED_TEMPLATES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <span className="block pt-1 text-xs text-white/45">
              {usingTemplate
                ? `Template carregado de client/src/lib/ab-test-registry.ts. Slug travado.`
                : "Use Custom para testes de dados (preço, etc.) que não trocam o componente renderizado."}
            </span>
          </label>

          <div className="grid gap-3 sm:grid-cols-2">
            <label className="space-y-1 text-sm">
              <span className="text-white/60">Nome</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Checkout — hero"
                className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm focus:border-[#8c1229] focus:outline-none"
              />
            </label>
            <label className="space-y-1 text-sm">
              <span className="text-white/60">Slug</span>
              <input
                value={slug}
                onChange={(e) => setSlug(e.target.value.trim())}
                placeholder="checkout-hero"
                disabled={usingTemplate}
                className={`w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm focus:border-[#8c1229] focus:outline-none ${usingTemplate ? "cursor-not-allowed opacity-60" : ""}`}
              />
            </label>
            <label className="space-y-1 text-sm sm:col-span-2">
              <span className="text-white/60">Path público</span>
              <input
                value={publicPath}
                onChange={(e) => setPublicPath(e.target.value.trim())}
                placeholder="/oferta"
                className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm focus:border-[#8c1229] focus:outline-none"
              />
            </label>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white/80">Variantes</h3>
              <div className="flex gap-2">
                <button onClick={distributeEvenly} className="rounded-lg border border-white/15 px-2 py-1 text-xs text-white/70 hover:bg-white/5">
                  Dividir igualmente
                </button>
                <button
                  onClick={addVariant}
                  disabled={usingTemplate && unusedComponentKeys.length === 0}
                  className="rounded-lg border border-white/15 px-2 py-1 text-xs text-white/70 hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-40"
                  title={usingTemplate && unusedComponentKeys.length === 0 ? "Todos os componentKeys do template já foram usados" : undefined}
                >
                  + Adicionar
                </button>
              </div>
            </div>
            {variants.map((v, idx) => (
              <div key={idx} className="rounded-2xl border border-white/10 bg-white/[0.02] p-3 space-y-2">
                <div className="grid gap-2 sm:grid-cols-3">
                  <input
                    value={v.name}
                    onChange={(e) => updateVariant(idx, { name: e.target.value })}
                    placeholder="Nome"
                    className="rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm focus:border-[#8c1229] focus:outline-none"
                  />
                  <input
                    value={v.slug}
                    onChange={(e) => updateVariant(idx, { slug: e.target.value.trim() })}
                    placeholder="slug"
                    className="rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm focus:border-[#8c1229] focus:outline-none"
                  />
                  {usingTemplate ? (
                    <select
                      value={v.componentKey}
                      onChange={(e) => updateVariant(idx, { componentKey: e.target.value })}
                      className="rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm focus:border-[#8c1229] focus:outline-none"
                    >
                      {availableComponentKeys.map((key) => {
                        const usedElsewhere = variants.some((vv, ii) => ii !== idx && vv.componentKey === key);
                        return (
                          <option key={key} value={key} disabled={usedElsewhere}>
                            {key}{usedElsewhere ? " (em uso)" : ""}
                          </option>
                        );
                      })}
                    </select>
                  ) : (
                    <input
                      value={v.componentKey}
                      onChange={(e) => updateVariant(idx, { componentKey: e.target.value.trim() })}
                      placeholder="componentKey"
                      className="rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm focus:border-[#8c1229] focus:outline-none"
                    />
                  )}
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={0.01}
                    value={v.weight}
                    onChange={(e) => updateVariant(idx, { weight: Number(e.target.value) })}
                    className="flex-1 accent-[#8c1229]"
                  />
                  <input
                    type="number"
                    min={0}
                    max={100}
                    step={0.01}
                    value={v.weight}
                    onChange={(e) => updateVariant(idx, { weight: Number(e.target.value) })}
                    className="w-20 rounded-lg border border-white/10 bg-black/40 px-2 py-1 text-right text-sm focus:border-[#8c1229] focus:outline-none"
                  />
                  <span className="text-xs text-white/50">%</span>
                  {variants.length > 2 && (
                    <button onClick={() => removeVariant(idx)} className="text-xs text-white/50 hover:text-white/80">
                      Remover
                    </button>
                  )}
                </div>
              </div>
            ))}
            <p className={`text-xs ${weightOk ? "text-emerald-300" : "text-amber-300"}`}>
              Soma dos pesos: {totalWeight}% {weightOk ? "✓" : "(precisa ser 100%)"}
            </p>
          </div>
        </div>
        <div className="flex items-center justify-end gap-2 border-t border-white/10 px-5 py-3">
          <button onClick={onClose} className="rounded-lg border border-white/15 px-3 py-2 text-sm text-white/70 hover:bg-white/5">
            Cancelar
          </button>
          <button
            onClick={() => createMut.mutate()}
            disabled={!formValid || createMut.isPending}
            className="rounded-lg bg-[#8c1229] px-4 py-2 text-sm font-medium text-white hover:bg-[#a61530] disabled:cursor-not-allowed disabled:opacity-50"
          >
            {createMut.isPending ? "Criando..." : "Criar teste"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AdminAbTestsListPage() {
  const [, setLocation] = useLocation();
  const [createOpen, setCreateOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const listQuery = useQuery<ListResponse>({
    queryKey: ["/api/admin/ab-tests"],
  });

  const handleLogout = async () => {
    await fetch("/api/admin/logout", { method: "POST", credentials: "include" });
    setLocation("/admin/login");
  };

  const toggleStatusMut = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: AbTestRow["status"] }) => {
      const res = await apiRequest("PATCH", `/api/admin/ab-tests/${id}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ab-tests"] });
    },
    onError: (err: Error) => toast({ title: "Erro", description: err.message, variant: "destructive" }),
  });

  return (
    <div className="min-h-screen bg-[#050102] text-white">
      <div className="mx-auto w-full max-w-6xl px-4 py-6 space-y-6">
        <header className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold">Testes A/B</h1>
            <p className="text-sm text-white/45">Gerencie variantes, tráfego e conversões</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLocation("/admin")}
              className="rounded-lg border border-white/15 px-3 py-2 text-sm hover:bg-white/5"
            >
              ← Painel
            </button>
            <button
              onClick={() => setCreateOpen(true)}
              className="rounded-lg bg-[#8c1229] px-3 py-2 text-sm font-medium hover:bg-[#a61530]"
            >
              Novo teste
            </button>
            <button
              onClick={handleLogout}
              className="rounded-lg border border-white/15 px-3 py-2 text-sm hover:bg-white/5"
            >
              Sair
            </button>
          </div>
        </header>

        <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
          {listQuery.isLoading && <p className="text-sm text-white/60">Carregando…</p>}
          {listQuery.isError && (
            <p className="text-sm text-rose-300">Erro ao carregar testes.</p>
          )}
          {listQuery.data && listQuery.data.tests.length === 0 && (
            <p className="text-sm text-white/60">Nenhum teste cadastrado ainda.</p>
          )}
          {listQuery.data && listQuery.data.tests.length > 0 && (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wide text-white/45">
                    <th className="px-3 py-2">Nome</th>
                    <th className="px-3 py-2">URL Pública</th>
                    <th className="px-3 py-2">Status</th>
                    <th className="px-3 py-2">Variantes</th>
                    <th className="px-3 py-2">Criado em</th>
                    <th className="px-3 py-2 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {listQuery.data.tests.map((test) => (
                    <tr key={test.id} className="border-t border-white/5">
                      <td className="px-3 py-3">
                        <div className="font-medium">{test.name}</div>
                        <div className="text-xs text-white/45">{test.slug}</div>
                      </td>
                      <td className="px-3 py-3">
                        <code className="rounded bg-black/40 px-2 py-0.5 text-xs">{test.publicPath}</code>
                      </td>
                      <td className="px-3 py-3"><StatusBadge status={test.status} /></td>
                      <td className="px-3 py-3 text-white/70">{test.variants.length}</td>
                      <td className="px-3 py-3 text-white/60 text-xs">
                        {formatShortDateInAppTimeZone(test.createdAt)}
                      </td>
                      <td className="px-3 py-3 text-right space-x-2">
                        {test.status === "active" && (
                          <button
                            onClick={() => toggleStatusMut.mutate({ id: test.id, status: "paused" })}
                            className="rounded-lg border border-white/15 px-2 py-1 text-xs hover:bg-white/5"
                          >
                            Pausar
                          </button>
                        )}
                        {test.status === "paused" && (
                          <button
                            onClick={() => toggleStatusMut.mutate({ id: test.id, status: "active" })}
                            className="rounded-lg border border-emerald-400/40 bg-emerald-500/10 px-2 py-1 text-xs text-emerald-200 hover:bg-emerald-500/20"
                          >
                            Reativar
                          </button>
                        )}
                        <button
                          onClick={() => setLocation(`/admin/ab-tests/${test.id}`)}
                          className="rounded-lg border border-white/15 px-2 py-1 text-xs hover:bg-white/5"
                        >
                          Dashboard →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>

      <CreateTestModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  );
}
