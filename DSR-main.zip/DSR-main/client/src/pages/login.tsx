import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User, Mail, KeyRound, Loader2, Check, Phone, CircleHelp } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { trackFunnelEvent } from "@/lib/funnel";

type AuthMode = "login" | "register";
const MIN_PASSWORD_LENGTH = 6;
const PHONE_DIGITS_MAX = 11;

function formatBrazilPhone(raw: string): string {
    const digits = raw.replace(/\D/g, "").slice(0, PHONE_DIGITS_MAX);
    if (!digits) return "";
    if (digits.length <= 2) return `(${digits}`;

    const ddd = digits.slice(0, 2);
    const local = digits.slice(2);

    if (local.length <= 5) return `(${ddd}) ${local}`;
    return `(${ddd}) ${local.slice(0, 5)}-${local.slice(5, 9)}`;
}

function LoginForm() {
    const { toast } = useToast();
    const [, setLocation] = useLocation();
    const [mode, setMode] = useState<AuthMode>("login");

    // Login fields
    const [loginUsername, setLoginUsername] = useState("");
    const [loginPassword, setLoginPassword] = useState("");

    // Register fields
    const [regUsername, setRegUsername] = useState("");
    const [regEmail, setRegEmail] = useState("");
    const [regPhone, setRegPhone] = useState("");
    const [regPassword, setRegPassword] = useState("");
    const [regConfirm, setRegConfirm] = useState("");
    const [showPhoneInfo, setShowPhoneInfo] = useState(false);

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const handleLogin = async () => {
        setError("");
        if (!loginUsername || !loginPassword) {
            setError("Preencha todos os campos");
            return;
        }
        setLoading(true);
        try {
            const res = await fetch("/api/auth/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username: loginUsername, password: loginPassword }),
                credentials: "include",
            });
            const data = await res.json();
            if (!res.ok) {
                setError(data.message || "Erro ao fazer login");
                return;
            }
            queryClient.invalidateQueries();
            setLocation("/painel");
        } catch {
            setError("Erro de conexão. Tente novamente.");
        } finally {
            setLoading(false);
        }
    };

    const handleRegister = async () => {
        setError("");
        if (regUsername.length < 3) {
            setError("Username deve ter pelo menos 3 caracteres");
            return;
        }
        if (!regEmail.trim()) {
            setError("E-mail é obrigatório");
            return;
        }
        if (regPassword.length < MIN_PASSWORD_LENGTH || regPassword.length > 40) {
            if (regPassword.length < MIN_PASSWORD_LENGTH) {
                const missingChars = Math.max(0, MIN_PASSWORD_LENGTH - regPassword.length);
                setError(`A senha precisa ter no mínimo ${MIN_PASSWORD_LENGTH} caracteres. Faltam ${missingChars}.`);
            } else {
                setError("A senha deve ter no máximo 40 caracteres.");
            }
            return;
        }
        if (regPassword !== regConfirm) {
            setError("As senhas não coincidem");
            return;
        }
        setLoading(true);
        try {
            const res = await fetch("/api/auth/register-funnel", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    username: regUsername,
                    email: regEmail.trim(),
                    phone: regPhone.replace(/\D/g, "") || undefined,
                    password: regPassword,
                    confirmPassword: regConfirm,
                }),
                credentials: "include",
            });
            const data = await res.json();
            if (!res.ok) {
                setError(data.message || "Erro ao criar conta");
                return;
            }
            queryClient.invalidateQueries();
            setLocation("/painel");
        } catch {
            setError("Erro de conexão. Tente novamente.");
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (mode === "login") handleLogin();
        else handleRegister();
    };

    const canSubmitLogin = loginUsername && loginPassword.length >= 1;
    const canSubmitRegister = regUsername.length >= 3 && regEmail.trim().length > 0 && regPassword.length >= MIN_PASSWORD_LENGTH && regConfirm.length >= MIN_PASSWORD_LENGTH;

    return (
        <div
            className="min-h-screen flex items-center justify-center overflow-y-auto px-4 py-8 bg-gradient-to-br from-[#0a0204] via-[#0f0407] to-[#17050a]"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
            {/* Ambient glow */}
            <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[70vw] max-w-[600px] h-[50vw] max-h-[500px] rounded-full bg-[#8c1229] opacity-[0.06] blur-[140px]" />
            </div>

            <div className="relative z-10 w-full max-w-[400px] flex flex-col items-center gap-8">
                {/* Logo */}
                <img
                    src="/uploads/logo.webp"
                    alt="DesireAI"
                    width={599}
                    height={171}
                    decoding="async"
                    fetchPriority="high"
                    className="h-10 object-contain opacity-90"
                />

                {/* Card */}
                <div className="w-full rounded-2xl border border-[#8c1229]/20 bg-[#0a0204]/90 backdrop-blur-xl p-6 md:p-8 shadow-2xl">
                    {/* Tabs */}
                    <div className="flex rounded-xl bg-white/[0.04] border border-white/[0.06] p-1 mb-6">
                        <button
                            onClick={() => { setMode("login"); setError(""); }}
                            className={`flex-1 py-2.5 rounded-lg text-[14px] font-semibold transition-all duration-300 ${mode === "login"
                                ? "bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white shadow-lg shadow-[#8c1229]/20"
                                : "text-white/40 hover:text-white/60"
                                }`}
                        >
                            Entrar
                        </button>
                        <button
                            onClick={() => { setMode("register"); setError(""); }}
                            className={`flex-1 py-2.5 rounded-lg text-[14px] font-semibold transition-all duration-300 ${mode === "register"
                                ? "bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white shadow-lg shadow-[#8c1229]/20"
                                : "text-white/40 hover:text-white/60"
                                }`}
                        >
                            Criar conta
                        </button>
                    </div>

                    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                        {mode === "login" ? (
                            <>
                                {/* Login Form */}
                                <div className="relative">
                                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                    <input
                                        type="text"
                                        value={loginUsername}
                                        onChange={(e) => setLoginUsername(e.target.value.replace(/[^a-zA-Z0-9._]/g, "").slice(0, 20))}
                                        placeholder="Nome de usuário"
                                        autoComplete="username"
                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                    />
                                </div>
                                <div className="relative">
                                    <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                    <input
                                        type="password"
                                        value={loginPassword}
                                        onChange={(e) => setLoginPassword(e.target.value)}
                                        placeholder="Senha"
                                        autoComplete="current-password"
                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                    />
                                </div>
                            </>
                        ) : (
                            <>
                                {/* Register Form */}
                                <div className="relative">
                                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                    <input
                                        type="text"
                                        value={regUsername}
                                        onChange={(e) => setRegUsername(e.target.value.replace(/[^a-zA-Z0-9._]/g, "").slice(0, 20))}
                                        placeholder="Nome de usuário"
                                        autoComplete="username"
                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                    />
                                </div>
                                <div className="relative">
                                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                    <input
                                        type="email"
                                        value={regEmail}
                                        onChange={(e) => setRegEmail(e.target.value)}
                                        placeholder="Seu e-mail"
                                        autoComplete="email"
                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                    />
                                </div>
                                <div>
                                    <div className="flex items-center justify-between px-1 mb-1">
                                        <p className="text-[12px] text-white/45">Telefone (opcional)</p>
                                        <button
                                            type="button"
                                            onClick={() => setShowPhoneInfo((prev) => !prev)}
                                            className="inline-flex items-center justify-center text-white/45 hover:text-white/70 transition-colors"
                                            aria-label="Informação sobre telefone"
                                        >
                                            <CircleHelp className="w-3.5 h-3.5" />
                                        </button>
                                    </div>
                                    <div className="relative">
                                        <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                        <input
                                            type="tel"
                                            value={regPhone}
                                            onChange={(e) => setRegPhone(formatBrazilPhone(e.target.value))}
                                            placeholder="(11) 99999-9999"
                                            inputMode="numeric"
                                            maxLength={15}
                                            className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                        />
                                    </div>
                                    {showPhoneInfo && (
                                        <p className="mt-1 px-1 text-[12px] text-white/55">
                                            Não enviaremos mensagem caso você não solicite.
                                        </p>
                                    )}
                                </div>
                                <div className="relative">
                                    <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                    <input
                                        type="password"
                                        maxLength={40}
                                        value={regPassword}
                                        onChange={(e) => setRegPassword(e.target.value.slice(0, 40))}
                                        placeholder="Senha (mínimo 6 caracteres)"
                                        autoComplete="new-password"
                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                    />
                                </div>
                                <div className="relative">
                                    <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                    <input
                                        type="password"
                                        maxLength={40}
                                        value={regConfirm}
                                        onChange={(e) => setRegConfirm(e.target.value.slice(0, 40))}
                                        placeholder="Confirme a senha"
                                        autoComplete="new-password"
                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                    />
                                </div>
                            </>
                        )}

                        {error && (
                            <p className="text-[13px] text-[#ff3b5c] font-medium px-1 animate-in fade-in">
                                {error}
                            </p>
                        )}

                        <button
                            type="submit"
                            disabled={loading || (mode === "login" ? !canSubmitLogin : !canSubmitRegister)}
                            className={`w-full py-4 rounded-xl text-[15px] font-semibold tracking-wide transition-all duration-300 mt-1 ${loading || (mode === "login" ? !canSubmitLogin : !canSubmitRegister)
                                ? "bg-white/[0.04] text-white/25 cursor-not-allowed border border-white/[0.04]"
                                : "bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white hover:from-[#a61530] hover:to-[#6b0d1e] active:scale-[0.98] shadow-[0_0_20px_rgba(140,18,41,0.2)] border border-[#ff3b5c]/20"
                                }`}
                        >
                            {loading ? (
                                <span className="flex items-center justify-center gap-2">
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                    {mode === "login" ? "Entrando..." : "Criando conta..."}
                                </span>
                            ) : (
                                <span className="flex items-center justify-center gap-2">
                                    <Check className="w-4 h-4" />
                                    {mode === "login" ? "ENTRAR" : "CRIAR CONTA"}
                                </span>
                            )}
                        </button>
                    </form>
                </div>

                <p className="text-[11px] text-white/15">© {new Date().getFullYear()} DesireAI · 100% Sigiloso</p>
            </div>
        </div>
    );
}

export default function LoginPage() {
    const [, setLocation] = useLocation();

    // Check if user is already authenticated — redirect away from login
    const { data: currentUser, isLoading: isCheckingAuth } = useQuery<{ id: string; hasPaidPix: boolean } | null>({
        queryKey: ["/api/user/me"],
        queryFn: getQueryFn({ on401: "returnNull" }),
        retry: false,
        staleTime: 30000,
    });

    useEffect(() => {
    trackFunnelEvent({
      step: "visitor_entered",
      eventName: "login.entered",
      idempotencyKey: "login:visitor_entered",
    });
  }, []);

  useEffect(() => {
        if (currentUser) {
            setLocation(currentUser.hasPaidPix ? "/painel" : "/");
        }
    }, [currentUser, setLocation]);

    // Show loading while checking auth
    if (isCheckingAuth) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#0a0204] via-[#0f0407] to-[#17050a]">
                <div className="w-6 h-6 border-2 border-[#8c1229] border-t-transparent rounded-full animate-spin" />
                <p className="mt-3 text-sm text-white/70">Traduzindo para o seu idioma</p>
            </div>
        );
    }

    // If authenticated, show spinner while redirect happens
    if (currentUser) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#0a0204] via-[#0f0407] to-[#17050a]">
                <div className="w-6 h-6 border-2 border-[#8c1229] border-t-transparent rounded-full animate-spin" />
                <p className="mt-3 text-sm text-white/70">Traduzindo para o seu idioma</p>
            </div>
        );
    }

    return <LoginForm />;
}
