import { useLocation } from "wouter";
import { CustomersListPanel } from "@/components/customers-list-panel";

export default function CallerDashboardPage() {
  const [, setLocation] = useLocation();

  const handleLogout = async () => {
    await fetch("/api/caller/logout", {
      method: "POST",
      credentials: "include",
    });
    setLocation("/caller-92192/login");
  };

  return (
    <div className="min-h-screen bg-[#050102] text-white">
      <div className="mx-auto w-full max-w-6xl px-4 py-6 space-y-6">
        <header className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold">Lista de usuários</h1>
            <p className="text-sm text-white/45">Atualização automática a cada 15 segundos</p>
          </div>
          <button
            onClick={handleLogout}
            className="rounded-lg border border-white/15 px-3 py-2 text-sm hover:bg-white/5"
          >
            Sair
          </button>
        </header>

        <CustomersListPanel scope="caller" />
      </div>
    </div>
  );
}
