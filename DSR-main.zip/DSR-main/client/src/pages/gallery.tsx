import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Grid, Download, Trash2, X, ZoomIn, Loader2 } from "lucide-react";
import { useFunnelPageView } from "@/hooks/use-funnel-page-view";

interface GalleryImage {
    id: string;
    imageUrl: string;
    prompt: string;
    status: string;
    createdAt: string;
}

export default function Gallery() {
    useFunnelPageView("app_gallery", "app.gallery_viewed");
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [expandedImage, setExpandedImage] = useState<GalleryImage | null>(null);
    const [deletingId, setDeletingId] = useState<string | null>(null);

    const { data: images, isLoading } = useQuery<GalleryImage[]>({
        queryKey: ["/api/generated-images"],
        select: (data: any) => {
            // API may return array directly or wrapped
            const arr = Array.isArray(data) ? data : (data?.images || []);
            return arr.filter((img: GalleryImage) => img.status === "completed" && img.imageUrl);
        },
    });

    const deleteMutation = useMutation({
        mutationFn: async (imageId: string) => {
            setDeletingId(imageId);
            const res = await fetch(`/api/generated-images/${imageId}`, {
                method: "DELETE",
                credentials: "include",
            });
            if (!res.ok) throw new Error("Falha ao excluir");
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["/api/generated-images"] });
            toast({ title: "Imagem excluída" });
            if (expandedImage && expandedImage.id === deletingId) setExpandedImage(null);
        },
        onError: () => {
            toast({ title: "Erro", description: "Falha ao excluir imagem", variant: "destructive" });
        },
        onSettled: () => setDeletingId(null),
    });

    const handleDownload = async (image: GalleryImage) => {
        try {
            const res = await fetch(`/api/generated-images/${image.id}/image?_cb=download`, { credentials: "include" });
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `desireai-${image.id}.jpg`;
            a.click();
            URL.revokeObjectURL(url);
        } catch {
            toast({ title: "Erro", description: "Falha ao baixar imagem", variant: "destructive" });
        }
    };

    const handleDelete = (imageId: string) => {
        if (confirm("Tem certeza que deseja excluir esta imagem?")) {
            deleteMutation.mutate(imageId);
        }
    };

    return (
        <div className="flex-1 w-full max-w-7xl mx-auto px-4 py-8">
            <header className="mb-6">
                <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
                    <Grid className="text-[#ff3b5c]" />
                    Minha Galeria
                </h1>
                <p className="text-white/30 mt-2 text-[13px]">Mídias são deletadas após 14 dias.</p>
            </header>

            {isLoading ? (
                <div className="flex items-center justify-center py-20">
                    <Loader2 className="w-6 h-6 text-white/30 animate-spin" />
                </div>
            ) : !images || images.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                    <div className="w-16 h-16 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center mb-4">
                        <Grid className="w-7 h-7 text-white/15" />
                    </div>
                    <p className="text-white/30 text-[15px]">Nenhuma mídia gerada ainda.</p>
                    <p className="text-white/15 text-[13px] mt-1">Use o Painel para criar suas primeiras imagens.</p>
                </div>
            ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                    {images.map((image) => (
                        <div
                            key={image.id}
                            className="group relative rounded-xl overflow-hidden border border-white/[0.06] bg-black/40 hover:border-[#8c1229]/30 transition-all duration-300 cursor-pointer"
                        >
                            <div className="aspect-[3/4]">
                                <img
                                    src={`/api/generated-images/${image.id}/image?_cb=gallery`}
                                    alt=""
                                    className="w-full h-full object-cover"
                                    onClick={() => setExpandedImage(image)}
                                    loading="lazy"
                                    decoding="async"
                                />
                            </div>

                            {/* Overlay buttons */}
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center gap-2 pb-3">
                                <button
                                    onClick={(e) => { e.stopPropagation(); handleDownload(image); }}
                                    className="p-2 rounded-lg bg-white/10 backdrop-blur-sm border border-white/10 text-white/80 hover:bg-white/20 transition-all"
                                    title="Download"
                                >
                                    <Download className="w-4 h-4" />
                                </button>
                                <button
                                    onClick={(e) => { e.stopPropagation(); setExpandedImage(image); }}
                                    className="p-2 rounded-lg bg-white/10 backdrop-blur-sm border border-white/10 text-white/80 hover:bg-white/20 transition-all"
                                    title="Expandir"
                                >
                                    <ZoomIn className="w-4 h-4" />
                                </button>
                                <button
                                    onClick={(e) => { e.stopPropagation(); handleDelete(image.id); }}
                                    disabled={deletingId === image.id}
                                    className="p-2 rounded-lg bg-red-500/10 backdrop-blur-sm border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-all"
                                    title="Excluir"
                                >
                                    {deletingId === image.id
                                        ? <Loader2 className="w-4 h-4 animate-spin" />
                                        : <Trash2 className="w-4 h-4" />
                                    }
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Expanded image modal */}
            {expandedImage && (
                <div
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm animate-in fade-in p-4"
                    onClick={() => setExpandedImage(null)}
                >
                    <button
                        onClick={() => setExpandedImage(null)}
                        className="absolute top-4 right-4 p-2 rounded-full bg-white/10 text-white/70 hover:bg-white/20 transition-all z-10"
                    >
                        <X className="w-5 h-5" />
                    </button>

                    <div className="absolute bottom-6 flex gap-3 z-10">
                        <button
                            onClick={(e) => { e.stopPropagation(); handleDownload(expandedImage); }}
                            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10 text-white/80 hover:bg-white/20 text-[13px] font-medium transition-all"
                        >
                            <Download className="w-4 h-4" />
                            Download
                        </button>
                        <button
                            onClick={(e) => { e.stopPropagation(); handleDelete(expandedImage.id); }}
                            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 backdrop-blur-sm border border-red-500/20 text-red-400 hover:bg-red-500/20 text-[13px] font-medium transition-all"
                        >
                            <Trash2 className="w-4 h-4" />
                            Excluir
                        </button>
                    </div>

                    <img
                        src={`/api/generated-images/${expandedImage.id}/image?_cb=expanded`}
                        alt=""
                        className="max-h-[85vh] max-w-[95vw] object-contain rounded-lg shadow-2xl"
                        onClick={(e) => e.stopPropagation()}
                        decoding="async"
                    />
                </div>
            )}
        </div>
    );
}
