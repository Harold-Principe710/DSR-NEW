import { useState, useRef, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import {
    Sparkles,
    Upload,
    Loader2,
    Camera,
    Eye,
    Clapperboard,
    ImagePlus,
    User,
    Wrench,
} from "lucide-react";
import CreditsPopup from "@/components/CreditsPopup";
import PixQrModal from "@/components/PixQrModal";
import { getUploadErrorMessage, getUploadValidationMessage } from "@/lib/upload-validation";
import { useFunnelPageView } from "@/hooks/use-funnel-page-view";

interface FeatureCard {
    id: string;
    label: string;
    description: string;
    icon: React.ElementType;
    active: boolean;
}

const featureCards: FeatureCard[] = [
    { id: "undress", label: "Tirar Roupa", description: "Resultado direto, sem borrar", icon: Eye, active: true },
    { id: "pov", label: "Vídeo POV", description: "Vídeo imersivo em primeira pessoa", icon: Clapperboard, active: false },
    { id: "scene", label: "Cena Pornô", description: "Cenas completas com IA", icon: Sparkles, active: false },
    { id: "dance", label: "Dança Sexy", description: "Dança sensual gerada por IA", icon: Sparkles, active: false },
    { id: "famous", label: "Famosas do Insta", description: "Celebridades do Instagram", icon: User, active: false },
    { id: "model", label: "Gere sua Modelo de IA", description: "Crie sua modelo perfeita", icon: ImagePlus, active: false },
];

export default function Dashboard() {
    useFunnelPageView("app_dashboard", "app.dashboard_viewed");
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const { subscribe, isConnected } = useWebSocket();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const cameraInputRef = useRef<HTMLInputElement>(null);

    const [showUndressFlow, setShowUndressFlow] = useState(false);
    const [referenceImages, setReferenceImages] = useState<string[]>([]);
    const [uploadedAspectRatio, setUploadedAspectRatio] = useState("1:1");
    const [isUploading, setIsUploading] = useState(false);
    const [generatedImage, setGeneratedImage] = useState<any>(null);
    const [isDragging, setIsDragging] = useState(false);

    // Credits popup & PIX modal
    const [creditsPopupOpen, setCreditsPopupOpen] = useState(false);
    const [pixModalOpen, setPixModalOpen] = useState(false);
    const [selectedPlanId, setSelectedPlanId] = useState("");

    // WS listeners for image completion
    useEffect(() => {
        const unsubCompleted = subscribe("image_completed", (image: any) => {
            setGeneratedImage(image);
        });
        const unsubFailed = subscribe("image_failed", (image: any) => {
            toast({
                title: "Falha na geração",
                description: image.errorMessage || "Não foi possível gerar a imagem.",
                variant: "destructive",
            });
        });
        return () => { unsubCompleted(); unsubFailed(); };
    }, [subscribe, toast]);

    // Listen for PIX payment confirmation via WebSocket
    useEffect(() => {
        const unsubPix = subscribe("pix_paid", (data: any) => {
            window.dispatchEvent(new CustomEvent("pix_paid", { detail: data }));
        });
        return () => { unsubPix(); };
    }, [subscribe]);

    useEffect(() => {
        if (!isConnected) return;
        queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
        queryClient.invalidateQueries({ queryKey: ["/api/credits"] });
    }, [isConnected, queryClient]);

    // Polling
    useEffect(() => {
        if (!generatedImage?.id || generatedImage?.status === "completed" || generatedImage?.status === "failed") return;
        let intervalId: NodeJS.Timeout;
        const timeoutId = setTimeout(() => {
            const poll = async () => {
                try {
                    const res = await fetch(`/api/generated-images/${generatedImage.id}`, { credentials: "include" });
                    if (res.ok) {
                        const data = await res.json();
                        if (data.status === "completed" || data.status === "failed") {
                            setGeneratedImage(data);
                            clearInterval(intervalId);
                        }
                    }
                } catch { }
            };
            poll();
            intervalId = setInterval(poll, 15000);
        }, 60000);
        return () => { clearTimeout(timeoutId); clearInterval(intervalId); };
    }, [generatedImage?.id, generatedImage?.status]);

    const processFile = async (file: File) => {
        const validationMessage = getUploadValidationMessage(file);
        if (validationMessage) {
            toast({ title: "Formato inválido", description: validationMessage, variant: "destructive" });
            return;
        }
        setIsUploading(true);
        try {
            const formData = new FormData();
            formData.append("image", file);
            const res = await fetch("/api/uploads/reference-image", { method: "POST", body: formData, credentials: "include" });
            if (!res.ok) {
                throw new Error(await getUploadErrorMessage(res, "Falha ao enviar foto."));
            }
            const data = await res.json();
            setReferenceImages([data.url]);
            setUploadedAspectRatio(data.aspectRatio || "1:1");
            setGeneratedImage(null);
        } catch (error) {
            toast({
                title: "Erro",
                description: error instanceof Error ? error.message : "Falha ao enviar foto.",
                variant: "destructive",
            });
        } finally {
            setIsUploading(false);
            if (fileInputRef.current) fileInputRef.current.value = "";
            if (cameraInputRef.current) cameraInputRef.current.value = "";
        }
    };

    const generateMutation = useMutation({
        mutationFn: async () => {
            const res = await apiRequest("POST", "/api/generated-images", {
                prompt: " ",
                model: "default",
                aspectRatio: uploadedAspectRatio,
                referenceImageUrls: referenceImages,
                quality: "high",
                quantity: 1,
            });
            return await res.json();
        },
        onSuccess: (data) => {
            const img = Array.isArray(data) ? data[0] : data;
            setGeneratedImage(img);
            queryClient.invalidateQueries({ queryKey: ["/api/credits"] });
            toast({ title: "Gerando...", description: "Sua imagem está sendo processada." });
        },
        onError: (error: any) => {
            toast({ title: "Erro", description: error.message || "Falha ao gerar", variant: "destructive" });
        },
    });

    const handleGenerate = () => {
        if (referenceImages.length === 0) return;
        generateMutation.mutate();
    };

    const handleCardClick = (card: FeatureCard) => {
        if (!card.active) return;
        if (card.id === "undress") {
            setShowUndressFlow(true);
            setReferenceImages([]);
            setGeneratedImage(null);
        }
    };

    const hasImage = referenceImages.length > 0;

    return (
        <div className="flex-1 w-full max-w-5xl mx-auto px-4 py-8">
            <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.heic,.heif" className="hidden" onChange={(e) => e.target.files?.[0] && processFile(e.target.files[0])} />
            <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => e.target.files?.[0] && processFile(e.target.files[0])} />

            {!showUndressFlow ? (
                <>
                    {/* Feature Cards Grid */}
                    <header className="mb-8">
                        <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
                            <Sparkles className="text-[#ff3b5c]" />
                            Painel
                        </h1>
                        <p className="text-white/40 mt-2 text-[15px]">Escolha o que você quer fazer.</p>
                    </header>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {featureCards.map((card) => (
                            <button
                                key={card.id}
                                onClick={() => handleCardClick(card)}
                                disabled={!card.active}
                                className={`relative flex flex-col items-start gap-3 p-5 rounded-2xl border transition-all duration-300 text-left group ${card.active
                                    ? "border-[#8c1229]/30 bg-gradient-to-br from-[#8c1229]/10 to-[#0a0204] hover:border-[#ff3b5c]/50 hover:shadow-[0_0_30px_rgba(140,18,41,0.15)] cursor-pointer"
                                    : "border-white/[0.06] bg-white/[0.02] cursor-not-allowed opacity-50"
                                    }`}
                            >
                                {!card.active && (
                                    <span className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/[0.06] border border-white/[0.08] text-[11px] text-white/40 font-medium">
                                        <Wrench className="w-3 h-3" />
                                        Em Manutenção
                                    </span>
                                )}
                                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${card.active ? "bg-[#8c1229]/20 text-[#ff3b5c]" : "bg-white/[0.04] text-white/20"
                                    }`}>
                                    <card.icon className="w-5 h-5" />
                                </div>
                                <div>
                                    <h3 className={`text-[15px] font-semibold ${card.active ? "text-white/90 group-hover:text-white" : "text-white/40"}`}>
                                        {card.label}
                                    </h3>
                                    <p className={`text-[13px] mt-0.5 ${card.active ? "text-white/40" : "text-white/20"}`}>
                                        {card.description}
                                    </p>
                                </div>
                            </button>
                        ))}
                    </div>
                </>
            ) : (
                <>
                    {/* Undress Flow */}
                    <header className="mb-6">
                        <button
                            onClick={() => { setShowUndressFlow(false); setReferenceImages([]); setGeneratedImage(null); }}
                            className="text-[13px] text-white/40 hover:text-white/70 transition-colors mb-2"
                        >
                            ← Voltar ao painel
                        </button>
                        <h1 className="text-2xl font-bold flex items-center gap-3">
                            <Eye className="text-[#ff3b5c]" />
                            Tirar Roupa
                        </h1>
                    </header>

                    <div className="max-w-sm mx-auto flex flex-col gap-5">
                        {/* Upload */}
                        <div
                            className={`relative w-full rounded-2xl border transition-all duration-300 cursor-pointer overflow-hidden shadow-xl ${isDragging
                                ? "border-[#c9a227]/60 bg-[#c9a227]/[0.04] scale-[1.01]"
                                : hasImage
                                    ? "border-white/10 bg-black/40"
                                    : "border-white/[0.08] bg-white/[0.02] hover:border-white/[0.15] hover:bg-white/[0.03]"
                                }`}
                            onClick={() => !hasImage && fileInputRef.current?.click()}
                            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                            onDragLeave={() => setIsDragging(false)}
                            onDrop={(e) => { e.preventDefault(); setIsDragging(false); if (e.dataTransfer.files.length > 0) processFile(e.dataTransfer.files[0]); }}
                        >
                            {!hasImage ? (
                                <div className="flex flex-col items-center justify-center gap-3 py-14 px-6">
                                    {isUploading ? (
                                        <Loader2 className="w-6 h-6 text-white/40 animate-spin" />
                                    ) : (
                                        <>
                                            <div className="w-11 h-11 rounded-full bg-white/[0.06] flex items-center justify-center">
                                                <Upload className="w-5 h-5 text-white/50" />
                                            </div>
                                            <p className="text-[15px] text-white/50">Envie a foto dela</p>
                                            <p className="text-xs text-white/20">100% anônimo e seguro.</p>
                                            <button
                                                type="button"
                                                onClick={(e) => { e.stopPropagation(); cameraInputRef.current?.click(); }}
                                                className="md:hidden mt-1 flex items-center gap-2 px-4 py-2 rounded-full bg-white/[0.05] border border-white/[0.10] text-white/50 hover:text-white/80 hover:border-white/20 text-[13px] font-medium transition-all"
                                            >
                                                <Camera className="w-4 h-4" />
                                                Tirar foto
                                            </button>
                                        </>
                                    )}
                                </div>
                            ) : (
                                <div className="relative group">
                                    <div className="aspect-[3/4] w-full bg-black/50">
                                        <img
                                            src={referenceImages[0]}
                                            alt="Foto enviada"
                                            className="w-full h-full object-cover"
                                            decoding="async"
                                        />
                                    </div>
                                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                        <button
                                            onClick={(e) => { e.stopPropagation(); setReferenceImages([]); setGeneratedImage(null); }}
                                            className="px-5 py-2 text-sm text-white/90 bg-white/10 hover:bg-white/15 backdrop-blur-sm border border-white/15 rounded-full transition-colors"
                                        >
                                            Trocar foto
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Generate button */}
                        <button
                            disabled={!hasImage || generateMutation.isPending}
                            onClick={handleGenerate}
                            className={`w-full py-4 rounded-[14px] text-[15px] font-semibold tracking-wide transition-all duration-500 relative group overflow-hidden ${!hasImage || generateMutation.isPending
                                ? "bg-white/[0.03] text-white/20 cursor-not-allowed border border-white/[0.02]"
                                : "bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white hover:from-[#a61530] hover:to-[#6b0d1e] active:scale-[0.98] shadow-[0_0_30px_rgba(140,18,41,0.25)] border border-[#ff3b5c]/20"
                                }`}
                        >
                            {generateMutation.isPending ? (
                                <span className="flex items-center justify-center gap-2">
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                    Gerando...
                                </span>
                            ) : (
                                <span className="relative z-10">GERAR IMAGEM</span>
                            )}
                        </button>

                        {/* Result */}
                        {generatedImage && (
                            <div className="w-full rounded-2xl overflow-hidden border border-[#8c1229]/20 shadow-2xl animate-in fade-in">
                                {generatedImage.status === "completed" ? (
                                    <img
                                        src={`/api/generated-images/${generatedImage.id}/image?_cb=revealed`}
                                        alt="Resultado"
                                        className="w-full object-cover"
                                        decoding="async"
                                    />
                                ) : generatedImage.status === "failed" ? (
                                    <div className="p-8 text-center text-white/40">
                                        <p>Falha na geração.</p>
                                        <p className="text-xs mt-1">{generatedImage.errorMessage}</p>
                                    </div>
                                ) : (
                                    <div className="aspect-[3/4] flex items-center justify-center bg-black/50">
                                        <div className="flex flex-col items-center gap-4">
                                            <div className="w-12 h-12 rounded-full border-2 border-[#8c1229]/20 border-t-[#8c1229] animate-spin" />
                                            <p className="text-sm text-white/60 animate-pulse">Processando...</p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </>
            )}

            {/* Modals */}
            <CreditsPopup
                open={creditsPopupOpen}
                onClose={() => setCreditsPopupOpen(false)}
                onSelectPlan={(planId) => { setSelectedPlanId(planId); setCreditsPopupOpen(false); setPixModalOpen(true); }}
            />
            <PixQrModal
                open={pixModalOpen}
                onClose={() => setPixModalOpen(false)}
                planId={selectedPlanId}
                redirectAfterPaymentTo="/upsell/instapro"
                onPaymentSuccess={(paymentData?: any) => {
                    // Optimistic update: show new balance immediately
                    const current = queryClient.getQueryData<{ balance: number }>(["/api/credits"]);
                    const newBalance = (current?.balance ?? 0) + (paymentData?.creditAmount ?? 0);
                    queryClient.setQueryData(["/api/credits"], { balance: newBalance });
                    // Then reconcile with server
                    queryClient.invalidateQueries({ queryKey: ["/api/credits"] });
                    queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
                }}
            />
        </div>
    );
}
