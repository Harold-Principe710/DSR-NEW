import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn, queryClient } from "@/lib/queryClient";

type AdminMe = { authenticated: boolean; username: string };

export default function AdminLoginPage() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const { data: adminMe, isLoading } = useQuery<AdminMe | null>({
    queryKey: ["/api/admin/me"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    retry: false,
  });

  useEffect(() => {
    if (adminMe?.authenticated) setLocation("/admin");
  }, [adminMe, setLocation]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        setError(data?.message || "Falha no login admin");
        return;
      }
      queryClient.setQueryData(["/api/admin/me"], {
        authenticated: true,
        username: data?.username || username,
      } satisfies AdminMe);
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/me"] });
      setLocation("/admin");
    } catch {
      setError("Erro de conexão");
    } finally {
      setLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#050102] flex items-center justify-center text-white/70">
        Carregando...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#050102] to-[#11040a] text-white flex items-center justify-center px-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm rounded-2xl border border-[#8c1229]/30 bg-black/40 p-6 space-y-4"
      >
        <div>
          <h1 className="text-xl font-semibold">Admin DesireAI</h1>
          <p className="text-sm text-white/40 mt-1">Acesso restrito</p>
        </div>
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Usuário"
          className="w-full rounded-lg bg-white/5 border border-white/10 px-3 py-2 outline-none focus:border-[#8c1229]/70"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Senha"
          className="w-full rounded-lg bg-white/5 border border-white/10 px-3 py-2 outline-none focus:border-[#8c1229]/70"
        />
        {error && <p className="text-sm text-[#ff7c94]">{error}</p>}
        <button
          disabled={loading || !username || !password}
          className="w-full rounded-lg bg-gradient-to-r from-[#8c1229] to-[#520a17] py-2.5 font-medium disabled:opacity-50"
        >
          {loading ? "Entrando..." : "Entrar"}
        </button>
      </form>
    </div>
  );
}
