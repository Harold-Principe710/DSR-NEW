import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Settings, User, KeyRound, Trash2, UserX, LogOut, Loader2, X } from "lucide-react";
import { useFunnelPageView } from "@/hooks/use-funnel-page-view";

type ModalType = "username" | "password" | "clear-history" | "deactivate" | "logout" | null;

export default function AppSettings() {
    useFunnelPageView("app_settings", "app.settings_viewed");
    const { toast } = useToast();
    const [activeModal, setActiveModal] = useState<ModalType>(null);
    const [loading, setLoading] = useState(false);

    // Username
    const [newUsername, setNewUsername] = useState("");
    // Password
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmNewPassword, setConfirmNewPassword] = useState("");

    const settingsItems = [
        { id: "username" as ModalType, label: "Mudar username", description: "Altere seu nome de exibição", icon: User },
        { id: "password" as ModalType, label: "Mudar senha", description: "Atualize sua senha de acesso", icon: KeyRound },
        { id: "clear-history" as ModalType, label: "Limpar histórico", description: "Apagar todas as mídias da galeria", icon: Trash2, danger: false },
        { id: "deactivate" as ModalType, label: "Deletar conta", description: "Sua conta será desativada permanentemente", icon: UserX, danger: true },
        { id: "logout" as ModalType, label: "Sair", description: "Encerrar sessão e voltar ao login", icon: LogOut },
    ];

    const handleLogout = async () => {
        await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
        window.location.href = "/login";
    };

    const handleAction = async () => {
        setLoading(true);
        try {
            if (activeModal === "username") {
                if (!newUsername || newUsername.length < 3) {
                    toast({ title: "Erro", description: "Username deve ter pelo menos 3 caracteres", variant: "destructive" });
                    return;
                }
                const res = await fetch("/api/user/username", {
                    method: "PATCH",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ username: newUsername }),
                    credentials: "include",
                });
                const data = await res.json();
                if (!res.ok) throw new Error(data.message);
                toast({ title: "Username atualizado!" });
                setActiveModal(null);
                setNewUsername("");
            }

            if (activeModal === "password") {
                if (newPassword.length < 6) {
                    toast({ title: "Erro", description: "Nova senha deve ter pelo menos 6 caracteres", variant: "destructive" });
                    return;
                }
                if (newPassword !== confirmNewPassword) {
                    toast({ title: "Erro", description: "As senhas não coincidem", variant: "destructive" });
                    return;
                }
                const res = await fetch("/api/user/password", {
                    method: "PATCH",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ currentPassword, newPassword }),
                    credentials: "include",
                });
                const data = await res.json();
                if (!res.ok) throw new Error(data.message);
                toast({ title: "Senha alterada com sucesso!" });
                setActiveModal(null);
                setCurrentPassword("");
                setNewPassword("");
                setConfirmNewPassword("");
            }

            if (activeModal === "clear-history") {
                const res = await fetch("/api/user/clear-history", {
                    method: "POST",
                    credentials: "include",
                });
                if (!res.ok) throw new Error("Falha ao limpar");
                toast({ title: "Histórico limpo!" });
                setActiveModal(null);
            }

            if (activeModal === "deactivate") {
                const res = await fetch("/api/user/deactivate", {
                    method: "POST",
                    credentials: "include",
                });
                if (!res.ok) throw new Error("Falha ao desativar");
                window.location.href = "/login";
            }
        } catch (err: any) {
            toast({ title: "Erro", description: err.message || "Operação falhou", variant: "destructive" });
        } finally {
            setLoading(false);
        }
    };

    const handleClickItem = (id: ModalType) => {
        if (id === "logout") {
            handleLogout();
            return;
        }
        setActiveModal(id);
    };

    return (
        <div className="flex-1 w-full max-w-2xl mx-auto px-4 py-8">
            <header className="mb-8">
                <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
                    <Settings className="text-[#ff3b5c]" />
                    Configurações
                </h1>
                <p className="text-white/40 mt-2 text-[15px]">Gerencie sua conta e preferências.</p>
            </header>

            <div className="flex flex-col gap-2">
                {settingsItems.map((item) => (
                    <button
                        key={item.id}
                        onClick={() => handleClickItem(item.id)}
                        className={`flex items-center gap-4 p-4 rounded-xl border transition-all duration-200 text-left group ${item.danger
                            ? "border-red-500/10 bg-red-500/[0.02] hover:border-red-500/30 hover:bg-red-500/[0.05]"
                            : "border-white/[0.06] bg-white/[0.02] hover:border-white/[0.12] hover:bg-white/[0.04]"
                            }`}
                    >
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${item.danger ? "bg-red-500/10 text-red-400" : "bg-white/[0.04] text-white/40 group-hover:text-white/60"
                            }`}>
                            <item.icon className="w-4 h-4" />
                        </div>
                        <div>
                            <span className={`text-[15px] font-medium block ${item.danger ? "text-red-400" : "text-white/80 group-hover:text-white"}`}>
                                {item.label}
                            </span>
                            <span className={`text-[12px] ${item.danger ? "text-red-400/50" : "text-white/30"}`}>
                                {item.description}
                            </span>
                        </div>
                    </button>
                ))}
            </div>

            {/* Modal */}
            {activeModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in p-4" onClick={() => setActiveModal(null)}>
                    <div className="w-full max-w-sm rounded-2xl border border-[#8c1229]/20 bg-[#0a0204] p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-between mb-5">
                            <h3 className="text-lg font-semibold text-white/90">
                                {activeModal === "username" && "Mudar username"}
                                {activeModal === "password" && "Mudar senha"}
                                {activeModal === "clear-history" && "Limpar histórico"}
                                {activeModal === "deactivate" && "Deletar conta"}
                            </h3>
                            <button onClick={() => setActiveModal(null)} className="text-white/30 hover:text-white/60">
                                <X className="w-5 h-5" />
                            </button>
                        </div>

                        {activeModal === "username" && (
                            <div className="flex flex-col gap-4">
                                <input
                                    type="text"
                                    value={newUsername}
                                    onChange={(e) => setNewUsername(e.target.value.replace(/[^a-zA-Z0-9._]/g, "").slice(0, 20))}
                                    placeholder="Novo username"
                                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 transition-all"
                                />
                            </div>
                        )}

                        {activeModal === "password" && (
                            <div className="flex flex-col gap-3">
                                <input
                                    type="password"
                                    value={currentPassword}
                                    onChange={(e) => setCurrentPassword(e.target.value)}
                                    placeholder="Senha atual"
                                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 transition-all"
                                />
                                <input
                                    type="password"
                                    value={newPassword}
                                    onChange={(e) => setNewPassword(e.target.value.slice(0, 40))}
                                    placeholder="Nova senha (mín. 6 caracteres)"
                                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 transition-all"
                                />
                                <input
                                    type="password"
                                    value={confirmNewPassword}
                                    onChange={(e) => setConfirmNewPassword(e.target.value.slice(0, 40))}
                                    placeholder="Confirme a nova senha"
                                    className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 transition-all"
                                />
                            </div>
                        )}

                        {activeModal === "clear-history" && (
                            <p className="text-[14px] text-white/50 leading-relaxed">
                                Isso vai apagar <span className="font-semibold text-white/70">todas as suas imagens</span> geradas. Esta ação não pode ser desfeita.
                            </p>
                        )}

                        {activeModal === "deactivate" && (
                            <p className="text-[14px] text-red-400/70 leading-relaxed">
                                Sua conta será <span className="font-semibold text-red-400">permanentemente desativada</span>. Você não poderá mais fazer login. Esta ação não pode ser desfeita.
                            </p>
                        )}

                        <div className="flex gap-3 mt-6">
                            <button
                                onClick={() => setActiveModal(null)}
                                className="flex-1 py-3 rounded-xl text-[14px] font-medium bg-white/[0.04] border border-white/[0.06] text-white/50 hover:text-white/70 hover:bg-white/[0.06] transition-all"
                            >
                                Cancelar
                            </button>
                            <button
                                onClick={handleAction}
                                disabled={loading}
                                className={`flex-1 py-3 rounded-xl text-[14px] font-semibold transition-all ${activeModal === "deactivate"
                                    ? "bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30"
                                    : "bg-gradient-to-r from-[#8c1229] to-[#520a17] border border-[#ff3b5c]/20 text-white hover:from-[#a61530] hover:to-[#6b0d1e]"
                                    }`}
                            >
                                {loading ? (
                                    <Loader2 className="w-4 h-4 animate-spin mx-auto" />
                                ) : (
                                    activeModal === "deactivate" ? "Sim, deletar" : "Confirmar"
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
