import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  CheckCircle2,
  CreditCard,
  FlaskConical,
  LogOut,
  PauseCircle,
  Plus,
  RefreshCw,
  Save,
  SlidersHorizontal,
  XCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { formatShortDateTimeInAppTimeZone } from "@/lib/timezone";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

type GatewayStatus = "active" | "paused";
type GatewayProvider = "blackcat" | "woovi" | "custom";
type GatewayTestStatus = "active" | "paused" | "ended";

type PaymentGateway = {
  id: string;
  name: string;
  slug: string;
  provider: GatewayProvider;
  status: GatewayStatus;
  description: string | null;
  createdAt: string | null;
  updatedAt: string | null;
  generated: number;
  converted: number;
  paid: number;
  activePaid: number;
  refunded: number;
  chargedback: number;
  conversionRate: number;
  revenueCents: number;
  refundedCents: number;
  netRevenueCents: number;
  lastCreatedAt: string | null;
};

type PaymentGatewayTestVariant = {
  id: string;
  testId: string;
  gatewayId: string;
  name: string;
  weight: number;
  visits: number;
  createdAt: string | null;
  gateway: PaymentGateway | null;
  generated: number;
  converted: number;
  paid: number;
  refunded: number;
  chargedback: number;
  conversionRate: number;
  revenueCents: number;
  refundedCents: number;
  netRevenueCents: number;
};

type PaymentGatewayTest = {
  id: string;
  name: string;
  slug: string;
  status: GatewayTestStatus;
  createdAt: string | null;
  updatedAt: string | null;
  variants: PaymentGatewayTestVariant[];
};

type PaymentGatewayTransaction = {
  id: string;
  pixPaymentId: string;
  gatewayId: string | null;
  provider: string;
  providerTransactionId: string | null;
  externalReference: string;
  status: "pending" | "paid" | "failed" | "expired" | "cancelled" | "refunded" | "chargedback";
  amountCents: number;
  planId: string | null;
  lastEvent: string | null;
  createdAt: string | null;
  paidAt: string | null;
  errorMessage: string | null;
  gateway: { id: string; name: string; slug: string } | null;
  test: { id: string; name: string; slug: string } | null;
  variant: { id: string; name: string } | null;
  fallbackReason: string | null;
  fallbackDetail: string | null;
  attemptedGatewaySlug: string | null;
  attemptedGatewayProvider: string | null;
  failedGatewayTransactionId: string | null;
  failedPixPaymentId: string | null;
};

type GatewayResponse = {
  dateFrom: string;
  dateTo: string;
  gateways: PaymentGateway[];
  tests: PaymentGatewayTest[];
  fallback: {
    generated: number;
    converted: number;
    paid: number;
    refunded: number;
    chargedback: number;
    conversionRate: number;
    revenueCents: number;
    refundedCents: number;
    netRevenueCents: number;
    failedGatewayAttempts: number;
  };
  recentTransactions: PaymentGatewayTransaction[];
  diagnostics?: {
    degraded: boolean;
    errors: Array<{
      scope: string;
      message: string;
      code: string | null;
    }>;
  };
};

type Preset = "today" | "yesterday" | "7d" | "30d";

const PRESETS: Array<{ value: Preset; label: string }> = [
  { value: "today", label: "Hoje" },
  { value: "yesterday", label: "Ontem" },
  { value: "7d", label: "7 dias" },
  { value: "30d", label: "30 dias" },
];

const statusLabel: Record<GatewayStatus | GatewayTestStatus, string> = {
  active: "Ativo",
  paused: "Pausado",
  ended: "Encerrado",
};

const transactionStatusLabel: Record<PaymentGatewayTransaction["status"], string> = {
  pending: "Pendente",
  paid: "Pago",
  failed: "Falhou",
  expired: "Expirado",
  cancelled: "Cancelado",
  refunded: "Reembolsado",
  chargedback: "Chargeback",
};

const brlFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

const numberFormatter = new Intl.NumberFormat("pt-BR");

function formatMoneyFromCents(value: number | null | undefined) {
  return brlFormatter.format((value ?? 0) / 100);
}

function formatPercent(value: number | null | undefined) {
  return `${((value ?? 0) * 100).toFixed(1)}%`;
}

function formatNumber(value: number | null | undefined) {
  return numberFormatter.format(value ?? 0);
}

function formatDate(value: string | null | undefined) {
  return formatShortDateTimeInAppTimeZone(value).replace("—", "-");
}

function formatShortId(value: string | null | undefined) {
  if (!value) return "-";
  return value.length > 18 ? `${value.slice(0, 10)}...${value.slice(-6)}` : value;
}

function getFallbackReasonLabel(reason: string | null | undefined) {
  if (reason === "gateway_timeout") return "Timeout do gateway";
  if (reason === "gateway_create_failed") return "Falha no gateway";
  if (reason === "gateway_unavailable") return "Gateway indisponível";
  return reason || null;
}

function getTransactionProviderLabel(transaction: PaymentGatewayTransaction) {
  if (transaction.provider === "legacy-fallback") return "Fallback legado";
  if (transaction.gateway) return `${transaction.gateway.name} (${transaction.gateway.slug})`;
  return transaction.provider;
}

function slugify(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
}

function StatusBadge({ status }: { status: GatewayStatus | GatewayTestStatus }) {
  return (
    <Badge
      variant="outline"
      className={cn(
        "rounded-md border px-2 py-1 text-xs",
        status === "active" && "border-emerald-500/30 bg-emerald-500/10 text-emerald-100",
        status === "paused" && "border-amber-500/30 bg-amber-500/10 text-amber-100",
        status === "ended" && "border-white/10 bg-white/[0.04] text-white/55",
      )}
    >
      {statusLabel[status]}
    </Badge>
  );
}

function TransactionStatusBadge({ status }: { status: PaymentGatewayTransaction["status"] }) {
  return (
    <span
      className={cn(
        "inline-flex rounded-md border px-2 py-1 text-xs",
        status === "paid" && "border-emerald-500/30 bg-emerald-500/10 text-emerald-100",
        status === "pending" && "border-sky-500/30 bg-sky-500/10 text-sky-100",
        status !== "paid" && status !== "pending" && "border-rose-500/30 bg-rose-500/10 text-rose-100",
      )}
    >
      {transactionStatusLabel[status]}
    </span>
  );
}

function MetricCard({
  label,
  value,
  detail,
  icon: Icon,
  tone = "neutral",
}: {
  label: string;
  value: string;
  detail: string;
  icon: typeof CreditCard;
  tone?: "neutral" | "brand" | "success" | "warning";
}) {
  return (
    <div className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase text-white/[0.42]">{label}</p>
          <p className="mt-2 text-2xl font-semibold tracking-normal text-white tabular-nums">{value}</p>
        </div>
        <div
          className={cn(
            "flex h-9 w-9 shrink-0 items-center justify-center rounded-md border",
            tone === "neutral" && "border-white/10 bg-white/[0.04] text-white/65",
            tone === "brand" && "border-[#8c1229]/35 bg-[#8c1229]/15 text-[#ffdbe2]",
            tone === "success" && "border-emerald-500/25 bg-emerald-500/10 text-emerald-100",
            tone === "warning" && "border-amber-500/25 bg-amber-500/10 text-amber-100",
          )}
        >
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <p className="mt-3 min-h-5 text-sm text-white/50">{detail}</p>
    </div>
  );
}

function GatewayCreateForm({ gateways }: { gateways: PaymentGateway[] }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [provider, setProvider] = useState<GatewayProvider>("custom");
  const [description, setDescription] = useState("");

  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/payment-gateways", {
        name,
        slug,
        provider,
        status: "active",
        description: description.trim() || null,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Gateway cadastrado", description: "O provedor já pode entrar em um teste A/B." });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-gateways"] });
      setName("");
      setSlug("");
      setProvider("custom");
      setDescription("");
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao cadastrar gateway", description: error.message, variant: "destructive" });
    },
  });

  const formValid = name.trim().length > 0 && /^[a-z0-9][a-z0-9-]*$/.test(slug);
  const existingSlug = gateways.some((gateway) => gateway.slug === slug);

  return (
    <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase text-white/[0.42]">Integrações</p>
          <h2 className="mt-1 text-lg font-semibold tracking-normal text-white">Novo gateway</h2>
        </div>
        <div className="flex h-9 w-9 items-center justify-center rounded-md border border-[#8c1229]/35 bg-[#8c1229]/15 text-[#ffdbe2]">
          <Plus className="h-4 w-4" />
        </div>
      </div>

      <div className="mt-4 grid gap-3">
        <label className="grid gap-1 text-sm">
          <span className="text-white/55">Nome</span>
          <Input
            value={name}
            onChange={(event) => {
              const next = event.target.value;
              setName(next);
              if (!slug) setSlug(slugify(next));
            }}
            placeholder="Gateway principal"
            className="border-white/10 bg-black/25 text-white"
          />
        </label>

        <div className="grid gap-3 sm:grid-cols-2">
          <label className="grid gap-1 text-sm">
            <span className="text-white/55">Slug</span>
            <Input
              value={slug}
              onChange={(event) => setSlug(slugify(event.target.value))}
              placeholder="gateway-principal"
              className="border-white/10 bg-black/25 text-white"
            />
          </label>
          <label className="grid gap-1 text-sm">
            <span className="text-white/55">Provider</span>
            <select
              value={provider}
              onChange={(event) => setProvider(event.target.value as GatewayProvider)}
              className="min-h-10 rounded-md border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:border-[#8c1229]"
            >
              <option value="custom">Customizado</option>
              <option value="woovi">Woovi/OpenPix</option>
              <option value="blackcat">BlackCat</option>
            </select>
          </label>
        </div>

        <label className="grid gap-1 text-sm">
          <span className="text-white/55">Descrição interna</span>
          <Input
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            placeholder="Conta, rota ou observação operacional"
            className="border-white/10 bg-black/25 text-white"
          />
        </label>

        {existingSlug ? <p className="text-xs text-amber-200">Este slug já está cadastrado.</p> : null}

        <Button
          type="button"
          onClick={() => createMutation.mutate()}
          disabled={!formValid || existingSlug || createMutation.isPending}
          className="border border-[#8c1229] bg-[#8c1229] text-white hover:bg-[#a61530]"
        >
          <Plus className="h-4 w-4" />
          {createMutation.isPending ? "Cadastrando" : "Cadastrar gateway"}
        </Button>
      </div>
    </section>
  );
}

function GatewayRow({ gateway }: { gateway: PaymentGateway }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const nextStatus: GatewayStatus = gateway.status === "active" ? "paused" : "active";

  const updateMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/admin/payment-gateways/${gateway.id}`, { status: nextStatus });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-gateways"] });
    },
    onError: (error: Error) => toast({ title: "Erro ao atualizar gateway", description: error.message, variant: "destructive" }),
  });

  return (
    <tr className="border-t border-white/[0.06]">
      <td className="px-3 py-3">
        <div className="font-medium text-white">{gateway.name}</div>
        <div className="mt-0.5 text-xs text-white/45">{gateway.slug}</div>
      </td>
      <td className="px-3 py-3 text-white/60">{gateway.provider}</td>
      <td className="px-3 py-3"><StatusBadge status={gateway.status} /></td>
      <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatNumber(gateway.generated)}</td>
      <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatNumber(gateway.paid)}</td>
      <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatNumber(gateway.refunded + gateway.chargedback)}</td>
      <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatPercent(gateway.conversionRate)}</td>
      <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatMoneyFromCents(gateway.netRevenueCents)}</td>
      <td className="px-3 py-3 text-right">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => updateMutation.mutate()}
          disabled={updateMutation.isPending}
          className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
        >
          {gateway.status === "active" ? <PauseCircle className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
          {gateway.status === "active" ? "Pausar" : "Ativar"}
        </Button>
      </td>
    </tr>
  );
}

function CreateTestPanel({ gateways }: { gateways: PaymentGateway[] }) {
  const activeGateways = gateways.filter((gateway) => gateway.status === "active");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [selectedGatewayIds, setSelectedGatewayIds] = useState<string[]>([]);
  const [weights, setWeights] = useState<Record<string, number>>({});

  useEffect(() => {
    if (selectedGatewayIds.length > 0 || activeGateways.length < 2) return;
    const initial = activeGateways.slice(0, 2).map((gateway) => gateway.id);
    setSelectedGatewayIds(initial);
    setWeights(Object.fromEntries(initial.map((gatewayId) => [gatewayId, 50])));
  }, [activeGateways, selectedGatewayIds.length]);

  const totalWeight = useMemo(
    () => selectedGatewayIds.reduce((sum, gatewayId) => sum + Number(weights[gatewayId] || 0), 0),
    [selectedGatewayIds, weights],
  );

  const distributeEvenly = () => {
    if (selectedGatewayIds.length === 0) return;
    const each = Math.floor(10000 / selectedGatewayIds.length) / 100;
    const remainder = 100 - each * selectedGatewayIds.length;
    setWeights(Object.fromEntries(selectedGatewayIds.map((gatewayId, index) => [
      gatewayId,
      index === selectedGatewayIds.length - 1 ? Math.round((each + remainder) * 100) / 100 : each,
    ])));
  };

  const toggleGateway = (gatewayId: string) => {
    setSelectedGatewayIds((prev) => {
      const exists = prev.includes(gatewayId);
      const next = exists ? prev.filter((id) => id !== gatewayId) : [...prev, gatewayId];
      if (!exists) {
        setWeights((current) => ({ ...current, [gatewayId]: 0 }));
      }
      return next;
    });
  };

  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/payment-gateway-tests", {
        name,
        slug,
        status: "active",
        variants: selectedGatewayIds.map((gatewayId) => {
          const gateway = activeGateways.find((item) => item.id === gatewayId);
          return {
            gatewayId,
            name: gateway?.name || "Gateway",
            weight: Number(weights[gatewayId] || 0),
          };
        }),
      });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Teste de gateways criado", description: "Novos PIX já entram na distribuição configurada." });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-gateways"] });
      setName("");
      setSlug("");
      setSelectedGatewayIds([]);
      setWeights({});
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao criar teste", description: error.message, variant: "destructive" });
    },
  });

  const formValid =
    name.trim().length > 0 &&
    /^[a-z0-9][a-z0-9-]*$/.test(slug) &&
    selectedGatewayIds.length >= 2 &&
    Math.abs(totalWeight - 100) < 0.01;

  return (
    <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase text-white/[0.42]">Roteamento</p>
          <h2 className="mt-1 text-lg font-semibold tracking-normal text-white">Novo teste A/B de gateway</h2>
        </div>
        <div className="flex h-9 w-9 items-center justify-center rounded-md border border-sky-500/25 bg-sky-500/10 text-sky-100">
          <FlaskConical className="h-4 w-4" />
        </div>
      </div>

      <div className="mt-4 grid gap-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="grid gap-1 text-sm">
            <span className="text-white/55">Nome</span>
            <Input
              value={name}
              onChange={(event) => {
                const next = event.target.value;
                setName(next);
                if (!slug) setSlug(slugify(next));
              }}
              placeholder="Gateway A vs Gateway B"
              className="border-white/10 bg-black/25 text-white"
            />
          </label>
          <label className="grid gap-1 text-sm">
            <span className="text-white/55">Slug</span>
            <Input
              value={slug}
              onChange={(event) => setSlug(slugify(event.target.value))}
              placeholder="gateway-a-vs-gateway-b"
              className="border-white/10 bg-black/25 text-white"
            />
          </label>
        </div>

        <div className="space-y-2">
          {activeGateways.length < 2 ? (
            <p className="rounded-md border border-amber-500/25 bg-amber-500/10 p-3 text-sm text-amber-100">
              Cadastre e ative pelo menos dois gateways para criar um teste.
            </p>
          ) : (
            activeGateways.map((gateway) => {
              const selected = selectedGatewayIds.includes(gateway.id);
              return (
                <div key={gateway.id} className="rounded-md border border-white/10 bg-black/20 p-3">
                  <label className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={selected}
                      onChange={() => toggleGateway(gateway.id)}
                      className="h-4 w-4 rounded border-white/20 bg-black accent-[#8c1229]"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-medium text-white">{gateway.name}</span>
                      <span className="block text-xs text-white/45">{gateway.slug}</span>
                    </span>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      step={0.01}
                      value={weights[gateway.id] ?? 0}
                      onChange={(event) => setWeights((current) => ({ ...current, [gateway.id]: Number(event.target.value) }))}
                      disabled={!selected}
                      className="h-9 w-24 border-white/10 bg-black/25 text-right text-white"
                    />
                    <span className="text-xs text-white/45">%</span>
                  </label>
                </div>
              );
            })
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className={cn("text-xs", Math.abs(totalWeight - 100) < 0.01 ? "text-emerald-200" : "text-amber-200")}>
            Soma dos pesos: {totalWeight.toFixed(2)}%
          </span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={distributeEvenly}
            disabled={selectedGatewayIds.length < 2}
            className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
          >
            <SlidersHorizontal className="h-4 w-4" />
            Dividir igualmente
          </Button>
        </div>

        <Button
          type="button"
          onClick={() => createMutation.mutate()}
          disabled={!formValid || createMutation.isPending}
          className="border border-[#8c1229] bg-[#8c1229] text-white hover:bg-[#a61530]"
        >
          <FlaskConical className="h-4 w-4" />
          {createMutation.isPending ? "Criando" : "Criar teste"}
        </Button>
      </div>
    </section>
  );
}

function GatewayTestPanel({ test }: { test: PaymentGatewayTest }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [weights, setWeights] = useState<Record<string, number>>(
    () => Object.fromEntries(test.variants.map((variant) => [variant.id, variant.weight])),
  );

  useEffect(() => {
    setWeights(Object.fromEntries(test.variants.map((variant) => [variant.id, variant.weight])));
  }, [test.id, test.variants]);

  const totalWeight = test.variants.reduce((sum, variant) => sum + Number(weights[variant.id] || 0), 0);

  const updateMutation = useMutation({
    mutationFn: async (payload: { status?: GatewayTestStatus; variants?: Array<{ id: string; weight: number }> }) => {
      const res = await apiRequest("PATCH", `/api/admin/payment-gateway-tests/${test.id}`, payload);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Teste atualizado" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-gateways"] });
    },
    onError: (error: Error) => toast({ title: "Erro ao atualizar teste", description: error.message, variant: "destructive" }),
  });

  const saveWeights = () => {
    updateMutation.mutate({
      variants: test.variants.map((variant) => ({ id: variant.id, weight: Number(weights[variant.id] || 0) })),
    });
  };

  return (
    <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-semibold text-white">{test.name}</h3>
            <StatusBadge status={test.status} />
          </div>
          <p className="mt-1 text-sm text-white/45">{test.slug}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {test.status === "active" ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => updateMutation.mutate({ status: "paused" })}
              disabled={updateMutation.isPending}
              className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
            >
              <PauseCircle className="h-4 w-4" />
              Pausar
            </Button>
          ) : null}
          {test.status === "paused" ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => updateMutation.mutate({ status: "active" })}
              disabled={updateMutation.isPending}
              className="border-emerald-500/25 bg-emerald-500/10 text-emerald-100 hover:bg-emerald-500/15"
            >
              <CheckCircle2 className="h-4 w-4" />
              Ativar
            </Button>
          ) : null}
          {test.status !== "ended" ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => updateMutation.mutate({ status: "ended" })}
              disabled={updateMutation.isPending}
              className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
            >
              <XCircle className="h-4 w-4" />
              Encerrar
            </Button>
          ) : null}
        </div>
      </div>

      <div className="mt-4 overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase text-white/42">
              <th className="px-3 py-2">Variante</th>
              <th className="px-3 py-2 text-right">Peso</th>
              <th className="px-3 py-2 text-right">PIX gerados</th>
              <th className="px-3 py-2 text-right">Pagos no período</th>
              <th className="px-3 py-2 text-right">Reembolsos</th>
              <th className="px-3 py-2 text-right">Conversão gerada</th>
              <th className="px-3 py-2 text-right">Receita líquida</th>
            </tr>
          </thead>
          <tbody>
            {test.variants.map((variant) => (
              <tr key={variant.id} className="border-t border-white/[0.06]">
                <td className="px-3 py-3">
                  <div className="font-medium text-white">{variant.name}</div>
                  <div className="text-xs text-white/45">{variant.gateway?.slug ?? "gateway removido"}</div>
                </td>
                <td className="px-3 py-3">
                  <div className="ml-auto flex max-w-[180px] items-center justify-end gap-2">
                    <input
                      type="range"
                      min={0}
                      max={100}
                      step={0.01}
                      value={weights[variant.id] ?? 0}
                      onChange={(event) => setWeights((current) => ({ ...current, [variant.id]: Number(event.target.value) }))}
                      className="w-24 accent-[#8c1229]"
                    />
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      step={0.01}
                      value={weights[variant.id] ?? 0}
                      onChange={(event) => setWeights((current) => ({ ...current, [variant.id]: Number(event.target.value) }))}
                      className="h-8 w-20 border-white/10 bg-black/25 text-right text-white"
                    />
                  </div>
                </td>
                <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatNumber(variant.generated)}</td>
                <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatNumber(variant.paid)}</td>
                <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatNumber(variant.refunded + variant.chargedback)}</td>
                <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatPercent(variant.conversionRate)}</td>
                <td className="px-3 py-3 text-right tabular-nums text-white/75">{formatMoneyFromCents(variant.netRevenueCents)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
        <span className={cn("text-xs", Math.abs(totalWeight - 100) < 0.01 ? "text-emerald-200" : "text-amber-200")}>
          Soma dos pesos: {totalWeight.toFixed(2)}%
        </span>
        <Button
          type="button"
          size="sm"
          onClick={saveWeights}
          disabled={Math.abs(totalWeight - 100) >= 0.01 || updateMutation.isPending}
          className="border border-[#8c1229] bg-[#8c1229] text-white hover:bg-[#a61530]"
        >
          <Save className="h-4 w-4" />
          Salvar pesos
        </Button>
      </div>
    </section>
  );
}

export default function AdminPaymentGatewaysPage() {
  const [, setLocation] = useLocation();
  const [preset, setPreset] = useState<Preset>("7d");

  const queryString = useMemo(() => {
    const params = new URLSearchParams();
    params.set("preset", preset);
    return params.toString();
  }, [preset]);

  const gatewayQuery = useQuery<GatewayResponse>({
    queryKey: ["/api/admin/payment-gateways", queryString],
    queryFn: async () => {
      const res = await fetch(`/api/admin/payment-gateways?${queryString}`, { credentials: "include" });
      if (res.status === 401) {
        setLocation("/admin/login");
        throw new Error("unauthorized");
      }
      if (!res.ok) throw new Error("Erro ao carregar gateways");
      return res.json();
    },
    staleTime: 30_000,
  });

  const handleLogout = async () => {
    await fetch("/api/admin/logout", { method: "POST", credentials: "include" });
    setLocation("/admin/login");
  };

  const gateways = gatewayQuery.data?.gateways ?? [];
  const fallback = gatewayQuery.data?.fallback ?? {
    generated: 0,
    converted: 0,
    paid: 0,
    refunded: 0,
    chargedback: 0,
    conversionRate: 0,
    revenueCents: 0,
    refundedCents: 0,
    netRevenueCents: 0,
    failedGatewayAttempts: 0,
  };
  const gatewayGenerated = gateways.reduce((sum, gateway) => sum + gateway.generated, 0);
  const gatewayConverted = gateways.reduce((sum, gateway) => sum + gateway.converted, 0);
  const gatewayPaid = gateways.reduce((sum, gateway) => sum + gateway.paid, 0);
  const gatewayRefunded = gateways.reduce((sum, gateway) => sum + gateway.refunded + gateway.chargedback, 0);
  const generated = gatewayGenerated + fallback.generated;
  const converted = gatewayConverted + fallback.converted;
  const paid = gatewayPaid + fallback.paid;
  const refunded = gatewayRefunded + fallback.refunded + fallback.chargedback;
  const netRevenueCents = gateways.reduce((sum, gateway) => sum + gateway.netRevenueCents, 0) + fallback.netRevenueCents;
  const activeTest = gatewayQuery.data?.tests.find((test) => test.status === "active");

  return (
    <div className="min-h-screen bg-[#060405] text-white">
      <main className="mx-auto flex w-full max-w-[1680px] flex-col gap-5 px-4 py-4 sm:px-6 lg:px-8">
        <header className="sticky top-0 z-20 -mx-4 border-b border-white/10 bg-[#060405]/90 px-4 py-4 backdrop-blur sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className="border-[#8c1229]/30 bg-[#8c1229]/[0.14] text-[#ffdbe2]">
                  Gateway PIX
                </Badge>
                {activeTest ? <StatusBadge status="active" /> : null}
              </div>
              <h1 className="mt-2 text-[26px] font-semibold leading-tight tracking-normal text-white sm:text-[30px]">
                Orquestração de gateways
              </h1>
              <p className="mt-1 max-w-2xl text-sm text-white/50">
                Integrações, roteamento A/B e leitura de conversão dos provedores PIX.
              </p>
            </div>

            <div className="flex flex-col gap-3 xl:items-end">
              <div className="grid grid-cols-2 gap-1.5 rounded-md border border-white/10 bg-black/25 p-1 sm:flex">
                {PRESETS.map((item) => (
                  <button
                    key={item.value}
                    type="button"
                    onClick={() => setPreset(item.value)}
                    className={cn(
                      "min-h-9 rounded-md px-3 text-sm font-medium text-white/[0.62] transition-colors hover:bg-white/[0.06] hover:text-white",
                      preset === item.value && "bg-white/[0.09] text-white shadow-[inset_0_0_0_1px_rgba(255,255,255,0.08)]",
                    )}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {gatewayQuery.isFetching ? (
                  <span className="inline-flex items-center gap-2 text-xs text-white/45">
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    Atualizando
                  </span>
                ) : null}
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation("/admin")}
                  className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Painel
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => gatewayQuery.refetch()}
                  disabled={gatewayQuery.isFetching}
                  className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
                >
                  <RefreshCw className={cn("h-4 w-4", gatewayQuery.isFetching && "animate-spin")} />
                  Atualizar
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleLogout}
                  className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
                >
                  <LogOut className="h-4 w-4" />
                  Sair
                </Button>
              </div>
            </div>
          </div>
        </header>

        {gatewayQuery.isError ? (
          <div className="rounded-md border border-rose-500/25 bg-rose-500/10 p-4 text-sm text-rose-100">
            Não foi possível carregar as integrações de pagamento.
          </div>
        ) : null}

        {gatewayQuery.data?.diagnostics?.degraded ? (
          <div className="flex gap-3 rounded-md border border-amber-500/25 bg-amber-500/10 p-4 text-sm text-amber-100">
            <AlertTriangle className="mt-0.5 h-4 w-4 flex-none" />
            <div>
              <p className="font-medium">Algumas métricas estão temporariamente indisponíveis.</p>
              <p className="mt-1 text-amber-100/70">
                O painel foi carregado com dados parciais. Verifique o deploy/migração do banco e os logs do servidor.
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {gatewayQuery.data.diagnostics.errors.map((error) => (
                  <span key={`${error.scope}-${error.code || error.message}`} className="rounded border border-amber-100/15 bg-black/20 px-2 py-1 text-xs text-amber-100/75">
                    {error.scope}{error.code ? ` · ${error.code}` : ""}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ) : null}

        <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
          <MetricCard
            label="PIX gerados"
            value={formatNumber(generated)}
            detail={`${formatNumber(fallback.generated)} sem gateway atribuído`}
            icon={CreditCard}
            tone="brand"
          />
          <MetricCard
            label="PIX pagos"
            value={formatNumber(paid)}
            detail={`${formatPercent(generated > 0 ? converted / generated : 0)} das cobranças geradas`}
            icon={CheckCircle2}
            tone="success"
          />
          <MetricCard
            label="Reembolsos"
            value={formatNumber(refunded)}
            detail={`${formatNumber(fallback.refunded + fallback.chargedback)} sem gateway atribuído`}
            icon={RefreshCw}
            tone={refunded > 0 ? "warning" : "neutral"}
          />
          <MetricCard
            label="Receita líquida"
            value={formatMoneyFromCents(netRevenueCents)}
            detail="Pagas e reembolsadas no período"
            icon={BarChart3}
            tone="warning"
          />
          <MetricCard
            label="Teste ativo"
            value={activeTest?.name ?? "Nenhum"}
            detail={activeTest ? `${activeTest.variants.length} variantes em distribuição` : "Gateway ativo padrão será usado"}
            icon={Activity}
          />
        </section>

        <section className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_420px]">
          <div className="space-y-4">
            <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-medium uppercase text-white/[0.42]">Gateways</p>
                  <h2 className="mt-1 text-lg font-semibold tracking-normal text-white">Provedores integrados</h2>
                </div>
              </div>

              <div className="mt-4 overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs uppercase text-white/42">
                      <th className="px-3 py-2">Gateway</th>
                      <th className="px-3 py-2">Provider</th>
                      <th className="px-3 py-2">Status</th>
                      <th className="px-3 py-2 text-right">Gerados</th>
                      <th className="px-3 py-2 text-right">Pagos no período</th>
                      <th className="px-3 py-2 text-right">Reembolsos</th>
                      <th className="px-3 py-2 text-right">Conversão gerada</th>
                      <th className="px-3 py-2 text-right">Receita líquida</th>
                      <th className="px-3 py-2 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {gateways.length > 0 ? gateways.map((gateway) => <GatewayRow key={gateway.id} gateway={gateway} />) : (
                      <tr>
                        <td className="px-3 py-6 text-sm text-white/55" colSpan={9}>
                          Nenhum gateway cadastrado ainda.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-medium uppercase text-white/[0.42]">Experimentos</p>
                  <h2 className="mt-1 text-lg font-semibold tracking-normal text-white">Testes A/B de gateway</h2>
                </div>
              </div>
              {(gatewayQuery.data?.tests ?? []).length > 0 ? (
                gatewayQuery.data?.tests.map((test) => <GatewayTestPanel key={test.id} test={test} />)
              ) : (
                <div className="rounded-md border border-white/10 bg-[#0d0a0c] p-4 text-sm text-white/55">
                  Nenhum teste de gateway cadastrado ainda.
                </div>
              )}
            </section>
          </div>

          <aside className="space-y-4">
            <GatewayCreateForm gateways={gateways} />
            <CreateTestPanel gateways={gateways} />
            <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-medium uppercase text-white/[0.42]">Eventos</p>
                  <h2 className="mt-1 text-lg font-semibold tracking-normal text-white">Últimas transações</h2>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                {(gatewayQuery.data?.recentTransactions ?? []).length > 0 ? (
                  gatewayQuery.data?.recentTransactions.map((transaction) => {
                    const fallbackReason = getFallbackReasonLabel(transaction.fallbackReason);
                    return (
                      <div key={transaction.id} className="rounded-md border border-white/10 bg-black/20 p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium text-white">
                              {formatShortId(transaction.providerTransactionId || transaction.pixPaymentId)}
                            </p>
                            <p className="mt-0.5 text-xs text-white/45">
                              {getTransactionProviderLabel(transaction)} · {transaction.lastEvent || "created"}
                            </p>
                          </div>
                          <TransactionStatusBadge status={transaction.status} />
                        </div>

                        <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-white/50">
                          <span>Valor: <span className="text-white/75">{formatMoneyFromCents(transaction.amountCents)}</span></span>
                          <span>Plano: <span className="text-white/75">{transaction.planId || "-"}</span></span>
                          <span>Criado: <span className="text-white/75">{formatDate(transaction.createdAt)}</span></span>
                          <span>Pago: <span className="text-white/75">{formatDate(transaction.paidAt)}</span></span>
                        </div>

                        {transaction.test || transaction.variant ? (
                          <p className="mt-2 text-xs text-white/45">
                            Teste: {transaction.test?.slug || "-"} · Variante: {transaction.variant?.name || "-"}
                          </p>
                        ) : null}

                        {fallbackReason ? (
                          <div className="mt-3 rounded-md border border-amber-500/20 bg-amber-500/10 p-2 text-xs text-amber-100">
                            <p className="font-medium">Fallback: {fallbackReason}</p>
                            <p className="mt-1 text-amber-100/70">
                              Tentou {transaction.attemptedGatewaySlug || "gateway"} {transaction.attemptedGatewayProvider ? `(${transaction.attemptedGatewayProvider})` : ""}
                            </p>
                            {transaction.fallbackDetail ? (
                              <p className="mt-1 break-words text-amber-100/60">{transaction.fallbackDetail}</p>
                            ) : null}
                          </div>
                        ) : null}

                        {transaction.errorMessage ? (
                          <p className="mt-2 break-words rounded-md border border-rose-500/20 bg-rose-500/10 p-2 text-xs text-rose-100/80">
                            {transaction.errorMessage}
                          </p>
                        ) : null}

                        <div className="mt-3 space-y-1 border-t border-white/[0.06] pt-2 text-[11px] text-white/35">
                          <p>PIX interno: {formatShortId(transaction.pixPaymentId)}</p>
                          <p>Referência: {formatShortId(transaction.externalReference)}</p>
                          {transaction.failedGatewayTransactionId ? (
                            <p>Falha original: {formatShortId(transaction.failedGatewayTransactionId)}</p>
                          ) : null}
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-sm text-white/55">Sem transações recentes.</p>
                )}
              </div>
            </section>
          </aside>
        </section>
      </main>
    </div>
  );
}
