import { useDeferredValue, useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  Activity,
  AlertTriangle,
  BarChart3,
  CalendarDays,
  CheckCircle2,
  Clock,
  CreditCard,
  DollarSign,
  FileWarning,
  FlaskConical,
  Image,
  LayoutDashboard,
  LogOut,
  RefreshCw,
  Route,
  ShieldCheck,
  Users,
  type LucideIcon,
} from "lucide-react";
import {
  AdminFunnelChart,
  type FunnelStepData,
} from "@/components/admin-funnel-chart";
import { CustomersListPanel } from "@/components/customers-list-panel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type FunnelResponse = {
  dateFrom: string;
  dateTo: string;
  pixByPage: Array<{
    label: string;
    parentNode: string;
    pixGenerated: number;
    pixPaid: number;
    pixConversionRate: number;
  }>;
  summary: {
    topTotal: number;
    uniqueSessions: number;
  };
  generatedMediaCount: number;
  apiCostUsd: number;
  pixPaymentsCreated: number;
  pixPaymentsConverted: number;
  pixPaymentsPaid: number;
  pixPaymentsActivePaid: number;
  pixPaymentsRefunded: number;
  pixPaymentsChargedback: number;
  pixGrossRevenueCents: number;
  pixRefundedCents: number;
  pixNetRevenueCents: number;
  pixPaidOverCreatedRate: number;
  funnelSteps?: FunnelStepData[];
};

type RealPreviewLogsResponse = {
  dateFrom: string;
  dateTo: string;
  page: number;
  pageSize: number;
  total: number;
  summary: {
    total: number;
    success: number;
    errors: number;
    previewFallbacks: number;
    aiFallbacks: number;
    pending: number;
    processing: number;
    openAiSuccess: number;
    geminiFallbackSuccess: number;
    avgResolveMs: number | null;
  };
  rows: Array<{
    requestId: string;
    sessionId: string | null;
    userId: string;
    username: string | null;
    customerName: string | null;
    customerEmail: string | null;
    paymentStatus: "paid" | "unpaid";
    position: string;
    previewAnalysisStatus: string;
    previewAnalysisProvider: string | null;
    previewAnalysisError: string | null;
    previewVisualTone: string | null;
    previewBodyType: string | null;
    previewVideoKey: string | null;
    previewResolvedAt: string | null;
    createdAt: string | null;
    updatedAt: string | null;
  }>;
};

type AdminPreset = "today" | "yesterday" | "7d" | "30d" | "custom";

const BRAND = "#8c1229";

const DATE_PRESETS: Array<{ value: AdminPreset; label: string }> = [
  { value: "today", label: "Hoje" },
  { value: "yesterday", label: "Ontem" },
  { value: "7d", label: "7 dias" },
  { value: "30d", label: "30 dias" },
  { value: "custom", label: "Personalizado" },
];

const NAV_ITEMS: Array<{ label: string; href: string; icon: LucideIcon; active?: boolean }> = [
  { label: "Visão geral", href: "/admin", icon: LayoutDashboard, active: true },
  { label: "Jornada", href: "/admin/journey", icon: Route },
  { label: "Testes A/B", href: "/admin/ab-tests", icon: FlaskConical },
  { label: "Gateways PIX", href: "/admin/payment-gateways", icon: CreditCard },
];

const numberFormatter = new Intl.NumberFormat("pt-BR");
const usdFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 2,
});
const brlFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  maximumFractionDigits: 2,
});
const dateTimeFormatter = new Intl.DateTimeFormat("pt-BR", {
  day: "2-digit",
  month: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
});

function formatNumber(value: number | null | undefined) {
  return numberFormatter.format(value ?? 0);
}

function formatPercent(value: number | null | undefined) {
  return `${(value ?? 0).toFixed(1)}%`;
}

function formatUsd(value: number | null | undefined) {
  return usdFormatter.format(value ?? 0);
}

function formatBrlFromCents(value: number | null | undefined) {
  return brlFormatter.format((value ?? 0) / 100);
}

function formatDateTime(value: string | null | undefined) {
  if (!value) return "Sem data";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Data inválida";
  return dateTimeFormatter.format(date);
}

function formatDurationMs(value: number | null | undefined) {
  if (!value) return "Sem média";
  if (value < 1000) return `${value} ms`;
  return `${(value / 1000).toFixed(1)} s`;
}

function shortId(value: string | null | undefined) {
  if (!value) return "sem-id";
  return value.length > 8 ? value.slice(0, 8) : value;
}

function getRangeLabel(preset: AdminPreset, dateFrom: string, dateTo: string) {
  if (preset !== "custom") {
    return DATE_PRESETS.find((item) => item.value === preset)?.label ?? "Período";
  }

  if (dateFrom && dateTo) return `${dateFrom} a ${dateTo}`;
  if (dateFrom) return `Desde ${dateFrom}`;
  if (dateTo) return `Até ${dateTo}`;
  return "Personalizado";
}

function getCostPerMedia(data?: FunnelResponse) {
  if (!data?.generatedMediaCount) return 0;
  return data.apiCostUsd / data.generatedMediaCount;
}

function getBestPixOrigin(data?: FunnelResponse) {
  const groups = data?.pixByPage ?? [];
  return groups
    .filter((item) => item.pixGenerated > 0 || item.pixPaid > 0)
    .sort((a, b) => {
      if (b.pixPaid !== a.pixPaid) return b.pixPaid - a.pixPaid;
      return b.pixConversionRate - a.pixConversionRate;
    })[0];
}

function DateRangeControls({
  preset,
  dateFrom,
  dateTo,
  onPresetChange,
  onDateFromChange,
  onDateToChange,
}: {
  preset: AdminPreset;
  dateFrom: string;
  dateTo: string;
  onPresetChange: (preset: AdminPreset) => void;
  onDateFromChange: (value: string) => void;
  onDateToChange: (value: string) => void;
}) {
  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-1.5 rounded-md border border-white/10 bg-black/25 p-1 sm:flex">
        {DATE_PRESETS.map((rangePreset) => (
          <button
            key={rangePreset.value}
            type="button"
            onClick={() => onPresetChange(rangePreset.value)}
            className={cn(
              "min-h-9 rounded-md px-3 text-sm font-medium text-white/[0.62] transition-colors hover:bg-white/[0.06] hover:text-white",
              preset === rangePreset.value && "bg-white/[0.09] text-white shadow-[inset_0_0_0_1px_rgba(255,255,255,0.08)]",
            )}
          >
            {rangePreset.label}
          </button>
        ))}
      </div>

      {preset === "custom" ? (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          <Input
            type="date"
            value={dateFrom}
            onChange={(event) => onDateFromChange(event.target.value)}
            className="border-white/10 bg-black/25 text-white [color-scheme:dark]"
          />
          <Input
            type="date"
            value={dateTo}
            onChange={(event) => onDateToChange(event.target.value)}
            className="border-white/10 bg-black/25 text-white [color-scheme:dark]"
          />
        </div>
      ) : null}
    </div>
  );
}

function AdminSidebar({
  onNavigate,
  onLogout,
}: {
  onNavigate: (href: string) => void;
  onLogout: () => void;
}) {
  return (
    <aside className="hidden min-h-screen w-[280px] shrink-0 border-r border-white/10 bg-[#080607] lg:flex lg:flex-col">
      <div className="flex h-20 items-center gap-3 border-b border-white/10 px-6">
        <div className="flex h-10 w-10 items-center justify-center rounded-md border border-[#8c1229]/[0.35] bg-[#8c1229]/[0.18]">
          <ShieldCheck className="h-5 w-5 text-[#ffccd5]" />
        </div>
        <div>
          <p className="text-sm font-semibold text-white">DesireAI Admin</p>
          <p className="text-xs text-white/[0.42]">Operação comercial</p>
        </div>
      </div>

      <nav className="flex flex-1 flex-col gap-1 px-3 py-5">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.href}
              type="button"
              onClick={() => onNavigate(item.href)}
              className={cn(
                "flex min-h-10 items-center gap-3 rounded-md px-3 text-sm font-medium text-white/[0.58] transition-colors hover:bg-white/[0.05] hover:text-white",
                item.active && "border border-[#8c1229]/[0.28] bg-[#8c1229]/[0.14] text-white",
              )}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-white/10 p-3">
        <button
          type="button"
          onClick={onLogout}
          className="flex min-h-10 w-full items-center gap-3 rounded-md px-3 text-sm font-medium text-white/[0.58] transition-colors hover:bg-white/[0.05] hover:text-white"
        >
          <LogOut className="h-4 w-4" />
          Sair
        </button>
      </div>
    </aside>
  );
}

function MobileAdminNav({
  onNavigate,
  onLogout,
}: {
  onNavigate: (href: string) => void;
  onLogout: () => void;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 lg:hidden">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        return (
          <button
            key={item.href}
            type="button"
            onClick={() => onNavigate(item.href)}
            className={cn(
              "inline-flex min-h-10 shrink-0 items-center gap-2 rounded-md border border-white/10 bg-black/20 px-3 text-sm font-medium text-white/[0.65]",
              item.active && "border-[#8c1229]/[0.4] bg-[#8c1229]/[0.18] text-white",
            )}
          >
            <Icon className="h-4 w-4" />
            {item.label}
          </button>
        );
      })}
      <button
        type="button"
        onClick={onLogout}
        className="inline-flex min-h-10 shrink-0 items-center gap-2 rounded-md border border-white/10 bg-black/20 px-3 text-sm font-medium text-white/[0.65]"
      >
        <LogOut className="h-4 w-4" />
        Sair
      </button>
    </div>
  );
}

function MetricCard({
  label,
  value,
  detail,
  icon: Icon,
  tone = "neutral",
}: {
  label: string;
  value: string;
  detail: string;
  icon: LucideIcon;
  tone?: "neutral" | "brand" | "success" | "warning";
}) {
  const toneClassName = {
    neutral: "border-white/[0.12] bg-white/[0.035] text-white/70",
    brand: "border-[#8c1229]/[0.34] bg-[#8c1229]/[0.14] text-[#ffdbe2]",
    success: "border-emerald-500/[0.24] bg-emerald-500/10 text-emerald-100",
    warning: "border-amber-500/[0.24] bg-amber-500/10 text-amber-100",
  }[tone];

  return (
    <div className="rounded-md border border-white/10 bg-[#0d0a0c] p-4 shadow-[0_18px_50px_rgba(0,0,0,0.18)]">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase text-white/[0.42]">{label}</p>
          <p className="mt-2 text-2xl font-semibold tracking-normal text-white tabular-nums">{value}</p>
        </div>
        <div className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-md border", toneClassName)}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <p className="mt-3 min-h-5 text-sm text-white/50">{detail}</p>
    </div>
  );
}

function OperationsPanel({ data }: { data?: FunnelResponse }) {
  const bestPixOrigin = getBestPixOrigin(data);
  const costPerMedia = getCostPerMedia(data);
  const paid = data?.pixPaymentsPaid ?? 0;
  const created = data?.pixPaymentsCreated ?? 0;
  const reversed = (data?.pixPaymentsRefunded ?? 0) + (data?.pixPaymentsChargedback ?? 0);

  const rows = [
    {
      label: "PIX criados",
      value: formatNumber(created),
      detail: `${formatNumber(paid)} pagos no período · ${formatNumber(reversed)} estornos`,
      icon: CreditCard,
      tone: "brand" as const,
    },
    {
      label: "Receita líquida",
      value: formatBrlFromCents(data?.pixNetRevenueCents),
      detail: `${formatBrlFromCents(data?.pixGrossRevenueCents)} bruto · ${formatBrlFromCents(data?.pixRefundedCents)} estornado`,
      icon: DollarSign,
      tone: "success" as const,
    },
    {
      label: "Custo por mídia",
      value: formatUsd(costPerMedia),
      detail: `${formatUsd(data?.apiCostUsd)} em custo KIE estimado`,
      icon: DollarSign,
      tone: "warning" as const,
    },
    {
      label: "Melhor origem PIX",
      value: bestPixOrigin?.label ?? "Sem atividade",
      detail: bestPixOrigin
        ? `${formatNumber(bestPixOrigin.pixPaid)} pagos · ${formatPercent(bestPixOrigin.pixConversionRate)}`
        : "Aguardando geração de cobranças",
      icon: Activity,
      tone: "success" as const,
    },
  ];

  return (
    <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase text-white/[0.42]">Leitura executiva</p>
          <h2 className="mt-1 text-lg font-semibold tracking-normal text-white">Saúde do período</h2>
        </div>
        <Badge variant="outline" className="border-emerald-500/[0.24] bg-emerald-500/10 text-emerald-100 [--badge-outline:rgba(16,185,129,0.25)]">
          Online
        </Badge>
      </div>

      <div className="mt-4 divide-y divide-white/[0.08]">
        {rows.map((row) => {
          const Icon = row.icon;
          return (
            <div key={row.label} className="flex gap-3 py-3 first:pt-0 last:pb-0">
              <div
                className={cn(
                  "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-md border",
                  row.tone === "brand" && "border-[#8c1229]/30 bg-[#8c1229]/[0.14] text-[#ffdbe2]",
                  row.tone === "warning" && "border-amber-500/[0.24] bg-amber-500/10 text-amber-100",
                  row.tone === "success" && "border-emerald-500/[0.24] bg-emerald-500/10 text-emerald-100",
                )}
              >
                <Icon className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <p className="text-xs text-white/[0.42]">{row.label}</p>
                <p className="mt-0.5 truncate text-sm font-semibold text-white">{row.value}</p>
                <p className="mt-0.5 text-xs text-white/[0.48]">{row.detail}</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function getRealPreviewStatusLabel(status: string, provider: string | null) {
  if (status === "completed" && provider && provider !== "gpt-5.3-chat-latest") return "Fallback IA";
  if (status === "completed") return "Sucesso";
  if (status === "failed") return "Fallback preview";
  if (status === "processing") return "Processando";
  if (status === "pending") return "Pendente";
  return status || "Desconhecido";
}

function getRealPreviewStatusClassName(status: string, provider: string | null) {
  if (status === "completed" && provider && provider !== "gpt-5.3-chat-latest") return "border-amber-500/25 bg-amber-500/10 text-amber-100";
  if (status === "completed") return "border-emerald-500/25 bg-emerald-500/10 text-emerald-100";
  if (status === "failed") return "border-rose-500/25 bg-rose-500/10 text-rose-100";
  return "border-white/10 bg-white/[0.05] text-white/70";
}

function RealPreviewLogsPanel({
  data,
  isLoading,
  isError,
  isFetching,
  search,
  onSearchChange,
  onRefresh,
  onPageChange,
}: {
  data?: RealPreviewLogsResponse;
  isLoading: boolean;
  isError: boolean;
  isFetching: boolean;
  search: string;
  onSearchChange: (value: string) => void;
  onRefresh: () => void;
  onPageChange: (page: number) => void;
}) {
  const summary = data?.summary;
  const rows = data?.rows ?? [];
  const currentPage = data?.page ?? 1;
  const pageSize = data?.pageSize ?? 20;
  const total = data?.total ?? 0;
  const hasPreviousPage = currentPage > 1;
  const hasNextPage = currentPage * pageSize < total;
  const summaryItems = [
    {
      label: "Sucessos",
      value: formatNumber(summary?.success),
      detail: `${formatNumber(summary?.openAiSuccess)} OpenAI · ${formatNumber(summary?.geminiFallbackSuccess)} Gemini fallback`,
      icon: CheckCircle2,
      tone: "success" as const,
    },
    {
      label: "Fallbacks",
      value: formatNumber((summary?.previewFallbacks ?? 0) + (summary?.aiFallbacks ?? 0)),
      detail: `${formatNumber(summary?.previewFallbacks)} preview antigo · ${formatNumber(summary?.aiFallbacks)} IA`,
      icon: FileWarning,
      tone: "warning" as const,
    },
    {
      label: "Erros",
      value: formatNumber(summary?.errors),
      detail: "Requests que caíram no preview fallback",
      icon: AlertTriangle,
      tone: "danger" as const,
    },
    {
      label: "Fila",
      value: formatNumber((summary?.pending ?? 0) + (summary?.processing ?? 0)),
      detail: `Tempo médio: ${formatDurationMs(summary?.avgResolveMs)}`,
      icon: Clock,
      tone: "neutral" as const,
    },
  ];

  return (
    <section className="rounded-md border border-white/10 bg-[#0d0a0c] p-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase text-white/[0.42]">Real Preview Logs</p>
          <h2 className="mt-1 text-lg font-semibold tracking-normal text-white">Auditoria do preview personalizado</h2>
          <p className="mt-1 text-sm text-white/48">
            Sucesso, fallback da IA, fallback para vídeo antigo e erros detalhados do fluxo POV.
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <Input
            value={search}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder="Buscar request, erro, cliente..."
            className="h-9 min-w-[240px] border-white/10 bg-black/25 text-white placeholder:text-white/30"
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onRefresh}
            disabled={isFetching}
            className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
          >
            <RefreshCw className={cn("h-4 w-4", isFetching && "animate-spin")} />
            Atualizar
          </Button>
        </div>
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
        {summaryItems.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="rounded-md border border-white/[0.08] bg-black/20 p-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs text-white/[0.42]">{item.label}</p>
                  <p className="mt-1 text-xl font-semibold tabular-nums text-white">{item.value}</p>
                </div>
                <div
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-md border",
                    item.tone === "success" && "border-emerald-500/25 bg-emerald-500/10 text-emerald-100",
                    item.tone === "warning" && "border-amber-500/25 bg-amber-500/10 text-amber-100",
                    item.tone === "danger" && "border-rose-500/25 bg-rose-500/10 text-rose-100",
                    item.tone === "neutral" && "border-white/10 bg-white/[0.05] text-white/70",
                  )}
                >
                  <Icon className="h-4 w-4" />
                </div>
              </div>
              <p className="mt-2 text-xs text-white/45">{item.detail}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-4 overflow-hidden rounded-md border border-white/[0.08]">
        <div className="grid grid-cols-[140px_190px_150px_minmax(220px,1fr)_minmax(260px,1.3fr)] border-b border-white/[0.08] bg-black/25 px-3 py-2 text-xs font-medium uppercase text-white/38 max-xl:hidden">
          <span>Horário</span>
          <span>Request</span>
          <span>Status</span>
          <span>Resultado</span>
          <span>Erro / log</span>
        </div>

        {isLoading ? (
          <div className="flex min-h-[180px] items-center justify-center text-sm text-white/50">
            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
            Carregando logs...
          </div>
        ) : isError ? (
          <div className="p-4 text-sm text-rose-100">Não foi possível carregar os logs do Real Preview.</div>
        ) : rows.length === 0 ? (
          <div className="p-4 text-sm text-white/48">Nenhum log encontrado neste período.</div>
        ) : (
          <div className="divide-y divide-white/[0.08]">
            {rows.map((row) => (
              <div
                key={row.requestId}
                className="grid gap-3 px-3 py-3 text-sm text-white/72 xl:grid-cols-[140px_190px_150px_minmax(220px,1fr)_minmax(260px,1.3fr)] xl:items-start"
              >
                <div>
                  <p className="text-xs text-white/38 xl:hidden">Horário</p>
                  <p className="tabular-nums">{formatDateTime(row.createdAt)}</p>
                  {row.previewResolvedAt ? (
                    <p className="mt-0.5 text-xs text-white/36">Resolveu {formatDateTime(row.previewResolvedAt)}</p>
                  ) : null}
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-white/38 xl:hidden">Request</p>
                  <p className="font-medium text-white">#{shortId(row.requestId)}</p>
                  <p className="mt-0.5 truncate text-xs text-white/42">{row.username || row.customerName || row.userId}</p>
                  <p className="mt-0.5 truncate text-xs text-white/32">{row.sessionId || "sem sessão"}</p>
                </div>
                <div>
                  <p className="text-xs text-white/38 xl:hidden">Status</p>
                  <span className={cn("inline-flex min-h-7 items-center rounded-md border px-2 text-xs font-medium", getRealPreviewStatusClassName(row.previewAnalysisStatus, row.previewAnalysisProvider))}>
                    {getRealPreviewStatusLabel(row.previewAnalysisStatus, row.previewAnalysisProvider)}
                  </span>
                  <p className="mt-1 text-xs text-white/38">{row.previewAnalysisProvider || "sem provider"}</p>
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-white/38 xl:hidden">Resultado</p>
                  <p className="truncate text-white/78">
                    {row.previewVisualTone || "skin?"} · {row.previewBodyType || "body?"} · {row.position}
                  </p>
                  <p className="mt-0.5 truncate text-xs text-white/42">{row.previewVideoKey || "sem vídeo personalizado"}</p>
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-white/38 xl:hidden">Erro / log</p>
                  <p className={cn("break-words text-xs leading-relaxed", row.previewAnalysisError ? "text-rose-100/85" : "text-white/38")}>
                    {row.previewAnalysisError || "Sem erro registrado."}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-white/36">
          Mostrando {formatNumber(rows.length)} de {formatNumber(total)} registros do período.
        </p>
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => onPageChange(currentPage - 1)}
            disabled={!hasPreviousPage || isFetching}
            className="h-8 border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
          >
            Anterior
          </Button>
          <span className="text-xs text-white/42">Página {formatNumber(currentPage)}</span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => onPageChange(currentPage + 1)}
            disabled={!hasNextPage || isFetching}
            className="h-8 border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
          >
            Próxima
          </Button>
        </div>
      </div>
    </section>
  );
}

export default function AdminDashboardPage() {
  const [, setLocation] = useLocation();
  const [preset, setPreset] = useState<AdminPreset>("7d");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [realPreviewSearch, setRealPreviewSearch] = useState("");
  const [realPreviewPage, setRealPreviewPage] = useState(1);
  const deferredRealPreviewSearch = useDeferredValue(realPreviewSearch);

  const funnelQueryString = useMemo(() => {
    const params = new URLSearchParams();
    params.set("preset", preset);
    if (preset === "custom") {
      if (dateFrom) params.set("dateFrom", dateFrom);
      if (dateTo) params.set("dateTo", dateTo);
    }
    return params.toString();
  }, [preset, dateFrom, dateTo]);

  const realPreviewLogsQueryString = useMemo(() => {
    const params = new URLSearchParams(funnelQueryString);
    params.set("page", String(realPreviewPage));
    params.set("pageSize", "20");
    const search = deferredRealPreviewSearch.trim();
    if (search) params.set("search", search);
    return params.toString();
  }, [funnelQueryString, realPreviewPage, deferredRealPreviewSearch]);

  useEffect(() => {
    setRealPreviewPage(1);
  }, [funnelQueryString, deferredRealPreviewSearch]);

  const funnelQuery = useQuery<FunnelResponse>({
    queryKey: ["/api/admin/journey-map", funnelQueryString],
    queryFn: async () => {
      const res = await fetch(`/api/admin/journey-map?${funnelQueryString}`, { credentials: "include" });
      if (res.status === 401) {
        setLocation("/admin/login");
        throw new Error("unauthorized");
      }
      if (!res.ok) throw new Error("Erro ao carregar funil");
      return res.json();
    },
    staleTime: 30_000,
  });

  const realPreviewLogsQuery = useQuery<RealPreviewLogsResponse>({
    queryKey: ["/api/admin/real-preview-logs", realPreviewLogsQueryString],
    queryFn: async () => {
      const res = await fetch(`/api/admin/real-preview-logs?${realPreviewLogsQueryString}`, { credentials: "include" });
      if (res.status === 401) {
        setLocation("/admin/login");
        throw new Error("unauthorized");
      }
      if (!res.ok) throw new Error("Erro ao carregar Real Preview Logs");
      return res.json();
    },
    staleTime: 15_000,
  });

  const handleLogout = async () => {
    await fetch("/api/admin/logout", {
      method: "POST",
      credentials: "include",
    });
    setLocation("/admin/login");
  };

  const handleNavigate = (href: string) => {
    setLocation(href);
  };

  const rangeLabel = getRangeLabel(preset, dateFrom, dateTo);
  const conversionRate = funnelQuery.data?.pixPaidOverCreatedRate ?? 0;
  const topTotal = funnelQuery.data?.summary?.topTotal ?? 0;
  const uniqueSessions = funnelQuery.data?.summary?.uniqueSessions ?? 0;
  const generatedMediaCount = funnelQuery.data?.generatedMediaCount ?? 0;
  const paidCount = funnelQuery.data?.pixPaymentsPaid ?? 0;
  const createdCount = funnelQuery.data?.pixPaymentsCreated ?? 0;
  const convertedCount = funnelQuery.data?.pixPaymentsConverted ?? 0;
  const reversedCount = (funnelQuery.data?.pixPaymentsRefunded ?? 0) + (funnelQuery.data?.pixPaymentsChargedback ?? 0);
  const isRefreshing = funnelQuery.isFetching || realPreviewLogsQuery.isFetching;

  return (
    <div className="min-h-screen bg-[#060405] text-white">
      <div className="flex min-h-screen bg-[linear-gradient(180deg,#080506_0%,#050405_48%,#070506_100%)]">
        <AdminSidebar onNavigate={handleNavigate} onLogout={handleLogout} />

        <main className="min-w-0 flex-1">
          <div className="mx-auto flex w-full max-w-[1680px] flex-col gap-5 px-4 py-4 sm:px-6 lg:px-8">
            <MobileAdminNav onNavigate={handleNavigate} onLogout={handleLogout} />

            <header className="sticky top-0 z-20 -mx-4 border-b border-white/10 bg-[#060405]/90 px-4 py-4 backdrop-blur sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
              <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline" className="border-[#8c1229]/30 bg-[#8c1229]/[0.14] text-[#ffdbe2] [--badge-outline:rgba(140,18,41,0.36)]">
                      <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-emerald-400" />
                      Admin
                    </Badge>
                    <span className="inline-flex items-center gap-1.5 text-xs text-white/[0.42]">
                      <CalendarDays className="h-3.5 w-3.5" />
                      {rangeLabel}
                    </span>
                  </div>
                  <h1 className="mt-2 text-[26px] font-semibold leading-tight tracking-normal text-white sm:text-[30px]">
                    Centro de controle comercial
                  </h1>
                  <p className="mt-1 max-w-2xl text-sm text-white/50">
                    Funil, pagamentos PIX, custos de geração e sessões de clientes em uma visão operacional.
                  </p>
                </div>

                <div className="flex flex-col gap-3 xl:min-w-[620px] xl:items-end">
                  <DateRangeControls
                    preset={preset}
                    dateFrom={dateFrom}
                    dateTo={dateTo}
                    onPresetChange={setPreset}
                    onDateFromChange={setDateFrom}
                    onDateToChange={setDateTo}
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    {isRefreshing ? (
                      <span className="inline-flex items-center gap-2 text-xs text-white/45">
                        <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                        Atualizando métricas
                      </span>
                    ) : null}
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        void funnelQuery.refetch();
                        void realPreviewLogsQuery.refetch();
                      }}
                      disabled={isRefreshing}
                      className="border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.07]"
                    >
                      <RefreshCw className={cn("h-4 w-4", isRefreshing && "animate-spin")} />
                      Atualizar
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      onClick={() => setLocation("/admin/journey")}
                      className="border border-[#8c1229] bg-[#8c1229] text-white hover:bg-[#a61530]"
                      style={{ borderColor: BRAND }}
                    >
                      <Route className="h-4 w-4" />
                      Jornada
                    </Button>
                  </div>
                </div>
              </div>
            </header>

            {funnelQuery.isError ? (
              <div className="rounded-md border border-rose-500/25 bg-rose-500/10 p-4 text-sm text-rose-100">
                Não foi possível carregar as métricas do funil. Tente atualizar em alguns segundos.
              </div>
            ) : null}

            <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <MetricCard
                label="Entradas no funil"
                value={formatNumber(uniqueSessions)}
                detail="Sessões com evento de entrada"
                icon={Users}
                tone="brand"
              />
              <MetricCard
                label="Mídias geradas"
                value={formatNumber(generatedMediaCount)}
                detail={`${formatUsd(funnelQuery.data?.apiCostUsd)} em custo estimado`}
                icon={Image}
              />
              <MetricCard
                label="PIX pagos"
                value={formatNumber(paidCount)}
                detail={`${formatNumber(createdCount)} criados · ${formatNumber(reversedCount)} estornos`}
                icon={CreditCard}
                tone="success"
              />
              <MetricCard
                label="Conversão PIX"
                value={formatPercent(conversionRate)}
                detail={`${formatNumber(convertedCount)} pagos de ${formatNumber(createdCount)} criados`}
                icon={BarChart3}
                tone={conversionRate >= 35 ? "success" : conversionRate > 0 ? "warning" : "neutral"}
              />
            </section>

            <section className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
              <div className="min-w-0">
                {funnelQuery.isLoading ? (
                  <div className="flex min-h-[360px] items-center justify-center rounded-md border border-white/10 bg-[#0d0a0c] text-sm text-white/50">
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Carregando funil...
                  </div>
                ) : (
                  <AdminFunnelChart
                    pixByPage={funnelQuery.data?.pixByPage || []}
                    funnelSteps={funnelQuery.data?.funnelSteps || []}
                  />
                )}
              </div>
              <OperationsPanel data={funnelQuery.data} />
            </section>

            <RealPreviewLogsPanel
              data={realPreviewLogsQuery.data}
              isLoading={realPreviewLogsQuery.isLoading}
              isError={realPreviewLogsQuery.isError}
              isFetching={realPreviewLogsQuery.isFetching}
              search={realPreviewSearch}
              onSearchChange={setRealPreviewSearch}
              onRefresh={() => { void realPreviewLogsQuery.refetch(); }}
              onPageChange={setRealPreviewPage}
            />

            <CustomersListPanel
              scope="admin"
              preset={preset}
              dateFrom={preset === "custom" ? dateFrom : ""}
              dateTo={preset === "custom" ? dateTo : ""}
            />
          </div>
        </main>
      </div>
    </div>
  );
}
