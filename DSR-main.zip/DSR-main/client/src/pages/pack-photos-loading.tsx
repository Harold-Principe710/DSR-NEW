import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { Loader2, CheckCircle2, Infinity } from "lucide-react";
import VideoPovModal, { type VideoPovPreferences } from "@/components/VideoPovModal";
import PixQrModal, { PLANS } from "@/components/PixQrModal";
import { trackFunnelEvent } from "@/lib/funnel";
import { useResolvePlanId } from "@/lib/ab-pricing";

const LOADING_SECONDS = 30;

function priceShort(planId: string, fallback: string): string {
  const raw = PLANS[planId]?.price;
  return raw ? raw.replace(/^R\$\s*/, "") : fallback;
}

export default function PackPhotosLoadingPage() {
  const [, setLocation] = useLocation();
  const resolvePlanId = useResolvePlanId("landing-pricing");
  const planUnlimited = "ilimitado-pack-fotos-4490";
  const planVideoPack = resolvePlanId("video-pov-pack-2990");
  const planPackOnly = resolvePlanId("pack-fotos-1990");

  const [secondsLeft, setSecondsLeft] = useState(LOADING_SECONDS);
  const [promoOpen, setPromoOpen] = useState(false);
  const [promoAccepted, setPromoAccepted] = useState(false);
  const [pixModalOpen, setPixModalOpen] = useState(false);
  const [selectedPlanId, setSelectedPlanId] = useState("");
  const [isOpeningPayment, setIsOpeningPayment] = useState(false);
  const [openingPlanId, setOpeningPlanId] = useState<string | null>(null);
  const [isSubmittingPromo, setIsSubmittingPromo] = useState(false);
  const [funnelImageId, setFunnelImageId] = useState<string | null>(null);

  const promoShownRef = useRef(false);
  const openingPaymentRef = useRef(false);

  useEffect(() => {
    try {
      const raw = window.sessionStorage.getItem("desireai:landing:funnel-state:v1");
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.generatedImageId) {
          setFunnelImageId(parsed.generatedImageId);
        }
      }
    } catch {}
  }, []);

  useEffect(() => {
    trackFunnelEvent({
      step: "video_loading_screen",
      eventName: "pack_photos.loading_screen_entered",
      idempotencyKey: "pack_photos:loading_screen",
    });
    const intervalId = window.setInterval(() => {
      setSecondsLeft((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => window.clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      promoShownRef.current = true;
      setPromoOpen(true);
    }, 5000);

    return () => window.clearTimeout(timeoutId);
  }, []);

  const progressPercent = useMemo(() => {
    const elapsed = LOADING_SECONDS - secondsLeft;
    return Math.round((elapsed / LOADING_SECONDS) * 100);
  }, [secondsLeft]);

  useEffect(() => {
    if (secondsLeft !== 0) return;
    trackFunnelEvent({
      step: "video_loaded",
      eventName: "pack_photos.loaded",
      idempotencyKey: "pack_photos:loaded",
      metadata: {
        promoAccepted,
      },
    });
  }, [secondsLeft, promoAccepted]);

  const handlePromoAccept = () => {
    setPromoAccepted(true);
    setPromoOpen(false);
  };

  const handlePromoSubmit = async (_preferences: VideoPovPreferences) => {
    setIsSubmittingPromo(true);
    try {
      // UX-only in this context: no backend persistence of POV filters
      handlePromoAccept();
    } finally {
      setIsSubmittingPromo(false);
    }
  };

  const openPix = (planId: string) => {
    if (openingPaymentRef.current || isOpeningPayment || pixModalOpen) return;
    openingPaymentRef.current = true;
    trackFunnelEvent({
      step: "offer_responded",
      eventName: "pack_photos.offer_clicked",
      idempotencyKey: `pack_photos:offer_clicked:${planId}`,
      metadata: { planId, funnelBranch: "pack_photos" },
    });
    setIsOpeningPayment(true);
    setOpeningPlanId(planId);
    setSelectedPlanId(planId);
    window.setTimeout(() => {
      setPixModalOpen(true);
      setIsOpeningPayment(false);
      setOpeningPlanId(null);
      openingPaymentRef.current = false;
    }, 240);
  };

  const handlePixPaymentSuccess = () => {
    setLocation("/");
  };

  return (
    <div
      className="min-h-[100svh] bg-gradient-to-br from-[#050102] to-[#0a0204] text-white px-5 py-6"
      style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
    >
      <div className="mx-auto w-full max-w-md flex flex-col gap-5">
        <header className="w-full flex items-center justify-center pt-1 pb-1">
          <img
            src="/uploads/logo.webp"
            alt="DesireAI"
            width={599}
            height={171}
            decoding="async"
            fetchPriority="high"
            className="h-[2.2rem] object-contain opacity-90"
          />
        </header>

        <section className="w-full rounded-2xl overflow-hidden bg-[#0a0204] border border-[#8c1229]/20 shadow-xl md:shadow-[0_20px_80px_rgba(82,10,23,0.3)] min-h-[400px]">
          <div className="w-full min-h-[480px] relative bg-black/40 px-5 py-6 flex items-center justify-center">
            <div className={`w-full transition-all duration-200 ${secondsLeft > 0 ? "opacity-100 scale-100" : "opacity-0 scale-[0.985] pointer-events-none absolute"}`}>
              <div className="w-full max-w-[290px] mx-auto flex flex-col items-center text-center gap-2.5">
                <div className="relative">
                  <div className="w-14 h-14 rounded-full border-2 border-[#8c1229]/20 border-t-[#8c1229] border-r-[#8c1229]/60 animate-[spin_1.5s_linear_infinite]" />
                  <div className="absolute inset-0 w-14 h-14 rounded-full border border-transparent border-b-[#ff3b5c]/40 animate-[spin_2s_reverse_linear_infinite]" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Loader2 className="w-4 h-4 text-[#ff3b5c]/70 animate-pulse" />
                  </div>
                </div>
                <h1 className="text-[20px] font-semibold text-white/95">Gerando seu pack de imagens</h1>
                <p className="text-[13px] text-white/45">Seu conteúdo está sendo preparado agora.</p>

                <div className="w-full h-2 rounded-full bg-white/[0.06] mt-1 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#8c1229] to-[#ff3b5c] transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </div>
            <div className={`w-full flex flex-col items-center justify-center transition-all duration-700 ${secondsLeft === 0 ? "opacity-100 scale-100" : "opacity-0 scale-[0.985] pointer-events-none absolute"}`}>
              <div className="relative w-[160px] sm:w-[180px] aspect-[3/4] mb-8 mt-2 md:mb-10 md:mt-4">
                {/* 9 Silhouettes */}
                {Array.from({ length: 9 }).map((_, i) => {
                  const order = i + 1;
                  const shiftX = order * 3;
                  const shiftY = order * 3;
                  const rotate = (order % 2 === 0 ? 1 : -1) * (order * 1.5);
                  return (
                    <div
                      key={i}
                      className="absolute inset-0 rounded-xl border border-white/20 bg-transparent"
                      style={{
                        zIndex: 10 - order,
                        transform: `translate(${shiftX}px, ${shiftY}px) rotate(${rotate}deg)`,
                        transformOrigin: "center center",
                        opacity: Math.max(0.1, 1 - order * 0.1),
                      }}
                    />
                  );
                })}

                {/* Main Card */}
                <div className="absolute inset-0 z-10 rounded-xl border border-[#ff3b5c]/30 overflow-hidden shadow-[0_0_25px_rgba(140,18,41,0.3)] bg-[#0a0204]">
                  {funnelImageId && (
                    <img
                      src={`/api/generated-images/${funnelImageId}/image`}
                      className="w-full h-full object-cover opacity-90"
                      alt="Preview"
                      decoding="async"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
                </div>
              </div>

              <p className="text-center text-[15px] sm:text-[17px] font-medium text-white/90 max-w-[320px] mx-auto leading-relaxed">
                Seu pack de imagens está pronto, desbloqueie para ver e baixar.
              </p>

              <div className="mt-6 w-full grid grid-cols-2 gap-2 max-w-[360px] mx-auto px-1">
                {[
                  "De quatro", "Com as pernas abertas", "Mamando", "Com a cara gozada",
                  "Fudendo no cuzinho (Posição 1)", "Fudendo no cuzinho (Posição 2)", "Fudendo no cuzinho (Posição 3)",
                  "Fudendo na bucetinha (Posição 1)", "Fudendo na bucetinha (Posição 2)", "Fudendo na bucetinha (Posição 3)"
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start gap-1.5 text-left border border-white/5 bg-white/[0.03] rounded-md p-2 shadow-sm">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-[1px]" />
                    <span className="text-[10px] text-white/80 leading-snug">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-[#8c1229]/20 bg-[#0a0204]/90 p-4">
          {promoAccepted && secondsLeft > 0 && (
            <div className="w-full rounded-xl border border-emerald-500/30 bg-emerald-500/[0.08] p-3 text-left">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                <div>
                  <p className="text-[13px] text-emerald-300 font-medium">Vídeo promocional adicionado ao pedido</p>
                  <p className="text-[12px] text-white/55 mt-1">
                    Estamos preparando seu pack com o vídeo POV incluso nesta geração.
                  </p>
                </div>
              </div>
            </div>
          )}

          {!promoAccepted && promoShownRef.current && secondsLeft > 0 && (
            <p className="text-[12px] text-white/30 text-center">
              Oferta relâmpago exibida. Você ainda pode finalizar com a melhor opção no próximo passo.
            </p>
          )}

          {secondsLeft === 0 && (
            <div className="mt-2 flex flex-col gap-3">
              <p className="text-center text-[12px] text-white/35">
                Escolha como finalizar seu pedido:
              </p>

              <button
                type="button"
                onClick={() => openPix(planUnlimited)}
                disabled={isOpeningPayment || pixModalOpen}
                className="w-full text-left rounded-2xl border border-[#ff3b5c]/45 bg-gradient-to-r from-[#8c1229]/30 to-[#520a17]/20 p-4 transition-all duration-200 hover:border-[#ff3b5c]/70 disabled:opacity-75 disabled:cursor-wait shadow-[0_0_24px_rgba(140,18,41,0.22)]"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="inline-flex items-center rounded-full border border-[#ff3b5c]/45 bg-[#8c1229]/30 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[#ffd5de] mb-2">
                      Mais escolhido
                    </span>
                    <div className="flex items-center gap-2 mb-1">
                      <Infinity className="w-4 h-4 text-[#ffd5de]" />
                      <p className="text-[15px] font-semibold text-white/95">Uso diário ilimitado</p>
                    </div>
                    <p className="mt-1 text-[12px] text-white/55 leading-relaxed">
                      {openingPlanId === planUnlimited ? "Abrindo pagamento..." : "24 horas para criar fotos e vídeos ilimitados de quem você quiser"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {openingPlanId === planUnlimited && (
                      <Loader2 className="w-3.5 h-3.5 text-[#ff8ca0] animate-spin" />
                    )}
                    <p className="text-[16px] font-bold text-[#ff3b5c]">{priceShort(planUnlimited, "44,90")}</p>
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => openPix(planVideoPack)}
                disabled={isOpeningPayment || pixModalOpen}
                className="w-full text-left rounded-2xl border border-white/[0.18] bg-white/[0.04] p-4 transition-colors hover:border-white/[0.3] disabled:opacity-70 disabled:cursor-wait"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-[15px] font-semibold text-white/95">Pack de fotos + Vídeo POV</p>
                    <p className="mt-1 text-[12px] text-white/55 leading-relaxed">
                      {openingPlanId === planVideoPack ? "Abrindo pagamento..." : "Esta oferta única só está disponível aqui e agora."}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {openingPlanId === planVideoPack && (
                      <Loader2 className="w-3.5 h-3.5 text-white/70 animate-spin" />
                    )}
                    <p className="text-[16px] font-semibold text-white/90">{priceShort(planVideoPack, "29,90")}</p>
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => openPix(planPackOnly)}
                disabled={isOpeningPayment || pixModalOpen}
                className="w-full text-left rounded-2xl border border-white/[0.09] bg-white/[0.02] p-4 transition-colors hover:border-white/[0.2] disabled:opacity-70 disabled:cursor-wait"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-[15px] font-semibold text-white/90">Apenas Pack de Fotos</p>
                    <p className="mt-1 text-[12px] text-white/50 leading-relaxed">
                      {openingPlanId === planPackOnly ? "Abrindo pagamento..." : "Continue somente com seu pack de imagens."}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {openingPlanId === planPackOnly && (
                      <Loader2 className="w-3.5 h-3.5 text-white/70 animate-spin" />
                    )}
                    <p className="text-[16px] font-semibold text-white/75">{priceShort(planPackOnly, "19,90")}</p>
                  </div>
                </div>
              </button>
            </div>
          )}
        </section>
      </div>

      <VideoPovModal
        open={promoOpen}
        onClose={() => setPromoOpen(false)}
        onSubmit={handlePromoSubmit}
        isSubmitting={isSubmittingPromo}
      />

      <PixQrModal
        open={pixModalOpen}
        onClose={() => setPixModalOpen(false)}
        planId={selectedPlanId}
        onPaymentSuccess={handlePixPaymentSuccess}
      />
    </div>
  );
}
