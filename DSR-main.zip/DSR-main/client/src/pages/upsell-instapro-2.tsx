import { useCallback, useEffect, useReducer, useRef, useState, type ReactNode } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
    ArrowRight,
    CheckCircle2,
    Clock,
    Crown,
    Film,
    Infinity,
    Lock,
    MessageCircle,
    Play,
    Search,
    ShieldCheck,
    SlidersHorizontal,
    Sparkles,
    Star,
    X,
    type LucideIcon,
} from "lucide-react";
import PixQrModal from "@/components/PixQrModal";
import { useToast } from "@/hooks/use-toast";
import { getQueryFn, CRITICAL_QUERY_OPTIONS } from "@/lib/queryClient";
import { trackFunnelEvent, getTrackingSessionKey } from "@/lib/funnel";
import {
    AlertDialog,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const TIMER_DURATION_MS = 10 * 60 * 1000;
const TIMER_START_KEY = "upsell_ai15_v2_10min_timer_started_at";
const TIMER_PAUSED_KEY = "upsell_ai15_v2_10min_timer_paused_at";
const TIMER_FROZEN_REMAINING_KEY = "upsell_ai15_v2_10min_timer_frozen_remaining";
const VARIANT_KEY = "upsell_ai15_v2_variant";
const LANDING_FUNNEL_STATE_KEY = "desireai:landing:funnel-state:v1";
const PLAN_ID = "upsell-instapro-semanal";
const PRICE_FULL = "R$ 249";
const PRICE_NOW = "R$ 59,90";

type UserMe = { id: string; username: string; email: string | null; hasPaidPix: boolean } | null;
type CtaVariant = "A" | "B";
type DialogState = "none" | "decline";

type IconItem = {
    icon: LucideIcon;
    title: string;
    description?: string;
};

function readOrInitTimerStart(): number {
    if (typeof window === "undefined") return Date.now();
    const existing = window.sessionStorage.getItem(TIMER_START_KEY);
    if (existing) {
        const parsed = parseInt(existing, 10);
        if (!Number.isNaN(parsed)) return parsed;
    }
    const now = Date.now();
    window.sessionStorage.setItem(TIMER_START_KEY, String(now));
    return now;
}

function readFrozenRemaining(): number | null {
    if (typeof window === "undefined") return null;
    const raw = window.sessionStorage.getItem(TIMER_FROZEN_REMAINING_KEY);
    if (!raw) return null;
    const parsed = parseInt(raw, 10);
    return Number.isNaN(parsed) ? null : parsed;
}

function formatMMSS(ms: number): string {
    const totalSec = Math.max(0, Math.floor(ms / 1000));
    const mm = Math.floor(totalSec / 60).toString().padStart(2, "0");
    const ss = (totalSec % 60).toString().padStart(2, "0");
    return `${mm}:${ss}`;
}

function pickVariant(): CtaVariant {
    if (typeof window === "undefined") return "B";
    const existing = window.sessionStorage.getItem(VARIANT_KEY);
    if (existing === "A" || existing === "B") return existing;
    const chosen: CtaVariant = Math.random() < 0.5 ? "A" : "B";
    window.sessionStorage.setItem(VARIANT_KEY, chosen);
    return chosen;
}

function readGeneratedPreviewSrc(): string | null {
    if (typeof window === "undefined") return null;
    try {
        const raw = window.sessionStorage.getItem(LANDING_FUNNEL_STATE_KEY);
        if (!raw) return null;
        const parsed = JSON.parse(raw) as { generatedImageId?: string; generatedImageStatus?: string };
        if (!parsed.generatedImageId || parsed.generatedImageStatus !== "completed") return null;
        return `/api/generated-images/${parsed.generatedImageId}/image`;
    } catch {
        return null;
    }
}

function clearTimerStorage() {
    if (typeof window === "undefined") return;
    window.sessionStorage.removeItem(TIMER_START_KEY);
    window.sessionStorage.removeItem(TIMER_PAUSED_KEY);
    window.sessionStorage.removeItem(TIMER_FROZEN_REMAINING_KEY);
}

function useAuthUser() {
    return useQuery<UserMe>({
        queryKey: ["/api/user/me"],
        queryFn: getQueryFn({ on401: "returnNull" }),
        retry: false,
        ...CRITICAL_QUERY_OPTIONS,
    });
}

const heroBullets = [
    "Mulheres reais",
    "Famosas",
    "Filtros de idade e etnia",
    "Filtros por região e categoria",
    "Comentários da comunidade",
];

const unlockItems: IconItem[] = [
    {
        icon: Infinity,
        title: "Qualquer mulher, cenas ilimitadas",
    },
    {
        icon: Film,
        title: "Vídeos POV do jeito que desejar",
    },
    {
        icon: Crown,
        title: "Área de membros VIP com mais de 300.000 conteúdos",
    },
    {
        icon: SlidersHorizontal,
        title: "Sistema de filtros para encontrar os melhores conteúdos",
    },
];

const fantasyChips = [
    "namorada",
    "academia",
    "praia",
    "cosplay",
    "secretária",
    "enfermeira",
    "professora",
    "policial",
    "vizinha",
    "influencer",
    "madura",
    "lingerie",
    "duas mulheres",
    "gangbang",
    "roleplay consensual",
];

const howItWorks = [
    "Sua geração já está salva na sua conta",
    "Reembolso automático da compra anterior comprando o upgrade",
    "PIX único, sem renovação automática, sem cartão",
    "Liberação automática logo após confirmar o pagamento",
];

const testimonials = [
    { quote: "Bom pra caralho", label: "Cliente anônimo" },
    { quote: "Fiz vídeo com todas as mulheres do trabalho, top demais", label: "Cliente anônimo" },
    { quote: "Melhor compra do ano kkkkkkkkk sfd", label: "Cliente anônimo" },
    {
        quote: "A biblioteca de conteúdos é simplesmente bizarra de boa, valeu cada centavo",
        label: "Cliente anônimo",
    },
];

const vipTiles = [
    { label: "Top hoje", meta: "12.4k comentários", tone: "from-[#84223b] via-[#1d2939] to-[#101828]" },
    { label: "Famosas", meta: "verificadas", tone: "from-[#7a2e0e] via-[#30170a] to-[#101828]" },
    { label: "Academia", meta: "packs novos", tone: "from-[#065f46] via-[#113329] to-[#101828]" },
    { label: "POV", meta: "vídeos curtos", tone: "from-[#1d4ed8] via-[#172554] to-[#101828]" },
    { label: "Influencer", meta: "alta retenção", tone: "from-[#9a3412] via-[#431407] to-[#101828]" },
    { label: "Cosplay", meta: "categorias", tone: "from-[#6d28d9] via-[#2e1065] to-[#101828]" },
];

type DialogAction =
    | { type: "open"; dialog: Exclude<DialogState, "none"> }
    | { type: "close" };

function dialogReducer(_: DialogState, action: DialogAction): DialogState {
    return action.type === "open" ? action.dialog : "none";
}

function TimerDisplay({
    remainingMs,
    expired,
    lastMinute,
}: {
    remainingMs: number;
    expired: boolean;
    lastMinute: boolean;
}) {
    const label = formatMMSS(remainingMs);
    const sec = Math.floor(remainingMs / 1000);
    const shouldAnnounce = sec % (remainingMs <= 60_000 ? 15 : 60) === 0;
    return (
        <div
            className={`sticky top-0 z-50 border-b border-white/10 ${
                expired || lastMinute ? "bg-[#8c1229]" : "bg-[#08090d]/95 backdrop-blur-md"
            }`}
            data-testid="upsell-topbar-timer"
        >
            <div className="mx-auto flex max-w-6xl items-center justify-center gap-2 px-4 py-2 text-center text-xs font-semibold text-white sm:text-sm">
                <Clock className="h-4 w-4 shrink-0 opacity-90" />
                {expired ? (
                    <span>Oferta expirada · o acesso de 15 dias voltou para {PRICE_FULL}</span>
                ) : (
                    <span className="flex flex-wrap items-center justify-center gap-x-1.5 gap-y-0.5">
                        <span>Oferta expira em até 10 minutos</span>
                        <span aria-hidden="true">·</span>
                        <span
                            className={`tabular-nums ${lastMinute ? "animate-pulse" : ""}`}
                            role="timer"
                            aria-live={shouldAnnounce ? "polite" : "off"}
                            aria-atomic="true"
                        >
                            {label}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>Somente agora, essa tela nunca mais irá aparecer</span>
                    </span>
                )}
            </div>
        </div>
    );
}

function SectionKicker({ children }: { children: ReactNode }) {
    return <p className="text-sm font-semibold text-[#ff8fa3]">{children}</p>;
}

function PrimaryCta({
    onClick,
    disabled,
    testId,
}: {
    onClick: () => void;
    disabled?: boolean;
    testId: string;
}) {
    return (
        <button
            onClick={onClick}
            disabled={disabled}
            className="group flex h-16 w-full items-center justify-center gap-3 rounded-lg border border-[#ff5a76]/35 bg-[#8c1229] px-5 text-base font-black text-white shadow-[0_14px_44px_rgba(140,18,41,0.32)] transition hover:bg-[#a61530] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#ff8fa3] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 sm:text-lg"
            data-testid={testId}
        >
            <Lock className="h-5 w-5 shrink-0" />
            <span>LIBERAR UPGRADE</span>
            <ArrowRight className="h-5 w-5 shrink-0 transition-transform group-hover:translate-x-0.5" />
        </button>
    );
}

function PriceBlock() {
    return (
        <div className="grid gap-3 sm:grid-cols-[0.8fr_1.2fr]">
            <div className="rounded-lg border border-white/10 bg-white/[0.03] p-4">
                <p className="text-sm text-white/50">Preço normal</p>
                <p className="mt-1 text-3xl font-semibold text-white/45 line-through decoration-[#ff5a76] decoration-2">
                    {PRICE_FULL}
                </p>
            </div>
            <div className="rounded-lg border border-[#ff5a76]/40 bg-[#8c1229]/20 p-4">
                <p className="text-sm font-semibold text-[#ffb3c0]">Somente agora · e nunca mais</p>
                <p className="mt-1 text-5xl font-black leading-none text-white">{PRICE_NOW}</p>
            </div>
        </div>
    );
}

function GeneratedPreview({
    src,
    onError,
}: {
    src: string | null;
    onError: () => void;
}) {
    return (
        <div className="relative overflow-hidden rounded-lg border border-white/10 bg-[#111827]">
            <div className="aspect-[4/5]">
                {src ? (
                    <img
                        src={src}
                        alt="Sua geração concluída"
                        className="h-full w-full object-cover"
                        decoding="async"
                        fetchPriority="high"
                        onError={onError}
                    />
                ) : (
                    <div className="grid h-full w-full place-items-center bg-[linear-gradient(135deg,#0f172a_0%,#8c1229_48%,#111827_100%)]">
                        <div className="mx-8 rounded-lg border border-white/15 bg-black/35 p-5 text-center backdrop-blur-sm">
                            <CheckCircle2 className="mx-auto h-9 w-9 text-emerald-300" />
                            <p className="mt-3 text-lg font-semibold text-white">Sua geração já está salva na sua conta</p>
                            <p className="mt-1 text-sm text-white/65">Faça o upgrade promocional para gerações ilimitadas.</p>
                        </div>
                    </div>
                )}
            </div>
            <div className="absolute left-3 right-3 top-3 flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-400/25 bg-black/55 px-2.5 py-1.5 text-xs font-semibold text-emerald-200 backdrop-blur-sm">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Pagamento aprovado
                </span>
                <span className="rounded-lg border border-white/15 bg-black/55 px-2.5 py-1.5 text-xs font-semibold text-white/80 backdrop-blur-sm">
                    Conteúdo pronto
                </span>
            </div>
        </div>
    );
}

function VipInterfacePreview({
    generatedPreviewSrc,
    canShowGeneratedPreview,
    onPreviewError,
}: {
    generatedPreviewSrc: string | null;
    canShowGeneratedPreview: boolean;
    onPreviewError: () => void;
}) {
    return (
        <section className="border-y border-white/10 bg-[#0f1117] py-10 md:py-14">
            <div className="mx-auto max-w-6xl px-4 sm:px-5">
                <div className="mb-5 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                        <SectionKicker>INTERFACE DA ÁREA VIP DESIRES</SectionKicker>
                        <h2 className="mt-1 text-3xl font-black text-white sm:text-4xl">VIP Desires</h2>
                    </div>
                    <div className="flex items-center gap-2 rounded-lg border border-emerald-400/20 bg-emerald-400/10 px-3 py-2 text-sm font-semibold text-emerald-200">
                        <Crown className="h-4 w-4" />
                        +300.000 conteúdos
                    </div>
                </div>

                <div className="overflow-hidden rounded-lg border border-white/10 bg-[#090b10] shadow-[0_24px_80px_rgba(0,0,0,0.35)]">
                    <div className="flex flex-col gap-3 border-b border-white/10 bg-[#111827] p-3 sm:flex-row sm:items-center sm:justify-between">
                        <div className="flex items-center gap-2">
                            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#8c1229] text-white">
                                <Crown className="h-5 w-5" />
                            </div>
                            <div>
                                <p className="font-black text-white">VIP Desires</p>
                                <p className="text-xs text-white/50">15 dias sem travas</p>
                            </div>
                        </div>
                        <div className="flex min-h-10 items-center gap-2 rounded-lg border border-white/10 bg-black/25 px-3 text-sm text-white/55 sm:w-[320px]">
                            <Search className="h-4 w-4 shrink-0" />
                            <span className="truncate">Buscar mulher, região, categoria...</span>
                        </div>
                    </div>

                    <div className="grid lg:grid-cols-[230px_minmax(0,1fr)]">
                        <aside className="border-b border-white/10 bg-[#0d1017] p-4 lg:border-b-0 lg:border-r">
                            <p className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                                <SlidersHorizontal className="h-4 w-4 text-[#ff8fa3]" />
                                Filtros
                            </p>
                            <div className="grid gap-2 text-sm text-white/70">
                                {["Idade", "Etnia", "Região", "Categoria", "Mais comentadas"].map((filter) => (
                                    <div
                                        key={filter}
                                        className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2"
                                    >
                                        <span>{filter}</span>
                                        <CheckCircle2 className="h-4 w-4 text-emerald-300" />
                                    </div>
                                ))}
                            </div>
                        </aside>

                        <div className="p-4">
                            <div className="mb-4 grid gap-2 sm:grid-cols-3">
                                <div className="rounded-lg border border-white/10 bg-white/[0.03] p-3">
                                    <p className="text-xs text-white/45">Catálogo</p>
                                    <p className="mt-1 text-xl font-black text-white">+300.000 conteúdos</p>
                                </div>
                                <div className="rounded-lg border border-white/10 bg-white/[0.03] p-3">
                                    <p className="text-xs text-white/45">Comunidade</p>
                                    <p className="mt-1 text-xl font-black text-white">Comentários da comunidade</p>
                                </div>
                                <div className="rounded-lg border border-white/10 bg-white/[0.03] p-3">
                                    <p className="text-xs text-white/45">Gerações</p>
                                    <p className="mt-1 text-xl font-black text-white">sem limite</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                                {vipTiles.map((tile, index) => {
                                    const showPreview = index === 0 && canShowGeneratedPreview;
                                    return (
                                        <div
                                            key={tile.label}
                                            className="relative min-h-[150px] overflow-hidden rounded-lg border border-white/10 bg-[#111827]"
                                        >
                                            {showPreview ? (
                                                <img
                                                    src={generatedPreviewSrc ?? undefined}
                                                    alt="Prévia da sua geração na área VIP"
                                                    className="absolute inset-0 h-full w-full object-cover"
                                                    loading="lazy"
                                                    decoding="async"
                                                    onError={onPreviewError}
                                                />
                                            ) : (
                                                <div className={`absolute inset-0 bg-gradient-to-br ${tile.tone}`} />
                                            )}
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-transparent" />
                                            <div className="absolute bottom-0 left-0 right-0 p-3">
                                                <p className="text-sm font-black text-white">{tile.label}</p>
                                                <p className="mt-1 flex items-center gap-1.5 text-xs text-white/65">
                                                    {index === 3 ? (
                                                        <Play className="h-3.5 w-3.5" />
                                                    ) : (
                                                        <MessageCircle className="h-3.5 w-3.5" />
                                                    )}
                                                    {tile.meta}
                                                </p>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default function UpsellInstaPro2Page() {
    const { toast } = useToast();
    const [, setLocation] = useLocation();
    const { data: user } = useAuthUser();

    const [variant] = useState<CtaVariant>(() => pickVariant());
    const [generatedPreviewSrc] = useState<string | null>(() => readGeneratedPreviewSrc());
    const [previewLoadFailed, setPreviewLoadFailed] = useState(false);
    const [isPixModalOpen, setIsPixModalOpen] = useState(false);
    const [remainingMs, setRemainingMs] = useState<number>(() => {
        const frozen = readFrozenRemaining();
        if (frozen !== null) return frozen;
        const start = readOrInitTimerStart();
        return Math.max(0, TIMER_DURATION_MS - (Date.now() - start));
    });
    const [expired, setExpired] = useState(false);
    const [dialog, dispatchDialog] = useReducer(dialogReducer, "none");
    const [stickyCtaVisible, setStickyCtaVisible] = useState(false);

    const exitingRef = useRef(false);
    const heroCtaRef = useRef<HTMLDivElement | null>(null);
    const finalCtaRef = useRef<HTMLDivElement | null>(null);
    const channelRef = useRef<BroadcastChannel | null>(null);

    const fallbackRedirectPath = user?.id ? "/painel" : "/";
    const lastMinute = remainingMs <= 60_000 && remainingMs > 0;
    const canShowGeneratedPreview = Boolean(generatedPreviewSrc && !previewLoadFailed);

    useEffect(() => {
        if (typeof window === "undefined" || typeof BroadcastChannel === "undefined") return;
        const channel = new BroadcastChannel("upsell_instapro_v2");
        channel.onmessage = (event) => {
            if (event.data?.type === "paid" && !exitingRef.current) {
                exitingRef.current = true;
                clearTimerStorage();
                toast({
                    title: "Upgrade já aceito em outra aba.",
                    description: "Redirecionando...",
                });
                window.setTimeout(() => {
                    setLocation(user?.id ? "/painel" : "/");
                }, 1500);
            }
        };
        channelRef.current = channel;
        return () => {
            channel.close();
            channelRef.current = null;
        };
    }, [setLocation, toast, user?.id]);

    useEffect(() => {
        void trackFunnelEvent({
            step: "offer_viewed",
            eventName: "upsell.instapro_viewed",
            idempotencyKey: `upsell_ai15_v2:viewed:${getTrackingSessionKey()}`,
            metadata: { variant, offer: "ai_unlimited_15_days", screen: "instapro_2" },
        });
    }, [variant]);

    useEffect(() => {
        if (expired || isPixModalOpen) return;

        const frozen = readFrozenRemaining();
        let startRef: number;
        if (frozen !== null) {
            const consumed = TIMER_DURATION_MS - frozen;
            startRef = Date.now() - consumed;
            window.sessionStorage.setItem(TIMER_START_KEY, String(startRef));
            window.sessionStorage.removeItem(TIMER_FROZEN_REMAINING_KEY);
            window.sessionStorage.removeItem(TIMER_PAUSED_KEY);
        } else {
            startRef = readOrInitTimerStart();
        }

        const tick = () => {
            const remaining = Math.max(0, TIMER_DURATION_MS - (Date.now() - startRef));
            setRemainingMs(remaining);
            if (remaining <= 0) setExpired(true);
        };

        tick();
        const id = window.setInterval(tick, 1000);
        return () => window.clearInterval(id);
    }, [expired, isPixModalOpen]);

    useEffect(() => {
        if (typeof window === "undefined" || !isPixModalOpen || expired) return;
        const start = readOrInitTimerStart();
        const remaining = Math.max(0, TIMER_DURATION_MS - (Date.now() - start));
        window.sessionStorage.setItem(TIMER_FROZEN_REMAINING_KEY, String(remaining));
        window.sessionStorage.setItem(TIMER_PAUSED_KEY, String(Date.now()));
    }, [isPixModalOpen, expired]);

    useEffect(() => {
        if (expired) return;
        const handler = (e: BeforeUnloadEvent) => {
            if (isPixModalOpen || exitingRef.current) return undefined;
            e.preventDefault();
            e.returnValue = "";
            return "";
        };
        window.addEventListener("beforeunload", handler);
        return () => window.removeEventListener("beforeunload", handler);
    }, [expired, isPixModalOpen]);

    useEffect(() => {
        if (typeof window === "undefined") return;
        const hero = heroCtaRef.current;
        const finalC = finalCtaRef.current;
        if (!hero || !finalC) return;

        let heroPassed = false;
        let finalVisible = false;
        const update = () => setStickyCtaVisible(heroPassed && !finalVisible);

        const heroObs = new IntersectionObserver(
            ([entry]) => {
                if (!entry.isIntersecting && entry.boundingClientRect.top < 0) {
                    heroPassed = true;
                } else if (entry.isIntersecting) {
                    heroPassed = false;
                }
                update();
            },
            { threshold: 0, rootMargin: "-56px 0px 0px 0px" },
        );

        const finalObs = new IntersectionObserver(
            ([entry]) => {
                finalVisible = entry.isIntersecting;
                update();
            },
            { threshold: 0, rootMargin: "0px 0px 160px 0px" },
        );

        heroObs.observe(hero);
        finalObs.observe(finalC);
        return () => {
            heroObs.disconnect();
            finalObs.disconnect();
        };
    }, []);

    useEffect(() => {
        if (isPixModalOpen) setStickyCtaVisible(false);
    }, [isPixModalOpen]);

    const handleCtaClick = useCallback(
        (source: string) => {
            if (expired) return;
            void trackFunnelEvent({
                step: "offer_responded",
                eventName: "upsell.instapro_cta_clicked",
                idempotencyKey: `upsell_ai15_v2:cta_clicked:${getTrackingSessionKey()}:${source}`,
                metadata: { variant, source, offer: "ai_unlimited_15_days", screen: "instapro_2" },
            });
            setIsPixModalOpen(true);
        },
        [expired, variant],
    );

    const handlePixClose = useCallback(() => {
        setIsPixModalOpen(false);
    }, []);

    const handlePaid = useCallback(
        (paymentData?: unknown) => {
            exitingRef.current = true;
            channelRef.current?.postMessage({ type: "paid" });
            void trackFunnelEvent({
                step: "pix_paid",
                eventName: "upsell.instapro_paid",
                idempotencyKey: `upsell_ai15_v2:paid:${getTrackingSessionKey()}`,
                metadata: { variant, paymentData: paymentData ?? null, offer: "ai_unlimited_15_days", screen: "instapro_2" },
            });
            clearTimerStorage();
            toast({
                title: "Upgrade liberado.",
                description: "Reembolso da compra anterior acionado. Acesso de 15 dias ativo.",
            });
            window.setTimeout(() => {
                setLocation(user?.id ? "/painel" : "/");
            }, 1500);
        },
        [setLocation, toast, user?.id, variant],
    );

    const handleDecline = useCallback(() => {
        dispatchDialog({ type: "open", dialog: "decline" });
    }, []);

    const confirmDecline = useCallback(() => {
        void trackFunnelEvent({
            step: "offer_responded",
            eventName: "upsell.instapro_declined",
            idempotencyKey: `upsell_ai15_v2:declined:${getTrackingSessionKey()}`,
            metadata: { variant, offer: "ai_unlimited_15_days", screen: "instapro_2" },
        });
        clearTimerStorage();
        exitingRef.current = true;
        dispatchDialog({ type: "close" });
        setLocation(fallbackRedirectPath);
    }, [fallbackRedirectPath, setLocation, variant]);

    return (
        <div
            className="min-h-screen overflow-x-hidden bg-[#07080c] text-white"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
            <TimerDisplay remainingMs={remainingMs} expired={expired} lastMinute={lastMinute} />

            <main>
                <section className="relative border-b border-white/10 bg-[linear-gradient(180deg,#101218_0%,#07080c_100%)]">
                    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-8 sm:px-5 md:grid-cols-[minmax(0,1fr)_410px] md:items-center md:py-12">
                        <div>
                            <div className="mb-4 inline-flex items-center gap-2 rounded-lg border border-emerald-400/20 bg-emerald-400/10 px-3 py-2 text-sm font-semibold text-emerald-200">
                                <CheckCircle2 className="h-4 w-4" />
                                Pagamento aprovado · Geração concluída
                            </div>

                            <h1 className="max-w-3xl text-4xl font-black leading-tight text-white sm:text-5xl md:text-6xl">
                                Faça o upgrade promocional para gerações ilimitadas.
                            </h1>

                            <p className="mt-4 max-w-2xl text-base leading-relaxed text-white/72 sm:text-lg">
                                Gere fotos, packs e vídeos POV. Sem limite por 15 dias. Receba o acesso à comunidade VIP Desires e tenha acesso a todas as gerações da plataforma (+300.000 conteúdos)
                            </p>

                            <div className="mt-5 grid gap-2 sm:grid-cols-2">
                                {heroBullets.map((item) => (
                                    <div key={item} className="flex items-center gap-2 text-sm font-semibold text-white/86">
                                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-300" />
                                        <span>{item}</span>
                                    </div>
                                ))}
                            </div>

                            <div className="mt-7 max-w-2xl">
                                <PriceBlock />
                                <div className="mt-3 flex items-start gap-2 rounded-lg border border-emerald-400/20 bg-emerald-400/10 px-3 py-2 text-sm leading-relaxed text-emerald-100">
                                    <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
                                    <span>Comprando o upgrade, o reembolso da compra anterior é feito automaticamente</span>
                                </div>
                                <div ref={heroCtaRef} className="mt-4">
                                    <PrimaryCta
                                        onClick={() => handleCtaClick("hero")}
                                        disabled={expired}
                                        testId="upsell-cta-hero"
                                    />
                                    <p className="mt-2 text-center text-sm text-white/58 sm:text-left">
                                        PIX único · Sem renovação automática · Satisfação garantida
                                    </p>
                                </div>
                            </div>
                        </div>

                        <GeneratedPreview
                            src={canShowGeneratedPreview ? generatedPreviewSrc : null}
                            onError={() => setPreviewLoadFailed(true)}
                        />
                    </div>
                </section>

                <VipInterfacePreview
                    generatedPreviewSrc={generatedPreviewSrc}
                    canShowGeneratedPreview={canShowGeneratedPreview}
                    onPreviewError={() => setPreviewLoadFailed(true)}
                />

                <section className="mx-auto max-w-6xl px-4 py-10 sm:px-5 md:py-14">
                    <SectionKicker>15 dias SEM TRAVAS</SectionKicker>
                    <h2 className="mt-1 text-3xl font-black text-white sm:text-4xl">O que tu libera agora</h2>

                    <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                        {unlockItems.map((item) => {
                            const Icon = item.icon;
                            return (
                                <div key={item.title} className="rounded-lg border border-white/10 bg-white/[0.03] p-4">
                                    <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg border border-[#ff5a76]/25 bg-[#8c1229]/20 text-[#ff8fa3]">
                                        <Icon className="h-5 w-5" />
                                    </div>
                                    <h3 className="text-lg font-black leading-tight text-white">{item.title}</h3>
                                    {item.description ? (
                                        <p className="mt-2 text-sm leading-relaxed text-white/60">{item.description}</p>
                                    ) : null}
                                </div>
                            );
                        })}
                    </div>
                </section>

                <section className="border-y border-white/10 bg-[#101218] py-10 md:py-14">
                    <div className="mx-auto max-w-6xl px-4 sm:px-5">
                        <SectionKicker>Fantasias prontas</SectionKicker>
                        <h2 className="mt-1 text-3xl font-black text-white sm:text-4xl">Gere do jeito que desejar.</h2>
                        <p className="mt-3 max-w-2xl text-base leading-relaxed text-white/65">
                            Ajuste cada detalhe: roupa, pose, cenário, expressão, estilo.
                        </p>
                        <div className="mt-5 flex flex-wrap gap-2">
                            {fantasyChips.map((fantasy) => (
                                <span
                                    key={fantasy}
                                    className="rounded-lg border border-white/10 bg-white/[0.04] px-3 py-2 text-sm font-semibold text-white/78"
                                >
                                    {fantasy}
                                </span>
                            ))}
                        </div>
                    </div>
                </section>

                <section className="mx-auto grid max-w-6xl gap-5 px-4 py-10 sm:px-5 md:grid-cols-[0.8fr_1.2fr] md:py-14">
                    <div>
                        <SectionKicker>Como funciona:</SectionKicker>
                        <div className="mt-4 grid gap-3">
                            {howItWorks.map((item) => (
                                <div key={item} className="flex items-start gap-3 rounded-lg border border-white/10 bg-white/[0.03] p-3 text-sm leading-relaxed text-white/72">
                                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-300" />
                                    <span>{item}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="grid gap-3 sm:grid-cols-2">
                        {testimonials.map((testimonial) => (
                            <div key={testimonial.quote} className="rounded-lg border border-white/10 bg-white/[0.03] p-4">
                                <div className="mb-3 flex gap-1 text-amber-300">
                                    {Array.from({ length: 5 }).map((_, index) => (
                                        <Star key={index} className="h-4 w-4 fill-current" />
                                    ))}
                                </div>
                                <p className="text-base font-semibold leading-relaxed text-white/88">
                                    “{testimonial.quote}”
                                </p>
                                <p className="mt-3 text-sm font-semibold text-white/45">{testimonial.label}</p>
                            </div>
                        ))}
                    </div>
                </section>

                <section className="border-t border-white/10 bg-[#0d1017] px-4 py-10 sm:px-5 md:py-14">
                    <div className="mx-auto max-w-3xl text-center">
                        <p className="text-base font-black text-[#ff8fa3]">
                            Somente agora, essa tela nunca mais irá aparecer!
                        </p>
                        <h2 className="mt-3 text-3xl font-black leading-tight text-white sm:text-5xl">
                            {PRICE_FULL} viraram {PRICE_NOW}.
                        </h2>
                        <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-white/64">
                            Ao confirmar o upgrade, o reembolso da compra anterior é feito automaticamente. Fora desta tela, o passe de 15 dias volta para {PRICE_FULL}.
                        </p>

                        <div ref={finalCtaRef} className="mx-auto mt-6 max-w-xl">
                            <PrimaryCta
                                onClick={() => handleCtaClick("final")}
                                disabled={expired}
                                testId="upsell-cta-final"
                            />
                            <p className="mt-2 text-sm text-white/58">
                                PIX único · sem renovação · reembolso acionado no upgrade
                            </p>
                        </div>

                        <button
                            onClick={handleDecline}
                            className="mt-5 text-sm text-white/52 underline underline-offset-4 transition-colors hover:text-white/86 focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-white/30"
                            data-testid="upsell-decline-link"
                        >
                            Não, quero apenas minha geração
                        </button>
                    </div>
                </section>
            </main>

            <div
                className={`fixed bottom-0 left-0 right-0 z-40 transition-transform duration-300 sm:hidden ${
                    stickyCtaVisible && !isPixModalOpen && !expired
                        ? "translate-y-0"
                        : "pointer-events-none translate-y-full"
                }`}
            >
                <div className="border-t border-white/10 bg-black/[0.92] p-3 backdrop-blur-md">
                    <button
                        onClick={() => handleCtaClick("sticky")}
                        className="flex h-14 w-full items-center justify-center gap-2 rounded-lg bg-[#8c1229] px-4 text-sm font-black text-white shadow-[0_8px_32px_rgba(140,18,41,0.45)] transition active:scale-[0.98]"
                        data-testid="upsell-cta-sticky"
                        aria-label={`Liberar upgrade, oferta expira em ${formatMMSS(remainingMs)}`}
                    >
                        <Lock className="h-4 w-4 shrink-0" />
                        <span className="truncate">LIBERAR UPGRADE</span>
                        <ArrowRight className="h-4 w-4 shrink-0" />
                    </button>
                    <p className="mt-1 text-center text-xs text-white/45 tabular-nums">
                        Oferta expira em {formatMMSS(remainingMs)}
                    </p>
                </div>
            </div>

            <PixQrModal
                open={isPixModalOpen}
                onClose={handlePixClose}
                planId={PLAN_ID}
                onPaymentSuccess={handlePaid}
                redirectAfterPaymentTo={null}
            />

            <AlertDialog
                open={dialog === "decline"}
                onOpenChange={(open) => !open && dispatchDialog({ type: "close" })}
            >
                <AlertDialogContent className="border-[#8c1229]/40 bg-[#0a0a0a] text-[#f5f5f5]">
                    <AlertDialogHeader>
                        <AlertDialogTitle className="text-[#f5f5f5]">Continuar sem o upgrade?</AlertDialogTitle>
                        <AlertDialogDescription asChild>
                            <div className="space-y-3 text-[#d4d4d4]">
                                <p>
                                    Sua geração atual continua liberada. Tu só perde os 15 dias sem travas,
                                    a área VIP e o reembolso acionado no upgrade.
                                </p>
                                <p>Esta condição só aparece nesta tela e termina quando o timer zerar.</p>
                            </div>
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter className="flex flex-col-reverse gap-2 sm:flex-col-reverse sm:space-x-0">
                        <AlertDialogCancel
                            onClick={() => dispatchDialog({ type: "close" })}
                            className="mt-0 h-14 w-full border-[#8c1229] bg-[#8c1229] text-base font-black text-white hover:bg-[#b51836]"
                        >
                            <Sparkles className="mr-2 h-4 w-4" />
                            Voltar e liberar upgrade
                        </AlertDialogCancel>
                        <button
                            onClick={confirmDecline}
                            className="mx-auto mt-2 flex items-center gap-1 text-sm text-[#888] underline underline-offset-4 transition-colors hover:text-[#bbb]"
                            data-testid="upsell-decline-confirm"
                        >
                            <X className="h-3.5 w-3.5" />
                            Continuar com minha geração
                        </button>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}
