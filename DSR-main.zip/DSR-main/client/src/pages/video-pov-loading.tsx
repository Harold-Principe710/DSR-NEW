import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { Loader2, CheckCircle2, Infinity } from "lucide-react";
import PackPhotosPromoModal from "@/components/PackPhotosPromoModal";
import PixQrModal, { PLANS } from "@/components/PixQrModal";
import { trackFunnelEvent } from "@/lib/funnel";
import { useResolvePlanId } from "@/lib/ab-pricing";
import { fetchWithTimeout } from "@/lib/queryClient";

function priceShort(planId: string, fallback: string): string {
  const raw = PLANS[planId]?.price;
  return raw ? raw.replace(/^R\$\s*/, "") : fallback;
}

const LOADING_SECONDS = 30;
const PREVIEW_POLL_INTERVAL_MS = 2000;
const PREVIEW_POLL_TIMEOUT_MS = (LOADING_SECONDS * 1000) + 60000;
type PreviewLoadResult = "resolved" | "pending" | "error";

function canPreloadPreviewVideo(): boolean {
  if (typeof navigator === "undefined") return true;
  const connection = (navigator as Navigator & {
    connection?: { saveData?: boolean; effectiveType?: string };
  }).connection;
  if (connection?.saveData) return false;
  return !["slow-2g", "2g"].includes(String(connection?.effectiveType || "").toLowerCase());
}

export default function VideoPovLoadingPage() {
  const [, setLocation] = useLocation();
  const resolvePlanId = useResolvePlanId("landing-pricing");
  const planUnlimited = resolvePlanId("ilimitado");
  const planVideoPack = resolvePlanId("video-pov-pack-2990");
  const planVideoOnly = resolvePlanId("video-pov-1990");

  const [secondsLeft, setSecondsLeft] = useState(LOADING_SECONDS);
  const [promoOpen, setPromoOpen] = useState(false);
  const [promoAccepted, setPromoAccepted] = useState(false);
  const [pixModalOpen, setPixModalOpen] = useState(false);
  const [selectedPlanId, setSelectedPlanId] = useState("");
  const [isOpeningPayment, setIsOpeningPayment] = useState(false);
  const [openingPlanId, setOpeningPlanId] = useState<string | null>(null);
  const [previewVideoUrl, setPreviewVideoUrl] = useState<string | null>(null);
  const [previewPosterUrl, setPreviewPosterUrl] = useState<string | undefined>(undefined);

  const promoShownRef = useRef(false);
  const openingPaymentRef = useRef(false);
  const preloadVideoRef = useRef<HTMLVideoElement | null>(null);
  const shouldPreloadPreview = useMemo(() => canPreloadPreviewVideo(), []);
  const videoPreloadMode = shouldPreloadPreview ? "auto" : "metadata";

  const previewParams = useMemo(() => {
    const params = new URLSearchParams(window.location.search);
    return {
      requestId: params.get("requestId") || "",
    };
  }, []);

  const loadPreview = useCallback(async (options: { allowFallback?: boolean } = {}): Promise<PreviewLoadResult> => {
    if (!previewParams.requestId) {
      setPreviewVideoUrl(null);
      setPreviewPosterUrl(undefined);
      return "resolved";
    }

    try {
      const response = await fetchWithTimeout(
        `/api/video-pov-requests/${encodeURIComponent(previewParams.requestId)}/preview`,
        { credentials: "include" },
        8000,
      );

      if (!response.ok) {
        return "error";
      }

      const data = await response.json().catch(() => ({}));
      const isFallback = data?.fallback === true;
      const status = typeof data?.status === "string" ? data.status : "";

      if (isFallback && status !== "failed" && !options.allowFallback) {
        return "pending";
      }

      if (typeof data?.videoUrl !== "string" || !data.videoUrl) {
        return "error";
      }

      setPreviewVideoUrl(data.videoUrl);
      setPreviewPosterUrl(typeof data?.posterUrl === "string" && data.posterUrl ? data.posterUrl : undefined);
      return "resolved";
    } catch {
      return "error";
    }
  }, [previewParams.requestId]);

  useEffect(() => {
    trackFunnelEvent({
      step: "video_loading_screen",
      eventName: "video_pov.loading_screen_entered",
      idempotencyKey: "video_pov:loading_screen",
    });
    const intervalId = window.setInterval(() => {
      setSecondsLeft((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => window.clearInterval(intervalId);
  }, []);

  useEffect(() => {
    if (!previewParams.requestId) return;

    let cancelled = false;
    let intervalId: number | undefined;
    let timeoutId: number | undefined;

    const stop = () => {
      if (intervalId) window.clearInterval(intervalId);
      if (timeoutId) window.clearTimeout(timeoutId);
    };

    const poll = async () => {
      const resolved = await loadPreview({ allowFallback: false });
      if (resolved === "resolved" && !cancelled) stop();
    };

    void poll();
    intervalId = window.setInterval(() => void poll(), PREVIEW_POLL_INTERVAL_MS);
    timeoutId = window.setTimeout(() => stop(), PREVIEW_POLL_TIMEOUT_MS);

    return () => {
      cancelled = true;
      stop();
    };
  }, [loadPreview]);

  useEffect(() => {
    if (!previewVideoUrl) return;
    preloadVideoRef.current?.load();
  }, [previewVideoUrl]);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      promoShownRef.current = true;
      setPromoOpen(true);
    }, 5000);

    return () => window.clearTimeout(timeoutId);
  }, []);

  const progressPercent = useMemo(() => {
    const elapsed = LOADING_SECONDS - secondsLeft;
    return Math.round((elapsed / LOADING_SECONDS) * 100);
  }, [secondsLeft]);

  useEffect(() => {
    if (secondsLeft !== 0) return;
    void loadPreview({ allowFallback: true });
    trackFunnelEvent({
      step: "video_loaded",
      eventName: "video_pov.loaded",
      idempotencyKey: "video_pov:loaded",
      metadata: {
        promoAccepted,
      },
    });
  }, [secondsLeft, promoAccepted]);

  const handlePromoAccept = () => {
    setPromoAccepted(true);
    setPromoOpen(false);
  };

  const openPix = (planId: string) => {
    if (openingPaymentRef.current || isOpeningPayment || pixModalOpen) return;
    openingPaymentRef.current = true;
    trackFunnelEvent({
      step: "offer_responded",
      eventName: "video_pov.offer_clicked",
      idempotencyKey: `video_pov:offer_clicked:${planId}`,
      metadata: { planId, funnelBranch: "video_pov" },
    });
    setIsOpeningPayment(true);
    setOpeningPlanId(planId);
    setSelectedPlanId(planId);
    window.setTimeout(() => {
      setPixModalOpen(true);
      setIsOpeningPayment(false);
      setOpeningPlanId(null);
      openingPaymentRef.current = false;
    }, 240);
  };

  const handlePixPaymentSuccess = () => {
    setLocation("/");
  };

  return (
    <div
      className="min-h-[100svh] bg-gradient-to-br from-[#050102] to-[#0a0204] text-white px-5 py-6"
      style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
    >
      <div className="mx-auto w-full max-w-md flex flex-col gap-5">
        <header className="w-full flex items-center justify-center pt-1 pb-1">
          <img
            src="/uploads/logo.webp"
            alt="DesireAI"
            width={599}
            height={171}
            decoding="async"
            fetchPriority="high"
            className="h-[2.2rem] object-contain opacity-90"
          />
        </header>

        <section className="rounded-2xl border border-[#8c1229]/25 bg-[#0a0204]/70 p-4">
          <div className="aspect-video rounded-xl border border-white/[0.08] bg-black/30 px-5 py-6 flex items-center justify-center">
            <div className={`w-full transition-all duration-200 ${secondsLeft > 0 ? "opacity-100 scale-100" : "opacity-0 scale-[0.985] pointer-events-none absolute"}`}>
              <div className="w-full max-w-[290px] mx-auto flex flex-col items-center text-center gap-2.5">
                <div className="relative">
                  <div className="w-14 h-14 rounded-full border-2 border-[#8c1229]/20 border-t-[#8c1229] border-r-[#8c1229]/60 animate-[spin_1.5s_linear_infinite]" />
                  <div className="absolute inset-0 w-14 h-14 rounded-full border border-transparent border-b-[#ff3b5c]/40 animate-[spin_2s_reverse_linear_infinite]" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Loader2 className="w-4 h-4 text-[#ff3b5c]/70 animate-pulse" />
                  </div>
                </div>
                <h1 className="text-[20px] font-semibold text-white/95">Gerando seu vídeo</h1>
                <p className="text-[13px] text-white/45">Seu conteúdo está sendo preparado agora.</p>

                <div className="w-full h-2 rounded-full bg-white/[0.06] mt-1 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#8c1229] to-[#ff3b5c] transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </div>
            <div className={`w-full transition-all duration-200 ${secondsLeft === 0 ? "opacity-100 scale-100" : "opacity-0 scale-[0.985] pointer-events-none absolute"}`}>
              <div className="w-full max-w-[320px] mx-auto flex flex-col items-center gap-3">
                <p className="text-center text-[17px] font-medium text-white/90 leading-relaxed">
                  Seu vídeo está pronto, desbloqueie para ver e baixar.
                </p>
                {previewVideoUrl && (
                  <>
                    <div className="w-full rounded-xl overflow-hidden border border-white/[0.1] bg-black/40">
                      <video
                        className="w-full aspect-video object-cover"
                        src={previewVideoUrl}
                        poster={previewPosterUrl}
                        controls
                        autoPlay
                        muted
                        loop
                        playsInline
                        preload={videoPreloadMode}
                      />
                    </div>
                    <p className="text-center text-[12px] text-white/65 leading-relaxed">
                      Essa é uma prévia aleatória do vídeo, o vídeo completo contém 10 minutos altamente realistas e imersivos
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>
          {shouldPreloadPreview && previewVideoUrl && secondsLeft > 0 && (
            <video
              ref={preloadVideoRef}
              src={previewVideoUrl}
              poster={previewPosterUrl}
              muted
              playsInline
              preload={videoPreloadMode}
              aria-hidden="true"
              className="fixed h-px w-px opacity-0 pointer-events-none"
              style={{ left: -9999, top: -9999 }}
            />
          )}
        </section>
        <section className="rounded-2xl border border-[#8c1229]/20 bg-[#0a0204]/90 p-4">
          {promoAccepted && secondsLeft > 0 && (
            <div className="w-full rounded-xl border border-emerald-500/30 bg-emerald-500/[0.08] p-3 text-left">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                <div>
                  <p className="text-[13px] text-emerald-300 font-medium">Pack promocional adicionado ao pedido</p>
                  <p className="text-[12px] text-white/55 mt-1">
                    Estamos processando o vídeo junto com o pack premium nesta geração.
                  </p>
                </div>
              </div>
            </div>
          )}

          {!promoAccepted && promoShownRef.current && secondsLeft > 0 && (
            <p className="text-[12px] text-white/30 text-center">
              Oferta relâmpago exibida. Você ainda pode finalizar com a melhor opção no próximo passo.
            </p>
          )}

          {secondsLeft === 0 && (
            <div className="mt-2 flex flex-col gap-3">
              <p className="text-center text-[12px] text-white/35">
                Escolha como finalizar seu pedido:
              </p>

              <button
                type="button"
                onClick={() => openPix(planUnlimited)}
                disabled={isOpeningPayment || pixModalOpen}
                className="w-full text-left rounded-2xl border border-[#ff3b5c]/45 bg-gradient-to-r from-[#8c1229]/30 to-[#520a17]/20 p-4 transition-all duration-200 hover:border-[#ff3b5c]/70 disabled:opacity-75 disabled:cursor-wait shadow-[0_0_24px_rgba(140,18,41,0.22)]"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="inline-flex items-center rounded-full border border-[#ff3b5c]/45 bg-[#8c1229]/30 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[#ffd5de] mb-2">
                      Mais escolhido
                    </span>
                    <div className="flex items-center gap-2 mb-1">
                      <Infinity className="w-4 h-4 text-[#ffd5de]" />
                      <p className="text-[15px] font-semibold text-white/95">Uso diário ilimitado</p>
                    </div>
                    <p className="mt-1 text-[12px] text-white/55 leading-relaxed">
                      {openingPlanId === planUnlimited ? "Abrindo pagamento..." : "24 horas para criar fotos e vídeos ilimitados de quem você quiser"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {openingPlanId === planUnlimited && (
                      <Loader2 className="w-3.5 h-3.5 text-[#ff8ca0] animate-spin" />
                    )}
                    <p className="text-[16px] font-bold text-[#ff3b5c]">{priceShort(planUnlimited, "49,90")}</p>
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => openPix(planVideoPack)}
                disabled={isOpeningPayment || pixModalOpen}
                className="w-full text-left rounded-2xl border border-white/[0.18] bg-white/[0.04] p-4 transition-colors hover:border-white/[0.3] disabled:opacity-70 disabled:cursor-wait"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-[15px] font-semibold text-white/95">Vídeo POV + Pack de fotos</p>
                    <p className="mt-1 text-[12px] text-white/55 leading-relaxed">
                      {openingPlanId === planVideoPack ? "Abrindo pagamento..." : "Esta oferta única só está disponível aqui e agora."}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {openingPlanId === planVideoPack && (
                      <Loader2 className="w-3.5 h-3.5 text-white/70 animate-spin" />
                    )}
                    <p className="text-[16px] font-semibold text-white/90">{priceShort(planVideoPack, "29,90")}</p>
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => openPix(planVideoOnly)}
                disabled={isOpeningPayment || pixModalOpen}
                className="w-full text-left rounded-2xl border border-white/[0.09] bg-white/[0.02] p-4 transition-colors hover:border-white/[0.2] disabled:opacity-70 disabled:cursor-wait"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-[15px] font-semibold text-white/90">Apenas Vídeo POV</p>
                    <p className="mt-1 text-[12px] text-white/50 leading-relaxed">
                      {openingPlanId === planVideoOnly ? "Abrindo pagamento..." : "Continue somente com o vídeo personalizado."}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {openingPlanId === planVideoOnly && (
                      <Loader2 className="w-3.5 h-3.5 text-white/70 animate-spin" />
                    )}
                    <p className="text-[16px] font-semibold text-white/75">{priceShort(planVideoOnly, "19,90")}</p>
                  </div>
                </div>
              </button>
            </div>
          )}
        </section>
      </div>

      <PackPhotosPromoModal
        open={promoOpen}
        onClose={() => setPromoOpen(false)}
        onAccept={handlePromoAccept}
      />

      <PixQrModal
        open={pixModalOpen}
        onClose={() => setPixModalOpen(false)}
        planId={selectedPlanId}
        onPaymentSuccess={handlePixPaymentSuccess}
      />
    </div>
  );
}
