import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  Controls,
  MiniMap,
  Handle,
  Position,
  type Node,
  type Edge,
  type NodeProps,
  type EdgeProps,
  BaseEdge,
  getBezierPath,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { getDateStampInAppTimeZone } from "@/lib/timezone";

type Breakdown = { key: string; label: string; count: number; pct: number };
type AccentKey = "primary" | "pack" | "pov" | "upsell";
type JourneyNode = {
  id: string;
  label: string;
  x: number;
  y: number;
  parent?: string;
  count: number;
  conversionFromParent: number;
  breakdown?: Breakdown[];
  accent?: AccentKey;
};
type JourneyEdge = {
  id: string;
  source: string;
  target: string;
  count: number;
  conversionPct: number;
};
type JourneyTreeResponse = {
  dateFrom: string;
  dateTo: string;
  preset: string;
  totals: { sessions: number };
  nodes: JourneyNode[];
  edges: JourneyEdge[];
  generatedAt: string;
};

type StepNodeData = JourneyNode & { isRoot?: boolean } & Record<string, unknown>;
type StepNodeType = Node<StepNodeData, "stepNode">;
type ProportionalEdgeData = { count: number; conversionPct: number; maxCount: number } & Record<string, unknown>;
type ProportionalEdgeType = Edge<ProportionalEdgeData, "proportional">;

const ACCENT_COLORS: Record<AccentKey, string> = {
  primary: "#8c1229",
  pack: "#c97a16",
  pov: "#1f6f9c",
  upsell: "#15803d",
};

function conversionTone(pct: number): { bg: string; text: string; border: string } {
  if (pct >= 70) return { bg: "rgba(34,197,94,0.18)", text: "#86efac", border: "rgba(34,197,94,0.4)" };
  if (pct >= 40) return { bg: "rgba(234,179,8,0.18)", text: "#fde047", border: "rgba(234,179,8,0.4)" };
  return { bg: "rgba(239,68,68,0.18)", text: "#fca5a5", border: "rgba(239,68,68,0.45)" };
}

function StepNode({ data: node }: NodeProps<StepNodeType>) {
  const accent = ACCENT_COLORS[node.accent || "primary"];
  const conv = node.conversionFromParent ?? 0;
  const tone = conversionTone(conv);
  const breakdownTotal = node.breakdown?.reduce((s, b) => s + b.count, 0) || 0;

  return (
    <div
      className="rounded-2xl border bg-gradient-to-b from-[#160b12] to-[#0a0204] shadow-[0_18px_48px_rgba(0,0,0,0.55)]"
      style={{
        borderColor: `${accent}55`,
        width: 224,
        boxShadow: `0 0 0 1px ${accent}22, 0 18px 48px rgba(0,0,0,0.55)`,
      }}
    >
      <Handle type="target" position={Position.Left} style={{ background: accent, opacity: 0.55 }} />
      <Handle type="source" position={Position.Right} style={{ background: accent, opacity: 0.55 }} />
      <div className="px-3 py-2 border-b" style={{ borderColor: `${accent}33` }}>
        <p className="text-[11px] uppercase tracking-wider text-white/45">{node.label}</p>
      </div>
      <div className="px-3 py-3 flex items-center justify-between gap-2">
        <p className="text-3xl font-semibold text-white tabular-nums">
          {node.count.toLocaleString("pt-BR")}
        </p>
        {!node.isRoot && (
          <span
            className="rounded-full px-2 py-0.5 text-[10px] font-semibold"
            style={{ backgroundColor: tone.bg, color: tone.text, borderColor: tone.border, borderWidth: 1 }}
          >
            {conv.toFixed(1)}%
          </span>
        )}
      </div>
      {node.breakdown && node.breakdown.length > 0 && (
        <div className="px-3 pb-3 pt-1 border-t border-white/5 flex flex-col gap-1.5">
          {node.breakdown.map((b) => {
            const widthPct = breakdownTotal > 0 ? Math.max(2, (b.count / breakdownTotal) * 100) : 0;
            return (
              <div key={b.key} className="flex flex-col gap-0.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10.5px] text-white/65 truncate" title={b.label}>{b.label}</span>
                  <span className="text-[10.5px] font-semibold text-white/85 tabular-nums shrink-0">
                    {b.count.toLocaleString("pt-BR")} · {b.pct.toFixed(1)}%
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-white/[0.05] overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${widthPct}%`, backgroundColor: accent }} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ProportionalEdge({ id, sourceX, sourceY, targetX, targetY, data, style }: EdgeProps<ProportionalEdgeType>) {
  const count = data?.count ?? 0;
  const maxCount = data?.maxCount ?? 1;
  const ratio = Math.max(0.06, Math.min(1, count / Math.max(1, maxCount)));
  const stroke = 2 + ratio * 9;

  const [edgePath, labelX, labelY] = getBezierPath({
    sourceX, sourceY, targetX, targetY,
    sourcePosition: Position.Right, targetPosition: Position.Left,
  });

  const tone = conversionTone(data?.conversionPct ?? 0);
  return (
    <>
      <BaseEdge
        id={id}
        path={edgePath}
        style={{ stroke: "#8c1229", strokeOpacity: 0.55, strokeWidth: stroke, ...style }}
      />
      {count > 0 && (
        <foreignObject width={130} height={26} x={labelX - 65} y={labelY - 13} style={{ overflow: "visible" }}>
          <div className="pointer-events-none flex h-[26px] w-[130px] items-center justify-center">
            <span
              className="rounded-full px-2 py-0.5 text-[10px] font-semibold backdrop-blur-sm"
              style={{
                backgroundColor: tone.bg,
                color: tone.text,
                border: `1px solid ${tone.border}`,
                whiteSpace: "nowrap",
              }}
            >
              {count.toLocaleString("pt-BR")} · {(data?.conversionPct ?? 0).toFixed(1)}%
            </span>
          </div>
        </foreignObject>
      )}
    </>
  );
}

const nodeTypes = { stepNode: StepNode };
const edgeTypes = { proportional: ProportionalEdge };

function downloadCsv(filename: string, rows: Array<Record<string, string | number>>) {
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const escape = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
  const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => escape(r[h] ?? "")).join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function JourneyChart({ data }: { data: JourneyTreeResponse }) {
  const maxEdgeCount = useMemo(
    () => Math.max(1, ...data.edges.map((e) => e.count)),
    [data.edges],
  );

  const flowNodes: StepNodeType[] = useMemo(
    () => data.nodes.map((n) => ({
      id: n.id,
      type: "stepNode",
      position: { x: n.x, y: n.y },
      data: { ...n, isRoot: !n.parent },
      draggable: false,
    })),
    [data.nodes],
  );

  const flowEdges: ProportionalEdgeType[] = useMemo(
    () => data.edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      type: "proportional",
      data: { count: e.count, conversionPct: e.conversionPct, maxCount: maxEdgeCount },
      animated: e.count > 0,
    })),
    [data.edges, maxEdgeCount],
  );

  return (
    <div className="h-[78vh] w-full rounded-2xl border border-white/10 overflow-hidden bg-[#050102]">
      <ReactFlow
        nodes={flowNodes}
        edges={flowEdges}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        fitView
        fitViewOptions={{ padding: 0.18 }}
        minZoom={0.3}
        maxZoom={1.5}
        nodesDraggable={false}
        proOptions={{ hideAttribution: true }}
      >
        <Background color="#1a0a10" gap={28} />
        <MiniMap
          maskColor="rgba(5,1,2,0.85)"
          nodeColor={(n) => {
            const accent = (n.data as StepNodeData | undefined)?.accent;
            return ACCENT_COLORS[accent || "primary"];
          }}
          style={{ backgroundColor: "#0a0204", border: "1px solid rgba(255,255,255,0.08)" }}
        />
        <Controls
          position="top-right"
          style={{ background: "#0a0204", border: "1px solid rgba(255,255,255,0.08)" }}
        />
      </ReactFlow>
    </div>
  );
}

export default function AdminJourneyPage() {
  const [, setLocation] = useLocation();
  const [preset, setPreset] = useState("7d");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  useEffect(() => {
    document.title = "Jornada do Funil · Admin";
  }, []);

  const queryString = useMemo(() => {
    const params = new URLSearchParams();
    params.set("preset", preset);
    if (preset === "custom") {
      if (dateFrom) params.set("dateFrom", dateFrom);
      if (dateTo) params.set("dateTo", dateTo);
    }
    return params.toString();
  }, [preset, dateFrom, dateTo]);

  const { data, isLoading, isError, refetch, isFetching } = useQuery<JourneyTreeResponse>({
    queryKey: ["/api/admin/funnel/journey-tree", queryString],
    queryFn: async () => {
      const res = await fetch(`/api/admin/funnel/journey-tree?${queryString}`, { credentials: "include" });
      if (res.status === 401) {
        setLocation("/admin/login");
        throw new Error("unauthorized");
      }
      if (!res.ok) throw new Error("Erro ao carregar jornada");
      return res.json();
    },
    staleTime: 30_000,
  });

  const handleExport = () => {
    if (!data) return;
    const rows = data.nodes.map((n) => ({
      id: n.id,
      etapa: n.label,
      total: n.count,
      conversao_do_pai_pct: n.conversionFromParent,
      breakdown: (n.breakdown || []).map((b) => `${b.label}: ${b.count} (${b.pct}%)`).join(" | "),
    }));
    downloadCsv(`jornada-${data.preset}-${getDateStampInAppTimeZone()}.csv`, rows);
  };

  return (
    <div className="min-h-screen bg-[#050102] text-white">
      <div className="mx-auto w-full max-w-[1400px] px-4 py-6 space-y-5">
        <header className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold">Jornada do Funil</h1>
            <p className="text-sm text-white/45">Diagrama em árvore com volume + conversão por etapa</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLocation("/admin")}
              className="rounded-lg border border-white/15 px-3 py-2 text-sm hover:bg-white/5"
            >
              ← Voltar ao painel
            </button>
            <button
              onClick={handleExport}
              disabled={!data}
              className="rounded-lg border border-white/15 px-3 py-2 text-sm hover:bg-white/5 disabled:opacity-50"
            >
              Exportar CSV
            </button>
            <button
              onClick={() => refetch()}
              disabled={isFetching}
              className="rounded-lg bg-[#8c1229] px-3 py-2 text-sm font-medium text-white hover:bg-[#a61530] disabled:opacity-60"
            >
              {isFetching ? "Atualizando..." : "Atualizar"}
            </button>
          </div>
        </header>

        <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-4 space-y-3">
          <div className="flex flex-wrap gap-2">
            {["today", "yesterday", "7d", "30d", "custom"].map((p) => (
              <button
                key={p}
                onClick={() => setPreset(p)}
                className={`rounded-lg px-3 py-1.5 text-sm border ${
                  preset === p ? "border-[#8c1229] bg-[#8c1229]/30" : "border-white/10 hover:bg-white/5"
                }`}
              >
                {p === "today" ? "Hoje" : p === "yesterday" ? "Ontem" : p === "7d" ? "7 dias" : p === "30d" ? "30 dias" : "Personalizado"}
              </button>
            ))}
          </div>
          {preset === "custom" && (
            <div className="flex flex-wrap gap-2">
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm"
              />
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm"
              />
            </div>
          )}
          <div className="flex flex-wrap items-center gap-4 text-xs text-white/50">
            <span>
              Sessões na entrada do funil: <span className="text-white/85 font-semibold">{data?.totals.sessions.toLocaleString("pt-BR") ?? 0}</span>
            </span>
            <span className="hidden sm:flex items-center gap-3">
              <Legend color={ACCENT_COLORS.primary} label="Trunk" />
              <Legend color={ACCENT_COLORS.pack} label="Pack de Fotos" />
              <Legend color={ACCENT_COLORS.pov} label="Vídeo POV" />
              <Legend color={ACCENT_COLORS.upsell} label="Upsell" />
            </span>
          </div>
        </section>

        {isError ? (
          <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-6 text-sm text-red-200">
            Erro ao carregar a jornada. Tente novamente em alguns segundos.
          </div>
        ) : isLoading || !data ? (
          <div className="h-[78vh] rounded-2xl border border-white/10 bg-[#050102] flex items-center justify-center">
            <div className="flex flex-col items-center gap-3 text-white/60 text-sm">
              <div className="w-6 h-6 border-2 border-[#8c1229] border-t-transparent rounded-full animate-spin" />
              Carregando jornada...
            </div>
          </div>
        ) : (
          <ReactFlowProvider>
            <JourneyChart data={data} />
          </ReactFlowProvider>
        )}
      </div>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
      <span>{label}</span>
    </span>
  );
}
