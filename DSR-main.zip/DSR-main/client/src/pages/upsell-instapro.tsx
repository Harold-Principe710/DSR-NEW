import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
    ArrowRight,
    CheckCircle2,
    Clock,
    Eye,
    Film,
    Images,
    Lock,
    ShieldCheck,
    Sparkles,
    Star,
    Users,
    X,
    type LucideIcon,
} from "lucide-react";
import PixQrModal from "@/components/PixQrModal";
import { useToast } from "@/hooks/use-toast";
import { getQueryFn, CRITICAL_QUERY_OPTIONS } from "@/lib/queryClient";
import { trackFunnelEvent, getTrackingSessionKey } from "@/lib/funnel";
import {
    AlertDialog,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const TIMER_DURATION_MS = 7 * 60 * 1000;
const TIMER_START_KEY = "upsell_ai15_timer_started_at";
const TIMER_PAUSED_KEY = "upsell_ai15_timer_paused_at";
const TIMER_FROZEN_REMAINING_KEY = "upsell_ai15_timer_frozen_remaining";
const VARIANT_KEY = "upsell_ai15_variant";
const LANDING_FUNNEL_STATE_KEY = "desireai:landing:funnel-state:v1";
const PLAN_ID = "upsell-instapro-semanal";
const PRICE_FULL = "R$ 249";
const PRICE_NOW = "R$ 59,90";

type UserMe = { id: string; username: string; email: string | null; hasPaidPix: boolean } | null;
type CtaVariant = "A" | "B";
type DialogState = "none" | "expiry" | "decline";

function readOrInitTimerStart(): number {
    if (typeof window === "undefined") return Date.now();
    const existing = window.sessionStorage.getItem(TIMER_START_KEY);
    if (existing) {
        const parsed = parseInt(existing, 10);
        if (!Number.isNaN(parsed)) return parsed;
    }
    const now = Date.now();
    window.sessionStorage.setItem(TIMER_START_KEY, String(now));
    return now;
}

function readFrozenRemaining(): number | null {
    if (typeof window === "undefined") return null;
    const raw = window.sessionStorage.getItem(TIMER_FROZEN_REMAINING_KEY);
    if (!raw) return null;
    const parsed = parseInt(raw, 10);
    return Number.isNaN(parsed) ? null : parsed;
}

function formatMMSS(ms: number): string {
    const totalSec = Math.max(0, Math.floor(ms / 1000));
    const mm = Math.floor(totalSec / 60).toString().padStart(2, "0");
    const ss = (totalSec % 60).toString().padStart(2, "0");
    return `${mm}:${ss}`;
}

function pickVariant(): CtaVariant {
    if (typeof window === "undefined") return "B";
    const existing = window.sessionStorage.getItem(VARIANT_KEY);
    if (existing === "A" || existing === "B") return existing;
    const chosen: CtaVariant = Math.random() < 0.5 ? "A" : "B";
    window.sessionStorage.setItem(VARIANT_KEY, chosen);
    return chosen;
}

function readGeneratedPreviewSrc(): string | null {
    if (typeof window === "undefined") return null;
    try {
        const raw = window.sessionStorage.getItem(LANDING_FUNNEL_STATE_KEY);
        if (!raw) return null;
        const parsed = JSON.parse(raw) as { generatedImageId?: string; generatedImageStatus?: string };
        if (!parsed.generatedImageId || parsed.generatedImageStatus !== "completed") return null;
        return `/api/generated-images/${parsed.generatedImageId}/image`;
    } catch {
        return null;
    }
}

function clearTimerStorage() {
    if (typeof window === "undefined") return;
    window.sessionStorage.removeItem(TIMER_START_KEY);
    window.sessionStorage.removeItem(TIMER_PAUSED_KEY);
    window.sessionStorage.removeItem(TIMER_FROZEN_REMAINING_KEY);
}

function useAuthUser() {
    return useQuery<UserMe>({
        queryKey: ["/api/user/me"],
        queryFn: getQueryFn({ on401: "returnNull" }),
        retry: false,
        ...CRITICAL_QUERY_OPTIONS,
    });
}

type IconItem = {
    icon: LucideIcon;
    title: string;
    description: string;
};

const unlockItems: IconItem[] = [
    {
        icon: Eye,
        title: "Mesma mulher, novas cenas",
        description: "Repete o rosto e muda pose, roupa, luz, cenário e clima.",
    },
    {
        icon: Film,
        title: "Vídeo POV adulto",
        description: "Cenas curtas em primeira pessoa, com a mesma base.",
    },
    {
        icon: Images,
        title: "Packs completos",
        description: "Sequências de fotos pra salvar, comparar e refazer.",
    },
    {
        icon: Users,
        title: "Várias adultas geradas",
        description: "Cria cenas com duas ou mais personagens, 100% IA.",
    },
];

const fantasyChips = [
    "namorada",
    "academia",
    "praia",
    "cosplay",
    "secretária",
    "enfermeira",
    "professora",
    "policial",
    "vizinha",
    "influencer",
    "madura",
    "lingerie",
    "festa privada",
    "duas adultas",
    "roleplay consensual",
];

// Depoimentos placeholder — substituir por reais antes de subir.
// Sem nomes reais, sem fotos, sem contadores inventados.
const testimonials = [
    {
        quote: "Paguei a foto pra testar. Acabei usando pack e POV o resto da noite.",
        label: "Cliente anônimo",
    },
    {
        quote: "A parte de refazer a mesma mulher em outra roupa foi o que me pegou.",
        label: "Cliente anônimo",
    },
];

const trustItems = [
    "Sua geração já está salva na sua conta",
    "Reembolso da compra anterior acionado no upgrade",
    "PIX único, sem renovação automática, sem cartão",
    "Liberação automática logo após confirmar o pagamento",
];

const previewGradients = [
    "linear-gradient(145deg, #4b0b1a 0%, #160407 42%, #270814 100%)",
    "linear-gradient(165deg, #250510 0%, #701226 54%, #120204 100%)",
    "linear-gradient(135deg, #160407 0%, #3a0a18 48%, #8c1229 100%)",
    "linear-gradient(155deg, #310817 0%, #0a0204 45%, #5c0d20 100%)",
    "linear-gradient(125deg, #8c1229 0%, #250510 38%, #0a0204 100%)",
    "linear-gradient(150deg, #17050a 0%, #520a17 55%, #190308 100%)",
];

type DialogAction =
    | { type: "open"; dialog: Exclude<DialogState, "none"> }
    | { type: "close" };

function dialogReducer(_: DialogState, action: DialogAction): DialogState {
    return action.type === "open" ? action.dialog : "none";
}

function TimerDisplay({
    remainingMs,
    expired,
    lastMinute,
}: {
    remainingMs: number;
    expired: boolean;
    lastMinute: boolean;
}) {
    const label = formatMMSS(remainingMs);
    const sec = Math.floor(remainingMs / 1000);
    const announceEverySec = remainingMs <= 60_000 ? 15 : 60;
    const shouldAnnounce = sec % announceEverySec === 0;
    return (
        <div
            className={`sticky top-0 z-50 border-b border-white/[0.06] ${
                expired || lastMinute ? "bg-[#8c1229]" : "bg-[#8c1229]/95 backdrop-blur-md"
            }`}
            data-testid="upsell-topbar-timer"
        >
            <div className="mx-auto flex max-w-5xl items-center justify-center gap-2 px-4 py-2.5 text-center text-[12px] font-semibold uppercase tracking-[0.08em] text-white sm:text-[13px]">
                <Clock className="h-3.5 w-3.5 shrink-0 opacity-90" />
                {expired ? (
                    <span>Oferta expirada · acesso volta para {PRICE_FULL}</span>
                ) : (
                    <span className="flex items-baseline gap-1.5">
                        <span>Oferta só nesta tela ·</span>
                        <span
                            className={`tabular-nums inline-block min-w-[3.4ch] text-center ${
                                lastMinute ? "animate-pulse" : ""
                            }`}
                            role="timer"
                            aria-live={shouldAnnounce ? "polite" : "off"}
                            aria-atomic="true"
                        >
                            {label}
                        </span>
                        <span className="hidden sm:inline">· depois volta para {PRICE_FULL}</span>
                    </span>
                )}
            </div>
        </div>
    );
}

export default function UpsellInstaProPage() {
    const { toast } = useToast();
    const [, setLocation] = useLocation();
    const { data: user } = useAuthUser();

    const [variant] = useState<CtaVariant>(() => pickVariant());
    const [generatedPreviewSrc] = useState<string | null>(() => readGeneratedPreviewSrc());
    const [previewLoadFailed, setPreviewLoadFailed] = useState(false);
    const [isPixModalOpen, setIsPixModalOpen] = useState(false);
    const [remainingMs, setRemainingMs] = useState<number>(() => {
        const frozen = readFrozenRemaining();
        if (frozen !== null) return frozen;
        const start = readOrInitTimerStart();
        return Math.max(0, TIMER_DURATION_MS - (Date.now() - start));
    });
    const [expired, setExpired] = useState(false);
    const [dialog, dispatchDialog] = useReducer(dialogReducer, "none");
    const [stickyCtaVisible, setStickyCtaVisible] = useState(false);

    const exitingRef = useRef(false);
    const heroCtaRef = useRef<HTMLDivElement | null>(null);
    const finalCtaRef = useRef<HTMLDivElement | null>(null);
    const channelRef = useRef<BroadcastChannel | null>(null);

    const fallbackRedirectPath = user?.id ? "/painel" : "/";
    const lastMinute = remainingMs <= 60_000 && remainingMs > 0;
    const canShowGeneratedPreview = Boolean(generatedPreviewSrc && !previewLoadFailed);

    useEffect(() => {
        if (typeof window === "undefined" || typeof BroadcastChannel === "undefined") return;
        const channel = new BroadcastChannel("upsell_instapro");
        channel.onmessage = (event) => {
            if (event.data?.type === "paid" && !exitingRef.current) {
                exitingRef.current = true;
                clearTimerStorage();
                toast({
                    title: "Upgrade já aceito em outra aba.",
                    description: "Redirecionando...",
                });
                window.setTimeout(() => {
                    setLocation(user?.id ? "/painel" : "/");
                }, 1500);
            }
        };
        channelRef.current = channel;
        return () => {
            channel.close();
            channelRef.current = null;
        };
    }, [setLocation, toast, user?.id]);

    useEffect(() => {
        void trackFunnelEvent({
            step: "offer_viewed",
            eventName: "upsell.instapro_viewed",
            idempotencyKey: `upsell_ai15:viewed:${getTrackingSessionKey()}`,
            metadata: { variant, offer: "ai_unlimited_15_days" },
        });
    }, [variant]);

    useEffect(() => {
        if (expired || isPixModalOpen) return;

        const frozen = readFrozenRemaining();
        let startRef: number;
        if (frozen !== null) {
            const consumed = TIMER_DURATION_MS - frozen;
            startRef = Date.now() - consumed;
            window.sessionStorage.setItem(TIMER_START_KEY, String(startRef));
            window.sessionStorage.removeItem(TIMER_FROZEN_REMAINING_KEY);
            window.sessionStorage.removeItem(TIMER_PAUSED_KEY);
        } else {
            startRef = readOrInitTimerStart();
        }

        const tick = () => {
            const remaining = Math.max(0, TIMER_DURATION_MS - (Date.now() - startRef));
            setRemainingMs(remaining);
            if (remaining <= 0) {
                setExpired(true);
            }
        };

        tick();
        const id = window.setInterval(tick, 1000);
        return () => window.clearInterval(id);
    }, [expired, isPixModalOpen]);

    useEffect(() => {
        if (typeof window === "undefined" || !isPixModalOpen || expired) return;
        const start = readOrInitTimerStart();
        const remaining = Math.max(0, TIMER_DURATION_MS - (Date.now() - start));
        window.sessionStorage.setItem(TIMER_FROZEN_REMAINING_KEY, String(remaining));
        window.sessionStorage.setItem(TIMER_PAUSED_KEY, String(Date.now()));
    }, [isPixModalOpen, expired]);

    useEffect(() => {
        if (expired) return;
        const handler = (e: BeforeUnloadEvent) => {
            if (isPixModalOpen || exitingRef.current) return undefined;
            e.preventDefault();
            e.returnValue = "";
            return "";
        };
        window.addEventListener("beforeunload", handler);
        return () => window.removeEventListener("beforeunload", handler);
    }, [expired, isPixModalOpen]);

    useEffect(() => {
        if (typeof window === "undefined") return;
        const hero = heroCtaRef.current;
        const finalC = finalCtaRef.current;
        if (!hero || !finalC) return;

        let heroPassed = false;
        let finalVisible = false;
        const update = () => setStickyCtaVisible(heroPassed && !finalVisible);

        const heroObs = new IntersectionObserver(
            ([entry]) => {
                if (!entry.isIntersecting && entry.boundingClientRect.top < 0) {
                    heroPassed = true;
                } else if (entry.isIntersecting) {
                    heroPassed = false;
                }
                update();
            },
            { threshold: 0, rootMargin: "-56px 0px 0px 0px" },
        );

        const finalObs = new IntersectionObserver(
            ([entry]) => {
                finalVisible = entry.isIntersecting;
                update();
            },
            { threshold: 0.2 },
        );

        heroObs.observe(hero);
        finalObs.observe(finalC);
        return () => {
            heroObs.disconnect();
            finalObs.disconnect();
        };
    }, []);

    useEffect(() => {
        if (isPixModalOpen) setStickyCtaVisible(false);
    }, [isPixModalOpen]);

    const handleCtaClick = useCallback(
        (source: string) => {
            if (expired) {
                return;
            }
            void trackFunnelEvent({
                step: "offer_responded",
                eventName: "upsell.instapro_cta_clicked",
                idempotencyKey: `upsell_ai15:cta_clicked:${getTrackingSessionKey()}:${source}`,
                metadata: { variant, source, offer: "ai_unlimited_15_days" },
            });
            setIsPixModalOpen(true);
        },
        [expired, variant],
    );

    const handlePixClose = useCallback(() => {
        setIsPixModalOpen(false);
    }, []);

    const handlePaid = useCallback(
        (paymentData?: unknown) => {
            exitingRef.current = true;
            channelRef.current?.postMessage({ type: "paid" });
            void trackFunnelEvent({
                step: "pix_paid",
                eventName: "upsell.instapro_paid",
                idempotencyKey: `upsell_ai15:paid:${getTrackingSessionKey()}`,
                metadata: { variant, paymentData: paymentData ?? null, offer: "ai_unlimited_15_days" },
            });
            clearTimerStorage();
            toast({
                title: "Upgrade liberado.",
                description: "Reembolso da compra anterior acionado. Acesso de 15 dias ativo.",
            });
            window.setTimeout(() => {
                setLocation(user?.id ? "/painel" : "/");
            }, 1500);
        },
        [setLocation, toast, user?.id, variant],
    );

    const handleDecline = useCallback(() => {
        dispatchDialog({ type: "open", dialog: "decline" });
    }, []);

    const confirmDecline = useCallback(() => {
        void trackFunnelEvent({
            step: "offer_responded",
            eventName: "upsell.instapro_declined",
            idempotencyKey: `upsell_ai15:declined:${getTrackingSessionKey()}`,
            metadata: { variant, offer: "ai_unlimited_15_days" },
        });
        clearTimerStorage();
        exitingRef.current = true;
        dispatchDialog({ type: "close" });
        setLocation(fallbackRedirectPath);
    }, [fallbackRedirectPath, setLocation, variant]);

    return (
        <div
            className="min-h-screen overflow-x-hidden bg-gradient-to-br from-[#050102] via-[#0a0204] to-[#17050a] text-white"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
            <TimerDisplay remainingMs={remainingMs} expired={expired} lastMinute={lastMinute} />

            <main className="relative mx-auto max-w-6xl px-4 pb-32 sm:px-5">
                <div className="pointer-events-none absolute left-1/2 top-8 h-[420px] w-[90vw] max-w-[900px] -translate-x-1/2 rounded-full bg-[#8c1229] opacity-[0.07] blur-[60px] md:blur-[140px]" />
                <div className="pointer-events-none absolute right-[-15%] top-[420px] h-[360px] w-[360px] rounded-full bg-[#520a17] opacity-[0.12] blur-[60px] md:blur-[110px]" />

                <div className="relative z-10 mx-auto mt-4 flex w-fit items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-400/[0.07] px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-emerald-300 sm:text-[12px]">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>Pagamento aprovado · Geração concluída · Compra garantida</span>
                </div>

                <section className="relative z-10 grid items-center gap-6 pt-4 md:grid-cols-[minmax(0,1fr)_minmax(360px,0.8fr)] md:gap-10 md:pt-8">
                    <div className="relative order-1 mx-auto w-full max-w-[400px] md:order-2 md:mr-0 md:max-w-[460px]">
                        <div className="relative overflow-hidden rounded-[24px] border border-[#8c1229]/30 bg-[#0a0204] shadow-[0_24px_90px_rgba(82,10,23,0.42)]">
                            <div className="relative aspect-[4/5] sm:aspect-[3/4]">
                                {canShowGeneratedPreview ? (
                                    <img
                                        src={generatedPreviewSrc ?? undefined}
                                        alt="Sua geração concluída"
                                        className="absolute inset-0 h-full w-full scale-[1.02] object-cover brightness-[0.78] saturate-[1.08]"
                                        decoding="async"
                                        fetchPriority="high"
                                        onError={() => setPreviewLoadFailed(true)}
                                    />
                                ) : (
                                    <div className="absolute inset-0 grid grid-cols-3 gap-1.5 bg-[#0a0204] p-1.5">
                                        {previewGradients.map((background, index) => {
                                            const isPeek = index === 4;
                                            return (
                                                <div
                                                    key={index}
                                                    className="relative overflow-hidden rounded-[12px]"
                                                >
                                                    <div
                                                        className="absolute inset-0 scale-110 blur-[10px]"
                                                        style={{ background }}
                                                    />
                                                    <div
                                                        className={`absolute inset-0 ${
                                                            isPeek
                                                                ? "bg-gradient-to-t from-black/55 via-black/10 to-transparent"
                                                                : "bg-gradient-to-t from-black/75 via-black/20 to-white/[0.03]"
                                                        }`}
                                                    />
                                                    <div className="absolute inset-0 grid place-items-center">
                                                        {isPeek ? (
                                                            <Eye className="h-4 w-4 text-white/75 drop-shadow-[0_0_10px_rgba(255,59,92,0.55)]" />
                                                        ) : (
                                                            <Lock className="h-3.5 w-3.5 text-white/55 drop-shadow-[0_0_8px_rgba(140,18,41,0.55)]" />
                                                        )}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/25 to-transparent" />

                                <div className="absolute left-3.5 right-3.5 top-3.5 flex items-center justify-between gap-3">
                                    <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-black/55 px-2.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-emerald-300 backdrop-blur-md">
                                        <CheckCircle2 className="h-3 w-3" />
                                        Pronta
                                    </span>
                                    <span className="rounded-full border border-[#ff3b5c]/35 bg-[#8c1229]/45 px-2.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-[#ffd6dd] backdrop-blur-md">
                                        Cofre VIP · 15 dias
                                    </span>
                                </div>

                                <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5">
                                    <div className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-[#ff3b5c]/30 bg-[#8c1229]/40 px-2.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#ffd6dd] backdrop-blur-md">
                                        <Sparkles className="h-3 w-3" />
                                        Upgrade desbloqueia variações
                                    </div>
                                    <h2 className="text-[20px] font-semibold leading-tight text-white sm:text-2xl">
                                        Mesma mulher · novas cenas, fantasias e POV.
                                    </h2>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="order-2 flex flex-col md:order-1">
                        <h1 className="text-[2.1rem] font-semibold leading-[1.05] tracking-[-0.02em] text-white/95 sm:text-5xl md:text-[3.6rem]">
                            Ela ficou pronta.
                            <span className="mt-1 block text-transparent bg-clip-text bg-gradient-to-r from-[#ff3b5c] via-[#cc1a3a] to-[#8c1229]">
                                Agora gere ela sem limite.
                            </span>
                        </h1>

                        <p className="mt-3 max-w-xl text-[15px] leading-relaxed text-white/70 sm:mt-4 sm:text-lg">
                            Gere essa mesma mulher em novas fotos, packs e vídeos POV. Sem limite por 15 dias.
                        </p>

                        <div className="mt-5 grid grid-cols-2 gap-2.5 sm:max-w-md">
                            <div className="rounded-2xl border border-white/[0.08] bg-white/[0.035] px-3.5 py-3">
                                <p className="text-[10px] uppercase tracking-[0.16em] text-white/40">Normalmente</p>
                                <p className="mt-1 text-[22px] font-semibold leading-none text-white/45 line-through decoration-[#ff3b5c] decoration-2">
                                    {PRICE_FULL}
                                </p>
                            </div>
                            <div className="rounded-2xl border border-[#ff3b5c]/40 bg-gradient-to-br from-[#8c1229]/35 to-[#520a17]/15 px-3.5 py-3 shadow-[0_0_30px_rgba(140,18,41,0.18)]">
                                <p className="text-[10px] uppercase tracking-[0.16em] text-[#ffb3c0]">Agora · só nesta tela</p>
                                <p className="mt-1 text-[28px] font-black leading-none text-white">{PRICE_NOW}</p>
                            </div>
                        </div>

                        <div className="mt-2.5 inline-flex w-fit items-start gap-2 rounded-xl border border-emerald-400/25 bg-emerald-400/[0.06] px-3 py-2 text-[12px] leading-snug text-emerald-200">
                            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                            <span>Ao confirmar o upgrade, o reembolso da compra anterior é acionado automaticamente.</span>
                        </div>

                        <div ref={heroCtaRef} className="mt-5 max-w-xl">
                            <button
                                onClick={() => handleCtaClick("hero")}
                                disabled={expired}
                                className="group relative flex h-16 w-full items-center justify-center gap-3 overflow-hidden rounded-[14px] border border-[#ff3b5c]/25 bg-gradient-to-r from-[#8c1229] to-[#520a17] px-5 text-[15px] font-black uppercase tracking-[0.04em] text-white shadow-[0_0_34px_rgba(140,18,41,0.35)] transition-all hover:from-[#a61530] hover:to-[#6b0d1e] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#ff3b5c] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 sm:text-[17px]"
                                data-testid="upsell-cta-hero"
                            >
                                <Lock className="relative z-10 h-5 w-5" />
                                <span className="relative z-10">LIBERAR 15 DIAS SEM LIMITE</span>
                                <ArrowRight className="relative z-10 h-5 w-5 transition-transform group-hover:translate-x-0.5" />
                            </button>
                            <p className="mt-2.5 text-center text-[12px] leading-relaxed text-white/55 sm:text-left">
                                PIX único · sem renovação automática · sem cadastro de cartão · sua geração já está garantida na sua conta.
                            </p>
                        </div>
                    </div>
                </section>

                <section className="relative z-10 pt-10 md:pt-14">
                    <div>
                        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#ff3b5c]/80">
                            15 dias destravados
                        </p>
                        <h2 className="mt-1.5 text-[22px] font-semibold tracking-tight text-white/95 sm:text-3xl">
                            O que tu libera agora
                        </h2>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-2.5 md:grid-cols-4">
                        {unlockItems.map((item) => {
                            const Icon = item.icon;
                            return (
                                <div
                                    key={item.title}
                                    className="rounded-[16px] border border-white/[0.07] bg-white/[0.035] p-3.5 transition-colors hover:border-[#8c1229]/40 hover:bg-[#8c1229]/[0.07]"
                                >
                                    <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-xl border border-[#8c1229]/30 bg-[#8c1229]/15 text-[#ff3b5c]">
                                        <Icon className="h-4 w-4" />
                                    </div>
                                    <h3 className="text-[14px] font-semibold text-white/92">{item.title}</h3>
                                    <p className="mt-1.5 text-[12.5px] leading-relaxed text-white/55">
                                        {item.description}
                                    </p>
                                </div>
                            );
                        })}
                    </div>
                </section>

                <section className="relative z-10 pt-10 md:pt-14">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#ff3b5c]/80">
                        Fantasias prontas
                    </p>
                    <h2 className="mt-1.5 text-[22px] font-semibold leading-tight text-white/95 sm:text-3xl">
                        Gera do jeito que vier na tua cabeça.
                    </h2>
                    <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-white/55">
                        Use como ponto de partida e ajusta cada detalhe: roupa, pose, cenário, expressão, estilo.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                        {fantasyChips.map((fantasy) => (
                            <span
                                key={fantasy}
                                className="rounded-full border border-white/[0.08] bg-white/[0.045] px-3.5 py-1.5 text-[12.5px] font-medium text-white/75"
                            >
                                {fantasy}
                            </span>
                        ))}
                    </div>
                </section>

                <section className="relative z-10 grid gap-3 pt-10 md:grid-cols-3 md:pt-14">
                    {testimonials.map((testimonial) => (
                        <div
                            key={testimonial.quote}
                            className="rounded-[18px] border border-white/[0.07] bg-white/[0.035] p-4"
                        >
                            <div className="mb-3 flex gap-1">
                                {Array.from({ length: 5 }).map((_, index) => (
                                    <Star
                                        key={index}
                                        className="h-3 w-3 fill-[#fbbf24] text-[#fbbf24]"
                                    />
                                ))}
                            </div>
                            <p className="text-[13.5px] leading-relaxed text-white/72">
                                &ldquo;{testimonial.quote}&rdquo;
                            </p>
                            <p className="mt-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-white/40">
                                {testimonial.label}
                            </p>
                        </div>
                    ))}

                    <div className="rounded-[18px] border border-[#8c1229]/30 bg-[#8c1229]/[0.08] p-4">
                        <div className="mb-3 flex items-center gap-2 text-[#ff9bad]">
                            <ShieldCheck className="h-4 w-4" />
                            <p className="text-[11px] font-semibold uppercase tracking-[0.16em]">
                                Como funciona
                            </p>
                        </div>
                        <div className="grid gap-2">
                            {trustItems.map((item) => (
                                <div
                                    key={item}
                                    className="flex items-start gap-2 text-[12.5px] leading-relaxed text-white/75"
                                >
                                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-300" />
                                    <span>{item}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                <section className="relative z-10 pt-10 md:pt-14">
                    <div className="rounded-[24px] border border-[#8c1229]/30 bg-gradient-to-br from-[#160407] via-[#0a0204] to-[#050102] p-5 text-center shadow-[0_22px_90px_rgba(82,10,23,0.28)] md:p-8">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#ff9bad]">
                            Só nesta tela
                        </p>
                        <h2 className="mx-auto mt-2.5 max-w-2xl text-[26px] font-semibold leading-tight text-white sm:text-4xl">
                            <span className="text-white/40 line-through decoration-2">{PRICE_FULL}</span>{" "}
                            viraram <span className="text-[#ff3b5c]">{PRICE_NOW}</span>.
                        </h2>
                        <p className="mx-auto mt-3 max-w-xl text-[13.5px] leading-relaxed text-white/60 sm:text-[15px]">
                            Ao confirmar o upgrade, o reembolso da compra anterior é acionado automaticamente e tu liga 15 dias com os modelos mais avançados de foto e vídeo. Fora desta tela, o passo de 15 dias volta para {PRICE_FULL}.
                        </p>

                        <div ref={finalCtaRef} className="mx-auto mt-5 max-w-xl">
                            <button
                                onClick={() => handleCtaClick("final")}
                                disabled={expired}
                                className="group relative flex h-16 w-full items-center justify-center gap-3 overflow-hidden rounded-[14px] border border-[#ff3b5c]/25 bg-gradient-to-r from-[#8c1229] to-[#520a17] px-5 text-[15px] font-black uppercase tracking-[0.04em] text-white shadow-[0_0_34px_rgba(140,18,41,0.35)] transition-all hover:from-[#a61530] hover:to-[#6b0d1e] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#ff3b5c] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 sm:text-[17px]"
                                data-testid="upsell-cta-final"
                            >
                                <span className="relative z-10">LIBERAR 15 DIAS SEM LIMITE</span>
                                <ArrowRight className="relative z-10 h-5 w-5 transition-transform group-hover:translate-x-0.5" />
                            </button>
                            <p className="mt-2.5 text-[12px] leading-relaxed text-white/55">
                                PIX único · sem renovação · reembolso acionado no upgrade
                            </p>
                        </div>

                        <button
                            onClick={handleDecline}
                            className="mt-5 text-[13px] text-white/55 underline underline-offset-4 transition-colors hover:text-white/85 focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-white/30"
                            data-testid="upsell-decline-link"
                        >
                            Não, quero apenas minha geração
                        </button>
                    </div>
                </section>
            </main>

            <div
                className={`fixed bottom-0 left-0 right-0 z-40 sm:hidden transition-transform duration-300 ${
                    stickyCtaVisible && !isPixModalOpen && !expired
                        ? "translate-y-0"
                        : "pointer-events-none translate-y-full"
                }`}
            >
                <div className="border-t border-[#8c1229]/40 bg-black/90 p-3 backdrop-blur-md">
                    <button
                        onClick={() => handleCtaClick("sticky")}
                        className="flex h-14 w-full items-center justify-center gap-2 rounded-[14px] bg-gradient-to-r from-[#8c1229] to-[#520a17] text-[14px] font-black uppercase tracking-[0.04em] text-white shadow-[0_8px_32px_rgba(140,18,41,0.5)] transition active:scale-[0.98]"
                        data-testid="upsell-cta-sticky"
                        aria-label={`Liberar 15 dias sem limite, oferta expira em ${formatMMSS(remainingMs)}`}
                    >
                        <span className="truncate">LIBERAR 15 DIAS SEM LIMITE</span>
                        <ArrowRight className="h-4 w-4 shrink-0" />
                    </button>
                    <p className="mt-1 text-center text-[10px] uppercase tracking-widest text-white/45 tabular-nums">
                        Oferta expira em {formatMMSS(remainingMs)}
                    </p>
                </div>
            </div>

            <PixQrModal
                open={isPixModalOpen}
                onClose={handlePixClose}
                planId={PLAN_ID}
                onPaymentSuccess={handlePaid}
                redirectAfterPaymentTo={null}
            />

            <AlertDialog
                open={dialog === "decline"}
                onOpenChange={(open) => !open && dispatchDialog({ type: "close" })}
            >
                <AlertDialogContent className="border-[#8c1229]/40 bg-[#0a0a0a] text-[#f5f5f5]">
                    <AlertDialogHeader>
                        <AlertDialogTitle className="text-[#f5f5f5]">Continuar sem o upgrade?</AlertDialogTitle>
                        <AlertDialogDescription asChild>
                            <div className="space-y-3 text-[#d4d4d4]">
                                <p>
                                    Sua geração atual continua liberada. Tu só perde o acesso de 15 dias,
                                    o preço promocional e o reembolso acionado no upgrade.
                                </p>
                                <p>Esta condição só aparece nesta tela e termina quando o timer zerar.</p>
                            </div>
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter className="flex flex-col-reverse gap-2 sm:flex-col-reverse sm:space-x-0">
                        <AlertDialogCancel
                            onClick={() => dispatchDialog({ type: "close" })}
                            className="mt-0 h-14 w-full border-[#8c1229] bg-[#8c1229] text-[15px] font-black uppercase tracking-wide text-white hover:bg-[#b51836]"
                        >
                            <Eye className="mr-2 h-4 w-4" />
                            Voltar e liberar 15 dias
                        </AlertDialogCancel>
                        <button
                            onClick={confirmDecline}
                            className="mx-auto mt-2 flex items-center gap-1 text-[13px] text-[#888] underline underline-offset-4 transition-colors hover:text-[#bbb]"
                            data-testid="upsell-decline-confirm"
                        >
                            <X className="h-3 w-3" />
                            Continuar com minha geração
                        </button>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}
