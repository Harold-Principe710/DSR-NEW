import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type AbVariantRow = {
  id: string;
  testId: string;
  name: string;
  slug: string;
  componentKey: string;
  weight: number;
  visits: number;
  createdAt: string;
};
type AbTestRow = {
  id: string;
  name: string;
  slug: string;
  publicPath: string;
  status: "active" | "paused" | "ended";
  createdAt: string;
  variants: AbVariantRow[];
};
type StatsVariant = {
  id: string;
  name: string;
  slug: string;
  componentKey: string;
  weight: number;
  visits: number;
  conversions: number;
  conversionRate: number;
  revenueCents: number;
  rpvCents: number;
  previewToken: string;
  previewTokenExpiresAt: string;
};
type StatsResponse = {
  test: AbTestRow;
  variants: StatsVariant[];
  integrity: {
    serverSideVisits: number;
    funnelSessionsCount: number;
    visitorEnteredCount: number;
    since: string;
  };
};

function formatBrl(cents: number): string {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function formatPct(value: number): string {
  return `${(value * 100).toFixed(2)}%`;
}

/**
 * Two-proportion z-test (one-tailed): returns true when the variant's
 * conversion rate is significantly different from the control at >95%
 * confidence (|z| > 1.96).
 */
function isSignificantVsControl(variant: StatsVariant, control: StatsVariant): boolean {
  if (!control || variant.id === control.id) return false;
  if (variant.visits < 30 || control.visits < 30) return false;
  const p1 = variant.conversions / variant.visits;
  const p2 = control.conversions / control.visits;
  const pPool = (variant.conversions + control.conversions) / (variant.visits + control.visits);
  const denom = Math.sqrt(pPool * (1 - pPool) * (1 / variant.visits + 1 / control.visits));
  if (denom === 0) return false;
  const z = (p1 - p2) / denom;
  return Math.abs(z) > 1.96;
}

export default function AdminAbTestDetailPage() {
  const [, params] = useRoute<{ id: string }>("/admin/ab-tests/:id");
  const id = params?.id ?? "";
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [editOpen, setEditOpen] = useState(false);
  const [draftWeights, setDraftWeights] = useState<Record<string, number>>({});

  const statsQuery = useQuery<StatsResponse>({
    queryKey: [`/api/admin/ab-tests/${id}/stats`],
    enabled: id.length > 0,
    refetchInterval: 30000,
  });

  const totals = useMemo(() => {
    const variants = statsQuery.data?.variants ?? [];
    const visits = variants.reduce((s, v) => s + v.visits, 0);
    const conversions = variants.reduce((s, v) => s + v.conversions, 0);
    const revenueCents = variants.reduce((s, v) => s + v.revenueCents, 0);
    const rpvCents = visits > 0 ? revenueCents / visits : 0;
    return { visits, conversions, revenueCents, rpvCents };
  }, [statsQuery.data]);

  const bestVariantId = useMemo(() => {
    const variants = statsQuery.data?.variants ?? [];
    if (variants.length === 0) return null;
    let best = variants[0];
    for (const v of variants) {
      if (v.rpvCents > best.rpvCents) best = v;
    }
    return best.id;
  }, [statsQuery.data]);

  const controlVariant = useMemo(() => {
    const variants = statsQuery.data?.variants ?? [];
    return variants.find((v) => v.componentKey === "control" || v.slug === "control") ?? variants[0];
  }, [statsQuery.data]);

  const updateMut = useMutation({
    mutationFn: async (payload: { status?: AbTestRow["status"]; variants?: Array<{ id: string; weight: number }> }) => {
      const res = await apiRequest("PATCH", `/api/admin/ab-tests/${id}`, payload);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/admin/ab-tests/${id}/stats`] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ab-tests"] });
    },
    onError: (err: Error) => toast({ title: "Erro", description: err.message, variant: "destructive" }),
  });

  const endMut = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/admin/ab-tests/${id}`);
    },
    onSuccess: () => {
      toast({ title: "Teste encerrado" });
      queryClient.invalidateQueries({ queryKey: [`/api/admin/ab-tests/${id}/stats`] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ab-tests"] });
    },
    onError: (err: Error) => toast({ title: "Erro", description: err.message, variant: "destructive" }),
  });

  const openWeightModal = () => {
    const variants = statsQuery.data?.variants ?? [];
    const initial: Record<string, number> = {};
    for (const v of variants) initial[v.id] = v.weight;
    setDraftWeights(initial);
    setEditOpen(true);
  };

  const draftSum = useMemo(
    () => Math.round(Object.values(draftWeights).reduce((s, w) => s + w, 0) * 100) / 100,
    [draftWeights],
  );
  const draftValid = Math.abs(draftSum - 100) < 0.01;

  const saveWeights = () => {
    const variantsPayload = Object.entries(draftWeights).map(([variantId, weight]) => ({ id: variantId, weight }));
    updateMut.mutate(
      { variants: variantsPayload },
      {
        onSuccess: () => {
          setEditOpen(false);
          toast({ title: "Pesos atualizados" });
        },
      },
    );
  };

  if (!id) return null;

  return (
    <div className="min-h-screen bg-[#050102] text-white">
      <div className="mx-auto w-full max-w-6xl px-4 py-6 space-y-6">
        <header className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <button
              onClick={() => setLocation("/admin/ab-tests")}
              className="text-xs text-white/50 hover:text-white/80"
            >
              ← Todos os testes
            </button>
            <h1 className="mt-1 text-2xl font-semibold">{statsQuery.data?.test.name ?? "Carregando…"}</h1>
            <p className="text-sm text-white/45">
              {statsQuery.data?.test.slug} ·{" "}
              <code className="rounded bg-black/40 px-2 py-0.5 text-xs">{statsQuery.data?.test.publicPath}</code>
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {statsQuery.data?.test.status === "active" && (
              <button
                onClick={() => updateMut.mutate({ status: "paused" })}
                className="rounded-lg border border-white/15 px-3 py-2 text-sm hover:bg-white/5"
              >
                Pausar
              </button>
            )}
            {statsQuery.data?.test.status === "paused" && (
              <button
                onClick={() => updateMut.mutate({ status: "active" })}
                className="rounded-lg border border-emerald-400/40 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200 hover:bg-emerald-500/20"
              >
                Reativar
              </button>
            )}
            {statsQuery.data?.test.status !== "ended" && (
              <>
                <button
                  onClick={openWeightModal}
                  className="rounded-lg border border-white/15 px-3 py-2 text-sm hover:bg-white/5"
                >
                  Ajustar pesos
                </button>
                <button
                  onClick={() => {
                    if (confirm("Encerrar este teste? Esta ação não pode ser desfeita.")) endMut.mutate();
                  }}
                  className="rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200 hover:bg-rose-500/20"
                >
                  Encerrar
                </button>
              </>
            )}
          </div>
        </header>

        {statsQuery.isLoading && <p className="text-sm text-white/60">Carregando estatísticas…</p>}
        {statsQuery.isError && <p className="text-sm text-rose-300">Erro ao carregar estatísticas.</p>}

        {statsQuery.data && (
          <>
            <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
                <p className="text-xs uppercase text-white/45">Visitas</p>
                <p className="mt-1 text-2xl font-semibold">{totals.visits.toLocaleString("pt-BR")}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
                <p className="text-xs uppercase text-white/45">Conversões</p>
                <p className="mt-1 text-2xl font-semibold">{totals.conversions.toLocaleString("pt-BR")}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
                <p className="text-xs uppercase text-white/45">Faturamento</p>
                <p className="mt-1 text-2xl font-semibold">{formatBrl(totals.revenueCents)}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
                <p className="text-xs uppercase text-white/45">RPV médio</p>
                <p className="mt-1 text-2xl font-semibold">{formatBrl(totals.rpvCents)}</p>
              </div>
            </section>

            <p className="text-xs text-white/45">
              <strong className="text-white/60">Pré-visualizar</strong> abre a rota pública com um link assinado de curta duração. A escolha persiste nos cookies do navegador onde foi aberta e não conta como visita nem conversão nas métricas.
            </p>

            <section className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs uppercase tracking-wide text-white/45">
                      <th className="px-3 py-2">Variante</th>
                      <th className="px-3 py-2 text-right">Visitas</th>
                      <th className="px-3 py-2 text-right">Conversões</th>
                      <th className="px-3 py-2 text-right">Tx. conv.</th>
                      <th className="px-3 py-2 text-right">Faturamento</th>
                      <th className="px-3 py-2 text-right">RPV</th>
                      <th className="px-3 py-2 text-right">Peso</th>
                      <th className="px-3 py-2 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statsQuery.data.variants.map((v) => {
                      const isBest = v.id === bestVariantId;
                      const significant =
                        controlVariant && v.id !== controlVariant.id && isSignificantVsControl(v, controlVariant);
                      return (
                        <tr
                          key={v.id}
                          className={`border-t border-white/5 ${isBest ? "bg-[#8c1229]/15" : ""}`}
                        >
                          <td className="px-3 py-3">
                            <div className="flex items-center gap-2">
                              <div className="font-medium">{v.name}</div>
                              {isBest && (
                                <span className="rounded-full border border-[#8c1229]/60 bg-[#8c1229]/30 px-2 py-0.5 text-[10px] uppercase">
                                  Melhor RPV
                                </span>
                              )}
                              {significant && (
                                <span className="rounded-full border border-emerald-400/40 bg-emerald-500/15 px-2 py-0.5 text-[10px] uppercase text-emerald-200">
                                  ✓ Significativo
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-white/45">{v.slug} · {v.componentKey}</div>
                          </td>
                          <td className="px-3 py-3 text-right">{v.visits.toLocaleString("pt-BR")}</td>
                          <td className="px-3 py-3 text-right">{v.conversions.toLocaleString("pt-BR")}</td>
                          <td className="px-3 py-3 text-right">{formatPct(v.conversionRate)}</td>
                          <td className="px-3 py-3 text-right">{formatBrl(v.revenueCents)}</td>
                          <td className="px-3 py-3 text-right">{formatBrl(v.rpvCents)}</td>
                          <td className="px-3 py-3 text-right text-white/70">{v.weight}%</td>
                          <td className="px-3 py-3 text-right">
                            {(() => {
                              const path = statsQuery.data?.test.publicPath;
                              if (!path) return <span className="text-white/30 text-xs">—</span>;
                              const previewParams = new URLSearchParams({
                                ab_preview: v.componentKey,
                                ab_preview_token: v.previewToken,
                              });
                              const previewUrl = `${path}${path.includes("?") ? "&" : "?"}${previewParams.toString()}`;
                              return (
                                <a
                                  href={previewUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center rounded-lg border border-white/15 px-2 py-1 text-xs text-white/80 hover:bg-white/5"
                                  title={`Abrir ${path} forçando esta variante`}
                                >
                                  Pré-visualizar ↗
                                </a>
                              );
                            })()}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>

            {statsQuery.data.integrity && (() => {
              const { serverSideVisits, funnelSessionsCount, visitorEnteredCount } = statsQuery.data.integrity;
              const sessionsDiff = serverSideVisits - funnelSessionsCount;
              const visitorsDiff = serverSideVisits - visitorEnteredCount;
              const sessionsPct = serverSideVisits > 0 ? (sessionsDiff / serverSideVisits) * 100 : 0;
              const visitorsPct = serverSideVisits > 0 ? (visitorsDiff / serverSideVisits) * 100 : 0;
              const tone = (pct: number) =>
                pct < 10 ? "text-emerald-300" : pct < 25 ? "text-amber-300" : "text-rose-300";
              return (
                <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-4 space-y-3">
                  <div>
                    <h3 className="text-sm font-semibold text-white/80">Integridade dos dados</h3>
                    <p className="text-xs text-white/45">
                      Compara as visitas contadas no middleware A/B com sessões que ativaram tracking JS no front. A diferença típica vem de bots, pré-fetch e sessões com JS bloqueado.
                    </p>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-3">
                    <div className="rounded-xl border border-white/10 bg-black/20 p-3">
                      <p className="text-[10px] uppercase tracking-wide text-white/45">Visitas A/B (server)</p>
                      <p className="mt-1 text-xl font-semibold">{serverSideVisits.toLocaleString("pt-BR")}</p>
                      <p className="text-[11px] text-white/40">Soma de ab_variants.visits</p>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-black/20 p-3">
                      <p className="text-[10px] uppercase tracking-wide text-white/45">Sessões com tracking</p>
                      <p className="mt-1 text-xl font-semibold">{funnelSessionsCount.toLocaleString("pt-BR")}</p>
                      <p className={`text-[11px] ${tone(Math.abs(sessionsPct))}`}>
                        Δ {sessionsDiff >= 0 ? "+" : ""}{sessionsDiff.toLocaleString("pt-BR")} ({sessionsPct.toFixed(1)}%)
                      </p>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-black/20 p-3">
                      <p className="text-[10px] uppercase tracking-wide text-white/45">visitor_entered únicos</p>
                      <p className="mt-1 text-xl font-semibold">{visitorEnteredCount.toLocaleString("pt-BR")}</p>
                      <p className={`text-[11px] ${tone(Math.abs(visitorsPct))}`}>
                        Δ {visitorsDiff >= 0 ? "+" : ""}{visitorsDiff.toLocaleString("pt-BR")} ({visitorsPct.toFixed(1)}%)
                      </p>
                    </div>
                  </div>
                  <p className="text-[11px] text-white/35">
                    Δ &lt; 10% saudável · 10–25% atenção · &gt; 25% suspeito (verifique logs/UA filter).
                  </p>
                </section>
              );
            })()}
          </>
        )}
      </div>

      {editOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4 py-6">
          <div className="w-full max-w-lg overflow-hidden rounded-2xl border border-white/10 bg-[#0a0407]">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
              <h2 className="text-lg font-semibold">Ajustar pesos</h2>
              <button
                onClick={() => setEditOpen(false)}
                className="rounded-lg border border-white/15 px-3 py-1.5 text-xs text-white/70 hover:bg-white/5"
              >
                Fechar
              </button>
            </div>
            <div className="space-y-3 px-5 py-4">
              {(statsQuery.data?.variants ?? []).map((v) => (
                <div key={v.id} className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                  <div className="mb-2 flex items-center justify-between text-sm">
                    <span className="font-medium">{v.name}</span>
                    <span className="text-white/50">{draftWeights[v.id] ?? 0}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={0.01}
                    value={draftWeights[v.id] ?? 0}
                    onChange={(e) =>
                      setDraftWeights((prev) => ({ ...prev, [v.id]: Number(e.target.value) }))
                    }
                    className="w-full accent-[#8c1229]"
                  />
                </div>
              ))}
              <p className={`text-xs ${draftValid ? "text-emerald-300" : "text-amber-300"}`}>
                Soma: {draftSum}% {draftValid ? "✓" : "(precisa ser 100%)"}
              </p>
            </div>
            <div className="flex items-center justify-end gap-2 border-t border-white/10 px-5 py-3">
              <button
                onClick={() => setEditOpen(false)}
                className="rounded-lg border border-white/15 px-3 py-2 text-sm text-white/70 hover:bg-white/5"
              >
                Cancelar
              </button>
              <button
                onClick={saveWeights}
                disabled={!draftValid || updateMut.isPending}
                className="rounded-lg bg-[#8c1229] px-4 py-2 text-sm font-medium hover:bg-[#a61530] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {updateMut.isPending ? "Salvando…" : "Salvar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
