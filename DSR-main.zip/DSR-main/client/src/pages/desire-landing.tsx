import { Suspense, lazy, useState, useRef, useEffect, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, getQueryFn, CRITICAL_QUERY_OPTIONS, fetchWithTimeout } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import {
    Upload,
    Loader2,
    ChevronDown,
    Sparkles,
    Eye,
    Clapperboard,
    ImagePlus,
    User,
    KeyRound,
    Check,
    Images,
    Menu,
    ArrowRight,
    ShieldCheck,
} from "lucide-react";
import type { CreditsPopupItem } from "@/components/CreditsPopup";
import type { VideoPovPreferences } from "@/components/VideoPovModal";
import { trackFunnelEvent, getTrackingSessionKey } from "@/lib/funnel";
import { getBestAvailableUtms } from "@/lib/utm";
import { getUploadErrorMessage, getUploadValidationMessage } from "@/lib/upload-validation";
import { useResolvePlanId } from "@/lib/ab-pricing";

const CreditsPopup = lazy(() => import("@/components/CreditsPopup"));
const PixQrModal = lazy(() => import("@/components/PixQrModal"));
const VideoPovModal = lazy(() => import("@/components/VideoPovModal"));
const PackPhotosModal = lazy(() => import("@/components/PackPhotosModal"));
const FingerprintPaywallModal = lazy(() => import("@/components/FingerprintPaywallModal"));

type FunnelStage =
    | "upload"           // PV etapa 01 — upload + revelar agora
    | "funnel_register"  // Single page: image "Gerando..." at top, register form below
    | "funnel_generating"// Single page: register success, wait for image
    | "funnel_revealed"  // Imagem revelada + cards
    ;

const LANDING_FUNNEL_STATE_KEY = "desireai:landing:funnel-state:v1";
const LANDING_FUNNEL_MAX_AGE_MS = 12 * 60 * 60 * 1000; // 12h
const USER_CHECK_IDLE_TIMEOUT_MS = 1800;
const CARD_MEDIA_VERSION = "cards-media-20260504";

type PersistedFunnelState = {
    stage: FunnelStage;
    referenceImage?: string;
    uploadedAspectRatio?: string;
    generatedImageId?: string;
    generatedImageStatus?: string;
    savedAt: number;
};

const MIN_PASSWORD_LENGTH = 6;
let fingerprintAgentPromise: Promise<any> | null = null;

async function getFingerprintVisitorId(): Promise<string | undefined> {
    const apiKey = (import.meta.env.VITE_FINGERPRINT_PUBLIC_KEY as string | undefined)?.trim();
    if (!apiKey) return undefined;

    try {
        if (!fingerprintAgentPromise) {
            fingerprintAgentPromise = import("@fingerprintjs/fingerprintjs-pro")
                .then(({ load }) => load({ apiKey }));
        }
        const agent = await fingerprintAgentPromise;
        const result = await agent.get();
        return typeof result?.visitorId === "string" ? result.visitorId : undefined;
    } catch {
        fingerprintAgentPromise = null;
        return undefined;
    }
}

function getLandingFunnelStorage(): string | null {
    try {
        return window.sessionStorage.getItem(LANDING_FUNNEL_STATE_KEY);
    } catch {
        return null;
    }
}

function removeLandingFunnelStorage() {
    try {
        window.sessionStorage.removeItem(LANDING_FUNNEL_STATE_KEY);
    } catch {
        // Storage may be blocked.
    }
}

function setLandingFunnelStorage(payload: PersistedFunnelState) {
    try {
        window.sessionStorage.setItem(LANDING_FUNNEL_STATE_KEY, JSON.stringify(payload));
    } catch {
        // Storage can be unavailable or full on some mobile browsers.
    }
}

function isFunnelStage(value: unknown): value is FunnelStage {
    return value === "upload"
        || value === "funnel_register"
        || value === "funnel_generating"
        || value === "funnel_revealed";
}

function getSafeHydratedStage(
    stage: FunnelStage,
    options: {
        hasReferenceImage: boolean;
        hasGeneratedImage: boolean;
        isGeneratedImageCompleted: boolean;
    },
): FunnelStage {
    if (options.hasGeneratedImage) {
        return options.isGeneratedImageCompleted ? "funnel_revealed" : "funnel_generating";
    }

    if (!options.hasReferenceImage) {
        return "upload";
    }

    if (stage === "funnel_revealed") {
        return "funnel_generating";
    }

    return stage === "upload" ? "upload" : "funnel_register";
}

function DesireLandingPage() {
    const { toast } = useToast();
    const [referenceImages, setReferenceImages] = useState<string[]>([]);
    const [uploadedAspectRatio, setUploadedAspectRatio] = useState<string>("1:1");
    const [isUploading, setIsUploading] = useState(false);
    const [generatedImage, setGeneratedImage] = useState<any>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [funnelStage, setFunnelStage] = useState<FunnelStage>("upload");
    const [hasHydratedFunnel, setHasHydratedFunnel] = useState(false);
    const [shouldCheckCurrentUser, setShouldCheckCurrentUser] = useState(false);
    const [hasRegisteredFunnelUser, setHasRegisteredFunnelUser] = useState(false);
    const [showAccountCreatedFeedback, setShowAccountCreatedFeedback] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const cameraInputRef = useRef<HTMLInputElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const [, setLocation] = useLocation();
    const queryClient = useQueryClient();
    const [imageRevealCb, setImageRevealCb] = useState<string>("");
    const [revealedImageLoadFailed, setRevealedImageLoadFailed] = useState(false);
    const [hasTriedRecoveringGeneratedImage, setHasTriedRecoveringGeneratedImage] = useState(false);

    useEffect(() => {
        const utms = getBestAvailableUtms();
        const trackingSessionKey = getTrackingSessionKey();
        trackFunnelEvent({
            step: "visitor_entered",
            eventName: "landing.entered",
            idempotencyKey: `landing:visitor_entered:${trackingSessionKey}`,
            ...utms,
        });
    }, []);

    useEffect(() => {
        if (!hasHydratedFunnel || shouldCheckCurrentUser) return;
        if (typeof window === "undefined") {
            setShouldCheckCurrentUser(true);
            return;
        }

        const enableUserCheck = () => setShouldCheckCurrentUser(true);
        const idle = (window as any).requestIdleCallback as
            | ((cb: () => void, opts?: { timeout: number }) => number)
            | undefined;

        if (idle) {
            const idleId = idle(enableUserCheck, { timeout: USER_CHECK_IDLE_TIMEOUT_MS });
            return () => {
                (window as any).cancelIdleCallback?.(idleId);
            };
        }

        const timeoutId = window.setTimeout(enableUserCheck, USER_CHECK_IDLE_TIMEOUT_MS);
        return () => window.clearTimeout(timeoutId);
    }, [hasHydratedFunnel, shouldCheckCurrentUser]);

    const { data: meData } = useQuery<{ id: string; hasPaidPix: boolean } | null>({
        queryKey: ["/api/user/me"],
        queryFn: getQueryFn({ on401: "returnNull" }),
        enabled: shouldCheckCurrentUser,
        retry: false,
        ...CRITICAL_QUERY_OPTIONS,
    });
    const { subscribe, isConnected } = useWebSocket({ enabled: Boolean(meData) || hasRegisteredFunnelUser });

    useEffect(() => {
        // Redirect to panel only if user is authenticated AND has paid PIX
        if (hasHydratedFunnel && meData?.hasPaidPix && funnelStage === "upload" && !generatedImage) {
            setLocation("/painel");
        }
    }, [hasHydratedFunnel, meData, funnelStage, generatedImage, setLocation]);

    // Rehydrate landing funnel after refresh
    useEffect(() => {
        let cancelled = false;

        // Hydration may touch storage and a server endpoint. It must never own
        // first paint; the landing renders immediately while this resumes state.
        const watchdog = window.setTimeout(() => {
            if (!cancelled) setHasHydratedFunnel(true);
        }, 8000);

        const hydrateFunnel = async () => {
            if (typeof window === "undefined") {
                setHasHydratedFunnel(true);
                return;
            }

            try {
                const raw = getLandingFunnelStorage();
                if (!raw) return;

                const parsed = JSON.parse(raw) as Partial<PersistedFunnelState>;
                const isFresh = typeof parsed.savedAt === "number"
                    && (Date.now() - parsed.savedAt) <= LANDING_FUNNEL_MAX_AGE_MS;
                if (!isFresh) {
                    removeLandingFunnelStorage();
                    return;
                }

                const stage: FunnelStage = isFunnelStage(parsed.stage) ? parsed.stage : "upload";
                const referenceImage = typeof parsed.referenceImage === "string" ? parsed.referenceImage : "";
                const generatedImageId = typeof parsed.generatedImageId === "string" ? parsed.generatedImageId : "";
                let hydratedStage = getSafeHydratedStage(stage, {
                    hasReferenceImage: Boolean(referenceImage),
                    hasGeneratedImage: false,
                    isGeneratedImageCompleted: false,
                });

                if (referenceImage) setReferenceImages([referenceImage]);
                if (typeof parsed.uploadedAspectRatio === "string" && parsed.uploadedAspectRatio) {
                    setUploadedAspectRatio(parsed.uploadedAspectRatio);
                }

                if (generatedImageId) {
                    try {
                        // Use fetchWithTimeout (6s) so a hung response can't pin
                        // the spinner forever — the root cause of the intermittent
                        // "infinite loading on first visit" bug.
                        const response = await fetchWithTimeout(
                            `/api/generated-images/${generatedImageId}`,
                            { credentials: "include" },
                            6000,
                        );
                        if (response.ok) {
                            const image = await response.json();
                            if (!cancelled) {
                                setGeneratedImage(image);
                                hydratedStage = getSafeHydratedStage(stage, {
                                    hasReferenceImage: Boolean(referenceImage),
                                    hasGeneratedImage: Boolean(image?.id),
                                    isGeneratedImageCompleted: image?.status === "completed",
                                });
                            }
                        } else {
                            removeLandingFunnelStorage();
                            if (!cancelled) {
                                setGeneratedImage(null);
                                hydratedStage = getSafeHydratedStage(stage, {
                                    hasReferenceImage: Boolean(referenceImage),
                                    hasGeneratedImage: false,
                                    isGeneratedImageCompleted: false,
                                });
                            }
                        }
                    } catch {
                        hydratedStage = getSafeHydratedStage(stage, {
                            hasReferenceImage: Boolean(referenceImage),
                            hasGeneratedImage: false,
                            isGeneratedImageCompleted: false,
                        });
                    }
                }

                if (!cancelled) setFunnelStage(hydratedStage);
            } catch {
                removeLandingFunnelStorage();
            } finally {
                if (!cancelled) setHasHydratedFunnel(true);
                window.clearTimeout(watchdog);
            }
        };

        hydrateFunnel();
        return () => {
            cancelled = true;
            window.clearTimeout(watchdog);
        };
    }, []);

    // Persist funnel state so refresh can resume the same step
    useEffect(() => {
        if (!hasHydratedFunnel || typeof window === "undefined") return;

        const referenceImage = referenceImages[0];
        const generatedImageId = generatedImage?.id as string | undefined;
        const generatedImageStatus = generatedImage?.status as string | undefined;

        if (funnelStage === "upload" && !referenceImage && !generatedImageId) {
            removeLandingFunnelStorage();
            return;
        }

        const payload: PersistedFunnelState = {
            stage: funnelStage,
            referenceImage,
            uploadedAspectRatio,
            generatedImageId,
            generatedImageStatus,
            savedAt: Date.now(),
        };

        setLandingFunnelStorage(payload);
    }, [
        hasHydratedFunnel,
        funnelStage,
        referenceImages,
        uploadedAspectRatio,
        generatedImage?.id,
        generatedImage?.status,
    ]);

    // Registration form state
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [registerError, setRegisterError] = useState("");
    const [isRegistering, setIsRegistering] = useState(false);

    // Fingerprint — paywall for recurring visitors
    const [fingerprintPaywallOpen, setFingerprintPaywallOpen] = useState(false);
    const [fpVisitorId, setFpVisitorId] = useState<string | null>(null);

    // Credits popup & PIX modal
    const [creditsPopupOpen, setCreditsPopupOpen] = useState(false);
    const [pixModalOpen, setPixModalOpen] = useState(false);
    const [selectedPlanId, setSelectedPlanId] = useState("");
    const [videoPovModalOpen, setVideoPovModalOpen] = useState(false);
    const [isSubmittingVideoPov, setIsSubmittingVideoPov] = useState(false);
    const [packPhotosModalOpen, setPackPhotosModalOpen] = useState(false);
    const [isSubmittingPackPhotos, setIsSubmittingPackPhotos] = useState(false);
    const videoPovSubmitInFlightRef = useRef(false);
    const videoPovPrewarmInFlightRef = useRef(false);
    const videoPovPrewarmedImageIdRef = useRef("");
    const packPhotosSubmitInFlightRef = useRef(false);
    const shouldResolveLandingPricing = funnelStage !== "upload"
        || creditsPopupOpen
        || pixModalOpen
        || videoPovModalOpen
        || packPhotosModalOpen
        || fingerprintPaywallOpen;
    const resolvePlanId = useResolvePlanId("landing-pricing", {
        enabled: shouldResolveLandingPricing,
    });

    const scrollToHero = () => {
        // Use window scroll on mobile to avoid nested-scroll jitter at page edges.
        if (typeof window !== "undefined") {
            window.scrollTo({ top: 0, behavior: "smooth" });
            return;
        }
        containerRef.current?.scrollTo({ top: 0, behavior: "smooth" });
    };

    // Listen for image generation completion
    useEffect(() => {
        const unsubCompleted = subscribe("image_completed", (image: any) => {
            setGeneratedImage(image);
            setFunnelStage(prev => prev === "funnel_register" ? "funnel_register" : "funnel_revealed");
        });
        const unsubFailed = subscribe("image_failed", (image: any) => {
            setGeneratedImage(image);
            setFunnelStage("funnel_register");
            setIsRegistering(false);
            setRegisterError(image.errorMessage || "Não foi possível gerar a imagem. Tente revelar novamente.");
            toast({
                title: "Falha na geração",
                description: image.errorMessage || "Não foi possível gerar a imagem.",
                variant: "destructive",
            });
        });
        return () => {
            unsubCompleted();
            unsubFailed();
        };
    }, [subscribe, toast]);

    // Listen for PIX payment confirmation via WebSocket
    useEffect(() => {
        const unsubPix = subscribe("pix_paid", (data: any) => {
            // Dispatch custom event so the PixQrModal can also react
            window.dispatchEvent(new CustomEvent("pix_paid", { detail: data }));
        });
        return () => { unsubPix(); };
    }, [subscribe]);

    useEffect(() => {
        if (!isConnected) return;
        queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
        queryClient.invalidateQueries({ queryKey: ["/api/credits"] });
    }, [isConnected, queryClient]);

    useEffect(() => {
        setRevealedImageLoadFailed(false);
    }, [funnelStage, generatedImage?.id, imageRevealCb]);

    useEffect(() => {
        if (funnelStage !== "funnel_revealed" || generatedImage?.id) return;
        setFunnelStage(referenceImages[0] ? "funnel_generating" : "upload");
    }, [funnelStage, generatedImage?.id, referenceImages]);

    useEffect(() => {
        if (!hasHydratedFunnel || hasTriedRecoveringGeneratedImage) return;
        if (!meData || meData.hasPaidPix || generatedImage?.id || referenceImages.length === 0) return;
        if (funnelStage !== "funnel_register" && funnelStage !== "funnel_generating") return;

        let cancelled = false;
        setHasTriedRecoveringGeneratedImage(true);

        const recoverGeneratedImage = async () => {
            try {
                const response = await fetchWithTimeout("/api/generated-images", { credentials: "include" }, 6000);
                if (!response.ok) return;
                const images = (await response.json()) as any[];
                const activeFunnelImage = images.find((image) =>
                    image?.creditCost === 0
                    && ["pending", "processing", "completed"].includes(String(image?.status || ""))
                );
                if (!activeFunnelImage || cancelled) return;

                setHasRegisteredFunnelUser(true);
                setGeneratedImage(activeFunnelImage);
                setFunnelStage(activeFunnelImage.status === "completed" ? "funnel_revealed" : "funnel_generating");
            } catch {
                // Best-effort recovery; the manual retry path remains available.
            }
        };

        recoverGeneratedImage();
        return () => {
            cancelled = true;
        };
    }, [
        hasHydratedFunnel,
        hasTriedRecoveringGeneratedImage,
        meData,
        generatedImage?.id,
        referenceImages,
        funnelStage,
    ]);

    // ── Handle PIX payment success ────────────────────────────────────
    const handlePixPaymentSuccess = useCallback((paymentData?: any) => {
        setShouldCheckCurrentUser(true);
        // Optimistic update: show new balance immediately
        const current = queryClient.getQueryData<{ balance: number }>(["/api/credits"]);
        const newBalance = (current?.balance ?? 0) + (paymentData?.creditAmount ?? 0);
        queryClient.setQueryData(["/api/credits"], { balance: newBalance });
        // Then reconcile with server
        queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
        queryClient.invalidateQueries({ queryKey: ["/api/credits"] });

        // Force image re-render by updating the cache buster
        setImageRevealCb(`paid_${Date.now()}`);
    }, [queryClient]);

    // ── Upload logic ─────────────────────────────────────────────────
    const processFile = async (file: File) => {
        const validationMessage = getUploadValidationMessage(file);
        if (validationMessage) {
            toast({ title: "Formato inválido", description: validationMessage, variant: "destructive" });
            return;
        }
        setIsUploading(true);
        try {
            const formData = new FormData();
            formData.append("image", file);
            const res = await fetch("/api/uploads/reference-image", {
                method: "POST", body: formData, credentials: "include"
            });
            if (!res.ok) {
                throw new Error(await getUploadErrorMessage(res, "Falha ao enviar foto."));
            }
            const data = await res.json();
            setReferenceImages([data.url]);
            setUploadedAspectRatio(data.aspectRatio || "1:1");
            setGeneratedImage(null);
            trackFunnelEvent({
                step: "photo_uploaded",
                eventName: "landing.photo_uploaded",
                idempotencyKey: `landing:photo_uploaded:${data.fileId || Date.now()}`,
                metadata: {
                    aspectRatio: data.aspectRatio,
                    url: data.url,
                },
            });
        } catch (error) {
            toast({
                title: "Erro",
                description: error instanceof Error ? error.message : "Falha ao enviar foto.",
                variant: "destructive",
            });
        } finally {
            setIsUploading(false);
            if (fileInputRef.current) fileInputRef.current.value = "";
            if (cameraInputRef.current) cameraInputRef.current.value = "";
        }
    };

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (!files || files.length === 0) return;
        processFile(files[0]);
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        const files = e.dataTransfer.files;
        if (files.length > 0) processFile(files[0]);
    };

    const canGenerateForRegisteredLead = hasRegisteredFunnelUser || Boolean(meData && !meData.hasPaidPix);

    // ── Generate mutation ────────────────────────────────────────────
    const generateMutation = useMutation({
        mutationFn: async () => {
            const res = await apiRequest("POST", "/api/generated-images", {
                referenceImageUrls: referenceImages,
                funnelFree: true,
            });
            return await res.json();
        },
        onSuccess: (data) => {
            const img = Array.isArray(data) ? data[0] : data;
            setGeneratedImage(img);
            setIsRegistering(false);
            if (img?.status === "failed") {
                const message = img.errorMessage || "Não foi possível gerar a imagem. Tente revelar novamente.";
                setRegisterError(message);
                setFunnelStage("funnel_register");
                toast({ title: "Falha na geração", description: message, variant: "destructive" });
                return;
            }
            if (img?.status === "completed") {
                setFunnelStage("funnel_revealed");
                return;
            }
            if (img?.id) {
                setFunnelStage("funnel_generating");
                return;
            }
            setRegisterError("Não foi possível iniciar a geração. Tente novamente.");
            setFunnelStage("funnel_register");
        },
        onError: (error: any) => {
            const message = error.message || "Falha ao requisitar geração";
            setIsRegistering(false);
            setFunnelStage("funnel_register");
            setRegisterError(
                canGenerateForRegisteredLead
                    ? `${message}. Sua conta já foi criada; tente revelar novamente.`
                    : message,
            );
            toast({ title: "Erro", description: message, variant: "destructive" });
        },
    });

    // ── Frontend Polling logic ───────────────────────────────────────
    useEffect(() => {
        let timeoutId: NodeJS.Timeout;
        let intervalId: NodeJS.Timeout;

        if ((funnelStage === "funnel_generating" || funnelStage === "funnel_register") && generatedImage?.id && generatedImage?.status !== "completed") {
            const poll = async () => {
                try {
                    const res = await fetch(`/api/generated-images/${generatedImage.id}`);
                    if (res.ok) {
                        const data = await res.json();
                        if (data.status === "completed") {
                            setGeneratedImage(data);
                            setFunnelStage(prev => prev === "funnel_register" ? "funnel_register" : "funnel_revealed");
                            clearInterval(intervalId);
                        } else if (data.status === "failed") {
                            const message = data.errorMessage || "Falha na geração. Tente revelar novamente.";
                            setGeneratedImage(data);
                            setFunnelStage("funnel_register");
                            setIsRegistering(false);
                            setRegisterError(message);
                            toast({ title: "Erro na geração", description: message, variant: "destructive" });
                            clearInterval(intervalId);
                        }
                    }
                } catch { } // ignore errors
            };

            // Start polling after 1 minute (60s), then every 15s
            timeoutId = setTimeout(() => {
                poll();
                intervalId = setInterval(poll, 15000);
            }, 60000);

            // Stop polling after 10 minutes (600,000ms) safety fallback
            const maxTimeout = setTimeout(() => {
                clearInterval(intervalId);
            }, 600000);

            return () => {
                clearTimeout(timeoutId);
                clearInterval(intervalId);
                clearTimeout(maxTimeout);
            };
        }
    }, [funnelStage, generatedImage?.id, generatedImage?.status, toast]);

    const checkFingerprintPaywall = async () => {
        const visitorId = await getFingerprintVisitorId();
        if (!visitorId) return;

        setFpVisitorId(visitorId);

        try {
            const checkRes = await fetch("/api/fingerprint/check-visitor", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ visitorId }),
                credentials: "include",
            });
            const checkData = await checkRes.json();

            if (checkData.registered && !checkData.hasActivePlan) {
                setFingerprintPaywallOpen(true);
            }
        } catch {
            // Fail open — don't block on network errors.
        }
    };

    // ── "Revelar Agora" button → advance immediately ─────────
    const handleReveal = () => {
        if (referenceImages.length === 0) return;

        setFunnelStage("funnel_register");
        setTimeout(() => {
            scrollToHero();
        }, 50);
        void checkFingerprintPaywall();
    };

    // ── Register handler ────────────────────────────────────────────
    const handleRegister = async () => {
        if (isRegistering || generateMutation.isPending) return;
        setRegisterError("");

        if (canGenerateForRegisteredLead) {
            if (referenceImages.length === 0) {
                setFunnelStage("upload");
                setRegisterError("Envie uma foto antes de revelar.");
                return;
            }
            setIsRegistering(true);
            setFunnelStage("funnel_generating");
            generateMutation.mutate();
            return;
        }

        // Client-side validation
        if (username.length < 3) {
            setRegisterError("Username deve ter pelo menos 3 caracteres");
            return;
        }
        if (password.length < MIN_PASSWORD_LENGTH || password.length > 40) {
            const missingChars = Math.max(0, MIN_PASSWORD_LENGTH - password.length);
            setRegisterError(
                missingChars > 0
                    ? `A senha precisa ter no mínimo ${MIN_PASSWORD_LENGTH} caracteres. Faltam ${missingChars}.`
                    : "Sua senha deve ter no máximo 40 caracteres."
            );
            return;
        }
        if (password !== confirmPassword) {
            setRegisterError("As senhas não coincidem");
            return;
        }

        setIsRegistering(true);
        try {
            // ── Collect visitorId for fingerprint tracking ──
            let visitorId: string | undefined = fpVisitorId || undefined;
            if (!visitorId) {
                visitorId = await getFingerprintVisitorId();
            }

            const res = await fetch("/api/auth/register-funnel", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    username,
                    password,
                    confirmPassword,
                    visitorId,
                    source: "landing_embedded_login",
                }),
                credentials: "include",
            });

            const data = await res.json();

            if (!res.ok) {
                setRegisterError(data.message || "Erro ao criar conta");
                setIsRegistering(false);
                return;
            }

            // ✅ Account created — only now we request KIE generation
            setHasRegisteredFunnelUser(true);
            setShouldCheckCurrentUser(true);
            setShowAccountCreatedFeedback(true);
            queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
            setFunnelStage("funnel_generating");
            generateMutation.mutate();
        } catch {
            setRegisterError("Erro de conexão. Tente novamente.");
            setIsRegistering(false);
        }
    };

    // ── Credits popup handlers ──────────────────────────────────────
    const openCreditsPopup = () => {
        trackFunnelEvent({
            step: "offer_responded",
            eventName: "landing.want_more_clicked",
            idempotencyKey: `landing:want_more_clicked:${generatedImage?.id || "none"}`,
            metadata: { imageId: generatedImage?.id || null },
        });
        setCreditsPopupOpen(true);
    };

    const handleSelectPlan = (planId: string) => {
        trackFunnelEvent({
            step: "offer_responded",
            eventName: "landing.credits_popup_plan_clicked",
            idempotencyKey: `landing:credits_popup_plan:${planId}:${Date.now()}`,
            metadata: { planId, source: "want_more_button" },
        });
        setSelectedPlanId(planId);
        setCreditsPopupOpen(false);
        setPixModalOpen(true);
    };

    const openPackPhotosFromCredits = useCallback(() => {
        const planId = resolvePlanId("10-fotos");
        trackFunnelEvent({
            step: "offer_responded",
            eventName: "landing.credits_popup_plan_clicked",
            idempotencyKey: `landing:credits_popup_plan:${planId}:${Date.now()}`,
            metadata: { planId, source: "want_more_button" },
        });
        setCreditsPopupOpen(false);
        setPackPhotosModalOpen(true);
    }, [resolvePlanId]);

    const prewarmVideoPovPreview = useCallback(() => {
        const imageId = typeof generatedImage?.id === "string" ? generatedImage.id : "";
        if (!imageId) return;
        if (videoPovPrewarmInFlightRef.current && videoPovPrewarmedImageIdRef.current === imageId) return;
        if (videoPovPrewarmedImageIdRef.current === imageId) return;

        videoPovPrewarmInFlightRef.current = true;
        videoPovPrewarmedImageIdRef.current = imageId;

        void fetch("/api/video-pov-preview/prewarm", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({ generatedImageId: imageId }),
        })
            .then(async (response) => {
                const data = await response.json().catch(() => ({}));
                if (!response.ok || (data?.status && !["processing", "completed"].includes(data.status))) {
                    videoPovPrewarmedImageIdRef.current = "";
                }
            })
            .catch(() => {
                videoPovPrewarmedImageIdRef.current = "";
            })
            .finally(() => {
                videoPovPrewarmInFlightRef.current = false;
            });
    }, [generatedImage?.id]);

    const openVideoPovFromCredits = useCallback(() => {
        const planId = resolvePlanId("10-fotos-1-video");
        trackFunnelEvent({
            step: "offer_responded",
            eventName: "landing.credits_popup_plan_clicked",
            idempotencyKey: `landing:credits_popup_plan:${planId}:${Date.now()}`,
            metadata: { planId, source: "want_more_button" },
        });
        prewarmVideoPovPreview();
        setCreditsPopupOpen(false);
        setVideoPovModalOpen(true);
    }, [prewarmVideoPovPreview, resolvePlanId]);

    const creditsPopupItems: CreditsPopupItem[] = [
        { planId: resolvePlanId("10-fotos"), title: "Pack de fotos", price: "saiba mais", onClick: openPackPhotosFromCredits },
        { planId: resolvePlanId("10-fotos-1-video"), title: "Vídeo POV", price: "saiba mais", onClick: openVideoPovFromCredits },
        { planId: "ilimitado" },
    ];

    const handleUpsellCardClick = (cardId: string) => {
        trackFunnelEvent({
            step: "offer_responded",
            eventName: "landing.offer_card_clicked",
            idempotencyKey: `landing:offer_responded:${cardId}:${generatedImage?.id || "none"}`,
            metadata: { cardId },
        });
        if (cardId === "pov") {
            prewarmVideoPovPreview();
            setVideoPovModalOpen(true);
            return;
        }
        if (cardId === "positions") {
            setPackPhotosModalOpen(true);
            return;
        }
        openCreditsPopup();
    };

    const handleVideoPovSubmit = useCallback(async (preferences: VideoPovPreferences) => {
        if (videoPovSubmitInFlightRef.current) return;
        videoPovSubmitInFlightRef.current = true;
        setIsSubmittingVideoPov(true);
        try {
            trackFunnelEvent({
                step: "offer_responded",
                eventName: "landing.video_pov_submit",
                idempotencyKey: `landing:video_pov_submit:${preferences.position}:${Date.now()}`,
                metadata: preferences as unknown as Record<string, unknown>,
            });
            const response = await fetch("/api/video-pov-requests", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({
                    ...preferences,
                    generatedImageId: generatedImage?.id ?? null,
                }),
            });

            const data = await response.json().catch(() => ({}));
            if (!response.ok) {
                throw new Error(data?.message || "Não foi possível salvar suas preferências.");
            }

            setVideoPovModalOpen(false);
            const query = new URLSearchParams();
            if (typeof data?.requestId === "string" && data.requestId) {
                query.set("requestId", data.requestId);
            }
            const loadingUrl = query.toString() ? `/video-pov-loading?${query.toString()}` : "/video-pov-loading";
            setLocation(loadingUrl);
        } catch (error: any) {
            toast({
                title: "Erro ao iniciar vídeo POV",
                description: error?.message || "Tente novamente em alguns segundos.",
                variant: "destructive",
            });
        } finally {
            videoPovSubmitInFlightRef.current = false;
            setIsSubmittingVideoPov(false);
        }
    }, [generatedImage?.id, setLocation, toast]);

    const handlePackPhotosSubmit = useCallback(async () => {
        if (packPhotosSubmitInFlightRef.current) return;
        packPhotosSubmitInFlightRef.current = true;
        setIsSubmittingPackPhotos(true);
        try {
            trackFunnelEvent({
                step: "offer_responded",
                eventName: "landing.pack_photos_submit",
                idempotencyKey: `landing:pack_photos_submit:${Date.now()}`,
            });
            setPackPhotosModalOpen(false);
            setLocation("/pack-photos-loading");
        } finally {
            packPhotosSubmitInFlightRef.current = false;
            setIsSubmittingPackPhotos(false);
        }
    }, [setLocation]);

    useEffect(() => {
        if (funnelStage !== "funnel_revealed" || !generatedImage?.id) return;
        trackFunnelEvent({
            step: "generated_photo_viewed",
            eventName: "landing.generated_photo_viewed",
            idempotencyKey: `landing:generated_photo_viewed:${generatedImage.id}`,
            metadata: { imageId: generatedImage.id },
        });
        trackFunnelEvent({
            step: "offer_viewed",
            eventName: "landing.offer_viewed",
            idempotencyKey: `landing:offer_viewed:${generatedImage.id}`,
            metadata: { imageId: generatedImage.id },
        });
    }, [funnelStage, generatedImage?.id]);



    const hasImage = referenceImages.length > 0;
    const revealedImageSrc = funnelStage === "funnel_revealed" && generatedImage?.id && !revealedImageLoadFailed
        ? `/api/generated-images/${generatedImage.id}/image?_cb=${imageRevealCb || "revealed"}`
        : null;

    return (
        <div
            ref={containerRef}
            className={`min-h-[100svh] overflow-x-hidden text-white md:scroll-smooth transition-colors duration-700
        ${funnelStage === "upload"
                    ? "bg-gradient-to-br from-[#0a0204] via-[#0f0407] to-[#17050a]"
                    : "bg-gradient-to-br from-[#050102] to-[#0a0204]" // Darker for single page focus
                }`}
            style={{
                fontFamily: "'Plus Jakarta Sans', sans-serif",
            }}
        >
            {/* ━━━ HEADER ━━━ */}
            <header className="w-full flex items-center justify-between px-5 py-6 bg-transparent border-b border-white/[0.02] relative z-20">
                {/* Spacer for centering logo */}
                <div className="w-10">
                    {meData?.hasPaidPix && (
                        <button
                            type="button"
                            onClick={() => setLocation("/painel")}
                            className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-white/50 hover:text-white/80 hover:bg-white/[0.08] hover:border-[#8c1229]/30 transition-all duration-200"
                            title="Abrir painel"
                        >
                            <Menu className="w-5 h-5" />
                        </button>
                    )}
                </div>
                <img
                    src="/uploads/logo.webp"
                    alt="DesireAI"
                    width={599}
                    height={171}
                    decoding="async"
                    fetchPriority="high"
                    className="h-[2.4rem] object-contain opacity-90"
                />
                <div className="w-10" /> {/* Right spacer for symmetry */}
            </header>

            <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.heic,.heif" className="hidden" onChange={handleFileUpload} />
            {/* Camera capture input (mobile) — capture="environment" opens rear camera on mobile */}
            <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileUpload} />

            {/* ━━━ HERO — PV ETAPA 01 ━━━ */}
            {funnelStage === "upload" && (
                <section className="relative w-full flex flex-col items-center justify-center min-h-[calc(100svh-56px)] shrink-0 px-5 pt-[19px] pb-12 md:py-24 md:animate-in md:fade-in md:duration-700">
                    {/* Ambient glow */}
                    <div className="absolute inset-0 pointer-events-none">
                        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[80vw] max-w-[800px] h-[60vw] max-h-[600px] rounded-full bg-[#8c1229] opacity-[0.08] blur-[70px] md:blur-[140px]" />
                        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[60vw] max-w-[600px] h-[40vw] max-h-[400px] rounded-full bg-[#520a17] opacity-[0.12] blur-[60px] md:blur-[120px]" />
                    </div>

                    <div className="relative z-10 w-full max-w-3xl flex flex-col items-center text-center gap-10">
                        {/* H1 */}
                        <h1 className="text-[2rem] leading-[1.15] sm:text-5xl sm:leading-[1.1] md:text-[3.5rem] md:leading-[1.08] font-semibold tracking-[-0.02em] text-white/95">
                            A mulher que você quer,
                            <br />
                            <span className="text-white/40">do jeito que você quiser.</span>
                        </h1>

                        {/* Upload Card */}
                        <div className="w-full max-w-sm">
                            <div
                                className={`relative w-full rounded-2xl border transition-all duration-300 cursor-pointer overflow-hidden shadow-lg md:shadow-xl
                  ${isDragging
                                        ? "border-[#c9a227]/60 bg-[#c9a227]/[0.04] scale-[1.01]"
                                        : hasImage
                                            ? "border-white/10 bg-black/40"
                                            : "border-white/[0.08] bg-white/[0.02] hover:border-white/[0.15] hover:bg-white/[0.03]"
                                    }`}
                                onClick={() => !hasImage && fileInputRef.current?.click()}
                                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                                onDragLeave={() => setIsDragging(false)}
                                onDrop={handleDrop}
                            >
                                {!hasImage ? (
                                    <div className="flex flex-col items-center justify-center gap-3 py-14 px-6">
                                        {isUploading ? (
                                            <Loader2 className="w-6 h-6 text-white/40 animate-spin" />
                                        ) : (
                                            <>
                                                <div className="w-11 h-11 rounded-full bg-white/[0.06] flex items-center justify-center">
                                                    <Upload className="w-5 h-5 text-white/50" />
                                                </div>
                                                <p className="text-[15px] text-white/50 font-normal">
                                                    Envie a foto dela
                                                </p>
                                                <p className="text-xs text-white/20">
                                                    100% anônimo, seguro e sem rastros.
                                                </p>
                                                {/* Mobile-only: open gallery */}
                                                <button
                                                    type="button"
                                                    onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
                                                    className="md:hidden mt-1 flex items-center gap-2 px-4 py-2 rounded-full bg-white/[0.05] border border-white/[0.10] text-white/50 hover:text-white/80 hover:border-white/20 text-[13px] font-medium transition-all"
                                                    aria-label="Escolher da galeria"
                                                >
                                                    <Images className="w-4 h-4" />
                                                    Escolher da galeria
                                                </button>
                                            </>
                                        )}
                                    </div>
                                ) : (
                                    <div className="relative group">
                                        <div className="aspect-[3/4] w-full bg-black/50">
                                            <img
                                                src={referenceImages[0]}
                                                alt="Foto enviada"
                                                className="w-full h-full object-cover"
                                                decoding="async"
                                            />
                                        </div>
                                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                                            <button
                                                type="button"
                                                onClick={(e) => { e.stopPropagation(); setReferenceImages([]); setUploadedAspectRatio("1:1"); setGeneratedImage(null); }}
                                                className="px-5 py-2 text-sm text-white/90 bg-white/10 hover:bg-white/15 backdrop-blur-[2px] md:backdrop-blur-sm border border-white/15 rounded-full transition-colors"
                                            >
                                                Trocar foto
                                            </button>
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* Generate / Reveal button */}
                            <button
                                type="button"
                                disabled={!hasImage}
                                onClick={handleReveal}
                                className={`mt-4 w-full py-4 rounded-[14px] text-[15px] font-semibold tracking-wide transition-all duration-500 overflow-hidden relative group
                  ${!hasImage
                                        ? "bg-white/[0.03] text-white/20 cursor-not-allowed border border-white/[0.02]"
                                        : "bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white hover:from-[#a61530] hover:to-[#6b0d1e] active:scale-[0.98] shadow-lg md:shadow-[0_0_30px_rgba(140,18,41,0.25)] border border-[#ff3b5c]/20"
                                    }`}
                            >
                                {hasImage && (
                                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-[shimmer_2s_infinite]" />
                                )}
                                <span className="relative z-10">MOSTRAR TUDO AGORA</span>
                            </button>
                        </div>
                    </div>

                    {!hasImage && (
                        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 md:animate-bounce opacity-30 text-[#8c1229]">
                            <ChevronDown className="w-6 h-6" />
                        </div>
                    )}
                </section>
            )}

            {/* ━━━ SINGLE PAGE FUNNEL (Register, Generating, Revealed) ━━━ */}
            {funnelStage !== "upload" && (
                <section className="w-full py-8 md:py-16 px-5 relative md:animate-in md:zoom-in-95 md:fade-in md:duration-500">
                    <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[300px] h-[400px] bg-[#520a17] opacity-20 blur-[60px] md:blur-[120px] pointer-events-none" />

                    <div className="max-w-sm mx-auto flex flex-col gap-6 relative z-10">

                        {/* --- IMAGE BLOCK AT TOP --- */}
                        <div className="w-full rounded-2xl overflow-hidden bg-[#0a0204] border border-[#8c1229]/20 shadow-xl md:shadow-[0_20px_80px_rgba(82,10,23,0.3)] min-h-[400px]">
                            <div className="w-full aspect-[3/4] relative">

                                {funnelStage !== "funnel_revealed" ? (
                                    // GENERATING OR REGISTER STATE
                                    <>
                                        {(funnelStage === "funnel_register" && generatedImage?.status === "completed") ? (
                                            <>
                                                {/* Reference image (original photo) as the base layer */}
                                                <img
                                                    src={referenceImages[0]}
                                                    alt="Quase lá"
                                                    className="absolute inset-0 w-full h-full object-cover scale-105"
                                                    decoding="async"
                                                />
                                                {/* Red veil overlay — conceals the original photo with brand identity */}
                                                <div className="absolute inset-0 bg-gradient-to-b from-[#8c1229]/75 via-[#6b0d1e]/70 to-[#520a17]/80" />
                                                {/* Text + CTA on top of the veil */}
                                                <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-black/30 p-6 text-center">
                                                    <h3 className="text-xl md:text-2xl font-bold text-[#ff3b5c] tracking-wide mb-2 drop-shadow-md">
                                                        Eu já estou pronta pra você...
                                                    </h3>
                                                    <p className="text-[15px] md:text-base font-medium text-white/90 leading-relaxed shadow-black drop-shadow-lg max-w-[280px]">
                                                        Crie sua conta e libere a imagem imediatamente
                                                    </p>
                                                </div>
                                            </>
                                        ) : (
                                            <>
                                                <img
                                                    src={referenceImages[0]}
                                                    alt=""
                                                    className="absolute inset-0 w-full h-full object-cover blur-[6px] md:blur-[13px] scale-105 opacity-60 brightness-75 transition-all duration-1000"
                                                    decoding="async"
                                                />
                                                <div className="absolute inset-0 flex flex-col items-center justify-center gap-6 bg-black/40">
                                                    <div className="relative">
                                                        <div className="w-14 h-14 rounded-full border-2 border-[#8c1229]/20 border-t-[#8c1229] border-r-[#8c1229]/60 animate-[spin_1.5s_linear_infinite]" />
                                                        <div className="absolute inset-0 w-14 h-14 rounded-full border border-transparent border-b-[#ff3b5c]/40 animate-[spin_2s_reverse_linear_infinite]" />
                                                    </div>
                                                    <div className="text-center">
                                                        <p className="text-sm text-white/90 font-medium animate-pulse tracking-wide">
                                                            Gerando...
                                                        </p>
                                                        <p className="text-[11px] text-white/40 mt-1 uppercase tracking-widest">
                                                            VAI VALER CADA SEGUNDO DE ESPERA
                                                        </p>
                                                    </div>
                                                </div>
                                            </>
                                        )}
                                    </>
                                ) : (
                                    // REVEALED STATE: image still blurred — full quality only via credits
                                    <div className="relative w-full h-full">
                                        {revealedImageSrc ? (
                                            <img
                                                src={revealedImageSrc}
                                                alt="Resultado"
                                                className="w-full h-full object-cover md:animate-in md:fade-in md:duration-1000"
                                                decoding="async"
                                                onError={() => setRevealedImageLoadFailed(true)}
                                            />
                                        ) : (
                                            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/40 px-6 text-center">
                                                <div className="w-10 h-10 rounded-full border-2 border-[#8c1229]/20 border-t-[#8c1229] animate-[spin_1.2s_linear_infinite]" />
                                                <div>
                                                    <p className="text-sm font-medium text-white/90">Sua imagem está sendo recuperada</p>
                                                    <p className="mt-1 text-[12px] text-white/45">Se ela não aparecer agora, tente novamente em alguns segundos.</p>
                                                </div>
                                            </div>
                                        )}
                                        {/* "Melhorar qualidade" button overlay — hidden after PIX payment */}
                                        {!meData?.hasPaidPix && (
                                            <button
                                                type="button"
                                                onClick={openCreditsPopup}
                                                className="absolute bottom-4 right-4 px-4 py-3 rounded-xl text-[13px] font-semibold bg-[#0a0204]/90 backdrop-blur-[2px] md:backdrop-blur-md border border-[#8c1229]/40 text-white hover:bg-black hover:border-[#ff3b5c]/60 transition-all shadow-lg md:shadow-[0_10px_40px_rgba(140,18,41,0.3)] flex items-center gap-2 group"
                                            >
                                                <Sparkles className="w-4 h-4 text-[#ff3b5c] group-hover:scale-110 transition-transform" />
                                                Quer ver mais?
                                            </button>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* "Abrir painel" button — visible only after PIX payment */}
                        {funnelStage === "funnel_revealed" && meData?.hasPaidPix && (
                            <button
                                type="button"
                                onClick={() => setLocation("/painel")}
                                className="w-full py-4 rounded-2xl text-[15px] font-semibold tracking-wide bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white hover:from-[#a61530] hover:to-[#6b0d1e] active:scale-[0.98] transition-all duration-300 shadow-lg md:shadow-[0_0_30px_rgba(140,18,41,0.25)] border border-[#ff3b5c]/20 flex items-center justify-center gap-2.5 group md:animate-in md:slide-in-from-bottom-4 md:fade-in md:duration-500"
                            >
                                <span>ABRIR PAINEL</span>
                                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                            </button>
                        )}

                        {/* --- FORM BLOCK BELOW (only in funnel_register) --- */}
                        {funnelStage === "funnel_register" && (
                            <div className="rounded-2xl border border-[#8c1229]/20 bg-[#0a0204]/90 backdrop-blur-[2px] md:backdrop-blur-xl p-6 md:p-8 shadow-xl md:shadow-2xl md:animate-in md:slide-in-from-bottom-8 md:fade-in md:duration-500">
                                <div className="text-center mb-6">
                                    <h3 className="text-lg font-semibold text-white/95">
                                        {canGenerateForRegisteredLead ? "Retomar revelação" : "Crie sua conta para revelar"}
                                    </h3>
                                    <p className="text-[13px] text-white/40 mt-1 font-light">
                                        {canGenerateForRegisteredLead ? "Sua conta já está criada. Vamos continuar de onde parou." : "Grátis, rápido e 100% sigiloso"}
                                    </p>
                                </div>

                                <div className="flex flex-col gap-4">
                                    {!canGenerateForRegisteredLead ? (
                                        <>
                                            <div>
                                                <div className="relative">
                                                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                                    <input
                                                        type="text"
                                                        value={username}
                                                        onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9._]/g, "").slice(0, 20))}
                                                        placeholder="Nome de usuário"
                                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                                    />
                                                </div>
                                            </div>

                                            <div>
                                                <div className="relative">
                                                    <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                                    <input
                                                        type="password"
                                                        maxLength={40}
                                                        value={password}
                                                        onChange={(e) => setPassword(e.target.value.slice(0, 40))}
                                                        placeholder="Senha (mínimo 6 caracteres)"
                                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                                    />
                                                </div>
                                            </div>

                                            <div>
                                                <div className="relative">
                                                    <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                                                    <input
                                                        type="password"
                                                        maxLength={40}
                                                        value={confirmPassword}
                                                        onChange={(e) => setConfirmPassword(e.target.value.slice(0, 40))}
                                                        placeholder="Confirme a senha"
                                                        className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/90 placeholder:text-white/20 text-[15px] focus:outline-none focus:border-[#8c1229]/50 focus:bg-white/[0.06] transition-all"
                                                    />
                                                </div>
                                            </div>
                                        </>
                                    ) : (
                                        <div className="rounded-xl border border-white/[0.08] bg-white/[0.04] px-4 py-3 text-[13px] leading-relaxed text-white/55">
                                            Se a geração anterior caiu ou você recarregou a página, toque abaixo para tentar revelar de novo.
                                        </div>
                                    )}

                                    {registerError && (
                                        <p className="text-[13px] text-[#ff3b5c] font-medium px-1 mt-[-4px] md:animate-in md:fade-in">
                                            {registerError}
                                        </p>
                                    )}

                                    <button
                                        type="button"
                                        onClick={handleRegister}
                                        disabled={isRegistering || (!canGenerateForRegisteredLead && (!username || password.length < MIN_PASSWORD_LENGTH || confirmPassword.length < MIN_PASSWORD_LENGTH))}
                                        className={`w-full py-4 rounded-xl text-[15px] font-semibold tracking-wide transition-all duration-300 mt-2
                      ${isRegistering || (!canGenerateForRegisteredLead && (!username || password.length < MIN_PASSWORD_LENGTH || confirmPassword.length < MIN_PASSWORD_LENGTH))
                                                ? "bg-white/[0.04] text-white/25 cursor-not-allowed border border-white/[0.04]"
                                                : "bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white hover:from-[#a61530] hover:to-[#6b0d1e] active:scale-[0.98] shadow-md md:shadow-[0_0_20px_rgba(140,18,41,0.2)] border border-[#ff3b5c]/20"
                                            }`}
                                    >
                                        {isRegistering ? (
                                            <span className="flex items-center justify-center gap-2">
                                                <Loader2 className="w-4 h-4 animate-spin" />
                                                {canGenerateForRegisteredLead ? "Revelando..." : "Criando conta..."}
                                            </span>
                                        ) : (
                                            <span className="flex items-center justify-center gap-2 relative z-10">
                                                <Check className="w-4 h-4" />
                                                {canGenerateForRegisteredLead ? "TENTAR REVELAR NOVAMENTE" : "CONFIRMAR E REVELAR"}
                                            </span>
                                        )}
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* --- ACCOUNT CREATED SUCCESS FEEDBACK (after register, during generation) --- */}
                        {showAccountCreatedFeedback && funnelStage === "funnel_generating" && (
                            <div className="rounded-2xl border border-white/8 bg-white/[0.02] p-6 md:p-7 md:animate-in md:slide-in-from-bottom-4 md:fade-in md:duration-500">
                                <div className="flex flex-col items-center text-center gap-3">
                                    <div className="w-9 h-9 rounded-full bg-emerald-500/[0.06] border border-emerald-500/15 flex items-center justify-center">
                                        <Check className="w-4 h-4 text-emerald-400/70" strokeWidth={2} />
                                    </div>
                                    <div>
                                        <h3 className="text-[14px] font-medium text-white/80 tracking-tight">
                                            Conta criada com sucesso
                                        </h3>
                                        <p className="text-[13px] text-white/45 font-light mt-1 leading-relaxed">
                                            Sua geração já está sendo preparada — em instantes ela estará pronta.
                                        </p>
                                    </div>
                                    <div className="w-full mt-1.5 flex items-start gap-2.5 rounded-xl border border-white/[0.06] bg-white/[0.015] px-3.5 py-3 text-left">
                                        <ShieldCheck className="w-3.5 h-3.5 text-white/40 mt-0.5 shrink-0" />
                                        <p className="text-[12px] leading-relaxed text-white/50">
                                            Nosso banco de dados é limpo a cada <span className="text-white/70">12 horas</span>, garantindo que seu acesso seja <span className="text-white/70">100% privado e seguro</span>.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* --- UPSELL CARDS (only in funnel_revealed) --- */}
                        {funnelStage === "funnel_revealed" && (
                            <div className="w-full flex flex-col gap-4 mt-10 md:animate-in md:slide-in-from-bottom-4 md:fade-in md:duration-700">
                                <div className="ml-1">
                                    <h4 className="text-[17px] font-semibold tracking-tight text-white/95 mb-0.5">
                                        VEJA ELA EM: 
                                    </h4>
                                   
                                </div>

                                <div className="grid grid-cols-2 gap-3">
                                    {[
                                        { id: "pov", label: "VÍDEO POV", mediaType: "video" as const },
                                        { id: "positions", label: "PACK DE FOTOS", mediaType: "image" as const },
                                    ].map((card) => (
                                        <button
                                            key={card.id}
                                            type="button"
                                            onClick={() => handleUpsellCardClick(card.id)}
                                            className="flex flex-col gap-2 p-2 rounded-[18px] bg-[#0a0204]/60 backdrop-blur-[2px] md:backdrop-blur-sm border border-white/[0.06] hover:border-[#8c1229]/40 hover:bg-[#8c1229]/[0.05] transition-all duration-300 group shadow-md md:shadow-[0_4px_20px_rgba(0,0,0,0.2)]"
                                        >
                                            <div className="w-full aspect-video rounded-[12px] bg-[#1a050a]/50 relative overflow-hidden">
                                                {card.mediaType === "video" ? (
                                                    <video
                                                        src={`/api/card-image/${card.id}?v=${CARD_MEDIA_VERSION}`}
                                                        poster={`/api/card-image/${card.id}/poster?v=${CARD_MEDIA_VERSION}`}
                                                        className="absolute inset-0 w-full h-full object-cover z-0 group-hover:scale-105 transition-transform duration-500"
                                                        autoPlay
                                                        loop
                                                        muted
                                                        playsInline
                                                        preload="metadata"
                                                    />
                                                ) : (
                                                    <img
                                                        src={`/api/card-image/${card.id}?v=${CARD_MEDIA_VERSION}`}
                                                        alt={card.label}
                                                        className="absolute inset-0 w-full h-full object-cover z-0 group-hover:scale-105 transition-transform duration-500"
                                                        loading="lazy"
                                                        decoding="async"
                                                        fetchPriority="low"
                                                    />
                                                )}
                                            </div>
                                            <span className="text-[13px] pb-1 text-white/80 group-hover:text-white font-medium text-center transition-colors px-1">
                                                {card.label}
                                            </span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </section>
            )}

            {/* ━━━ BOTTOM SECTIONS (Hidden in single page funnel) ━━━ */}
            {funnelStage === "upload" && (
                <>
                    <section className="w-full py-20 md:py-28 px-5 border-t border-[#8c1229]/10">
                        <div className="max-w-md mx-auto flex flex-col gap-16">
                            <h2 className="text-2xl sm:text-3xl font-semibold tracking-[-0.01em] text-center text-white/90">
                                Sacie seu desejo, com 1 toque.
                            </h2>
                            <div className="flex flex-col gap-10">
                                <div className="flex items-start gap-5">
                                    <div className="w-9 h-9 rounded-full bg-[#8c1229]/20 flex items-center justify-center text-sm font-semibold text-[#ff3b5c]/70 shrink-0 mt-0.5 border border-[#8c1229]/30">1</div>
                                    <div>
                                        <h3 className="text-lg font-medium text-white/90">A foto certa</h3>
                                        <p className="text-[15px] text-white/40 mt-1.5 leading-relaxed font-light">Selecione quem desperta seu interesse. Totalmente sigiloso, servidores privados.</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-5">
                                    <div className="w-9 h-9 rounded-full bg-[#8c1229]/20 flex items-center justify-center text-sm font-semibold text-[#ff3b5c]/70 shrink-0 mt-0.5 border border-[#8c1229]/30">2</div>
                                    <div>
                                        <h3 className="text-lg font-medium text-white/90">Revelação</h3>
                                        <p className="text-[15px] text-white/40 mt-1.5 leading-relaxed font-light">Deixe a inteligência artificial te mostrar o que você quer ver.</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-5">
                                    <div className="w-9 h-9 rounded-full bg-[#8c1229]/20 flex items-center justify-center text-sm font-semibold text-[#ff3b5c]/70 shrink-0 mt-0.5 border border-[#8c1229]/30">3</div>
                                    <div>
                                        <h3 className="text-lg font-medium text-white/90">Tudo que você imaginar</h3>
                                        <p className="text-[15px] text-white/40 mt-1.5 leading-relaxed font-light">Suas fantasias ganham vida. Vídeos POV, posições e situações feitas sob medida para o que você deseja — com ela.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className="w-full py-20 md:py-28 px-5 text-center relative">
                        <div className="absolute inset-0 pointer-events-none">
                            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[70vw] max-w-[500px] h-[300px] rounded-full bg-[#8c1229] opacity-[0.06] blur-[60px] md:blur-[120px]" />
                        </div>
                        <div className="max-w-md mx-auto relative z-10 flex flex-col items-center gap-8">
                            <h2 className="text-3xl sm:text-4xl font-semibold tracking-[-0.02em] text-white/95 leading-tight">
                                Mate sua <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff3b5c] via-[#cc1a3a] to-[#8c1229]">curiosidade</span> sem correr riscos.
                            </h2>
                            <button
                                type="button"
                                onClick={scrollToHero}
                                className="px-10 py-4 bg-gradient-to-r from-[#8c1229] to-[#520a17] text-white text-[15px] font-semibold tracking-wide rounded-[14px] hover:from-[#a61530] hover:to-[#6b0d1e] active:scale-[0.98] transition-all shadow-lg md:shadow-[0_0_30px_rgba(140,18,41,0.25)] border border-[#ff3b5c]/20 relative group overflow-hidden"
                            >
                                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-[shimmer_2s_infinite]" />
                                <span className="relative z-10">REVELAR GRATUITAMENTE</span>
                            </button>
                        </div>
                    </section>

                    <footer className="w-full py-6 text-center text-white/15 text-[11px] border-t border-white/[0.04]">
                        <p>© {new Date().getFullYear()} DesireAI · 100% Sigiloso</p>
                    </footer>
                </>
            )}

            {/* ━━━ MODALS ━━━ */}
            <Suspense fallback={null}>
                {creditsPopupOpen && (
                    <CreditsPopup
                        open={creditsPopupOpen}
                        onClose={() => setCreditsPopupOpen(false)}
                        onSelectPlan={handleSelectPlan}
                        customItems={creditsPopupItems}
                    />
                )}
                {pixModalOpen && (
                    <PixQrModal
                        open={pixModalOpen}
                        onClose={() => setPixModalOpen(false)}
                        planId={selectedPlanId}
                        onPaymentSuccess={handlePixPaymentSuccess}
                        redirectAfterPaymentTo="/upsell/instapro"
                    />
                )}
                {videoPovModalOpen && (
                    <VideoPovModal
                        open={videoPovModalOpen}
                        onClose={() => setVideoPovModalOpen(false)}
                        onSubmit={handleVideoPovSubmit}
                        isSubmitting={isSubmittingVideoPov}
                    />
                )}
                {packPhotosModalOpen && (
                    <PackPhotosModal
                        open={packPhotosModalOpen}
                        onClose={() => setPackPhotosModalOpen(false)}
                        onSubmit={handlePackPhotosSubmit}
                        isSubmitting={isSubmittingPackPhotos}
                    />
                )}

                {/* ━━━ FINGERPRINT PAYWALL FOR RECURRING VISITORS ━━━ */}
                {fingerprintPaywallOpen && (
                    <FingerprintPaywallModal
                        open={fingerprintPaywallOpen}
                        onPaymentSuccess={() => {
                            setFingerprintPaywallOpen(false);
                            setFunnelStage("funnel_register");
                            setTimeout(() => { scrollToHero(); }, 50);
                        }}
                    />
                )}
            </Suspense>
        </div>
    );
}

export default DesireLandingPage;
