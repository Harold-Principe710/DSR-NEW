export default function VarianteBPage() {
  return (
    <main className="min-h-screen bg-[#050102] text-white">
      <div className="mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center gap-4 px-6 text-center">
        <span className="rounded-full border border-[#8c1229]/60 bg-[#8c1229]/15 px-3 py-1 text-xs uppercase tracking-wide text-white">
          Variante B
        </span>
        <h1 className="text-3xl font-semibold sm:text-4xl">Oferta alternativa</h1>
        <p className="max-w-xl text-sm text-white/70">
          Esta é a variante B. Edite este componente para testar copy,
          preço, CTA ou layout sem tocar no resto do app.
        </p>
      </div>
    </main>
  );
}
