export default function ControlPage() {
  return (
    <main className="min-h-screen bg-[#050102] text-white">
      <div className="mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center gap-4 px-6 text-center">
        <span className="rounded-full border border-white/15 px-3 py-1 text-xs uppercase tracking-wide text-white/60">
          Variante Control
        </span>
        <h1 className="text-3xl font-semibold sm:text-4xl">Oferta padrão</h1>
        <p className="max-w-xl text-sm text-white/70">
          Esta é a versão de controle. Substitua este conteúdo pelo checkout
          atual sem alterar o fluxo de pagamento existente.
        </p>
      </div>
    </main>
  );
}
