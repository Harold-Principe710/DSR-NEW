# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Tech stack

Node 20 + TypeScript (ESM). Express 4 server, Vite 5 + React 18 client, Drizzle ORM on Postgres, `ws` for WebSockets, `express-session` + `connect-pg-simple` for sessions. UI: shadcn/ui on Radix + Tailwind 4 (via `@tailwindcss/vite`). Payments via PIX/BlackCat (primary) and Stripe (imported, unused). Image gen via KIE.AI (Seedream / Qwen2 edit). Pack preview images served via Cloudinary with responsive srcsets.

## Repo layout

`client/` SPA · `server/` Express+WS · `shared/` Drizzle schema + domain constants · `script/` build & DB repair scripts · `migrations/` Drizzle-generated SQL (artifacts, not the source of truth) · `uploads/` and `tmp/` runtime working dirs · `merged-films/` generated video outputs · `_template-gerar-imagem-seedream/` read-only fork source · `dist/` build output.

## Commands

- `npm run dev` — kills any process on port 8080, then runs `tsx --watch server/bootstrap.ts` with `.env` loaded. Server listens on `PORT` (default 5000 in dev, 8080 in production); Vite middleware is mounted by `server/vite.ts` in dev.
- `npm run build` — `script/build.ts`: Vite builds the client to `dist/public`, then esbuild bundles `server/bootstrap.ts` → `dist/index.cjs` (CJS, `--packages=external`).
- `npm run start` — runs the built server in production without blocking startup on `db:push`.
- `npm run start:with-db-push` — runs `db:push` then the built server in production; use only when a one-off deploy/startup schema push is intentional.
- `npm run check` — `tsc` typecheck only (no emit, see `tsconfig.json`). This is the only "test" command; there is no test runner configured.
- `npm run db:push` — `drizzle-kit push` against `DATABASE_URL`. On boot, `server/migrate.ts` shells out to the same command and auto-answers "n" to any destructive prompts.
- `npm run db:fix` — `tsx script/fix-db.ts` for manual schema repairs.
- `npm run ngrok` — exposes port 8080 on a fixed ngrok domain (used for webhook testing).

Migrations in `migrations/*.sql` are Drizzle-generated; the app uses `drizzle-kit push` against the live schema in `shared/schema.ts` rather than applying those SQL files directly. Boot-time push defaults to dev only; set `RUN_MIGRATIONS_ON_BOOT=true` when a deploy should run it after the HTTP server is already listening. `RUN_MIGRATIONS_ON_BOOT=false` or `SKIP_MIGRATIONS=true` disables the boot-time push.

After editing code, run `npm run check` to typecheck — this is the only verification command configured.

## Git workflow

- When the user says `git commit and push`, treat it as a request to stage, commit, and push **all site changes** to the `main` branch, unless the user clearly says otherwise.

### Environment variables (`.env.example`)

- `DATABASE_URL` — Postgres connection string (required).
- `SESSION_SECRET` — session signing key (generate via `openssl rand -hex 32`).
- `PORT` / `NODE_ENV` / `PUBLIC_DOMAIN` / `PUBLIC_PROTOCOL` — server binding and URL construction.
- `KIE_API_KEY`, `KIE_IMAGE_API_MODEL`, `KIE_IMAGE_API_EDIT` — KIE.AI image generation.
- `CARD_IMAGES_JSON` — JSON map of `cardId → URL` for landing media. `PACKFOTOS`, `pov`, `pov_modal_header` are explicit overrides that take precedence.
- `SKIP_MIGRATIONS` / `RUN_MIGRATIONS_ON_BOOT` — toggle boot-time `drizzle-kit push`.

Other secrets (admin/caller credentials, `PIX_WEBHOOK_URL`, Qwen prompt) are hardcoded in `server/routes.ts` — see Conventions below.

## Architecture

Single-process Express app that serves both the API and the SPA. One HTTP server, one WebSocket server, one Postgres connection.

### Layout & path aliases
- `client/` — React 18 + Vite SPA, root is `client/`, built to `dist/public`.
- `server/` — Express + Drizzle + WebSocket backend.
- `shared/` — Drizzle schema and domain constants imported by both sides. `shared/models/auth.ts` holds `users`, `sessions`, and verification/password tokens; `shared/schema.ts` re-exports it and adds everything else.
- Aliases (configured in both `vite.config.ts` and `tsconfig.json`): `@/*` → `client/src/*`, `@shared/*` → `shared/*`, `@assets/*` → `client/public/*`.

### Server startup sequence (`server/index.ts`)
1. Create `httpServer`, attach WebSocket (`setupWebSocket`) on path `/ws`.
2. Register health endpoints `/health` and `/ready` **before** `registerRoutes`, so probes work while initialization is still running.
3. Mount `compression`, `express.json({ limit: '25mb', verify })` — `req.rawBody` is preserved on every request (used by webhook signature checks).
4. `registerRoutes(httpServer, app)` mounts all `/api/*` handlers and calls `setupSession(app)`.
5. In dev, `setupVite` mounts Vite middleware; in prod, `serveStatic` serves `dist/public`.
6. After `listen`, `runAsyncInitialization` tests the DB, optionally runs migrations, and starts the `expireStaleImages` job (every 15 min, refunds credits for images stuck > 45 min).

### Auth model — three parallel realms, all session-based
`server/sessionAuth.ts` uses `express-session` with `connect-pg-simple` (table `sessions`). There are three distinct auth surfaces that share the same session store but are gated by separate middleware in `server/routes.ts`:

1. **End user** — `/api/user/me`, `/api/auth/login`, `/api/auth/register-funnel`. Sessions set `session.user.id`. `withSessionId` populates `req.userId` from the session user OR falls back to `req.sessionID` for anonymous funnel tracking. `requireAuth` hard-requires a logged-in user. Landing-page visitors are anonymous until they register via the funnel. Uploads validate MIME types + extensions with HEIC/HEIF support; validation utilities in `client/src/lib/upload-validation.ts`.
2. **Admin** — `/api/admin/*`, gated by `requireAdminAuth`. Credentials are loaded from env via `ADMIN_USERNAME` + `ADMIN_PASSWORD_HASH` (bcrypt). Rate-limited (5 attempts per 15 min) with 15-min lockout on failure. The admin dashboard (`/admin`) shows funnel analytics, journey map, customers, and pack/video-pov responses.
3. **Caller** — `/api/caller/*`, gated by `requireCallerAuth`, reachable only at the obscured path `/caller-92192`. Credentials are loaded from env via `CALLER_USERNAME` + `CALLER_PASSWORD_HASH` (bcrypt). Rate-limited with lockout protection. Read-only customer list for phone outreach.

The client mirrors this with three `ProtectedRoute` variants in `client/src/App.tsx`. `ProtectedRoute` additionally checks `user.hasPaidPix` and redirects unpaid users to `/`.

### Funnel tracking
The landing page drives a multi-step conversion funnel. Events are recorded in `funnel_events` (with `(session_id, idempotency_key)` unique index) and aggregated state lives in `funnel_sessions`. Steps are the `funnelStepEnum` values in `shared/schema.ts`: `visitor_entered` → `photo_uploaded` → `generated_photo_viewed` → `offer_viewed` → `offer_responded` → `video_loading_screen` → `video_loaded` → `pix_generated` → `pix_paid`.

- Client: `client/src/lib/funnel.ts` POSTs to `/api/funnel/events`.
- `JOURNEY_NODES_BY_PATH` maps routes to journey nodes; the admin dashboard visualizes these via nodes/edges defined in `server/routes.ts` (`JOURNEY_NODES`, `JOURNEY_EDGES`).

### Payments
- **PIX** (BRL, anonymous/landing flow): `/api/pix/create` forwards to an external webhook (`PIX_WEBHOOK_URL` hardcoded in `server/routes.ts`) and stores rows in `pix_payments`. The `externalref` format is `${sessionId}::${journeyNode}`. `abacatePayId` column holds the provider's transaction id. A legacy `_v2nodata` suffix on incoming webhook `externalReference` is stripped in `parseExternalReference` for compatibility with in-flight charges from the retired registration A/B test.
- **Webhooks** — two handlers:
  - `POST /api/webhooks/pix` — generic PIX status updates.
  - `POST /api/webhooks/blackcat` — BlackCat events. Requires `source: "blackcat-api"`. Idempotent via `blackcat_webhook_logs.idempotency_key` unique constraint. On success, updates the matching `funnel_sessions` row (keyed by `externalref`) to `pix_paid`.
- Stripe is imported but the primary monetization path is PIX + BlackCat.

### Image delivery & generation
**Delivery**: Pack preview images (in modals, loading screens) are served via Cloudinary with responsive srcsets (`PACK_PREVIEW_IMAGES` in `client/src/lib/pack-preview-images.ts`). Uses Cloudinary transforms: `f_auto,q_auto:eco,dpr_auto,c_fill,g_auto,ar_4:5` for optimal delivery across devices.

**Generation**: Image jobs use KIE.AI. Flow: client POSTs to `/api/generated-images` → server creates a `generated_images` row, calls KIE task API, and either polls KIE (`startImagePolling`) or waits for `/api/webhooks/generated-image/:imageId`. Completion fires a WebSocket `notifyImageCompleted`. The Qwen2 edit prompt is a hardcoded NSFW string constant (`QWEN2_EDIT_PROMPT`) in `server/routes.ts` — leave it alone unless the task is explicitly about editing the generation prompt. Costs are computed in `shared/schema.ts` via the `KIE_AI_COSTS` table × `KIE_COST_MARGIN` (1.1).

### Real Preview / Video POV agent
Use `.claude/agents/REALPREVIEW_CODER.md` whenever the user calls `REALPREVIEW_CODER` or any change touches the Real Preview Video POV flow: `server/pov-preview.ts`, `/api/video-pov-requests`, KIE Gemini/Claude analysis, `POV_PREVIEW_*` envs, Cloudinary preview media, thumbnails, `/video-pov-loading`, proxy streaming, preload behavior, or the admin **Real Preview Logs** block.

Real Preview rules:
- Media URLs and poster URLs must stay server-side in `.env` / `.env.example`; never expose them with `VITE_`, `import.meta.env`, `client/src`, `client/public`, or `dist/public`.
- Frontend receives only authenticated internal routes for stream/poster; backend validates request ownership and completed generated image before serving.
- GPT-5.3 Chat (`gpt-5.3-chat-latest`, GPT 5.3 Instant) via OpenAI Responses API is the primary analysis model; Gemini 3 Flash via KIE is the only active AI fallback. The quiz-selected position is code-owned and must not be sent to the IA prompt.
- `sentando` maps to `de_quatro` for preview selection.
- New or replaced videos require lightweight WebP thumbnails, env mapping, preload consideration, fallback preservation, and deletion of temporary local thumbnail files after Cloudinary upload.
- Diagnose failures first through `/admin` → **Real Preview Logs** or `GET /api/admin/real-preview-logs`.

### WebSocket (`server/websocket.ts`)
`ws` on path `/ws`. Authenticates by running the Express session middleware against the upgrade request; requires `session.user.id`. Connections are keyed by `userId` in a `Map<string, Set<WebSocket>>`. Used for `image_completed`, `image_failed`, and `pix_paid` push notifications. Anonymous (session-only) clients are rejected with close code 4001.

### Client state
- `wouter` for routing, `@tanstack/react-query` for server state. `queryClient` is in `client/src/lib/queryClient.ts`; `getQueryFn({ on401: "returnNull" })` is the standard 401-tolerant fetcher.
- Routes that require a paid user are wrapped in `ProtectedRoute` (which also wraps them in `AppLayout`). Admin/caller routes use `AdminProtectedRoute` / `CallerProtectedRoute` — these do NOT use `AppLayout`.
- All non-landing pages are `lazy()`-loaded; `AppRoutes` warms the other chunks in `requestIdleCallback` after first paint.
- UI is shadcn/ui (`client/src/components/ui`) on Radix + Tailwind. The dark brand color is `#8c1229`.

## Conventions & gotchas

- **Language**: user-facing strings and most comments are in Brazilian Portuguese. Keep that consistent when editing UI text, toast messages, and log strings (server logs are in English for `[source]` tags, Portuguese for messages).
- **`req.rawBody`** is populated by the JSON parser and required by webhook handlers — don't add a route-specific `bodyParser` that consumes the stream before them.
- **Schema changes** go in `shared/schema.ts` (or `shared/models/auth.ts` for user/session/token tables). Run `npm run db:push` after edits; do NOT hand-edit files under `migrations/` expecting them to be replayed — they're generated artifacts, not the source of truth.
- **Sensitive auth creds** for admin/caller must stay out of source. Use `ADMIN_USERNAME`, `ADMIN_PASSWORD_HASH`, `CALLER_USERNAME`, and `CALLER_PASSWORD_HASH` in env; do not reintroduce plaintext credentials into the repo. Privileged login attempts are rate-limited and locked out for 15 min after 5 failed attempts in a 15-min window.
- **Port 8080 vs 5000**: `npm run dev` kills whatever's on 8080 at startup (legacy), but the server actually binds to `PORT` which defaults to 5000. The `.env.example` sets `PORT=5000`. Both ports may appear in docs/scripts.
- **`client/get_bounds.js`** and `client/public` assets are served as-is; `_template-gerar-imagem-seedream` is the original template the project was forked from — treat it as read-only reference.

## Performance & Optimization Directive

This app is profit-driven. **All implementations must:**

- Minimize CPU, memory, and I/O usage whenever possible
- Prefer lightweight solutions over heavy frameworks/libraries
- Avoid over-engineering — simple and efficient first
- Optimize queries, avoid N+1, use proper indexes
- Reuse connections and avoid unnecessary instances
- Cache when it makes sense to reduce repeated processing
