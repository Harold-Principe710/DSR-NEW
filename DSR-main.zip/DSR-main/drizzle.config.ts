import { defineConfig } from "drizzle-kit";
import dns from "node:dns";
import { getDatabaseSslConfig, isLocalDatabaseUrl } from "./server/db-ssl";

// Force IPv4 because DigitalOcean blocks IPv6 outbound
dns.setDefaultResultOrder("ipv4first");

// Allow config to load even without DATABASE_URL (for build tools that scan configs)
const databaseUrl = process.env.DATABASE_URL || "";

if (!databaseUrl && process.argv.includes("push")) {
  console.error("ERROR: DATABASE_URL is not set. Cannot push schema.");
  console.error("Please set DATABASE_URL environment variable.");
  process.exit(1);
}

export default defineConfig({
  out: "./migrations",
  schema: "./shared/schema.ts",
  dialect: "postgresql",
  dbCredentials: {
    url: databaseUrl,
    ssl: databaseUrl && !isLocalDatabaseUrl(databaseUrl)
      ? getDatabaseSslConfig(databaseUrl)
      : false,
  },
});
