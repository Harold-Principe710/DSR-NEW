# Template: Gerar Imagem + Seedream 4.5

Pasta de referência para extrair o layout da página **Gerar Imagem** e a integração com **Seedream 4.5** do Big-AI, e usar como base de outro SaaS.

## Como usar

1. Crie um novo projeto (ex.: Vite + React + Node/Express).
2. Siga `FILES_TO_COPY.md` para copiar os arquivos necessários do Big-AI.
3. Aplique as alterações em `MODIFICATIONS.md` para manter apenas Seedream 4.5.
4. Configure variáveis de ambiente (KIE_API_KEY, banco, auth).

## Arquivos nesta pasta

| Arquivo | Descrição |
|---------|-----------|
| `README.md` | Este arquivo |
| `FILES_TO_COPY.md` | Lista exata de arquivos do Big-AI a copiar |
| `MODIFICATIONS.md` | O que remover/alterar ao extrair |
| `schema-seedream-only.ts` | Schema mínimo com só Seedream 4.5 (referência) |
