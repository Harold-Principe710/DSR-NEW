# Modificações ao extrair

## 1. IMAGE_MODELS (shared/schema.ts)

Manter **apenas** a entrada `seedream45`:

```ts
export const IMAGE_MODELS = {
  seedream45: {
    id: "seedream45",
    name: "Seedream 4.5",
    subtitle: "4K",
    description: "Imagens 4K de alta qualidade",
    creditCost: 12,
    hasNegativePrompt: false,
    maxPromptLength: 3000,
    apiModel: "seedream/4.5-text-to-image",
  },
} as const;
export type ImageModelKey = "seedream45";
```

## 2. image-generate.tsx

- `selectedModel`: usar `"seedream45"` como padrão e remover seletor de modelo (ou manter fixo).
- Remover estados de outros modelos: `mjStylization`, `mjWeirdness`, `mjVariety`, `enable4K`, `nanoBanana2Resolution`, etc.
- Manter: `prompt`, `aspectRatio`, `referenceImages`, `seedream45Quality` (basic/high).
- Remover opções `generateInAll` e `allModels` se não for usar.
- Aspect ratios: `["1:1", "4:3", "3:4", "16:9", "9:16", "2:3", "3:2", "21:9"]`.

## 3. Rotas (server/routes.ts)

- Em POST `/api/generated-images`: remover lógica de `allModels` ou simplificar para aceitar só `model: "seedream45"`.
- Manter apenas o branch `seedream45` em "Model specific overrides" (linhas ~7086-7093 do routes.ts original).

## 4. Sessões (opcional)

Se não quiser sessões, remova:
- `imageSessions` do schema e storage.
- Queries de sessões no frontend.
- Use só `recentImages` (GET `/api/generated-images?limit=50`).
