/**
 * Schema mínimo para Gerar Imagem com Seedream 4.5.
 * Use como referência ao criar o novo projeto.
 */

export const IMAGE_MODELS = {
  seedream45: {
    id: "seedream45",
    name: "Seedream 4.5",
    subtitle: "4K",
    description: "Imagens 4K de alta qualidade",
    creditCost: 12,
    hasNegativePrompt: false,
    maxPromptLength: 3000,
    apiModel: "seedream/4.5-text-to-image",
  },
} as const;

export type ImageModelKey = keyof typeof IMAGE_MODELS;
export type ImageAspectRatio = "1:1" | "4:3" | "3:4" | "16:9" | "9:16" | "2:3" | "3:2" | "21:9";

export const SEEDREAM_RATIOS: ImageAspectRatio[] = ["1:1", "4:3", "3:4", "16:9", "9:16", "2:3", "3:2", "21:9"];

export interface GeneratedImage {
  id: string;
  userId: string;
  prompt: string;
  negativePrompt: string | null;
  model: ImageModelKey;
  aspectRatio: ImageAspectRatio;
  creditCost: number;
  status: "pending" | "processing" | "completed" | "failed";
  taskId: string | null;
  imageUrl: string | null;
  errorMessage: string | null;
  createdAt: Date | null;
  completedAt: Date | null;
}
