# Prompt para o Cursor (novo projeto)

Abra o Big-AI em outra janela do Cursor e use este prompt para gerar o novo projeto:

---

Crie um novo projeto React (Vite) + Node/Express com o seguinte:

1. Copie os arquivos listados em `_template-gerar-imagem-seedream/FILES_TO_COPY.md` do projeto Big-AI para este novo projeto, mantendo a estrutura de pastas client/ e server/.

2. Aplique as modificações descritas em `_template-gerar-imagem-seedream/MODIFICATIONS.md`:
   - Schema: manter apenas seedream45 em IMAGE_MODELS
   - Página image-generate: modelo fixo seedream45, remover opções de outros modelos
   - Backend: simplificar POST /api/generated-images para só seedream45

3. Estrutura mínima: uma única página "Gerar Imagem" com prompt, aspect ratio, imagens de referência (opcional), botão gerar, feed de imagens com status e histórico.

4. Variáveis de ambiente: KIE_API_KEY, DATABASE_URL, e config de autenticação conforme o Big-AI.
