# Arquivos a copiar do Big-AI

Caminhos relativos à raiz do projeto Big-AI.

## Frontend

| Caminho | Uso |
|---------|-----|
| `client/src/pages/image-generate.tsx` | Página principal Gerar Imagem |
| `client/src/components/image-generate-history-modal.tsx` | Modal de histórico |
| `client/src/components/image-gallery-picker.tsx` | Seletor de imagens da galeria (opcional) |
| `client/src/components/model-icons.tsx` | Ícones por modelo |
| `client/src/components/sparkle-button.tsx` | Botão de gerar (ou substituir por Button) |
| `client/src/components/copy-script-button.tsx` | Copiar prompt (opcional) |
| `client/src/lib/queryClient.ts` | apiRequest, queryClient |
| `client/src/hooks/use-websocket.ts` | Atualização em tempo real |
| `client/src/hooks/use-toast.ts` | Toasts |
| `client/src/hooks/use-auth.ts` | Autenticação |
| `client/src/components/ui/*` | Button, Textarea, Badge, Label, Dialog, DropdownMenu, Popover, Input, ScrollArea |

## Backend

| Caminho | Extrair |
|---------|---------|
| `server/routes.ts` | GET/POST/DELETE `/api/generated-images`, POST `/api/webhooks/generated-image/:id`, POST `/api/image-sessions`, GET `/api/image-sessions`, GET `/api/image-sessions/:id/images`, PATCH/DELETE image-sessions, POST `/api/uploads/reference-image` |
| `server/storage.ts` | `getGeneratedImages`, `getGeneratedImage`, `createGeneratedImage`, `updateGeneratedImage`, `deleteGeneratedImage`, `getImageSessions`, `getImageSession`, `createImageSession`, `getGeneratedImagesBySession`, `touchImageSession`, `deleteImageSession` |
| `shared/schema.ts` | Tabela `generated_images`, `imageSessions`, enums `image_status`, `image_model`, `image_aspect_ratio`, objeto `IMAGE_MODELS` (apenas seedream45 após modificação) |

## Dependências (package.json)

- React, React Query (@tanstack/react-query), wouter, lucide-react
- shadcn/ui (ou equivalente): Button, Textarea, Badge, Label, Dialog, DropdownMenu, Popover, Input, ScrollArea
- Backend: express, drizzle-orm, pg
