CREATE TYPE "public"."affiliate_earning_status" AS ENUM('pending', 'available', 'paid', 'reversed');--> statement-breakpoint
CREATE TYPE "public"."affiliate_payout_status" AS ENUM('pending', 'approved', 'paid', 'rejected');--> statement-breakpoint
CREATE TYPE "public"."affiliate_status" AS ENUM('pending', 'active', 'suspended', 'rejected');--> statement-breakpoint
CREATE TYPE "public"."ai_model" AS ENUM('sora2', 'sora2_pro', 'grok', 'veo3_fast', 'veo3_quality', 'seedance', 'runway', 'midjourney', 'kling26');--> statement-breakpoint
CREATE TYPE "public"."audio_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."background_removal_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."film_model" AS ENUM('veo3_fast', 'veo3_quality');--> statement-breakpoint
CREATE TYPE "public"."film_project_status" AS ENUM('pending', 'processing', 'merging', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."image_aspect_ratio" AS ENUM('1:1', '9:16', '16:9', '3:4', '4:3');--> statement-breakpoint
CREATE TYPE "public"."image_edit_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."image_model" AS ENUM('nano_banana', 'imagen4', 'midjourney', 'seedream45', 'z_image', 'flux2_pro');--> statement-breakpoint
CREATE TYPE "public"."image_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."lipsync_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."motion_control_mode" AS ENUM('720p', '1080p');--> statement-breakpoint
CREATE TYPE "public"."motion_control_orientation" AS ENUM('image', 'video');--> statement-breakpoint
CREATE TYPE "public"."motion_control_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."plan_tier" AS ENUM('free', 'starter', 'creator', 'scale', 'big_scale');--> statement-breakpoint
CREATE TYPE "public"."sound_effect_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."transcription_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TYPE "public"."video_format" AS ENUM('9:16', '16:9', '2:3', '3:2', '1:1', '3:4', 'Auto');--> statement-breakpoint
CREATE TYPE "public"."video_status" AS ENUM('pending', 'processing', 'completed', 'failed');--> statement-breakpoint
CREATE TABLE "admin_audit_log" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"admin_user_id" varchar NOT NULL,
	"admin_email" text NOT NULL,
	"target_user_id" varchar,
	"action" text NOT NULL,
	"details" text,
	"previous_value" text,
	"new_value" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "affiliate_earnings" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"affiliate_id" varchar NOT NULL,
	"referral_id" varchar NOT NULL,
	"stripe_invoice_id" varchar,
	"plan_tier" text NOT NULL,
	"gross_amount" integer NOT NULL,
	"commission_percent" integer NOT NULL,
	"commission_amount" integer NOT NULL,
	"status" "affiliate_earning_status" DEFAULT 'pending' NOT NULL,
	"credited_at" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "affiliate_payouts" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"affiliate_id" varchar NOT NULL,
	"amount" integer NOT NULL,
	"pix_key" text NOT NULL,
	"pix_key_type" text,
	"status" "affiliate_payout_status" DEFAULT 'pending' NOT NULL,
	"requested_at" timestamp DEFAULT now(),
	"approved_by" varchar,
	"approved_at" timestamp,
	"paid_at" timestamp,
	"proof_reference" text,
	"notes" text
);
--> statement-breakpoint
CREATE TABLE "affiliate_referrals" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"affiliate_id" varchar NOT NULL,
	"referred_user_id" varchar NOT NULL,
	"referral_code" varchar(20) NOT NULL,
	"status" text DEFAULT 'registered' NOT NULL,
	"first_subscription_id" varchar,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "affiliate_referrals_referred_user_id_unique" UNIQUE("referred_user_id")
);
--> statement-breakpoint
CREATE TABLE "affiliates" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"referral_code" varchar(20) NOT NULL,
	"status" "affiliate_status" DEFAULT 'pending' NOT NULL,
	"commission_percent" integer DEFAULT 20 NOT NULL,
	"pix_key" text,
	"pix_key_type" text,
	"total_earnings" integer DEFAULT 0 NOT NULL,
	"available_balance" integer DEFAULT 0 NOT NULL,
	"paid_total" integer DEFAULT 0 NOT NULL,
	"total_referrals" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "affiliates_user_id_unique" UNIQUE("user_id"),
	CONSTRAINT "affiliates_referral_code_unique" UNIQUE("referral_code")
);
--> statement-breakpoint
CREATE TABLE "audios" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"text" text NOT NULL,
	"voice" text NOT NULL,
	"stability" real DEFAULT 0.5 NOT NULL,
	"similarity_boost" real DEFAULT 0.75 NOT NULL,
	"style" real DEFAULT 0 NOT NULL,
	"speed" real DEFAULT 1 NOT NULL,
	"speaker_boost" boolean DEFAULT false NOT NULL,
	"character_count" integer NOT NULL,
	"credit_cost" integer NOT NULL,
	"status" "audio_status" DEFAULT 'pending' NOT NULL,
	"task_id" text,
	"audio_url" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "background_removals" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"original_file_name" text NOT NULL,
	"original_image_url" text NOT NULL,
	"result_image_url" text,
	"task_id" text,
	"credit_cost" integer NOT NULL,
	"status" "background_removal_status" DEFAULT 'pending' NOT NULL,
	"error_message" text,
	"expires_at" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "credit_transactions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"amount" integer NOT NULL,
	"type" text NOT NULL,
	"description" text,
	"video_id" varchar,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "exchange_rates" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"from_currency" text NOT NULL,
	"to_currency" text NOT NULL,
	"rate" real NOT NULL,
	"fetched_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "film_projects" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"prompt" text,
	"model" "film_model" NOT NULL,
	"aspect_ratio" text DEFAULT '16:9' NOT NULL,
	"image_urls" text[] NOT NULL,
	"clip_count" integer NOT NULL,
	"credit_cost" integer NOT NULL,
	"status" "film_project_status" DEFAULT 'pending' NOT NULL,
	"clip_statuses" text,
	"clip_task_ids" text,
	"clip_video_urls" text,
	"final_video_url" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "generated_images" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"prompt" text NOT NULL,
	"negative_prompt" text,
	"model" "image_model" NOT NULL,
	"aspect_ratio" "image_aspect_ratio" DEFAULT '1:1' NOT NULL,
	"credit_cost" integer NOT NULL,
	"status" "image_status" DEFAULT 'pending' NOT NULL,
	"task_id" text,
	"image_url" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "image_edit_sessions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"name" text,
	"last_source_image_url" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "image_edits" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"session_id" varchar NOT NULL,
	"user_id" varchar NOT NULL,
	"prompt" text NOT NULL,
	"source_image_url" text NOT NULL,
	"result_image_url" text,
	"credit_cost" integer DEFAULT 38 NOT NULL,
	"status" "image_edit_status" DEFAULT 'pending' NOT NULL,
	"task_id" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "lipsyncs" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"prompt" text NOT NULL,
	"image_url" text NOT NULL,
	"audio_url" text NOT NULL,
	"resolution" text DEFAULT '480p' NOT NULL,
	"seed" integer,
	"audio_duration" real,
	"credit_cost" integer NOT NULL,
	"status" "lipsync_status" DEFAULT 'pending' NOT NULL,
	"task_id" text,
	"video_url" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "motion_controls" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"prompt" text,
	"image_url" text NOT NULL,
	"video_url" text NOT NULL,
	"character_orientation" "motion_control_orientation" DEFAULT 'video' NOT NULL,
	"mode" "motion_control_mode" DEFAULT '720p' NOT NULL,
	"video_duration" real,
	"credit_cost" integer NOT NULL,
	"status" "motion_control_status" DEFAULT 'pending' NOT NULL,
	"task_id" text,
	"result_video_url" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "sound_effects" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"text" text NOT NULL,
	"duration" real,
	"prompt_influence" real DEFAULT 0.3 NOT NULL,
	"loop" boolean DEFAULT false NOT NULL,
	"credit_cost" integer NOT NULL,
	"status" "sound_effect_status" DEFAULT 'pending' NOT NULL,
	"task_id" text,
	"audio_url" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "transcriptions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"file_name" text NOT NULL,
	"audio_url" text NOT NULL,
	"audio_duration" real,
	"credit_cost" integer NOT NULL,
	"status" "transcription_status" DEFAULT 'pending' NOT NULL,
	"task_id" text,
	"transcription_text" text,
	"language_code" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "user_credits" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"balance" integer DEFAULT 200 NOT NULL,
	"total_purchased" integer DEFAULT 0 NOT NULL,
	"total_spent" integer DEFAULT 0 NOT NULL,
	"has_purchased" boolean DEFAULT false NOT NULL,
	"plan_tier" "plan_tier" DEFAULT 'free' NOT NULL,
	"plan_start_date" timestamp,
	"plan_end_date" timestamp,
	"admin_assigned_plan" boolean DEFAULT false NOT NULL,
	"last_plan_credit_grant" timestamp,
	"last_daily_credits" timestamp,
	"daily_credits_accumulated" integer DEFAULT 0 NOT NULL,
	"stripe_customer_id" text,
	"stripe_subscription_id" text,
	"referral_code" text,
	"referred_by" varchar,
	"referral_reward_paid" boolean DEFAULT false NOT NULL,
	"referral_count" integer DEFAULT 0 NOT NULL,
	"referral_credits_earned" integer DEFAULT 0 NOT NULL,
	"has_completed_onboarding" boolean DEFAULT false NOT NULL,
	"monthly_image_count" integer DEFAULT 0 NOT NULL,
	"monthly_video_count" integer DEFAULT 0 NOT NULL,
	"last_monthly_reset" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "user_credits_referral_code_unique" UNIQUE("referral_code")
);
--> statement-breakpoint
CREATE TABLE "videos" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"prompt" text NOT NULL,
	"ai_model" "ai_model" NOT NULL,
	"grok_mode" text,
	"format" "video_format" NOT NULL,
	"duration" integer NOT NULL,
	"credit_cost" integer NOT NULL,
	"kie_cost_usd" real,
	"status" "video_status" DEFAULT 'pending' NOT NULL,
	"task_id" text,
	"thumbnail_task_id" text,
	"progress" integer DEFAULT 0,
	"video_url" text,
	"thumbnail_url" text,
	"error_message" text,
	"is_favorite" boolean DEFAULT false NOT NULL,
	"is_upscaled" boolean DEFAULT false NOT NULL,
	"auto_upscale" boolean DEFAULT false NOT NULL,
	"upscale_task_id" text,
	"upscale_status" text,
	"original_video_url" text,
	"grok_native_upscale_completed" boolean DEFAULT false NOT NULL,
	"has_reference_images" boolean DEFAULT false NOT NULL,
	"reference_image_urls" text[],
	"has_watermark" boolean DEFAULT false NOT NULL,
	"generate_audio" boolean DEFAULT false NOT NULL,
	"runway_quality" text,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "email_verification_tokens" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"token" varchar NOT NULL,
	"expires_at" timestamp NOT NULL,
	"used_at" timestamp,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "email_verification_tokens_token_unique" UNIQUE("token")
);
--> statement-breakpoint
CREATE TABLE "password_reset_tokens" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"token" varchar NOT NULL,
	"expires_at" timestamp NOT NULL,
	"used_at" timestamp,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "password_reset_tokens_token_unique" UNIQUE("token")
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"sid" varchar PRIMARY KEY NOT NULL,
	"sess" jsonb NOT NULL,
	"expire" timestamp NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" varchar,
	"first_name" varchar,
	"last_name" varchar,
	"profile_image_url" varchar,
	"password_hash" varchar,
	"email_verified" boolean DEFAULT false,
	"role" varchar DEFAULT 'user',
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "chat_conversations" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"title" text NOT NULL,
	"is_favorite" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"updated_at" timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"conversation_id" integer NOT NULL,
	"role" text NOT NULL,
	"content" text NOT NULL,
	"image_url" text,
	"credit_cost" integer DEFAULT 0,
	"created_at" timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_conversation_id_chat_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "public"."chat_conversations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "idx_unique_whatsapp_share_initiated" ON "credit_transactions" USING btree ("user_id") WHERE type = 'whatsapp_share_initiated';--> statement-breakpoint
CREATE UNIQUE INDEX "idx_unique_whatsapp_bonus" ON "credit_transactions" USING btree ("user_id") WHERE type = 'whatsapp_bonus';--> statement-breakpoint
CREATE INDEX "IDX_session_expire" ON "sessions" USING btree ("expire");