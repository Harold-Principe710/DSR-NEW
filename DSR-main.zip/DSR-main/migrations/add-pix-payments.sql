-- Add taxId field to users table
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "tax_id" varchar;

-- Create PIX payment status enum
DO $$ BEGIN
  CREATE TYPE "public"."pix_payment_status" AS ENUM('pending', 'paid', 'expired', 'failed');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Create PIX payments table
CREATE TABLE IF NOT EXISTS "pix_payments" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "external_id" serial NOT NULL,
  "user_id" varchar NOT NULL,
  "abacate_pay_id" varchar NOT NULL,
  "credit_amount" integer NOT NULL,
  "amount_cents" integer NOT NULL,
  "br_code" text,
  "br_code_base64" text,
  "status" "pix_payment_status" NOT NULL DEFAULT 'pending',
  "expires_at" timestamp,
  "paid_at" timestamp,
  "created_at" timestamp DEFAULT now()
);
