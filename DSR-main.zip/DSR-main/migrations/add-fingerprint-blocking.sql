-- Add blocked fields to user_credits
ALTER TABLE user_credits ADD COLUMN IF NOT EXISTS blocked boolean NOT NULL DEFAULT false;
ALTER TABLE user_credits ADD COLUMN IF NOT EXISTS block_reason text;

-- Create VPN confidence enum
DO $$ BEGIN
  CREATE TYPE vpn_confidence_score AS ENUM ('low', 'medium', 'high');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Create user_fingerprints table
CREATE TABLE IF NOT EXISTS user_fingerprints (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id varchar NOT NULL,
  fingerprint_id text NOT NULL,
  ip text,
  is_vpn boolean NOT NULL DEFAULT false,
  is_proxy boolean NOT NULL DEFAULT false,
  is_tor boolean NOT NULL DEFAULT false,
  vpn_confidence_score vpn_confidence_score DEFAULT 'low',
  vpn_suspected boolean NOT NULL DEFAULT false,
  affiliate_link text,
  created_at timestamp DEFAULT now(),
  updated_at timestamp DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_fingerprints_user_id ON user_fingerprints(user_id);
CREATE INDEX IF NOT EXISTS idx_user_fingerprints_fingerprint_id ON user_fingerprints(fingerprint_id);
