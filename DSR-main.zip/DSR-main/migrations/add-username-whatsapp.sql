-- Add username, whatsapp_country_code, whatsapp_number to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR UNIQUE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS whatsapp_country_code VARCHAR;
ALTER TABLE users ADD COLUMN IF NOT EXISTS whatsapp_number VARCHAR;
