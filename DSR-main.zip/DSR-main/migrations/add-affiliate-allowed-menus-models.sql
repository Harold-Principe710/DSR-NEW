ALTER TABLE affiliates ADD COLUMN IF NOT EXISTS allowed_menu_keys jsonb DEFAULT '[]'::jsonb;
ALTER TABLE affiliates ADD COLUMN IF NOT EXISTS allowed_model_ids jsonb DEFAULT '[]'::jsonb;
