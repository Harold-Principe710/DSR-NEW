-- Panel layout preference: "dev" (frozen Dev Mode) or "free" (evolving Estilo Livre)
ALTER TABLE "users"
ADD COLUMN IF NOT EXISTS "panel_layout" varchar DEFAULT 'free';
