-- Dashboard preference: hide/show Recent Media section
ALTER TABLE "users"
ADD COLUMN IF NOT EXISTS "recent_media_hidden" boolean;

-- Default behavior: hidden when missing/NULL.
-- We intentionally do NOT backfill existing rows to avoid heavy table rewrite.
