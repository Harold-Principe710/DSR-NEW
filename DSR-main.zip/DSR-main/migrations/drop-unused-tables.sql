-- ============================================================
-- Migration: drop-unused-tables.sql
-- Removes tables from old template that are no longer used.
-- !! Run this against your Supabase database !!
-- ============================================================

-- Drop video-related tables
DROP TABLE IF EXISTS "motion_controls" CASCADE;
DROP TABLE IF EXISTS "film_projects" CASCADE;
DROP TABLE IF EXISTS "flow_sessions" CASCADE;
DROP TABLE IF EXISTS "video_sessions" CASCADE;
DROP TABLE IF EXISTS "videos" CASCADE;

-- Drop audio-related tables
DROP TABLE IF EXISTS "lipsyncs" CASCADE;
DROP TABLE IF EXISTS "sound_effects" CASCADE;
DROP TABLE IF EXISTS "transcriptions" CASCADE;
DROP TABLE IF EXISTS "audios" CASCADE;

-- Drop image-editing tables
DROP TABLE IF EXISTS "image_edits" CASCADE;
DROP TABLE IF EXISTS "image_edit_sessions" CASCADE;
DROP TABLE IF EXISTS "extended_images" CASCADE;
DROP TABLE IF EXISTS "background_removals" CASCADE;
DROP TABLE IF EXISTS "image_sessions" CASCADE;

-- Drop unused enums
DO $$ BEGIN
  DROP TYPE IF EXISTS "video_format";
  DROP TYPE IF EXISTS "video_status";
  DROP TYPE IF EXISTS "audio_status";
  DROP TYPE IF EXISTS "lipsync_status";
  DROP TYPE IF EXISTS "ai_model";
  DROP TYPE IF EXISTS "sound_effect_status";
  DROP TYPE IF EXISTS "transcription_status";
  DROP TYPE IF EXISTS "background_removal_status";
  DROP TYPE IF EXISTS "motion_control_status";
  DROP TYPE IF EXISTS "motion_control_mode";
  DROP TYPE IF EXISTS "motion_control_orientation";
  DROP TYPE IF EXISTS "image_edit_status";
  DROP TYPE IF EXISTS "film_project_status";
  DROP TYPE IF EXISTS "film_model";
  DROP TYPE IF EXISTS "extended_image_status";
  DROP TYPE IF EXISTS "extended_image_aspect_ratio";
  DROP TYPE IF EXISTS "extended_image_mode";
EXCEPTION WHEN OTHERS THEN
  -- Ignore errors if types don't exist
  NULL;
END $$;
