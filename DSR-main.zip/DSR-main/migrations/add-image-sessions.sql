-- Image Sessions table (mirrors video_sessions)
CREATE TABLE IF NOT EXISTS image_sessions (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id VARCHAR NOT NULL,
  title TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Add session_id column to generated_images
ALTER TABLE generated_images ADD COLUMN IF NOT EXISTS session_id VARCHAR;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_image_sessions_user_id ON image_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_generated_images_session_id ON generated_images(session_id);
