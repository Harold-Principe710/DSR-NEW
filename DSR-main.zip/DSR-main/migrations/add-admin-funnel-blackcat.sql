DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'funnel_step') THEN
    CREATE TYPE funnel_step AS ENUM (
      'visitor_entered',
      'photo_uploaded',
      'generated_photo_viewed',
      'offer_viewed',
      'offer_responded',
      'video_loading_screen',
      'video_loaded',
      'pix_generated',
      'pix_paid'
    );
  END IF;
END
$$;

CREATE TABLE IF NOT EXISTS funnel_sessions (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id varchar NOT NULL UNIQUE,
  user_id varchar,
  current_step funnel_step NOT NULL DEFAULT 'visitor_entered',
  visitor_first_seen_at timestamp DEFAULT now(),
  visitor_last_seen_at timestamp DEFAULT now(),
  is_paid boolean NOT NULL DEFAULT false,
  paid_at timestamp,
  sale_amount_cents integer,
  sale_transaction_id text,
  sale_provider text,
  sale_event text,
  customer_name text,
  customer_email text,
  uploaded_photo_url text,
  generated_photo_url text,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  utm_content text,
  utm_term text,
  created_at timestamp DEFAULT now(),
  updated_at timestamp DEFAULT now()
);

CREATE TABLE IF NOT EXISTS funnel_events (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id varchar NOT NULL,
  user_id varchar,
  step funnel_step NOT NULL,
  event_name text NOT NULL,
  idempotency_key varchar,
  metadata json,
  occurred_at timestamp DEFAULT now(),
  created_at timestamp DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_funnel_events_idempotency_key
  ON funnel_events (idempotency_key)
  WHERE idempotency_key IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_funnel_events_session_id ON funnel_events (session_id);
CREATE INDEX IF NOT EXISTS idx_funnel_events_step ON funnel_events (step);
CREATE INDEX IF NOT EXISTS idx_funnel_events_occurred_at ON funnel_events (occurred_at);

CREATE TABLE IF NOT EXISTS blackcat_webhook_logs (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id varchar,
  event text,
  idempotency_key varchar NOT NULL UNIQUE,
  payload json,
  headers json,
  status text NOT NULL DEFAULT 'received',
  error_message text,
  processed_at timestamp,
  created_at timestamp DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_blackcat_logs_transaction_id ON blackcat_webhook_logs (transaction_id);
CREATE INDEX IF NOT EXISTS idx_blackcat_logs_created_at ON blackcat_webhook_logs (created_at);
