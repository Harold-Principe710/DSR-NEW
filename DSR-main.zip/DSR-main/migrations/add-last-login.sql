-- Add last_login to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login TIMESTAMP;
