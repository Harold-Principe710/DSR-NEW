-- Make funnel event idempotency scoped to session_id + idempotency_key.
-- This avoids global collisions across different users/sessions.
DROP INDEX IF EXISTS idx_funnel_events_idempotency_key;

CREATE UNIQUE INDEX IF NOT EXISTS idx_funnel_events_session_idempotency_key
  ON funnel_events (session_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;
