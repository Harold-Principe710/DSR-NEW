-- Create Video Sessions table
CREATE TABLE IF NOT EXISTS video_sessions (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id VARCHAR NOT NULL,
  title TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Add session_id column to videos table
ALTER TABLE videos ADD COLUMN IF NOT EXISTS session_id VARCHAR;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_video_sessions_user_id ON video_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_videos_session_id ON videos(session_id);
