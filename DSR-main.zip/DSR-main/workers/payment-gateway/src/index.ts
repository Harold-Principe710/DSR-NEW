type Env = {
  DB: D1Database;
  OUTBOX_QUEUE: Queue<OutboxMessage>;
  BLACKCAT_API_KEY: string;
  BLACKCAT_BASE_URL: string;
  BLACKCAT_WEBHOOK_SECRET?: string;
  WOOVI_APP_ID: string;
  WOOVI_BASE_URL: string;
  WOOVI_WEBHOOK_PUBLIC_KEY_BASE64: string;
  GATEWAY_PUBLIC_URL: string;
  DESIREAI_INTERNAL_URL: string;
  DESIREAI_INTERNAL_SECRET: string;
  GATEWAY_INTERNAL_SECRET: string;
  WEBHOOK_URL_TOKEN: string;
  UTMIFY_API_TOKEN: string;
  UTMIFY_ENDPOINT: string;
  PLATFORM_NAME: string;
};

type CreatePixRequest = {
  appPaymentId: string;
  externalReference?: string;
  provider?: string;
  amountCents: number;
  currency?: string;
  planId: string;
  productName: string;
  creditAmount?: number;
  sessionId?: string;
  userId?: string;
  journeyNode?: string | null;
  journeyPath?: string;
  abAssignments?: Record<string, string>;
  customer?: {
    name?: string | null;
    email?: string | null;
    phone?: string | null;
    document?: string | null;
    documentType?: "cpf" | "cnpj" | null;
    ip?: string | null;
  };
  tracking?: {
    src?: string | null;
    sck?: string | null;
    utm_source?: string | null;
    utm_campaign?: string | null;
    utm_medium?: string | null;
    utm_content?: string | null;
    utm_term?: string | null;
  };
  routingAssignment?: Record<string, unknown>;
};

type OutboxMessage = {
  outboxId: string;
};

type SupportedProvider = "blackcat" | "woovi";
type GatewayPaymentStatus = "paid" | "pending" | "failed" | "expired" | "cancelled" | "refunded" | "chargedback";

type GatewayRouteSelection = {
  provider: SupportedProvider;
  routingAssignment: Record<string, unknown>;
};

type NormalizedGatewayEvent = {
  event: string;
  providerPaymentId: string;
  externalRef: string;
  rawStatus: string;
  status: GatewayPaymentStatus;
  paidAt: string | null;
  occurredAt: string;
  amount: unknown;
  amountCents: number | null;
  idempotencyKey: string;
};

const APP_TIME_ZONE = "America/Sao_Paulo";

function json(data: unknown, init: ResponseInit = {}) {
  return new Response(JSON.stringify(data), {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init.headers || {}),
    },
  });
}

function nowIso() {
  return new Date().toISOString();
}

function uuid() {
  return crypto.randomUUID();
}

function normalizeEmail(value: unknown) {
  const email = String(value || "").trim();
  return email.includes("@") ? email : "nao_preenchido@desireai.local";
}

function normalizeString(value: unknown, fallback = "") {
  const text = String(value ?? "").trim();
  return text || fallback;
}

function onlyDigits(value: unknown) {
  return String(value ?? "").replace(/\D/g, "");
}

function normalizeRequiredEmail(value: unknown) {
  const email = normalizeEmail(value);
  return email === "nao_preenchido@desireai.local" ? "" : email;
}

function asRecord(value: unknown): Record<string, any> | null {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, any> : null;
}

function firstRecord(...values: unknown[]) {
  for (const value of values) {
    const record = asRecord(value);
    if (record) return record;
  }
  return {};
}

function firstString(...values: unknown[]) {
  for (const value of values) {
    const text = String(value ?? "").trim();
    if (text) return text;
  }
  return "";
}

function normalizeLookupKey(key: string) {
  return key.toLowerCase().replace(/[^a-z0-9]/g, "");
}

function normalizePixCopyPaste(value: unknown) {
  if (typeof value !== "string") return "";
  const trimmed = value.trim();
  const pixStart = trimmed.indexOf("000201");
  const candidate = pixStart >= 0 ? trimmed.slice(pixStart) : trimmed;
  const terminatorIndex = candidate.search(/["'<>\\{}]/);
  const clean = (terminatorIndex > 0 ? candidate.slice(0, terminatorIndex) : candidate).replace(/[\r\n]/g, "");
  if (!clean) return "";
  const lower = clean.toLowerCase();
  const looksLikePixEmv = clean.startsWith("000201") && lower.includes("br.gov.bcb.pix");
  return looksLikePixEmv && clean.length >= 60 ? clean : "";
}

function firstPixCopyPaste(...values: unknown[]) {
  for (const value of values) {
    const pixCode = normalizePixCopyPaste(value);
    if (pixCode) return pixCode;
  }
  return "";
}

const PIX_COPY_PASTE_KEYS = new Set([
  "brcode",
  "code",
  "copypaste",
  "emv",
  "emvqrcode",
  "pixbrcode",
  "pixcode",
  "pixcopypaste",
  "qrcode",
  "qrcodepix",
  "qrcodetext",
]);

function findPixCopyPaste(value: unknown, depth = 0): string {
  if (depth > 6 || value === null || value === undefined) return "";
  const direct = normalizePixCopyPaste(value);
  if (direct) return direct;

  if (Array.isArray(value)) {
    for (const item of value.slice(0, 20)) {
      const found = findPixCopyPaste(item, depth + 1);
      if (found) return found;
    }
    return "";
  }

  if (typeof value !== "object") return "";
  const record = value as Record<string, unknown>;
  for (const [key, nestedValue] of Object.entries(record)) {
    if (!PIX_COPY_PASTE_KEYS.has(normalizeLookupKey(key))) continue;
    const found = normalizePixCopyPaste(nestedValue);
    if (found) return found;
  }

  for (const nestedValue of Object.values(record)) {
    const found = findPixCopyPaste(nestedValue, depth + 1);
    if (found) return found;
  }
  return "";
}

function firstNumber(...values: unknown[]) {
  for (const value of values) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value === "string" && value.trim()) {
      const parsed = Number(value.replace(",", "."));
      if (Number.isFinite(parsed)) return parsed;
    }
  }
  return null;
}

function normalizeAmountCents(...values: unknown[]) {
  const amount = firstNumber(...values);
  if (amount === null) return null;
  if (Math.abs(amount) < 1000 && !Number.isInteger(amount)) {
    return Math.round(amount * 100);
  }
  return Math.round(amount);
}

function parseJsonRecord(value: unknown) {
  if (asRecord(value)) return value as Record<string, any>;
  if (typeof value !== "string" || !value.trim()) return {};
  try {
    return asRecord(JSON.parse(value)) || {};
  } catch {
    return {};
  }
}

function isSupportedProvider(value: unknown): value is SupportedProvider {
  return value === "blackcat" || value === "woovi";
}

function normalizeProvider(value: unknown): SupportedProvider | null {
  const provider = String(value ?? "").trim().toLowerCase();
  return isSupportedProvider(provider) ? provider : null;
}

function isProviderConfigured(env: Env, provider: SupportedProvider) {
  if (provider === "blackcat") return Boolean(normalizeString(env.BLACKCAT_API_KEY));
  if (provider === "woovi") {
    return Boolean(normalizeString(env.WOOVI_APP_ID) && normalizeString(env.WOOVI_WEBHOOK_PUBLIC_KEY_BASE64));
  }
  return false;
}

function isTerminalGatewayStatus(status: GatewayPaymentStatus) {
  return status === "paid" || status === "refunded" || status === "chargedback";
}

function getBlackcatResponseShape(data: unknown) {
  const root = asRecord(data);
  const inner = firstRecord(root?.data, root?.transaction, root?.sale, root?.result);
  const paymentData = firstRecord(inner.paymentData, inner.pix, root?.paymentData, root?.pix);

  return {
    rootKeys: root ? Object.keys(root).slice(0, 12) : [],
    dataKeys: Object.keys(inner).slice(0, 12),
    paymentDataKeys: Object.keys(paymentData).slice(0, 12),
  };
}

function getWooviResponseShape(data: unknown) {
  const root = asRecord(data);
  const charge = firstRecord(root?.charge, root?.data?.charge, root?.pix?.charge);

  return {
    rootKeys: root ? Object.keys(root).slice(0, 12) : [],
    chargeKeys: Object.keys(charge).slice(0, 12),
  };
}

function extractBlackcatPixResult(data: unknown) {
  const root = asRecord(data) || {};
  const sale = firstRecord(root.data, root.transaction, root.sale, root.result, root);
  const paymentData = firstRecord(sale.paymentData, sale.pix, root.paymentData, root.pix);
  const gatewayPaymentId = firstString(
    sale.transactionId,
    sale.id,
    sale.saleId,
    sale.paymentId,
    sale.gatewayPaymentId,
    root.transactionId,
    root.id,
    root.saleId,
  );
  const qrcode = firstPixCopyPaste(
    paymentData.copyPaste,
    paymentData.qrCode,
    paymentData.qrcode,
    paymentData.brCode,
    paymentData.pixCode,
    paymentData.code,
    paymentData.emv,
    sale.copyPaste,
    sale.qrCode,
    sale.qrcode,
    sale.brCode,
    sale.pixCode,
    sale.code,
    sale.emv,
    root.copyPaste,
    root.qrCode,
    root.qrcode,
    root.brCode,
    root.pixCode,
    root.code,
    root.emv,
    findPixCopyPaste(data),
  );
  const expiresAt = firstString(paymentData.expiresAt, sale.expiresAt, root.expiresAt) || null;

  return { gatewayPaymentId, qrcode, expiresAt };
}

function extractWooviPixResult(data: unknown) {
  const root = asRecord(data) || {};
  const charge = firstRecord(root.charge, root.data?.charge, root.pix?.charge, root);
  const pix = firstRecord(root.pix, root.data?.pix);
  const gatewayPaymentId = firstString(
    charge.transactionID,
    pix.transactionID,
    charge.identifier,
    charge.paymentLinkID,
    root.transactionID,
    root.identifier,
    root.paymentLinkID,
    charge.correlationID,
    root.correlationID,
  );
  const qrcode = firstPixCopyPaste(
    root.brCode,
    charge.brCode,
    pix.brCode,
    root.qrCode,
    charge.qrCode,
    pix.qrCode,
    root.pixCode,
    charge.pixCode,
    pix.pixCode,
    root.code,
    charge.code,
    pix.code,
    root.copyPaste,
    charge.copyPaste,
    pix.copyPaste,
    findPixCopyPaste(data),
  );
  const expiresAt = firstString(charge.expiresDate, charge.expiresAt, root.expiresDate, root.expiresAt) || null;

  return { gatewayPaymentId, qrcode, expiresAt };
}

function getD1Changes(result: D1Result) {
  return Number((result.meta as { changes?: number } | undefined)?.changes || 0);
}

function normalizeGatewayStatus(rawStatus: string, event: string): GatewayPaymentStatus {
  const statusUpper = rawStatus.toUpperCase();
  const eventUpper = event.toUpperCase();
  const text = `${statusUpper} ${eventUpper}`;

  if (text.includes("CHARGEBACK") || text.includes("CHARGED_BACK")) return "chargedback";
  if (text.includes("REFUND") || text.includes("REFUNDED") || text.includes("ESTORN") || text.includes("REEMBOLS")) return "refunded";
  if (
    eventUpper === "TRANSACTION.PAID"
    || eventUpper.includes("CHARGE_COMPLETED")
    || text.includes(" PAID")
    || statusUpper === "PAID"
    || statusUpper === "APPROVED"
    || statusUpper === "COMPLETED"
    || text.includes(" APROV")
    || text.includes(" PAGO")
    || text.includes(" PAGA")
  ) return "paid";
  if (text.includes("FAILED") || text.includes("REFUSED") || text.includes("DECLINED") || text.includes("REJECTED") || text.includes(" FALH")) return "failed";
  if (text.includes("EXPIRED") || text.includes("EXPIR")) return "expired";
  if (text.includes("CANCELLED") || text.includes("CANCELED") || text.includes("CANCEL")) return "cancelled";
  return "pending";
}

function normalizeBlackcatEvent(body: Record<string, any>, headerEvent?: string | null): NormalizedGatewayEvent {
  const webhookData = firstRecord(body.data, body.transaction, body.sale, body);
  const rawStatus = firstString(webhookData.status, body.status).toUpperCase();
  const event = firstString(headerEvent, body.event, webhookData.event)
    || (rawStatus === "PAID" ? "transaction.paid" : "transaction.created");
  const providerPaymentId = firstString(webhookData.transactionId, webhookData.id, webhookData.saleId, body.transactionId, body.id);
  const externalRef = firstString(webhookData.externalReference, webhookData.externalRef, body.externalReference, body.externalRef);
  const status = normalizeGatewayStatus(rawStatus, event);
  const paidAt = firstString(webhookData.paidAt, body.paidAt, webhookData.approvedDate, body.approvedDate)
    || (status === "paid" ? nowIso() : null);
  const occurredAt = firstString(
    webhookData.refundedAt,
    body.refundedAt,
    webhookData.refundAt,
    body.refundAt,
    webhookData.chargebackAt,
    body.chargebackAt,
    webhookData.updatedAt,
    body.updatedAt,
    webhookData.paidAt,
    body.paidAt,
    body.timestamp,
    webhookData.timestamp,
  ) || nowIso();
  const idempotencySubject = providerPaymentId || externalRef || "missing-provider-payment-id";
  const eventInstance = firstString(
    body.eventId,
    body.webhookId,
    webhookData.eventId,
    webhookData.webhookId,
    body.timestamp,
    webhookData.timestamp,
    webhookData.paidAt,
    body.paidAt,
    status,
  );
  const amount = webhookData.amount ?? body.amount ?? webhookData.total ?? body.total ?? null;

  return {
    event,
    providerPaymentId,
    externalRef,
    rawStatus,
    status,
    paidAt,
    occurredAt,
    amount,
    amountCents: normalizeAmountCents(amount),
    idempotencyKey: `blackcat:${event}:${idempotencySubject}:${eventInstance}`,
  };
}

function normalizeWooviEvent(body: Record<string, any>, headerEvent?: string | null): NormalizedGatewayEvent {
  const charge = firstRecord(body.charge, body.data?.charge, body.pix?.charge, body);
  const pix = firstRecord(body.pix, body.data?.pix);
  const rawStatus = firstString(charge.status, body.status).toUpperCase();
  const event = firstString(headerEvent, body.event, body.evento, body.type)
    || (rawStatus === "COMPLETED" ? "OPENPIX:CHARGE_COMPLETED" : "OPENPIX:CHARGE_CREATED");
  const providerPaymentId = firstString(
    charge.transactionID,
    pix.transactionID,
    charge.identifier,
    charge.paymentLinkID,
    body.transactionID,
  );
  const externalRef = firstString(charge.correlationID, body.correlationID, pix.charge?.correlationID);
  const status = normalizeGatewayStatus(rawStatus, event);
  const paidAt = firstString(pix.time, charge.paidAt, status === "paid" ? charge.updatedAt : null) || (status === "paid" ? nowIso() : null);
  const occurredAt = firstString(
    charge.refundedAt,
    body.refundedAt,
    pix.time,
    charge.updatedAt,
    body.updatedAt,
    body.createdAt,
    charge.createdAt,
    body.data_criacao,
  ) || nowIso();
  const idempotencySubject = providerPaymentId || externalRef || "missing-provider-payment-id";
  const eventInstance = firstString(
    body.eventId,
    body.webhookId,
    body.id,
    charge.globalID,
    pix.endToEndId,
    pix.time,
    charge.updatedAt,
    body.data_criacao,
    status,
  );
  const amount = charge.value ?? pix.value ?? body.value ?? charge.amount ?? pix.amount ?? body.amount ?? null;

  return {
    event,
    providerPaymentId,
    externalRef,
    rawStatus,
    status,
    paidAt,
    occurredAt,
    amount,
    amountCents: normalizeAmountCents(amount),
    idempotencyKey: `woovi:${event}:${idempotencySubject}:${eventInstance}`,
  };
}

function toProviderStatus(status: GatewayPaymentStatus, rawStatus: string) {
  if (status === "paid") return "PAID";
  if (status === "failed") return "FAILED";
  if (status === "expired") return "EXPIRED";
  if (status === "cancelled") return "CANCELLED";
  if (status === "refunded") return "REFUNDED";
  if (status === "chargedback") return "CHARGEDBACK";
  return rawStatus || "PENDING";
}

async function fetchWithTimeout(input: string, init: RequestInit, timeoutMs: number) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } catch (error: any) {
    if (error?.name === "AbortError") {
      throw new Error(`Timeout after ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

function assertInternalAuth(request: Request, env: Env) {
  const auth = request.headers.get("authorization") || "";
  return auth === `Bearer ${env.GATEWAY_INTERNAL_SECRET}`;
}

async function fetchGatewayConfig(env: Env) {
  const desireAiUrl = normalizeString(env.DESIREAI_INTERNAL_URL).replace(/\/+$/, "");
  const desireAiSecret = normalizeString(env.DESIREAI_INTERNAL_SECRET);
  if (!desireAiUrl || !desireAiSecret) {
    throw new Error("DESIREAI_INTERNAL_URL/DESIREAI_INTERNAL_SECRET não configurados para seleção de gateway");
  }

  const response = await fetchWithTimeout(`${desireAiUrl}/api/internal/payment-gateway-config`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${desireAiSecret}`,
    },
  }, 4_000);
  const text = await response.text();
  let data: unknown = {};
  try {
    data = text.trim() ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (!response.ok) {
    throw new Error(`Configuração de gateways HTTP ${response.status}: ${text.slice(0, 180)}`);
  }
  return asRecord(data) || {};
}

function numberOrZero(value: unknown) {
  const parsed = firstNumber(value);
  return parsed && parsed > 0 ? parsed : 0;
}

function pickWeighted<T extends { weight: number }>(items: T[]) {
  const total = items.reduce((sum, item) => sum + item.weight, 0);
  if (total <= 0) return null;
  let cursor = Math.random() * total;
  for (const item of items) {
    cursor -= item.weight;
    if (cursor <= 0) return item;
  }
  return items[items.length - 1] || null;
}

function selectRouteFromGatewayConfig(env: Env, config: Record<string, any>): GatewayRouteSelection {
  const selectedAt = nowIso();
  const activeTest = asRecord(config.activeTest);
  const rawVariants = activeTest && Array.isArray(activeTest.variants) ? activeTest.variants : [];
  const variants = rawVariants
    .map((value) => asRecord(value))
    .filter(Boolean)
    .map((variant) => {
      const gateway = firstRecord(variant?.gateway);
      const provider = normalizeProvider(gateway.provider);
      return provider && isProviderConfigured(env, provider)
        ? { variant, gateway, provider, weight: numberOrZero(variant?.weight) }
        : null;
    })
    .filter((item): item is { variant: Record<string, any>; gateway: Record<string, any>; provider: SupportedProvider; weight: number } => (
      Boolean(item && item.weight > 0)
    ));

  const selectedVariant = pickWeighted(variants);
  if (selectedVariant) {
    return {
      provider: selectedVariant.provider,
      routingAssignment: {
        source: "desireai-config",
        selectedAt,
        provider: selectedVariant.provider,
        testId: firstString(selectedVariant.variant.testId, activeTest?.id),
        testSlug: firstString(activeTest?.slug),
        testName: firstString(activeTest?.name),
        variantId: firstString(selectedVariant.variant.id),
        variantName: firstString(selectedVariant.variant.name),
        gatewayId: firstString(selectedVariant.gateway.id, selectedVariant.variant.gatewayId),
        gatewaySlug: firstString(selectedVariant.gateway.slug),
        gatewayName: firstString(selectedVariant.gateway.name),
        weight: selectedVariant.weight,
      },
    };
  }

  const rawGateways = Array.isArray(config.gateways) ? config.gateways : [];
  const gateway = rawGateways
    .map((value) => asRecord(value))
    .find((value) => {
      const provider = normalizeProvider(value?.provider);
      return provider ? isProviderConfigured(env, provider) : false;
    });
  const provider = normalizeProvider(gateway?.provider);
  if (gateway && provider) {
    return {
      provider,
      routingAssignment: {
        source: "desireai-config",
        selectedAt,
        provider,
        gatewayId: firstString(gateway.id),
        gatewaySlug: firstString(gateway.slug),
        gatewayName: firstString(gateway.name),
      },
    };
  }

  throw new Error("Nenhum gateway ativo compatível e configurado foi retornado pela DesireAI");
}

async function resolveGatewayRoute(env: Env, payload: CreatePixRequest): Promise<GatewayRouteSelection> {
  const requestedProvider = normalizeProvider(payload.provider);
  if (requestedProvider) {
    if (!isProviderConfigured(env, requestedProvider)) {
      throw new Error(`Provider ${requestedProvider} selecionado, mas secrets obrigatórios não estão configurados no Worker`);
    }
    return {
      provider: requestedProvider,
      routingAssignment: {
        ...parseJsonRecord(payload.routingAssignment),
        source: "worker-request",
        selectedAt: nowIso(),
        provider: requestedProvider,
      },
    };
  }

  const config = await fetchGatewayConfig(env);
  return selectRouteFromGatewayConfig(env, config);
}

async function signInternalPayload(payload: string, env: Env) {
  const timestamp = String(Math.floor(Date.now() / 1000));
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(env.DESIREAI_INTERNAL_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signatureBuffer = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(`${timestamp}.${payload}`),
  );
  const signature = Array.from(new Uint8Array(signatureBuffer))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
  return { timestamp, signature };
}

function base64ToBytes(value: string) {
  const clean = value.replace(/\s/g, "");
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}

async function verifyWooviWebhookSignature(rawBody: string, signature: string, publicKeyBase64: string) {
  const publicKeyPem = new TextDecoder().decode(base64ToBytes(publicKeyBase64));
  const publicKeyDer = base64ToBytes(
    publicKeyPem
      .replace(/-----BEGIN PUBLIC KEY-----/g, "")
      .replace(/-----END PUBLIC KEY-----/g, "")
      .replace(/\s/g, ""),
  );
  const key = await crypto.subtle.importKey(
    "spki",
    publicKeyDer,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["verify"],
  );

  return await crypto.subtle.verify(
    "RSASSA-PKCS1-v1_5",
    key,
    base64ToBytes(signature),
    new TextEncoder().encode(rawBody),
  );
}

function timingSafeStringEqual(left: string, right: string) {
  const maxLength = Math.max(left.length, right.length);
  let diff = left.length ^ right.length;
  for (let index = 0; index < maxLength; index += 1) {
    diff |= (left.charCodeAt(index) || 0) ^ (right.charCodeAt(index) || 0);
  }
  return diff === 0;
}

function normalizeSignatureCandidates(signatureHeader: string) {
  return signatureHeader
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean)
    .flatMap((part) => {
      const [, value] = part.includes("=") ? part.split("=", 2) : ["", part];
      return [part, value].map((candidate) => candidate.trim()).filter(Boolean);
    });
}

async function verifyHmacSha256Signature(rawBody: string, signatureHeader: string, secret: string) {
  const cleanSecret = normalizeString(secret);
  const cleanHeader = normalizeString(signatureHeader);
  if (!cleanSecret || !cleanHeader) return false;

  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(cleanSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signatureBuffer = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(rawBody));
  const bytes = new Uint8Array(signatureBuffer);
  const expectedHex = Array.from(bytes).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  let expectedBase64 = "";
  for (const byte of bytes) expectedBase64 += String.fromCharCode(byte);
  expectedBase64 = btoa(expectedBase64);

  return normalizeSignatureCandidates(cleanHeader).some((candidate) => (
    timingSafeStringEqual(candidate.toLowerCase(), expectedHex)
    || timingSafeStringEqual(candidate, expectedBase64)
    || timingSafeStringEqual(candidate, `sha256=${expectedHex}`)
  ));
}

function getWebhookSignatureHeader(request: Request) {
  return firstString(
    request.headers.get("x-webhook-signature"),
    request.headers.get("x-signature"),
    request.headers.get("x-blackcat-signature"),
    request.headers.get("x-blackcat-webhook-signature"),
  );
}

function formatDateInAppTimeZone(date: Date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: APP_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(date);
  const read = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value || "00";
  const hour = read("hour") === "24" ? "00" : read("hour");

  return `${read("year")}-${read("month")}-${read("day")} ${hour}:${read("minute")}:${read("second")}`;
}

function toUtmifyDate(value?: string | null) {
  const date = value ? new Date(value) : new Date();
  const valid = Number.isNaN(date.getTime()) ? new Date() : date;
  return formatDateInAppTimeZone(valid);
}

function mapUtmifyStatus(status: string) {
  const normalized = status.toLowerCase();
  if (normalized === "paid") return "paid";
  if (normalized === "refunded") return "refunded";
  if (normalized === "chargedback") return "chargedback";
  if (normalized === "failed" || normalized === "refused" || normalized === "expired" || normalized === "cancelled") return "refused";
  return "waiting_payment";
}

const CREATE_IN_PROGRESS_STALE_MS = 90 * 1000;

function parseTimestampMs(value: unknown) {
  const parsed = new Date(String(value || "")).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
}

function isCreateInProgressStale(payment: Record<string, any>) {
  const updatedAtMs = parseTimestampMs(payment.updated_at || payment.created_at);
  return !updatedAtMs || Date.now() - updatedAtMs > CREATE_IN_PROGRESS_STALE_MS;
}

function buildCreatePixResponseFromPayment(payment: Record<string, any>) {
  const provider = normalizeProvider(payment.provider) || "blackcat";
  const responsePayload = parseJsonRecord(payment.response_json);
  const pixResult = provider === "woovi"
    ? extractWooviPixResult(responsePayload)
    : extractBlackcatPixResult(responsePayload);
  return {
    success: Boolean(payment.provider_payment_id && pixResult.qrcode),
    gatewayPaymentId: payment.provider_payment_id,
    provider,
    status: payment.status,
    pix: {
      qrcode: pixResult.qrcode,
      copyPaste: pixResult.qrcode,
      brCode: pixResult.qrcode,
      expiresAt: pixResult.expiresAt,
    },
    qrcode: pixResult.qrcode,
    copyPaste: pixResult.qrcode,
    brCode: pixResult.qrcode,
    routingAssignment: parseJsonRecord(payment.routing_json),
  };
}

function buildUtmifyPayload(payment: Record<string, any>, status: string, occurredAt?: string | null) {
  const customer = JSON.parse(String(payment.customer_json || "{}"));
  const tracking = JSON.parse(String(payment.tracking_json || "{}"));
  const amountCents = Number(payment.amount_cents || 0);
  const createdAt = String(payment.created_at);
  const utmifyStatus = mapUtmifyStatus(status);
  const isPaidStatus = utmifyStatus === "paid" || utmifyStatus === "refunded" || utmifyStatus === "chargedback";
  const paidAt = isPaidStatus ? String(payment.paid_at || (utmifyStatus === "paid" ? occurredAt || nowIso() : "")) : "";
  const statusChangedAt = occurredAt || nowIso();
  return {
    orderId: String(payment.app_payment_id),
    platform: "DesireAI",
    paymentMethod: "pix",
    status: utmifyStatus,
    createdAt: toUtmifyDate(createdAt),
    approvedDate: paidAt ? toUtmifyDate(paidAt) : null,
    refundedAt: utmifyStatus === "refunded" || utmifyStatus === "chargedback" ? toUtmifyDate(statusChangedAt) : null,
    customer: {
      name: normalizeString(customer.name, "Cliente"),
      email: normalizeEmail(customer.email),
      phone: customer.phone ?? null,
      document: customer.document ?? null,
      country: "BR",
      ip: customer.ip ?? null,
    },
    products: [
      {
        id: String(payment.plan_id || "pix"),
        name: String(payment.product_name || payment.plan_id || "PIX"),
        planId: payment.plan_id ?? null,
        planName: payment.product_name ?? null,
        quantity: 1,
        priceInCents: amountCents,
      },
    ],
    trackingParameters: {
      src: tracking.src ?? null,
      sck: tracking.sck ?? null,
      utm_source: tracking.utm_source ?? null,
      utm_campaign: tracking.utm_campaign ?? null,
      utm_medium: tracking.utm_medium ?? null,
      utm_content: tracking.utm_content ?? null,
      utm_term: tracking.utm_term ?? null,
    },
    commission: {
      totalPriceInCents: amountCents,
      gatewayFeeInCents: 0,
      userCommissionInCents: amountCents,
      currency: payment.currency || "BRL",
    },
    isTest: false,
  };
}

async function enqueueOutbox(env: Env, target: "desireai" | "utmify", appPaymentId: string, status: string, payload: unknown) {
  const id = uuid();
  const idempotencyKey = `${target}:${appPaymentId}:${status}`;
  const now = nowIso();
  await env.DB.prepare(
    `insert or ignore into outbox (id, target, idempotency_key, app_payment_id, status, payload_json, next_attempt_at, created_at)
     values (?, ?, ?, ?, 'pending', ?, ?, ?)`,
  )
    .bind(id, target, idempotencyKey, appPaymentId, JSON.stringify(payload), now, now)
    .run();
  const row = await env.DB.prepare("select id from outbox where idempotency_key = ?").bind(idempotencyKey).first<{ id: string }>();
  if (row?.id) await env.OUTBOX_QUEUE.send({ outboxId: row.id });
}

async function findPaymentForProviderEvent(env: Env, provider: string, providerPaymentId: string, externalRef?: string | null) {
  if (providerPaymentId) {
    const payment = await env.DB.prepare("select * from payments where provider = ? and provider_payment_id = ?")
      .bind(provider, providerPaymentId)
      .first<Record<string, any>>();
    if (payment) return payment;
  }

  // Legacy fallback only. New tracking must work without external_ref because
  // not every gateway supports echoing it back in webhooks.
  if (externalRef) {
    return await env.DB.prepare("select * from payments where provider = ? and (external_ref = ? or app_payment_id = ?)")
      .bind(provider, externalRef, externalRef)
      .first<Record<string, any>>();
  }

  return null;
}

function getTerminalGatewayEventAmountError(payment: Record<string, any>, normalized: NormalizedGatewayEvent) {
  if (!isTerminalGatewayStatus(normalized.status)) return null;
  const expectedProviderPaymentId = firstString(payment.provider_payment_id);
  if (!normalized.providerPaymentId) {
    return "Evento terminal do gateway sem providerPaymentId";
  }
  if (expectedProviderPaymentId && normalized.providerPaymentId !== expectedProviderPaymentId) {
    return `providerPaymentId terminal (${normalized.providerPaymentId}) diverge do pagamento (${expectedProviderPaymentId})`;
  }
  if (normalized.amountCents === null || !Number.isFinite(normalized.amountCents)) {
    return "Evento terminal do gateway sem amountCents confiável";
  }
  const expectedAmount = Number(payment.amount_cents);
  if (!Number.isFinite(expectedAmount) || normalized.amountCents !== expectedAmount) {
    return `Valor do evento terminal (${normalized.amountCents}) diverge do pagamento (${expectedAmount})`;
  }
  return null;
}

async function markPaymentEventRejected(env: Env, eventRowId: string, message: string) {
  if (!eventRowId) return;
  await env.DB.prepare("update payment_events set processed_at = ?, error_message = ? where id = ?")
    .bind(nowIso(), message, eventRowId)
    .run();
}

function buildDesireAiOutboxPayload(
  provider: SupportedProvider,
  freshPayment: Record<string, any>,
  normalized: NormalizedGatewayEvent,
  body: Record<string, any>,
) {
  const routingAssignment = parseJsonRecord(freshPayment.routing_json);
  const responsePayload = parseJsonRecord(freshPayment.response_json);
  const pixResult = provider === "woovi"
    ? extractWooviPixResult(responsePayload)
    : extractBlackcatPixResult(responsePayload);
  const pixPayload = pixResult.qrcode
    ? {
      qrcode: pixResult.qrcode,
      copyPaste: pixResult.qrcode,
      brCode: pixResult.qrcode,
      expiresAt: pixResult.expiresAt,
    }
    : null;
  return {
    appPaymentId: freshPayment.app_payment_id,
    provider,
    gatewayProvider: provider,
    gateway: {
      id: firstString(routingAssignment.gatewayId),
      slug: firstString(routingAssignment.gatewaySlug),
      name: firstString(routingAssignment.gatewayName),
      provider,
    },
    gatewayId: firstString(routingAssignment.gatewayId),
    gatewaySlug: firstString(routingAssignment.gatewaySlug),
    testId: firstString(routingAssignment.testId),
    variantId: firstString(routingAssignment.variantId),
    routingAssignment,
    event: normalized.event,
    status: toProviderStatus(freshPayment.status as GatewayPaymentStatus, normalized.rawStatus),
    transactionId: normalized.providerPaymentId,
    externalReference: normalized.externalRef,
    amount: normalized.amount,
    amountCents: normalized.amountCents,
    paidAt: normalized.paidAt,
    occurredAt: normalized.occurredAt,
    ...(pixPayload ? {
      pix: pixPayload,
      qrcode: pixPayload.qrcode,
      copyPaste: pixPayload.copyPaste,
      brCode: pixPayload.brCode,
    } : {}),
    raw: body,
  };
}

async function applyGatewayEventToPayment(
  env: Env,
  provider: SupportedProvider,
  payment: Record<string, any>,
  normalized: NormalizedGatewayEvent,
  body: Record<string, any>,
) {
  const terminalAmountError = getTerminalGatewayEventAmountError(payment, normalized);
  if (terminalAmountError) {
    throw new Error(terminalAmountError);
  }

  await env.DB.prepare(
    `update payments
     set status = case
         when status in ('refunded', 'chargedback') then status
         when ? in ('refunded', 'chargedback') then ?
         when status = 'paid' and ? in ('pending', 'failed', 'expired', 'cancelled') then status
         when ? = 'paid' then 'paid'
         else ?
       end,
       paid_at = case
         when ? in ('paid', 'refunded', 'chargedback') then coalesce(paid_at, ?)
         else paid_at
       end,
       updated_at = ?
     where app_payment_id = ?`,
  )
    .bind(
      normalized.status,
      normalized.status,
      normalized.status,
      normalized.status,
      normalized.status,
      normalized.status,
      normalized.paidAt,
      nowIso(),
      payment.app_payment_id,
    )
    .run();

  const freshPayment = await env.DB.prepare("select * from payments where app_payment_id = ?")
    .bind(payment.app_payment_id)
    .first<Record<string, any>>();
  if (!freshPayment) return;

  const effectiveStatus = String(freshPayment.status || normalized.status);
  const staleAfterPaid = effectiveStatus === "paid" && normalized.status !== "paid";
  const staleAfterReversal = (effectiveStatus === "refunded" || effectiveStatus === "chargedback") && normalized.status !== effectiveStatus;
  if (staleAfterPaid || staleAfterReversal) return;

  await enqueueOutbox(
    env,
    "desireai",
    freshPayment.app_payment_id,
    effectiveStatus,
    buildDesireAiOutboxPayload(provider, freshPayment, normalized, body),
  );
  const utmifyStatus = mapUtmifyStatus(effectiveStatus);
  await enqueueOutbox(
    env,
    "utmify",
    freshPayment.app_payment_id,
    utmifyStatus,
    buildUtmifyPayload(freshPayment, effectiveStatus, normalized.occurredAt),
  );
}

async function reconcileUnmatchedGatewayEvents(env: Env, provider: SupportedProvider, providerPaymentId: string, appPaymentId: string) {
  if (!providerPaymentId || !appPaymentId) return;

  const events = await env.DB.prepare(
    `select * from payment_events
     where provider = ?
       and provider_payment_id = ?
       and app_payment_id is null
     order by received_at asc
     limit 25`,
  )
    .bind(provider, providerPaymentId)
    .all<Record<string, any>>();

  const payment = await env.DB.prepare("select * from payments where app_payment_id = ?")
    .bind(appPaymentId)
    .first<Record<string, any>>();
  if (!payment) return;

  for (const eventRow of events.results || []) {
    await env.DB.prepare("update payment_events set app_payment_id = ? where id = ?")
      .bind(appPaymentId, eventRow.id)
      .run();

    let eventBody: Record<string, any> = {};
    try {
      eventBody = JSON.parse(String(eventRow.payload_json || "{}"));
    } catch {
      eventBody = {};
    }
    const normalized = provider === "woovi"
      ? normalizeWooviEvent(eventBody, eventRow.event)
      : normalizeBlackcatEvent(eventBody, eventRow.event);
    const terminalAmountError = getTerminalGatewayEventAmountError(payment, normalized);
    if (terminalAmountError) {
      await markPaymentEventRejected(env, String(eventRow.id || ""), terminalAmountError);
      continue;
    }
    await applyGatewayEventToPayment(env, provider, payment, normalized, eventBody);
  }
}

async function createBlackcatPix(env: Env, payload: CreatePixRequest, externalRef: string) {
  const gatewayPublicUrl = normalizeString(env.GATEWAY_PUBLIC_URL).replace(/\/+$/, "");
  if (!gatewayPublicUrl) throw new Error("GATEWAY_PUBLIC_URL não configurado");

  const webhookUrl = `${gatewayPublicUrl}/v1/webhooks/blackcat?token=${encodeURIComponent(env.WEBHOOK_URL_TOKEN)}`;
  const customerName = normalizeString(payload.customer?.name);
  const customerEmail = normalizeRequiredEmail(payload.customer?.email);
  const customerPhone = onlyDigits(payload.customer?.phone);
  const customerDocument = onlyDigits(payload.customer?.document);
  if (!customerName || !customerEmail || !customerPhone || !customerDocument) {
    throw new Error("Dados do cliente são obrigatórios");
  }

  const blackcatPayload = {
    amount: payload.amountCents,
    currency: payload.currency || "BRL",
    paymentMethod: "pix",
    externalRef,
    postbackUrl: webhookUrl,
    items: [
      {
        title: payload.productName,
        unitPrice: payload.amountCents,
        quantity: 1,
        tangible: false,
      },
    ],
    customer: {
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      document: {
        number: customerDocument,
        type: payload.customer?.documentType || (customerDocument.length > 11 ? "cnpj" : "cpf"),
      },
    },
    pix: { expiresInDays: 1 },
    utm_source: payload.tracking?.utm_source || undefined,
    utm_medium: payload.tracking?.utm_medium || undefined,
    utm_campaign: payload.tracking?.utm_campaign || undefined,
    utm_content: payload.tracking?.utm_content || undefined,
    utm_term: payload.tracking?.utm_term || undefined,
  };

  const response = await fetchWithTimeout(`${env.BLACKCAT_BASE_URL.replace(/\/+$/, "")}/sales/create-sale`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-API-Key": env.BLACKCAT_API_KEY,
    },
    body: JSON.stringify({ ...blackcatPayload, postbackUrl: webhookUrl }),
  }, 12_000);
  const text = await response.text();
  let data: any = {};
  try {
    data = text.trim() ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (!response.ok) {
    throw new Error(data?.message || `BlackCat HTTP ${response.status}`);
  }
  return { data, request: { ...blackcatPayload, postbackUrl: webhookUrl } };
}

async function createWooviPix(env: Env, payload: CreatePixRequest, externalRef: string) {
  const customerName = normalizeString(payload.customer?.name);
  const customerEmail = normalizeRequiredEmail(payload.customer?.email);
  const customerPhone = onlyDigits(payload.customer?.phone);
  const customerDocument = onlyDigits(payload.customer?.document);
  if (!customerName || !customerEmail || !customerPhone || !customerDocument) {
    throw new Error("Dados do cliente são obrigatórios");
  }

  const baseUrl = normalizeString(env.WOOVI_BASE_URL, "https://api.woovi.com/api/v1").replace(/\/+$/, "");
  const appId = normalizeString(env.WOOVI_APP_ID);
  if (!appId) throw new Error("WOOVI_APP_ID não configurado");

  const wooviPayload = {
    correlationID: payload.appPaymentId,
    value: payload.amountCents,
    comment: payload.productName,
    expiresIn: 86400,
    customer: {
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      taxID: {
        taxID: customerDocument,
        type: customerDocument.length > 11 ? "BR:CNPJ" : "BR:CPF",
      },
    },
    additionalInfo: [
      { key: "appPaymentId", value: payload.appPaymentId },
      { key: "externalReference", value: externalRef },
      { key: "planId", value: payload.planId },
    ],
  };

  const response = await fetchWithTimeout(`${baseUrl}/charge`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: appId,
    },
    body: JSON.stringify(wooviPayload),
  }, 12_000);
  const text = await response.text();
  let data: any = {};
  try {
    data = text.trim() ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (!response.ok) {
    throw new Error(data?.error || data?.message || `Woovi HTTP ${response.status}`);
  }
  return { data, request: wooviPayload };
}

async function handleCreatePix(request: Request, env: Env) {
  if (!assertInternalAuth(request, env)) return json({ message: "Unauthorized" }, { status: 401 });
  const payload = (await request.json()) as CreatePixRequest;
  if (!payload.appPaymentId || !payload.amountCents || !payload.planId) {
    return json({ message: "Payload inválido" }, { status: 400 });
  }
  let route: GatewayRouteSelection;
  try {
    route = await resolveGatewayRoute(env, payload);
  } catch (error: any) {
    return json({
      success: false,
      retryable: true,
      message: error?.message || "Configuração de gateway indisponível",
    }, { status: 503 });
  }
  const { provider, routingAssignment } = route;

  const existing = await env.DB.prepare("select * from payments where app_payment_id = ?")
    .bind(payload.appPaymentId)
    .first<Record<string, any>>();
  if (existing?.provider_payment_id && existing.response_json) {
    return json(buildCreatePixResponseFromPayment(existing));
  }
  if (existing?.provider_payment_id) {
    return json({
      success: false,
      status: String(existing.status || "").toLowerCase() === "failed" ? "failed" : "creating",
      retryable: String(existing.status || "").toLowerCase() !== "failed",
      message: String(existing.status || "").toLowerCase() === "failed"
        ? "Falha ao criar cobrança PIX"
        : "Cobrança PIX aguardando sincronização",
    }, { status: String(existing.status || "").toLowerCase() === "failed" ? 200 : 202 });
  }
  if (existing && String(existing.status || "").toLowerCase() !== "failed" && !isCreateInProgressStale(existing)) {
    return json({
      success: false,
      status: "creating",
      retryable: true,
      message: "Cobrança PIX já está em criação para este pagamento",
    }, { status: 202 });
  }

  const createdAt = nowIso();
  const storageExternalRef = `dai_${payload.appPaymentId}`;
  const providerExternalRef = payload.externalReference || storageExternalRef;
  if (existing) {
    await env.DB.prepare(
      `update payments
       set provider = ?, status = 'pending', amount_cents = ?, currency = ?, plan_id = ?, product_name = ?,
           credit_amount = ?, customer_json = ?, tracking_json = ?, request_json = ?, routing_json = ?, updated_at = ?
       where app_payment_id = ? and provider_payment_id is null`,
    )
      .bind(
        provider,
        payload.amountCents,
        payload.currency || "BRL",
        payload.planId,
        payload.productName,
        payload.creditAmount || 0,
        JSON.stringify(payload.customer || {}),
        JSON.stringify(payload.tracking || {}),
        JSON.stringify({ ...payload, routingAssignment }),
        JSON.stringify(routingAssignment),
        createdAt,
        payload.appPaymentId,
      )
      .run();
  } else {
    const paymentRowId = uuid();
    await env.DB.prepare(
      `insert or ignore into payments (
        id, app_payment_id, external_ref, provider, status, amount_cents, currency, plan_id, product_name,
        credit_amount, customer_json, tracking_json, request_json, routing_json, created_at, updated_at
      ) values (?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
      .bind(
        paymentRowId,
        payload.appPaymentId,
        storageExternalRef,
        provider,
        payload.amountCents,
        payload.currency || "BRL",
        payload.planId,
        payload.productName,
        payload.creditAmount || 0,
        JSON.stringify(payload.customer || {}),
        JSON.stringify(payload.tracking || {}),
        JSON.stringify({ ...payload, routingAssignment }),
        JSON.stringify(routingAssignment),
        createdAt,
        createdAt,
      )
      .run();

    const insertedPayment = await env.DB.prepare("select id from payments where app_payment_id = ?")
      .bind(payload.appPaymentId)
      .first<{ id: string }>();
    if (insertedPayment?.id !== paymentRowId) {
      return json({
        success: false,
        status: "creating",
        retryable: true,
        message: "Cobrança PIX já está em criação para este pagamento",
      }, { status: 202 });
    }
  }

  let data: unknown;
  let providerRequest: unknown;
  let providerPaymentId = "";
  let qrcode = "";
  let expiresAt: string | null = null;
  try {
    const created = provider === "woovi"
      ? await createWooviPix(env, payload, providerExternalRef)
      : await createBlackcatPix(env, payload, providerExternalRef);
    data = created.data;
    providerRequest = created.request;
    const pixResult = provider === "woovi"
      ? extractWooviPixResult(data)
      : extractBlackcatPixResult(data);
    providerPaymentId = pixResult.gatewayPaymentId;
    qrcode = pixResult.qrcode;
    expiresAt = pixResult.expiresAt;
    if (!providerPaymentId || !qrcode) {
      const shape = provider === "woovi" ? getWooviResponseShape(data) : getBlackcatResponseShape(data);
      throw new Error(`Resposta ${provider} sem transactionId ou QR Code (${JSON.stringify(shape)})`);
    }
  } catch (error: any) {
    await env.DB.prepare(
      `update payments
       set status = 'failed', response_json = ?, updated_at = ?
       where app_payment_id = ? and provider_payment_id is null`,
    )
      .bind(JSON.stringify({ error: error?.message || "Erro ao criar PIX" }), nowIso(), payload.appPaymentId)
      .run();
    throw error;
  }

  await env.DB.prepare(
    `update payments
     set provider_payment_id = ?, response_json = ?, request_json = ?, updated_at = ?
     where app_payment_id = ?`,
  )
    .bind(
      providerPaymentId,
      JSON.stringify(data),
      JSON.stringify({ app: { ...payload, routingAssignment }, provider: providerRequest, routingAssignment }),
      nowIso(),
      payload.appPaymentId,
    )
    .run();

  await reconcileUnmatchedGatewayEvents(env, provider, providerPaymentId, payload.appPaymentId);

  const payment = await env.DB.prepare("select * from payments where app_payment_id = ?")
    .bind(payload.appPaymentId)
    .first<Record<string, any>>();
  if (payment) {
    await enqueueOutbox(env, "desireai", payload.appPaymentId, "created", {
      appPaymentId: payload.appPaymentId,
      provider,
      gatewayProvider: provider,
      routingAssignment,
      event: "transaction.created",
      status: "PENDING",
      transactionId: providerPaymentId,
      externalReference: providerExternalRef,
      amountCents: payload.amountCents,
      pix: {
        qrcode,
        copyPaste: qrcode,
        brCode: qrcode,
        expiresAt,
      },
      qrcode,
      copyPaste: qrcode,
      brCode: qrcode,
    });
    await enqueueOutbox(env, "utmify", payload.appPaymentId, "waiting_payment", buildUtmifyPayload(payment, "pending"));
  }

  return json({
    success: true,
    gatewayPaymentId: providerPaymentId,
    provider,
    status: "pending",
    pix: {
      qrcode,
      copyPaste: qrcode,
      brCode: qrcode,
      expiresAt,
    },
    qrcode,
    copyPaste: qrcode,
    brCode: qrcode,
    routingAssignment,
  });
}

async function handleGetPix(appPaymentId: string, request: Request, env: Env) {
  if (!assertInternalAuth(request, env)) return json({ message: "Unauthorized" }, { status: 401 });
  const cleanAppPaymentId = normalizeString(appPaymentId);
  if (!cleanAppPaymentId) return json({ message: "appPaymentId obrigatório" }, { status: 400 });

  const payment = await env.DB.prepare("select * from payments where app_payment_id = ?")
    .bind(cleanAppPaymentId)
    .first<Record<string, any>>();
  if (!payment) return json({ message: "Pagamento não encontrado" }, { status: 404 });

  if (payment.provider_payment_id && payment.response_json) {
    return json(buildCreatePixResponseFromPayment(payment));
  }

  return json({
    success: false,
    status: String(payment.status || "creating") === "failed" ? "failed" : "creating",
    retryable: String(payment.status || "") !== "failed",
    message: String(payment.status || "") === "failed"
      ? "Falha ao criar cobrança PIX"
      : "Cobrança PIX em criação",
  }, { status: String(payment.status || "") === "failed" ? 200 : 202 });
}

async function handleBlackcatWebhook(request: Request, env: Env) {
  const url = new URL(request.url);
  const webhookUrlToken = normalizeString(env.WEBHOOK_URL_TOKEN);
  if (!webhookUrlToken) {
    return json({ message: "WEBHOOK_URL_TOKEN não configurado" }, { status: 503 });
  }
  if (url.searchParams.get("token") !== webhookUrlToken) {
    return json({ message: "Unauthorized" }, { status: 401 });
  }

  const rawBody = await request.text();
  const blackcatWebhookSecret = normalizeString(env.BLACKCAT_WEBHOOK_SECRET);
  if (!blackcatWebhookSecret) {
    return json({ message: "BLACKCAT_WEBHOOK_SECRET não configurado" }, { status: 503 });
  }
  const valid = await verifyHmacSha256Signature(rawBody, getWebhookSignatureHeader(request), blackcatWebhookSecret)
    .catch(() => false);
  if (!valid) return json({ message: "Invalid signature" }, { status: 401 });

  let body: Record<string, any> = {};
  try {
    body = rawBody.trim() ? JSON.parse(rawBody) : {};
  } catch {
    return json({ message: "Invalid JSON" }, { status: 400 });
  }
  const normalized = normalizeBlackcatEvent(body, request.headers.get("x-webhook-event"));
  const headers: Record<string, string> = {};
  request.headers.forEach((value, key) => { headers[key] = value; });

  const payment = await findPaymentForProviderEvent(env, "blackcat", normalized.providerPaymentId, normalized.externalRef);

  const eventRowId = uuid();
  await env.DB.prepare(
    `insert or ignore into payment_events
      (id, idempotency_key, app_payment_id, provider, provider_payment_id, event, status, external_ref, payload_json, headers_json, received_at)
     values (?, ?, ?, 'blackcat', ?, ?, ?, ?, ?, ?, ?)`,
  )
    .bind(
      eventRowId,
      normalized.idempotencyKey,
      payment?.app_payment_id ?? null,
      normalized.providerPaymentId,
      normalized.event,
      normalized.status,
      normalized.externalRef,
      JSON.stringify(body),
      JSON.stringify(headers),
      nowIso(),
    )
    .run();

  const storedEvent = await env.DB.prepare("select id from payment_events where idempotency_key = ?")
    .bind(normalized.idempotencyKey)
    .first<{ id: string }>();
  if (storedEvent?.id !== eventRowId) {
    return json({ success: true, duplicate: true });
  }
  if (!payment) return json({ success: true, unmatched: true });

  const terminalAmountError = getTerminalGatewayEventAmountError(payment, normalized);
  if (terminalAmountError) {
    await markPaymentEventRejected(env, eventRowId, terminalAmountError);
    return json({ success: false, rejected: true, message: terminalAmountError }, { status: 422 });
  }

  await applyGatewayEventToPayment(env, "blackcat", payment, normalized, body);

  return json({ success: true });
}

async function handleWooviWebhook(request: Request, env: Env) {
  const url = new URL(request.url);
  const webhookUrlToken = normalizeString(env.WEBHOOK_URL_TOKEN);
  if (!webhookUrlToken) {
    return json({ message: "WEBHOOK_URL_TOKEN não configurado" }, { status: 503 });
  }
  if (url.searchParams.get("token") !== webhookUrlToken) {
    return json({ message: "Unauthorized" }, { status: 401 });
  }

  const rawBody = await request.text();
  const signature = request.headers.get("x-webhook-signature") || "";
  const publicKeyBase64 = normalizeString(env.WOOVI_WEBHOOK_PUBLIC_KEY_BASE64);
  if (!publicKeyBase64) {
    return json({ message: "WOOVI_WEBHOOK_PUBLIC_KEY_BASE64 não configurado" }, { status: 503 });
  }
  const valid = signature
    ? await verifyWooviWebhookSignature(rawBody, signature, publicKeyBase64).catch(() => false)
    : false;
  if (!valid) return json({ message: "Invalid signature" }, { status: 401 });

  let body: Record<string, any> = {};
  try {
    body = rawBody.trim() ? JSON.parse(rawBody) : {};
  } catch {
    return json({ message: "Invalid JSON" }, { status: 400 });
  }

  const normalized = normalizeWooviEvent(body, request.headers.get("x-webhook-event"));
  const headers: Record<string, string> = {};
  request.headers.forEach((value, key) => { headers[key] = value; });

  const payment = await findPaymentForProviderEvent(env, "woovi", normalized.providerPaymentId, normalized.externalRef);

  const eventRowId = uuid();
  await env.DB.prepare(
    `insert or ignore into payment_events
      (id, idempotency_key, app_payment_id, provider, provider_payment_id, event, status, external_ref, payload_json, headers_json, received_at)
     values (?, ?, ?, 'woovi', ?, ?, ?, ?, ?, ?, ?)`,
  )
    .bind(
      eventRowId,
      normalized.idempotencyKey,
      payment?.app_payment_id ?? null,
      normalized.providerPaymentId,
      normalized.event,
      normalized.status,
      normalized.externalRef,
      rawBody,
      JSON.stringify(headers),
      nowIso(),
    )
    .run();

  const storedEvent = await env.DB.prepare("select id from payment_events where idempotency_key = ?")
    .bind(normalized.idempotencyKey)
    .first<{ id: string }>();
  if (storedEvent?.id !== eventRowId) {
    return json({ success: true, duplicate: true });
  }
  if (!payment) return json({ success: true, unmatched: true });

  const terminalAmountError = getTerminalGatewayEventAmountError(payment, normalized);
  if (terminalAmountError) {
    await markPaymentEventRejected(env, eventRowId, terminalAmountError);
    return json({ success: false, rejected: true, message: terminalAmountError }, { status: 422 });
  }

  await applyGatewayEventToPayment(env, "woovi", payment, normalized, body);

  return json({ success: true });
}

async function deliverOutbox(row: Record<string, any>, env: Env) {
  const payload = String(row.payload_json);
  if (row.target === "desireai") {
    const { timestamp, signature } = await signInternalPayload(payload, env);
    const response = await fetchWithTimeout(`${env.DESIREAI_INTERNAL_URL.replace(/\/+$/, "")}/api/internal/payment-events/gateway`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Internal-Timestamp": timestamp,
        "X-Internal-Signature": `sha256=${signature}`,
      },
      body: payload,
    }, 10_000);
    if (!response.ok) throw new Error(`DesireAI HTTP ${response.status}: ${await response.text()}`);
    return;
  }

  if (row.target === "utmify") {
    const response = await fetchWithTimeout(env.UTMIFY_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-token": env.UTMIFY_API_TOKEN,
      },
      body: payload,
    }, 10_000);
    if (!response.ok) throw new Error(`UTMify HTTP ${response.status}: ${await response.text()}`);
    return;
  }
}

async function processOutbox(outboxId: string, env: Env) {
  const now = nowIso();
  const leaseUntil = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const claim = await env.DB.prepare(
    `update outbox
     set status = 'processing', attempts = attempts + 1, next_attempt_at = ?
     where id = ?
       and (
         status = 'pending'
         or (status = 'processing' and next_attempt_at <= ?)
       )`,
  )
    .bind(leaseUntil, outboxId, now)
    .run();
  if (getD1Changes(claim) === 0) return;

  const row = await env.DB.prepare("select * from outbox where id = ?").bind(outboxId).first<Record<string, any>>();
  if (!row) return;
  try {
    await deliverOutbox(row, env);
    await env.DB.prepare("update outbox set status = 'delivered', delivered_at = ?, last_error = null where id = ?")
      .bind(nowIso(), outboxId)
      .run();
  } catch (error: any) {
    const attempts = Number(row.attempts || 1);
    const delaySeconds = Math.min(900, 2 ** attempts * 30);
    const nextAttemptAt = new Date(Date.now() + delaySeconds * 1000).toISOString();
    await env.DB.prepare("update outbox set status = 'pending', next_attempt_at = ?, last_error = ? where id = ?")
      .bind(nextAttemptAt, error?.message || "Erro desconhecido", outboxId)
      .run();
    throw error;
  }
}

async function retryDueOutbox(env: Env) {
  const rows = await env.DB.prepare(
    "select id from outbox where status in ('pending', 'processing') and next_attempt_at <= ? order by created_at limit 50",
  ).bind(nowIso()).all<{ id: string }>();
  for (const row of rows.results || []) {
    await env.OUTBOX_QUEUE.send({ outboxId: row.id });
  }
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    try {
      if (request.method === "POST" && url.pathname === "/v1/internal/payments/pix") {
        return await handleCreatePix(request, env);
      }
      const pixStatusMatch = url.pathname.match(/^\/v1\/internal\/payments\/pix\/([^/]+)$/);
      if (request.method === "GET" && pixStatusMatch) {
        return await handleGetPix(decodeURIComponent(pixStatusMatch[1] || ""), request, env);
      }
      if (request.method === "POST" && url.pathname === "/v1/webhooks/blackcat") {
        return await handleBlackcatWebhook(request, env);
      }
      if (request.method === "POST" && url.pathname === "/v1/webhooks/woovi") {
        return await handleWooviWebhook(request, env);
      }
      if (request.method === "GET" && url.pathname === "/health") {
        return json({ ok: true });
      }
      return json({ message: "Not found" }, { status: 404 });
    } catch (error: any) {
      return json({ message: error?.message || "Erro interno" }, { status: 500 });
    }
  },

  async queue(batch: MessageBatch<OutboxMessage>, env: Env): Promise<void> {
    for (const message of batch.messages) {
      await processOutbox(message.body.outboxId, env);
      message.ack();
    }
  },

  async scheduled(_event: ScheduledEvent, env: Env): Promise<void> {
    await retryDueOutbox(env);
  },
};
