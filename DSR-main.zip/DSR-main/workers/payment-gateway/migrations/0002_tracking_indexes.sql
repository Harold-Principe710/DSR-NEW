create unique index if not exists idx_payments_provider_provider_payment_id_unique
  on payments(provider, provider_payment_id)
  where provider_payment_id is not null
    and provider_payment_id <> 'unknown'
    and provider_payment_id not like 'pending:%';
create index if not exists idx_payment_events_provider_provider_payment_id on payment_events(provider, provider_payment_id);
