create table if not exists payments (
  id text primary key,
  app_payment_id text not null unique,
  external_ref text not null unique,
  provider text not null,
  provider_payment_id text,
  status text not null default 'pending',
  amount_cents integer not null,
  currency text not null default 'BRL',
  plan_id text,
  product_name text,
  credit_amount integer not null default 0,
  customer_json text not null,
  tracking_json text not null,
  request_json text not null,
  response_json text,
  routing_json text,
  created_at text not null,
  updated_at text not null,
  paid_at text
);

create index if not exists idx_payments_provider_payment_id on payments(provider_payment_id);
create index if not exists idx_payments_status_created_at on payments(status, created_at);

create table if not exists payment_events (
  id text primary key,
  idempotency_key text not null unique,
  app_payment_id text,
  provider text not null,
  provider_payment_id text,
  event text not null,
  status text not null,
  external_ref text,
  payload_json text not null,
  headers_json text not null,
  received_at text not null,
  processed_at text,
  error_message text
);

create index if not exists idx_payment_events_app_payment_id on payment_events(app_payment_id);
create index if not exists idx_payment_events_provider_payment_id on payment_events(provider_payment_id);

create table if not exists outbox (
  id text primary key,
  target text not null,
  idempotency_key text not null unique,
  app_payment_id text not null,
  status text not null default 'pending',
  payload_json text not null,
  attempts integer not null default 0,
  next_attempt_at text not null,
  last_error text,
  created_at text not null,
  delivered_at text
);

create index if not exists idx_outbox_status_next_attempt on outbox(status, next_attempt_at);
