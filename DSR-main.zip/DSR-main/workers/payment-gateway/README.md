# DesireAI Payment Gateway Worker

Worker neutro para intermediar PIX entre o backend DesireAI, provedores como BlackCat/Woovi e UTMify.

## Fluxo

1. DesireAI chama `POST /v1/internal/payments/pix` com `Authorization: Bearer GATEWAY_INTERNAL_SECRET`.
2. Worker cria a venda no gateway configurado e o provedor envia webhooks para o domínio neutro:
   - BlackCat: `GATEWAY_PUBLIC_URL/v1/webhooks/blackcat?token=WEBHOOK_URL_TOKEN`
   - Woovi/OpenPix: `GATEWAY_PUBLIC_URL/v1/webhooks/woovi?token=WEBHOOK_URL_TOKEN`
3. Ao receber webhook do gateway, o Worker grava evento no D1 e envia dois outboxes:
   - DesireAI: `POST /api/internal/payment-events/gateway` assinado com HMAC.
   - UTMify: `POST UTMIFY_ENDPOINT` com `x-api-token`.
4. Cloudflare Queue + Cron retentam entregas pendentes.

Eventos de criação, alteração de status, pagamento, falha, expiração, cancelamento, estorno e chargeback são normalizados para um único pedido na UTMify pelo `appPaymentId`.

## Setup

```bash
cd workers/payment-gateway
npm install
wrangler d1 create desireai-payment-gateway
```

Copie o `database_id` retornado para `wrangler.toml`, ajuste `GATEWAY_PUBLIC_URL` para o subdomínio neutro e rode:

```bash
npm run db:migrate
wrangler secret put BLACKCAT_API_KEY
wrangler secret put WOOVI_APP_ID
wrangler secret put WOOVI_WEBHOOK_PUBLIC_KEY_BASE64
wrangler secret put GATEWAY_INTERNAL_SECRET
wrangler secret put DESIREAI_INTERNAL_URL
wrangler secret put DESIREAI_INTERNAL_SECRET
wrangler secret put WEBHOOK_URL_TOKEN
wrangler secret put UTMIFY_API_TOKEN
npm run deploy
```

Se Woovi estiver ativo, `WOOVI_WEBHOOK_PUBLIC_KEY_BASE64` é obrigatório: sem essa chave o Worker
recusa webhooks Woovi. Para BlackCat, configure `BLACKCAT_WEBHOOK_SECRET` se o provedor estiver
assinando o postback com HMAC SHA-256; independentemente da assinatura, eventos terminais só mudam
status quando `providerPaymentId` e `amountCents` batem com a cobrança gravada no D1.

A seleção do provedor também acontece no Worker. A cada criação de PIX ele lê
`/api/internal/payment-gateway-config` na DesireAI usando `DESIREAI_INTERNAL_SECRET`, aplica o teste
ativo/pesos quando houver, ignora provedores sem secrets obrigatórios no Worker e grava a
`routingAssignment` no D1 e nos callbacks.

No backend DesireAI, configure somente o endpoint do Worker neutro e os
segredos internos correspondentes. Credenciais BlackCat/Woovi ficam apenas no
Worker.

```bash
PIX_WORKER_CREATE_URL=https://pagamentos.seu-dominio-neutro.com/v1/internal/payments/pix
GATEWAY_INTERNAL_SECRET=mesmo_valor_do_worker_GATEWAY_INTERNAL_SECRET
DESIREAI_INTERNAL_SECRET=mesmo_valor_do_worker_DESIREAI_INTERNAL_SECRET
```
