# Gateway PIX neutro

Arquitetura implementada:

```mermaid
flowchart LR
  A["DesireAI backend"] --> B["Cloudflare Worker neutro"]
  B --> C["BlackCat/Woovi"]
  C --> B
  B --> D["Cloudflare Queue + D1"]
  D --> E["UTMify"]
  D --> A
```

## O que configurar fora do código

1. No Cloudflare, crie ou aponte um subdomínio neutro para o Worker, por exemplo `pagamentos.seu-dominio-neutro.com`.
2. Em `workers/payment-gateway/wrangler.toml`, troque `GATEWAY_PUBLIC_URL` para esse domínio.
3. Rode:

```bash
cd workers/payment-gateway
npm install
wrangler d1 create desireai-payment-gateway
```

4. Copie o `database_id` para `wrangler.toml`.
5. Aplique a migration:

```bash
npm run db:migrate
```

6. Configure os secrets do Worker:

```bash
wrangler secret put BLACKCAT_API_KEY
wrangler secret put WOOVI_APP_ID
wrangler secret put WOOVI_WEBHOOK_PUBLIC_KEY_BASE64
wrangler secret put GATEWAY_INTERNAL_SECRET
wrangler secret put DESIREAI_INTERNAL_URL
wrangler secret put DESIREAI_INTERNAL_SECRET
wrangler secret put WEBHOOK_URL_TOKEN
wrangler secret put UTMIFY_API_TOKEN
```

7. Publique:

```bash
npm run deploy
```

8. No backend DesireAI, configure somente o Worker neutro:

```bash
PIX_WORKER_CREATE_URL=https://pagamentos.seu-dominio-neutro.com/v1/internal/payments/pix
GATEWAY_INTERNAL_SECRET=mesmo_valor_do_worker_GATEWAY_INTERNAL_SECRET
DESIREAI_INTERNAL_SECRET=mesmo_valor_do_worker_DESIREAI_INTERNAL_SECRET
```

`PAYMENT_GATEWAY_URL=https://pagamentos.seu-dominio-neutro.com` também é aceito
como fallback legado; nesse caso o backend monta `/v1/internal/payments/pix`.
Não configure credenciais BlackCat/Woovi no backend DesireAI.

Se Woovi estiver ativo, a chave pública `WOOVI_WEBHOOK_PUBLIC_KEY_BASE64` é
obrigatória. Para BlackCat, configure `BLACKCAT_WEBHOOK_SECRET` se o provedor
assinar o postback com HMAC SHA-256. Em todos os provedores, o Worker recusa
evento terminal sem `providerPaymentId` e `amountCents` compatíveis com a
cobrança armazenada no D1.

Para ligar fluxos legados antigos, use apenas durante rollback planejado:

```bash
PAYMENT_PROVIDER=gateway_with_legacy_fallback
```

## Operação

- Admin: `/admin/payment-gateways`.
- Cadastre gateways ativos.
- Crie um teste A/B de gateway com pesos somando 100%.
- Métricas por gateway e variante:
  - PIX gerados
  - PIX pagos
  - taxa de conversão
  - receita atribuída

## Garantias do fluxo

- BlackCat recebe somente o webhook do domínio neutro.
- A seleção do gateway/provedor é feita no Worker a partir de
  `/api/internal/payment-gateway-config`; a DesireAI não envia rota direta para
  BlackCat/Woovi. Provedores sem secrets obrigatórios no Worker são ignorados.
- DesireAI recebe eventos internos assinados com HMAC SHA-256.
- UTMify recebe evento pendente na criação do PIX e evento pago quando o webhook confirma pagamento.
- Entregas para UTMify e DesireAI passam por outbox em D1, Cloudflare Queue e retry por Cron.
- Eventos repetidos usam chave de idempotência por destino, pagamento e status.
