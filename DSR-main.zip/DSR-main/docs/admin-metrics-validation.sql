-- Validation checklist for admin A/B metrics consistency.
-- Replace :date_from and :date_to with your desired timestamp range.

-- 1) Key steps should carry normalized variant.
SELECT
  step,
  COUNT(*) AS total_events,
  COUNT(*) FILTER (
    WHERE upper(trim(metadata->>'abVariant')) IN ('A', 'B')
  ) AS events_with_valid_variant,
  ROUND(
    (
      COUNT(*) FILTER (WHERE upper(trim(metadata->>'abVariant')) IN ('A', 'B'))::numeric
      / NULLIF(COUNT(*), 0)
    ) * 100,
    2
  ) AS valid_variant_pct
FROM funnel_events
WHERE step IN ('visitor_entered', 'pix_generated', 'pix_paid')
  AND occurred_at >= :date_from
  AND occurred_at <= :date_to
GROUP BY step
ORDER BY step;

-- 2) Sessions with pix_paid in range but missing visitor_entered in range.
SELECT COUNT(DISTINCT paid.session_id) AS paid_without_visit_same_window
FROM funnel_events paid
WHERE paid.step = 'pix_paid'
  AND paid.occurred_at >= :date_from
  AND paid.occurred_at <= :date_to
  AND NOT EXISTS (
    SELECT 1
    FROM funnel_events visit
    WHERE visit.session_id = paid.session_id
      AND visit.step = 'visitor_entered'
      AND visit.occurred_at >= :date_from
      AND visit.occurred_at <= :date_to
  );

-- 3) Variant distribution by step to detect A/B collapse.
SELECT
  step,
  COALESCE(NULLIF(upper(trim(metadata->>'abVariant')), ''), 'UNKNOWN') AS variant,
  COUNT(DISTINCT session_id) AS sessions
FROM funnel_events
WHERE step IN ('visitor_entered', 'pix_generated', 'pix_paid')
  AND occurred_at >= :date_from
  AND occurred_at <= :date_to
GROUP BY step, variant
ORDER BY step, variant;
